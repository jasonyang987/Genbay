//
//  EventTVC.swift
//  Genbay
//
//  Created by Nap Works on 30/03/23.
//

import UIKit

class EventTVC: UITableViewCell {
    let TAG = String(describing: EventTVC.self)
    @IBOutlet weak var eventView: UIView!
    @IBOutlet weak var addressView: UIView!
    @IBOutlet weak var eventTitlelabel: UILabel!
    @IBOutlet weak var hostNamelabel: UILabel!
    @IBOutlet weak var addresslabel: UILabel!
    
    @IBOutlet weak var addressStackView: UIStackView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func configure(data:EventModel){
        CommonMethods.roundCornerFilled(uiView: eventView, borderColor: .white, backgroundColor: .white, cornerRadius: 30.0, borderWidth: 0.0)
        let location = data.location
        let date = Date(timeIntervalSince1970: data.dateTimestamp ?? 0.0)
        //        let date = Date(timeIntervalSince1970: TimeInterval(date) ?? TimeInterval())
        let dateString = date.formattedDateString
        //        eventTitlelabel.text = "\(data.name ?? "") | \(data.startTime ?? "") \(dateString)"
        
        hostNamelabel.text = "Host: \(data.hostName ?? "")"
        CommonMethods.showLog(TAG, "Address : \(location)")
        
        
        if data.isDateConfirmed ?? false{
            eventTitlelabel.text = "\(data.name ?? "") | \(data.startTime ?? "") \(dateString)"
        }
        else{
            eventTitlelabel.text = "\(data.name ?? "") | \(data.startTime ?? "") Date TBD"
        }
        
        if location != nil && location != "" {
            addressView.alpha = 1
            if data.isLocationConfirmed ?? false{
                addresslabel.text = location
            }
            else{
                addresslabel.text = "TBD"
            }
        }else {
            addressView.alpha = 0
        }
        
        
    }
    
    func configure(name: String, date: String, hostName: String, location: String?){
        CommonMethods.roundCornerFilled(uiView: eventView, borderColor: .white, backgroundColor: .white, cornerRadius: 30.0, borderWidth: 0.0)
        let date = Date(timeIntervalSince1970: TimeInterval(date) ?? TimeInterval())
        let dateString = date.formattedString
        eventTitlelabel.text = "\(name) | \(dateString)"
        addresslabel.text = location
        hostNamelabel.text = "Host: \(hostName)"
        if location == nil {
            addressStackView.alpha = 0
        }else {
            addressStackView.alpha = 1
        }
    }
    
}

