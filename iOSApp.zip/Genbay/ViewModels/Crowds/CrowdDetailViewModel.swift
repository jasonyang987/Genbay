//
//  CrowdDetailViewModel.swift
//  Genbay
//
//  Created by Nap Works on 07/04/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class CrowdDetailViewModel{
    let TAG = String(describing: CrowdDetailViewModel.self)
    var vc : CrowdDetailVC
    
    
    
    init(vc: CrowdDetailVC) {
        self.vc = vc
    }
    
    
    func getMembersList(_ isShowLoading:Bool){
        if isShowLoading{
            self.vc.showProgressHUD()
        }
        FirebaseAPI.default.getMembersList(crowdId: self.vc.crowdId , userId: self.vc.userData?.id ?? ""){ crowdModel, usersList in
            self.vc.hideProgressHUD()
            self.vc.crowdModel = crowdModel
            self.vc.usersList = usersList?.filter { $0.id != nil} ?? []
            self.vc.setData()
            self.checkAndShowMessage()
            CommonMethods.showLog(self.TAG, "usersList count : \(self.vc.usersList.count)")
            self.vc.tableView.reloadData()
        }
    }
    
    func checkAndShowMessage(){
        if self.vc.usersList.count == 0 {
            self.vc.noDataText.isHidden = false
        }
        else{
            self.vc.noDataText.isHidden = true
        }
    }
}
