//
//  HomePVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit


class HomePVC: UIPageViewController {

    let TAG = String(describing: HomePVC.self)

//    var viewPagerList : [ProductsPagerModel] = []
    var pageControl : UIPageControl?
    var viewController : UIViewController?

    var customDelegate : ViewPagerDelegate?
    
    var identifiers: [String] = ["HomeTabVC", "NotificationTabVC", "CreateEventTabVC", "FriendsTabVC", "ProfileTabVC"]
    var currentPageIndex = 0
    var pages: [UIViewController] = [UIViewController]()
    
    
    override init(transitionStyle style: UIPageViewController.TransitionStyle, navigationOrientation: UIPageViewController.NavigationOrientation, options: [UIPageViewController.OptionsKey : Any]? = nil) {
        super.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        self.delegate = self
        for i in 0..<identifiers.count {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: identifiers[i]) as UIViewController
            let navController = UINavigationController(rootViewController: vc)
            navController.isNavigationBarHidden = true
            pages.append(navController)
        }
        setViewControllers([pages[0]], direction: .forward, animated: false, completion: nil)
        self.isPagingEnabled = false
      
    }

    func changePage(direction: UIPageViewController.NavigationDirection, posiiton: Int) {
        CommonMethods.showLog(TAG, "changePage")
        setViewControllers([pages[posiiton]], direction: direction, animated: true, completion: nil)
    }
}

extension HomePVC: UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    
    func pageViewController(_: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        CommonMethods.showLog(TAG, "viewControllerBefore")
        if pages.count > 1{
            guard let viewControllerIndex = pages.firstIndex(of: viewController) else {
                return nil
            }
            
            let previousIndex = viewControllerIndex - 1
            
            guard previousIndex >= 0 else {
                return pages.last
            }
            
            guard pages.count > previousIndex else {
                return nil
            }
            
            return pages[previousIndex]
        }else{
            return nil
        }
    }
    
    func pageViewController(_: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        CommonMethods.showLog(TAG, "viewControllerAfter")
        if pages.count > 1{
            guard let viewControllerIndex = pages.firstIndex(of: viewController) else {
                return nil
            }
            
            let nextIndex = viewControllerIndex + 1
            guard pages.count != nextIndex else {
                return pages.first
            }
            
            guard pages.count > nextIndex else {
                return nil
            }
            
            return pages[nextIndex]
        }else{
            return nil
        }
    }
    
    func presentationIndex(for _: UIPageViewController) -> Int {
        CommonMethods.showLog(TAG, "presentationIndex")
        guard let firstViewController = viewControllers?.first,
            let firstViewControllerIndex = pages.firstIndex(of: firstViewController)
        else {
            CommonMethods.showLog(TAG, "Else Case")
                return 0
        }
        CommonMethods.showLog(TAG, "presentationIndex firstViewControllerIndex : \(firstViewControllerIndex)")
        return firstViewControllerIndex
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        CommonMethods.showLog(TAG, "didFinishAnimating finished : \(finished)")
        CommonMethods.showLog(TAG, "didFinishAnimating completed : \(completed)")
        if (!completed)
        {
            return
        }
        let index = pageViewController.viewControllers!.first!.view.tag
//        customDelegate?.onPageChanged(type: viewPagerList[index].type ?? "")
//        CommonMethods.showLog(TAG, "didFinishAnimating TYPE : \(viewPagerList[index].type)")
        CommonMethods.showLog(TAG, "didFinishAnimating index : \(index)")
    }
}
