//
//  AddMembersVC.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import UIKit

class CrowdDetailVC: BaseViewController {
    let TAG = String(describing: CrowdDetailVC.self)
    
    
    
    @IBOutlet weak var noDataText: UILabel!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var pageTitle: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var removeMemberView: UIView!
    @IBOutlet weak var addMemberView: UIView!
    @IBOutlet weak var crowdImage: UIImageView!
    @IBOutlet weak var cameraView: UIView!
    
    var crowdModel:CrowdModel?
    var crowdId:String = ""
    var userData:UserModel?
    var viewModel:CrowdDetailViewModel?
    
    var usersList : [UserModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        noDataText.isHidden = true
        userData = UserDefaultsMapper.getUser()
        viewModel = CrowdDetailViewModel(vc: self)
        
        pageTitle.isHidden = true
        mainView.isHidden = true
        
        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(handleNotification(notification:)), name: .crowdDetailVC, object: nil)
        
        setUI()
        
        viewModel?.getMembersList(true)
        
    }
    
    func setData(){
        pageTitle.isHidden = false
        mainView.isHidden = false
        pageTitle.text = crowdModel?.name ?? ""
        desc.text = crowdModel?.description ?? ""
        
        let image = crowdModel?.imageUrl ?? ""
        if image != ""{
            crowdImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
        
//        if crowdModel?.membersList?.count ?? 0 > 0{
//            removeMemberView.isHidden = false
//        }
//        else{
//            removeMemberView.isHidden = true
//        }
    }
    
    func setUI(){
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .transparent
        tableView.register(UINib(nibName: "AddMembersTVC", bundle: nil), forCellReuseIdentifier: "AddMembersTVC")
        
        cameraView.layer.cornerRadius = cameraView.frame.width / 2
        crowdImage.layer.cornerRadius = crowdImage.frame.width / 2
        CommonMethods.roundCornerFilled(uiView: addMemberView, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 20.0, borderWidth: 0.0)
        
        CommonMethods.roundCornerFilled(uiView: removeMemberView, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 20.0, borderWidth: 0.0)
    }
    
    
    @IBAction func backPressed(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func addMembersPressed(_ sender: Any) {
        Navigations.goToAddMembers(calledFrom: Constants.ADD_MEMBERS, navigationController: navigationController,crowdModel: crowdModel)
    }
    
    
    @IBAction func removeMembersPressed(_ sender: Any) {
        Navigations.goToAddMembers(calledFrom: Constants.REMOVE_MEMBERS, navigationController: navigationController,crowdModel: crowdModel)
    }
    
    
    func handleNotificationData(_ actionType:String,_ selectedUsersList:[UserModel]){
        CommonMethods.showLog(TAG, "handleNotificationData")
        if actionType == Constants.REMOVE_MEMBERS{
            var finalList : [UserModel] = []
            usersList.forEach{ data in
                var isExist = false
                selectedUsersList.forEach{ innerData in
                    if data.id == innerData.id{
                        isExist = true
                    }
                }
                
                if !isExist{
                    finalList.append(data)
                }
            }
            self.usersList = finalList
            self.viewModel?.checkAndShowMessage()
            self.tableView.reloadData()
            
        }
        else{
            selectedUsersList.forEach{ data in
                usersList.append(data)
            }
            self.viewModel?.checkAndShowMessage()
            self.tableView.reloadData()
        }
    }
    
    
}

extension CrowdDetailVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddMembersTVC", for: indexPath) as! AddMembersTVC
        cell.selectionStyle = .none
        cell.configure(calledFrom:Constants.CROWD_DETAIL,data:usersList[indexPath.row],position: indexPath.row)
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
}

extension CrowdDetailVC{
    
    @objc func handleNotification(notification: NSNotification) {
        if let value = notification.userInfo as? [String : Any]{
            CommonMethods.showLog(TAG, "handleNotification value : \(value)")
            if let type = value["type"] as? String{
                if type == Constants.UPDATE_CROWD_MEMBERS{
                    if let actionType = value["actionType"] as? String,
                       let selectedUsersList = value["selectedUsersList"] as? [UserModel]{
                        handleNotificationData(actionType,selectedUsersList)
                    }
                    
                }
            }
        }
    }
    
}
