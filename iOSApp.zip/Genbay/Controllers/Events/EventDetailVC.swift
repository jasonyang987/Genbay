//
//  EventDetailVC.swift
//  Genbay
//
//  Created by Nap Works on 03/04/23.
//

import UIKit

protocol EventDetailVCDelegate: AnyObject {
    func pushToGuestListVC(vc: UIViewController, eventTitle: String, eventDate: String)
    func pushToCommentsVC(vc: UIViewController, eventTitle: String, eventDate: String)
    func pushToMemoriesVC(vc: UIViewController, eventTitle: String, eventDate: String)
}

class EventDetailVC: BaseViewController {
    let TAG = String(describing: EventDetailVC.self)
    weak var delegate: EventDetailVCDelegate?
    @IBOutlet weak var eventView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var hostNameLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UITextView!
    @IBOutlet weak var rsvpBtnView: UIView!
    @IBOutlet weak var guestListBtn: UIButton!
    @IBOutlet weak var commentsBtn: UIButton!
    @IBOutlet weak var eventMemoriesBtn: UIButton!
    @IBOutlet weak var addressView: UIView!
    
    var eventModel : EventModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    func setUI(){
        CommonMethods.roundCornerFilled(uiView: eventView,
                                        borderColor: .white,
                                        backgroundColor: .white,
                                        cornerRadius: 20,
                                        borderWidth: 0.0)
        CommonMethods.roundCornerFilled(uiView: rsvpBtnView,
                                        borderColor: .black,
                                        backgroundColor: .secondaryMainColor,
                                        cornerRadius: 20,
                                        borderWidth: 1)
        guestListBtn.underlineButton(text: "View Guest List", color: UIColor.black)
        commentsBtn.underlineButton(text: "View Comments", color: UIColor.black)
        eventMemoriesBtn.underlineButton(text: "See Event Memories!", color: UIColor.black)
        
        let location = eventModel?.location
        var dateString = ""
        if eventModel?.isDateConfirmed ?? false{
            let date = Date(timeIntervalSince1970: eventModel?.dateTimestamp ?? 0.0)
    //        let date = Date(timeIntervalSince1970: TimeInterval(date) ?? TimeInterval())
             dateString = date.formattedDateString
        }
        else{
            dateString = "DATE TBD"
        }
        
        titleLabel.text = "\(eventModel?.name ?? "") | \(eventModel?.startTime ?? "") \(dateString)"
        
        hostNameLabel.text = "Host: \(eventModel?.hostName ?? "")"
        if location == "" {
            addressView.isHidden = true
        }else {
            addressView.isHidden = false
            CommonMethods.showLog(TAG, "eventisfalse : \(eventModel?.isLocationConfirmed)")
            if eventModel?.isLocationConfirmed ?? false{
                addressLabel.text = location
            }
            else{
                addressLabel.text = "TBD"
            }
        }
        descriptionLabel.text = eventModel?.description ?? ""
        
//        if descriptionLabel.text.count >= 400 {
//            descriptionLabel.isScrollEnabled = true
//        }else {
//            descriptionLabel.isScrollEnabled = false
//        }
        view.backgroundColor = .black.withAlphaComponent(0.3)
    }
    
    @IBAction func crossBtnPressed(_ sender: UIButton){
        self.dismiss(animated: true)
    }
    
    @IBAction func seeGuestListBtnPressed(_ sender: UIButton){
//        delegate?.pushToGuestListVC(vc: self, eventTitle: self.name, eventDate: self.date)
    }
    
    @IBAction func seeCommentsBtnPressed(_ sender: UIButton){
//        delegate?.pushToCommentsVC(vc: self, eventTitle: self.name, eventDate: self.date)
    }
    
    @IBAction func seeMemoriesBtnPressed(_ sender: UIButton){
//        delegate?.pushToMemoriesVC(vc: self, eventTitle: self.name, eventDate: self.date)
    }
    
    @IBAction func closeBtnPressed(_ sender: UIButton){
        self.dismiss(animated: true)
    }
}
