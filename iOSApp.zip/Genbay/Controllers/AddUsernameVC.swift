//
//  AddUsernameVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit

class AddUsernameVC: BaseViewController,UITextFieldDelegate {
    
    let TAG = String(describing: AddUsernameVC.self)

    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var usernameText: UITextField!
    @IBOutlet weak var usernameView: UIView!
    
    var userModel:UserModel?
    var viewModel:AddUsernameViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        viewModel = AddUsernameViewModel(vc: self)

        setUI()
    }
    
    func setUI(){
        [usernameView].forEach{view in
            CommonMethods.roundCornerFilled(uiView: view, borderColor: .mainColor, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.7)}

        CommonMethods.setPlaceholderColor(textFields: [usernameText], color: .darkGray)


        CommonMethods.roundCornerFilled(uiView: nextBtn, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 25.0, borderWidth: 0.0)
        usernameText.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           textField.resignFirstResponder()
           return true
       }
    
    
    @IBAction func nextBtnPressed(_ sender: Any) {
        userModel?.username = usernameText.text
        do{
                try viewModel?.validate()
                viewModel?.updateData()
        }
        catch let error as AddUsernameViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }
}
