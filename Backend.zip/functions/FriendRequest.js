const functions = require("firebase-functions");
var admin = require("firebase-admin");

const { user } = require("firebase-functions/v1/auth");
const User = require("./User")
const Constants = require("./Constants");
const CommonMethods = require("./CommonMethods");
const notifications = admin.firestore().collection("notifications");

class FriendRequest {

    static checkAndSendFriendRequest(request, response, callback) {
        let userId = request.body.userId;
        let receiverId = request.body.receiverId
        console.log("Sender Id : " + userId);
        console.log("Receiver Id : " + receiverId);
        FriendRequest.checkAlreadyExistOrNot(Constants.ACCEPTED_LIST, userId, receiverId, function (isExistInAccepted) {
            if (isExistInAccepted) {
                console.log("Already Friend")
                callback(0, "Already added to friends.")
                //  response.send({ "status":0,message:"Already added to friends."});
            }
            else {
                console.log("Not Friend, Check In Pending")
                FriendRequest.checkAlreadyExistOrNot(Constants.PENDING_LIST, userId, receiverId, function (isExistInPending) {
                    if (isExistInPending) {
                        console.log("Already In Pending List")
                        callback(0, "You have already got request from this user.Check pending requests")
                        // response.send({ "status":0,message:"You have already got request from this user.Check pending requests"});
                    }
                    else {
                        console.log("Not Friend, Check In Sent")
                        FriendRequest.checkAlreadyExistOrNot(Constants.SENT_LIST, userId, receiverId, function (isExistInSent) {
                            if (isExistInSent) {
                                console.log("Already In Sent List")
                                callback(0, "You have already sent friend request to this user.")
                                // response.send({ "status":0,message:"You have already sent friend request to this user."});
                            }
                            else {
                                console.log("Add Data")
                                FriendRequest.addDataToPendingList(userId, receiverId, function (isAddedToDatabase) {
                                    if (isAddedToDatabase) {
                                        FriendRequest.addDataToSentList(userId, receiverId, function (isAddedToSentDatabase) {
                                            if (isAddedToSentDatabase) {
                                                User.getUserData('users', userId, function (userSuccess, userDetail) {
                                                    console.log("userSuccess  : ", userSuccess + " " + userDetail);
                                                    if (userSuccess) {
                                                        User.getUserData('users', receiverId, function (friendSuccess, friendData) {
                                                            console.log("friendSuccess  : ", friendSuccess + " " + friendData);
                                                            if (friendSuccess) {
                                                                // let body = `${userDetail.firstName} ${userDetail.lastName} sent you a friend request`
                                                                let body;
                                                                if (userDetail.lastName !== "") {
                                                                    body = `${userDetail.firstName} ${userDetail.lastName} sent you a friend request`
                                                                }
                                                                else {
                                                                    body = `${userDetail.firstName} sent you a friend request`
                                                                }
                                                                FriendRequest.sendFriendNotificationFromServer("Friend Request", body, friendData, userDetail, Constants.FRIEND_REQUEST_SENT)
                                                                callback(1, "Friend Request Sent successfully.")
                                                                // response.send({ "status":1,message:"Friend Request Sent successfully."  });
                                                            } else {
                                                                console.log("Error While Getting Friend Data");
                                                                callback(0, "Invalid Data.")
                                                                // response.send({ "status":0,message:"Invalid Data."});
                                                            }
                                                        });
                                                    } else {
                                                        console.log("Error While Getting User Data");
                                                        callback(0, "Invalid Data.")
                                                        // response.send({ "status":0,message:"Invalid Data."});
                                                    }
                                                });
                                            }
                                        })

                                    }
                                })
                            }
                        })

                    }
                })
            }
        })
    }

    static addDataToPendingList(userId, receiverId, callback) {
        admin.database().ref("friends" + '/' + receiverId + '/pendingList').once('value', (snapshot) => {
            var friendList = snapshot.val();
            var data = []
            if (friendList != null) {
                if (friendList.length > 0) {
                    data = friendList
                }

                data.push(userId)
                var finalData = {}
                finalData["id"] = receiverId
                finalData["pendingList"] = data
                admin.database().ref('friends/' + receiverId).update(finalData)
                callback(true);
            } else {
                console.log("Error While Getting Pending List");
                data.push(userId)
                var finalData = {}
                finalData["id"] = receiverId
                finalData["pendingList"] = data
                admin.database().ref('friends/' + receiverId).update(finalData)
                callback(true);
            }
        });
    }

    static addDataToSentList(userId, receiverId, callback) {
        admin.database().ref("friends" + '/' + userId + '/sentList').once('value', (snapshot) => {
            var sentList = snapshot.val();
            var data = []
            if (sentList != null) {
                if (sentList.length > 0) {
                    data = sentList
                }

                data.push(receiverId)
                var finalData = {}
                finalData["id"] = userId
                finalData["sentList"] = data
                admin.database().ref('friends/' + userId).update(finalData)
                callback(true);
            } else {
                console.log("Error While Getting Sent List");
                data.push(receiverId)
                var finalData = {}
                finalData["id"] = userId
                finalData["sentList"] = data
                admin.database().ref('friends/' + userId).update(finalData)
                callback(true);
            }
        });
    }

    static checkAlreadyExistOrNot(type, userId, receiverId, callback) {
        admin.database().ref(`/friends/${userId}/${type}`).once('value', (snapshot) => {
            var fetchedList = snapshot.val();
            if (fetchedList != null) {
                if (fetchedList.length == 0) {
                    callback = false
                }
                else {
                    if (fetchedList.includes(receiverId)) {
                        console.log(receiverId + " exists in the" + type);
                        callback(true);
                    } else {
                        console.log(receiverId + "does not exists in the" + type);
                        callback(false);
                    }
                }
            } else {
                callback(false);
            }
        });
    }

    static sendFriendNotificationFromServer(title, body, friendData, userData, type) {
        let notificationSettings = friendData.notificationSettings
        const notificationRef = notifications.doc(friendData.id).collection("notificationsList");
        let autoId = notificationRef.doc().id;

        const data = {
            type: type,
            message: body,
            userImage: userData.imageUrl,
            visibleTo: friendData.id,
            userId: userData.id,
            timeStamp: String(Date.now()),
            notificationId: autoId,
        };

        const newNotification = {
            type: type,
            info: data,
            id: autoId,
            status: 0,
        };
        notificationRef.doc(autoId).set(newNotification);

        if (type == Constants.FRIEND_REQUEST_SENT || type == Constants.FRIEND_REQUEST_ACCEPTED) {
            if (notificationSettings.friendRequests == false || notificationSettings.muteAllPushNotifications == true) {
                console.log("User has turned off event invite notifications.");
            } else {
                CommonMethods.sendNotification(title, body, data, friendData.tokens, type);
            }
        }
    }

    static checkIfExistInList(list, userId, callback) {
        if (list.length > 0) {
            if (list.includes(userId)) {
                callback(true)
            }
            else {
                callback(false)
            }
        }
        else {
            callback(false)
        }
    }

    static sendRequest(request, response, callback) {
        let userId = request.body.userId;
        let receiverId = request.body.receiverId
        console.log("Sender Id : " + userId);
        console.log("Receiver Id : " + receiverId);
        admin.database().ref("friends" + '/' + userId).once('value', (snapshot) => {
            var currentUserModel = snapshot.val();
            if (currentUserModel != null) {
                console.log("Current User Not Null");
                let acceptedList = currentUserModel.acceptedList || []
                let pendingList = currentUserModel.pendingList || []
                let sentList = currentUserModel.sentList || []

                if (!Array.isArray(acceptedList)) {
                    acceptedList = [acceptedList]; // Convert to an array if it's not already one
                }

                if (!Array.isArray(pendingList)) {
                    pendingList = [pendingList]; // Convert to an array if it's not already one
                }

                if (!Array.isArray(sentList)) {
                    sentList = [sentList]; // Convert to an array if it's not already one
                }

                console.log("Accepted List Count : " + acceptedList.length)
                console.log("Pending List Count : " + pendingList.length)
                console.log("Sent List Count : " + sentList.length)
                FriendRequest.checkIfExistInList(acceptedList, receiverId, function (isExistInAccepted) {
                    if (!isExistInAccepted) {
                        console.log("isExistInAccepted : " + isExistInAccepted);
                        FriendRequest.checkIfExistInList(pendingList, receiverId, function (isExistInPending) {
                            if (!isExistInPending) {
                                FriendRequest.checkIfExistInList(sentList, receiverId, function (isExistInSent) {
                                    if (!isExistInSent) {
                                        sentList.push(receiverId)
                                        currentUserModel.sentList = sentList

                                        admin.database().ref('friends/' + currentUserModel.id).update(currentUserModel)

                                        FriendRequest.checkAndUploadDataToReceiverTable(request, response, callback)

                                    }
                                    else {
                                        callback(0, "You have already sent an friend request to this user.")
                                    }
                                })
                            }
                            else {
                                callback(0, "You have already got request from this user.Check pending requests.")
                            }
                        })
                    }
                    else {
                        callback(0, "You have already added to friends.")
                    }

                })
            }
            else {
                var data = []
                var finalData = {}
                data.push(receiverId)
                finalData["id"] = userId
                finalData["sentList"] = data
                finalData["pendingList"] = []
                finalData["acceptedList"] = []
                admin.database().ref('friends/' + userId).update(finalData)
                FriendRequest.checkAndUploadDataToReceiverTable(request, response, callback)
            }
        });
    }

    static checkAndUploadDataToReceiverTable(request, response, callback) {
        let userId = request.body.userId;
        let receiverId = request.body.receiverId
        console.log("Sender Id : " + userId);
        console.log("Receiver Id : " + receiverId);
        admin.database().ref("friends" + '/' + receiverId).once('value', (snapshot) => {
            var receiverUserModel = snapshot.val();
            if (receiverUserModel != null) {
                let acceptedList = receiverUserModel.acceptedList || []
                let pendingList = receiverUserModel.pendingList || []
                let sentList = receiverUserModel.sentList || []

                if (!Array.isArray(acceptedList)) {
                    acceptedList = [acceptedList]; // Convert to an array if it's not already one
                }

                if (!Array.isArray(pendingList)) {
                    pendingList = [pendingList]; // Convert to an array if it's not already one
                }

                if (!Array.isArray(sentList)) {
                    sentList = [sentList]; // Convert to an array if it's not already one
                }
                console.log("Test Log");

                FriendRequest.checkIfExistInList(acceptedList, userId, function (isExistInAccepted) {
                    if (!isExistInAccepted) {
                        FriendRequest.checkIfExistInList(sentList, userId, function (isExistInSent) {
                            if (!isExistInSent) {
                                FriendRequest.checkIfExistInList(pendingList, userId, function (isExistInPending) {
                                    if (!isExistInPending) {
                                        pendingList.push(userId)
                                        receiverUserModel.pendingList = pendingList
                                        admin.database().ref('friends/' + receiverId).update(receiverUserModel)
                                        FriendRequest.sendNotification(request, response, callback)
                                    }
                                    else {
                                        callback(0, "You have already sent an friend request to this user.")
                                    }
                                })
                            }
                            else {
                                callback(0, "You have already sent an friend request to this user.")
                            }
                        })

                    }
                    else {
                        callback(0, "You have already added to friends.")
                    }

                })
            }
            else {
                var data = []
                var finalData = {}
                data.push(userId)
                finalData["id"] = receiverId
                finalData["sentList"] = []
                finalData["pendingList"] = data
                finalData["acceptedList"] = []
                admin.database().ref('friends/' + receiverId).update(finalData)
                FriendRequest.sendNotification(request, response, callback)
            }
        });
    }

    static sendNotification(request, response, callback) {
        let userId = request.body.userId;
        let receiverId = request.body.receiverId
        User.getUserData('users', userId, function (userSuccess, userDetail) {
            console.log("userSuccess  : ", userSuccess + " " + userDetail);
            if (userSuccess) {
                User.getUserData('users', receiverId, function (friendSuccess, friendData) {
                    console.log("friendSuccess  : ", friendSuccess + " " + friendData);
                    if (friendSuccess) {
                        // let body = `${userDetail.firstName} ${userDetail.lastName} sent you a friend request`
                        let body;
                        if (userDetail.lastName !== "") {
                            body = `${userDetail.firstName} ${userDetail.lastName} sent you a friend request`
                        }
                        else {
                            body = `${userDetail.firstName} sent you a friend request`
                        }
                        FriendRequest.sendFriendNotificationFromServer("Friend Request", body, friendData, userDetail, Constants.FRIEND_REQUEST_SENT)
                        callback(1, "Friend Request Sent successfully.")
                        // response.send({ "status":1,message:"Friend Request Sent successfully."  });
                    } else {
                        console.log("Error While Getting Friend Data");
                        callback(0, "Invalid Data.")
                        // response.send({ "status":0,message:"Invalid Data."});
                    }
                });
            } else {
                console.log("Error While Getting User Data");
                callback(0, "Invalid Data.")
                // response.send({ "status":0,message:"Invalid Data."});
            }
        });
    }

    static acceptRequest(request, response, callback) {
        let userId = request.body.userId;
        let receiverId = request.body.receiverId
        console.log("Sender Id : " + userId);
        console.log("Receiver Id : " + receiverId);

        admin.database().ref("friends" + '/' + userId).once('value', (snapshot) => {
            var currentUserModel = snapshot.val();
            if (currentUserModel != null) {
                let acceptedList = currentUserModel.acceptedList || []
                let pendingList = currentUserModel.pendingList || []

                if (!Array.isArray(acceptedList)) {
                    acceptedList = [acceptedList]; // Convert to an array if it's not already one
                }

                if (!Array.isArray(pendingList)) {
                    pendingList = [pendingList]; // Convert to an array if it's not already one
                }


                FriendRequest.checkIfExistInList(pendingList, receiverId, function (isExistInPending) {
                    if (isExistInPending) {
                        acceptedList.push(receiverId)
                        const index = pendingList.indexOf(receiverId);
                        if (index !== -1) {
                            pendingList.splice(index, 1);
                        }
                        currentUserModel.acceptedList = acceptedList
                        currentUserModel.pendingList = pendingList

                        admin.database().ref('friends/' + currentUserModel.id).update(currentUserModel)


                        admin.database().ref("friends/" + receiverId).once('value', (snapshot) => {
                            var receiverUserModel = snapshot.val();
                            if (receiverUserModel != null) {
                                let acceptedList = receiverUserModel.acceptedList || []
                                let sentList = receiverUserModel.sentList || []

                                if (!Array.isArray(acceptedList)) {
                                    acceptedList = [acceptedList]; // Convert to an array if it's not already one
                                }

                                if (!Array.isArray(sentList)) {
                                    sentList = [sentList]; // Convert to an array if it's not already one
                                }
                                console.log("Sent List : " + sentList)
                                FriendRequest.checkIfExistInList(sentList, userId, function (isExistInSent) {
                                    if (isExistInSent) {
                                        acceptedList.push(userId)
                                        const index = sentList.indexOf(userId);
                                        if (index !== -1) {
                                            sentList.splice(index, 1);
                                        }
                                        receiverUserModel.acceptedList = acceptedList
                                        receiverUserModel.sentList = sentList

                                        admin.database().ref('friends/' + receiverUserModel.id).update(receiverUserModel)
                                        FriendRequest.sendNotificationAccept(request, response, callback)



                                    }
                                    else {
                                        callback(0, "Some Error Occurred")
                                    }

                                })

                            }
                            else {
                                callback(0, "Invalid Data")
                            }
                        });
                    }
                    else {
                        callback(0, "Some Error Occurred")
                    }
                })
            }
            else {
                callback(0, "Invalid Data")
            }
        });
    }

    static sendNotificationAccept(request, response, callback) {
        let userId = request.body.userId;
        let receiverId = request.body.receiverId
        User.getUserData('users', userId, function (userSuccess, userDetail) {
            console.log("userSuccess  : ", userSuccess + " " + userDetail);
            if (userSuccess) {
                User.getUserData('users', receiverId, function (friendSuccess, friendData) {
                    console.log("friendSuccess  : ", friendSuccess + " " + friendData);
                    if (friendSuccess) {
                        // let body = `${userDetail.firstName} ${userDetail.lastName} has accepted your friend request`
                        let body;
                        if (userDetail.lastName !== "") {
                            body = `${userDetail.firstName} ${userDetail.lastName} has accepted your friend request`
                        }
                        else {
                            body = `${userDetail.firstName} has accepted your friend request`
                        }
                        FriendRequest.sendFriendNotificationFromServer("Friend Request Accepted", body, friendData, userDetail, Constants.FRIEND_REQUEST_ACCEPTED)
                        callback(1, "Friend Request Accepted successfully.")
                        // response.send({ "status":1,message:"Friend Request Sent successfully."  });
                    } else {
                        console.log("Error While Getting Friend Data");
                        callback(0, "Invalid Data.")
                        // response.send({ "status":0,message:"Invalid Data."});
                    }
                });
            } else {
                console.log("Error While Getting User Data");
                callback(0, "Invalid Data.")
                // response.send({ "status":0,message:"Invalid Data."});
            }
        });
    }
}
module.exports = FriendRequest