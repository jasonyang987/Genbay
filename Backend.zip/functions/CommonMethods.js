var admin = require("firebase-admin");
class CommonMethods {

    static sendNotification(title, body, data, tokens, notificationType) {
        if (tokens != null) {
            if (tokens.length > 0) {
                var filtered = tokens.filter(function(el) {
                    return el != null && el != "";
                });
                if (filtered != null) {
                    if (filtered.length > 0) {
                        const payload = {
                            "notification": {
                                "title": title,
                                "body": body,
                                "sound": 'default',
                                "badge": '0'
                            },
                            "data": data
                        }
                        console.log("token : "+filtered);
                        admin.messaging().sendToDevice(filtered, payload).then(function(response) {
                                console.log("Successfully sent message:", response);
                                response.results.forEach(result => {
                                    if (result.error && result.error.length > 0) {
                                        const errorMessage = result.error[0].message; // Assuming error message is in the first position of the array
                                        console.error(`Error sending message: ${errorMessage}`);
                                      } else {
                                        if (result.messageId) {
                                          console.log(`Message sent successfully. Message ID: ${result.messageId}`);
                                        } else {
                                          console.error("Unknown error occurred.");
                                        }
                                      }
                                  });
                            })
                            .catch(function(error) {
                                console.error("Error sending message:", error);
                            });
                    }
                }

            }
        }
    }

    static prepareDateString(isDateConfirmed,dateTimestamp){
        var dateString = ""
        if (isDateConfirmed == true) {
            // let dateTimestamp = eventData.dateTimestamp;
            const dateObj = new Date(dateTimestamp * 1000); // Convert to milliseconds
            const formattedDate = dateObj.toLocaleDateString("en-US", {
                weekday: "long",
                month: "2-digit",
                day: "2-digit",
                year: "numeric",
            });
            return dateString = formattedDate;
        } else {
           return dateString = "TBD";
        }
    }


    static convertTime12to24(time12h) {
        const [time, modifier] = time12h.split(' ');

        let [hours, minutes] = time.split(':');

        if (hours === '12') {
            hours = '00';
        }

        if (modifier === 'PM') {
            hours = parseInt(hours, 10) + 12;
        }

        return `${hours}:${minutes}:00`;
    }

    static toTimestamp(strDate) {
        var datum = Date.parse(strDate);
        return datum / 1000;
    }

    static convertDateToTimestamp(bookingDate, bookingTime) {

        console.log(bookingDate + " " + bookingTime);
        var convertedTime = convertTime12to24(bookingTime);
        var date = bookingDate;
        var datearray = date.split("/");

        var newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
        var dateLatest = newdate + " " + convertedTime;

        return toTimestamp(dateLatest);

    }

}

module.exports = CommonMethods