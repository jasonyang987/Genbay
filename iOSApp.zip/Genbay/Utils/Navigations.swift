//
//  Navigations.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import Foundation
import UIKit
//import PopupDialog

class Navigations {
    
    static let TAG = String(describing: Navigations.self)
    
    static func goToLogin(){
        let viewController = StoryboardScene.Authentication.loginVC.instantiate()
        if let nav = AppDelegate.shared.mainNavController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToSignup(){
        let viewController = StoryboardScene.Authentication.signupVC.instantiate()
        if let nav = AppDelegate.shared.mainNavController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToAddNameVC(calledFrom:String){
        let viewController = StoryboardScene.Authentication.addNameVC.instantiate()
        viewController.calledFrom = calledFrom
        if let nav = AppDelegate.shared.secondaryNavController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }else {
            CommonMethods.showLog(self.TAG, "NAV_NOT_FOUND")
        }
    }
    
    static func goToAddUsernameVC(){
        let viewController = StoryboardScene.Authentication.addUsernameVC.instantiate()
        if let nav = AppDelegate.shared.mainNavController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToAddImageVC(calledFrom:String){
        let viewController = StoryboardScene.Authentication.addImageVC.instantiate()
        viewController.calledFrom = calledFrom
        if let nav = AppDelegate.shared.mainNavController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    
    
    static func goToHome(_ calledFrom: String? = ""){
        let homeViewController = StoryboardScene.Main.homeVC.instantiate()
        let quickTourViewController = StoryboardScene.Main.quickTourVC.instantiate()
        if let nav = AppDelegate.shared.mainNavController{
            let isCompletedTutorial = UserDefaults.standard.bool(forKey: Constants.IS_COMPLETED_TUTORIAL)
            AppDelegate.shared.getFriends()
            AppDelegate.shared.getNotifications()
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(isCompletedTutorial ? homeViewController : quickTourViewController, animated: true)
            CommonMethods.showLog(self.TAG, "isCompletedTutorial: \(isCompletedTutorial)")
        }
    }
    
    
    static func goToChangePassword(){
        let viewController = StoryboardScene.Authentication.changePasswordVC.instantiate()
        if let nav = AppDelegate.shared.secondaryNavController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToForgotPassword(accountType:String){
        let viewController = StoryboardScene.Authentication.forgotPasswordVC.instantiate()
        if let nav = AppDelegate.shared.mainNavController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToAddFriend(navigationController:UINavigationController?){
        let viewController = StoryboardScene.Main.addFriendVC.instantiate()
        if let nav = navigationController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToFriends(navigationController:UINavigationController?){
        let viewController = StoryboardScene.Main.friendsVC.instantiate()
        if let nav = navigationController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToEvents(navigationController:UINavigationController?,eventList:[EventModel] = [],calledFrom:String){
        let viewController = StoryboardScene.Main.eventVC.instantiate()
        viewController.eventList = eventList
        viewController.calledFrom = calledFrom
        if let nav = navigationController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToCreateEvent(navigationController:UINavigationController?,eventModel:EventModel,type:String){
        let viewController = StoryboardScene.Main.createEventVC.instantiate()
        viewController.eventModel = eventModel
        viewController.calledFrom = type
        if let nav = navigationController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToCrowds(navigationController:UINavigationController?, calledFrom: String? = ""){
        let viewController = StoryboardScene.Main.crowdsVC.instantiate()
        if let nav = navigationController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToCreateCrowd(navigationController:UINavigationController?){
        let viewController = StoryboardScene.Main.createCrowdVC.instantiate()
        if let nav = navigationController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToEditCrowd(navigationController:UINavigationController?, model: CrowdModel, calledFrom: CrowdVCType = .editCrowd, delegate: CreateCrowdVCDelegate){
        let viewController = StoryboardScene.Main.createCrowdVC.instantiate()
        viewController.calledFrom = calledFrom
        viewController.model = model
        viewController.delegate = delegate
        if let nav = navigationController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    static func goToCrowdDetail(navigationController:UINavigationController?,crowdId:String){
        let viewController = StoryboardScene.Main.crowdDetailVC.instantiate()
        viewController.crowdId = crowdId
        if let nav = navigationController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }

    static func goToAddMembers(calledFrom:String,navigationController:UINavigationController?,crowdModel:CrowdModel?){
        let viewController = StoryboardScene.Main.addMembersVC.instantiate()
        viewController.calledFrom = calledFrom
        viewController.crowdModel = crowdModel
        if let nav = navigationController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
     
    static func goToVerification(email:String,calledFrom:String){
        let viewController = StoryboardScene.Authentication.verificationVC.instantiate()
        viewController.email = email
        viewController.calledFrom = calledFrom
        if let nav = AppDelegate.shared.mainNavController{
            nav.interactivePopGestureRecognizer?.isEnabled = false
            nav.pushViewController(viewController, animated: true)
        }
    }
    
    //    static func goToWebVC(pageTitle : String, urlString : String, delegate : OnProcessCompleteDelegate?){
    //        let viewController = StoryboardScene.Main.webVC.instantiate()
    //        viewController.pageTitleText = pageTitle
    //        viewController.urlString = urlString
    //        viewController.delegate = delegate
    //        if let nav = AppDelegate.shared.mainNavController{
    //            nav.interactivePopGestureRecognizer?.isEnabled = false
    //            nav.pushViewController(viewController, animated: true)
    //        }
    //    }
    
    static func showDatePicker(calledFrom:String,viewController : UIViewController?, delegate : DateSelectionDelegate?, pageTitle : String, minDate : Date?, maxDate : Date?, mode : UIDatePicker.Mode, currentDate : Date = Date()){
        if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(identifier: "DatePickerVC") as? DatePickerVC{
            vc.delegate = delegate
            vc.pageTitle = pageTitle
            vc.minDate = minDate
            vc.maxDate = maxDate
            vc.mode = mode
            vc.currentDate = currentDate
            vc.calledFrom = calledFrom
            
            //                if viewController is SettingsVC {
            //                    vc.doneTitle = "Update"
            //                }
            
            viewController?.present(vc, animated: true, completion: nil)
        }
    }
    
    static func showCreatePoll(viewController : UIViewController?, delegate : PollSelectionDelegate?, pageTitle : String,type:String,dateList:[DatePollModel],locationList:[Location]){
        if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(identifier: "CreatePollVC") as? CreatePollVC{
            vc.delegate = delegate
            vc.pageTitle = pageTitle
            vc.type = type
            vc.dateList = dateList
            vc.locationList = locationList
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .crossDissolve
            viewController?.present(vc, animated: true, completion: nil)
        }
    }
    
    static func showAddLocationVC(viewController : UIViewController?, delegate : LocationSelectionDelegate?){
              if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(identifier: "AddLocationVC") as? AddLocationVC{
                  vc.modalPresentationStyle = .overFullScreen
                  vc.modalTransitionStyle = .crossDissolve
                  vc.delegate = delegate
                  viewController?.present(vc, animated: true, completion: nil)
              }
          }
        
    
   
//    static func showDialog(navigationController : UINavigationController?, dialogView : UIViewController){
//        let popupDialog = PopupDialog(viewController: dialogView, tapGestureDismissal: false)
//
//        let containterView = PopupDialogContainerView.appearance()
//        containterView.backgroundColor = .clear
//
//        let overlayView = PopupDialogOverlayView.appearance()
//        overlayView.blurEnabled = false
//        popupDialog.transitionStyle = PopupDialogTransitionStyle.bounceUp
//
//        navigationController?.present(popupDialog, animated: true, completion: nil)
//    }
    
//    static func showEventDetailPopup(viewController : UIViewController?, delegate : DateSelectionDelegate?, pageTitle : String,type:String, name: String, date: String, hostName: String, address: String, description: String){
//                if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(identifier: "EventDetailVC") as? EventDetailVC{
//                    vc.pageTitle = pageTitle
//                    vc.type = type
//                    vc.delegate = viewController as? any EventDetailVCDelegate
//                    vc.configure(name: name,
//                                 date: date,
//                                 hostName: hostName,
//                                 address: address,
//                                 description: description)
//                    let navVC = UINavigationController(rootViewController: vc)
//                    navVC.modalPresentationStyle = .overFullScreen
//                    navVC.modalTransitionStyle = .crossDissolve
////                    vc.modalPresentationStyle = .overFullScreen
////                    vc.modalTransitionStyle = .crossDissolve
//                    viewController?.present(navVC, animated: true, completion: nil)
//                }
//            }
    
    static func showEventDetailPopup(viewController : UIViewController?,eventModel:EventModel){
                if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(identifier: "EventDetailVC") as? EventDetailVC{
                    vc.eventModel = eventModel
                    let navVC = UINavigationController(rootViewController: vc)
                    navVC.modalPresentationStyle = .overFullScreen
                    navVC.modalTransitionStyle = .crossDissolve
//                    vc.modalPresentationStyle = .overFullScreen
//                    vc.modalTransitionStyle = .crossDissolve
                    viewController?.present(navVC, animated: true, completion: nil)
                }
            }
    
    static func showMyEventDetailPopup(navVc:UINavigationController?,viewController : UIViewController?,eventId:String,isHost:Bool, delegate: MyEventDetailVCDelegate?, isUpcoming: Bool){
        if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(identifier: "MyEventDetailVC") as? MyEventDetailVC{
//            vc.eventModel = eventModel
            vc.eventId = eventId
            vc.isHost = isHost
            vc.isUpcoming = isUpcoming
            vc.navVc = navVc
            vc.delegate = delegate
            let navVC = UINavigationController(rootViewController: vc)
            navVC.modalPresentationStyle = .overFullScreen
            navVC.modalTransitionStyle = .crossDissolve
            //                    vc.modalPresentationStyle = .overFullScreen
            //                    vc.modalTransitionStyle = .crossDissolve
            viewController?.present(navVC, animated: true, completion: nil)
        }
    }
    
    static func showChooseCrowdDialog(viewController : UIViewController?, delegate:ChooseCrowdForEventDelegate?, crowdList:[CrowdModel],isVisibleToAllSelected:Bool, selectedMembers: [String]){
            if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(identifier: "ChooseCrowdsToEventVC") as? ChooseCrowdsToEventVC{
                vc.delegate = delegate
                vc.crowdList = crowdList
                vc.isVisibleToAllSelected = isVisibleToAllSelected
                vc.selectedFriends = selectedMembers
//                viewController?.present(vc, animated: true, completion: nil)
//                let navVC = UINavigationController(rootViewController: vc)
                vc.modalPresentationStyle = .overFullScreen
                vc.modalTransitionStyle = .crossDissolve
                viewController?.present(vc, animated: true, completion: nil)
            }
        }
    
    static func showInstructionsVC(_ viewController: UIViewController, delegate: ShowInstructionsVCDelegate, calledFrom: String? = ""){
        
        if let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ShowInstructionsVC") as? ShowInstructionsVC {
            vc.delegate = delegate
            vc.calledFrom = calledFrom ?? ""
            vc.modalPresentationStyle = .overFullScreen
            viewController.present(vc, animated: false)
        }
  
    }
    
    static func goToViewComments(navigationController:UINavigationController?,eventId:String, eventTitle: String = "", eventDate: String = "", calledFromDetail: Bool = false){
        guard let commentsVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CommentsVC") as? CommentsVC else {
            return
        }
        commentsVC.eventId = eventId
        commentsVC.eventTitle = eventTitle
        commentsVC.eventDate = eventDate
        commentsVC.calledFromDetail = calledFromDetail
//        commentsVC.eventModel = eventModel
        navigationController?.pushViewController(commentsVC, animated: true)
    }
    
    static func goToGuestListVC(navigationController:UINavigationController?, eventId: String){
        guard let guestListVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "GuestListVC") as? GuestListVC else {
            return
        }
        guestListVC.eventId = eventId
        navigationController?.pushViewController(guestListVC, animated: true)
    }
    
    static func goToEventMemories(eventId: String?, navigationController: UINavigationController?, eventTitle: String = "", eventDate: String = "", calledFromDetail: Bool = false){
        guard let memoriesVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MemoriesVC") as? MemoriesVC else {
            return
        }
//                   memoriesVC.eventModel = model
        memoriesVC.eventTitle = eventTitle
        memoriesVC.eventDate = eventDate
        memoriesVC.calledFromDetail = calledFromDetail
        memoriesVC.eventId = eventId
        if let nav = navigationController {
            nav.pushViewController(memoriesVC, animated: true)
        }
    }
       
    static func goToCreateEventMemory(model: EventModel?, navigationController: UINavigationController?, delegate: CreateEventMemoryVCDelegate?,image:UIImage,calledFrom:String ){
           let storyboard = UIStoryboard(name: "Common", bundle: nil)
           let vc = storyboard.instantiateViewController(withIdentifier: "CreateEventMemoryVC") as! CreateEventMemoryVC
           vc.delegate = delegate
        vc.image = image
        vc.calledFrom = calledFrom
        
           if let model = model {
               vc.eventModel = model
           }
           if let nav = navigationController {
               nav.pushViewController(vc, animated: true)
           }
       }
    
       static func showUploadPopupVC(viewController : UIViewController?, delegate : UploadPopupVCDelegate?){
               if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(identifier: "UploadPopupVC") as? UploadPopupVC{
                   vc.modalPresentationStyle = .overFullScreen
                   vc.modalTransitionStyle = .crossDissolve
                   vc.delegate = delegate
                   viewController?.present(vc, animated: true, completion: nil)
               }
           }
    
    static func goToEventMemoryDetail(eventModel: EventMemoryModel?, navigationController: UINavigationController?, index: Int? = 0){
          if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(identifier: "MemoryDetailVC") as? MemoryDetailVC{
              if let model = eventModel {
                  vc.eventMemoryModel = model
              }
//              if let index = index {
//                  vc.index = index
//              }
              if let nav = navigationController {
                  nav.pushViewController(vc, animated: true)
              }
          }
      }
    
    static func showVotingPopup(viewController: UIViewController, model: EventModel?, isDateList: Bool, delegate: VotingPopupVCDelegate, isHost: Bool){
          if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(withIdentifier: "VotingPopupVC") as? VotingPopupVC {
              if let model = model {
                  vc.eventModel = model
              }
              vc.isHostHere = isHost
              vc.delegate = delegate
              vc.isDateList = isDateList
              vc.modalPresentationStyle = .overFullScreen
              vc.modalTransitionStyle = .crossDissolve
              viewController.present(vc, animated: true)
          }
      }
    
    static func goToNotificationSettingsVC(_ navigationController: UINavigationController){
        if let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NotificationsSettingsVC") as? NotificationsSettingsVC {
            navigationController.pushViewController(vc, animated: true)
        }
    }
    
    static func showIndividualFriendsPopup(viewController: UIViewController, delegate: IndividualFriendsPopupVCDelegate, selectedFriends: [String], selectedCoHosts: [UserModel] = []){
          if let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(withIdentifier: "IndividualFriendsPopupVC") as? IndividualFriendsPopupVC {
              vc.delegate = delegate
              vc.selectedFriends = selectedFriends
              vc.selectedCoHosts = selectedCoHosts
              vc.modalPresentationStyle = .overFullScreen
              vc.modalTransitionStyle = .crossDissolve
              viewController.present(vc, animated: true)
          }
      }
}
