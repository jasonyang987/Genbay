//
//  LineTVC.swift
//  Genbay
//
//  Created by Nap Works on 05/04/23.
//

import UIKit

class LineTVC: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
