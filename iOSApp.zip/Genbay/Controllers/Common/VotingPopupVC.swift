//
//  VotingPopupVC.swift
//  Genbay
//
//  Created by Nap Works on 18/04/23.
//

import UIKit
import Firebase

protocol VotingPopupVCDelegate: AnyObject {
    func setEditedModel(_ model: EventModel, isConfirmed: Bool)
    func voteAdded(_ voteAdded: Bool)
}

class VotingPopupVC: BaseViewController, VoteTVCDelegate {
    
    var delegate: VotingPopupVCDelegate?
    let TAG = String(describing: VotingPopupVC.self)
    @IBOutlet weak var rsvpBtn: UIButton!
    @IBOutlet weak var rsvpView: UIView!
    @IBOutlet weak var eventView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var hostNameLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var addressView: UIView!
    @IBOutlet weak var pollDeadlineMessageView: UIView!
    @IBOutlet weak var pollDeadlineMessageLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableViewHeightConstraint: NSLayoutConstraint!
    var isHostHere: Bool?
    var eventModel : EventModel?
    var isDateList: Bool?
    var isCellSelected: Bool = false
    var previousSelectedIndexPath: IndexPath?
    var userModel: UserModel?
    var selectedIndex: Int?
    var isDateVoted: Bool = false
    var isLocationVoted: Bool = false
    var dateVotedPosition: Int?
    var locationVotedPosition: Int?
    var datePollList: [DatePollModel] = []
    var locationList: [Location] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        CommonMethods.showLog(self.TAG, "viewWillAppear")
    }
    
    func setUI(){
        userModel = UserDefaultsMapper.getUser()
        if let model = eventModel {
            if self.isDateList ?? true {
                self.fetchDatePollList(model.id ?? "") { datePollList in
                    if let datePollList = datePollList {
                        CommonMethods.showLog(self.TAG, "datePollListIs: \(datePollList)")
                        self.datePollList = datePollList
                        self.checkIfUserAlreadyVotedForDate(datePollList)
                        self.tableView.reloadData()
                    }
                }
            }else {
                self.fetchLocationPollList(model.id ?? "") { locationList in
                    if let locationList = locationList {
                        self.locationList = locationList
                        self.checkIfUserAlreadyVotedForLocation(locationList)
                        self.tableView.reloadData()
                    }
                }
            }
        }
        
        view.backgroundColor = .black.withAlphaComponent(0.6)
        CommonMethods.roundCornerFilled(uiView: eventView,
                                        borderColor: .white,
                                        backgroundColor: .white,
                                        cornerRadius: 20,
                                        borderWidth: 0.0)
        CommonMethods.roundCornerFilled(uiView: rsvpBtn,
                                        borderColor: .black,
                                        backgroundColor: .secondaryMainColor,
                                        cornerRadius: 20,
                                        borderWidth: 1)
        
        let nib = UINib(nibName: "VoteTVC", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "VoteTVC")
        tableView.delegate = self
        tableView.dataSource = self
        
        if let model = eventModel {
            setModel(model)

        }
        
        if isHostHere ?? false {
            if isDateList ?? true {
                rsvpBtn.setTitle("Confirm Date", for: .normal)
            }else {
                rsvpBtn.setTitle("Confirm Location", for: .normal)
            }
        }else {
            
            if isDateList ?? true {
                rsvpBtn.setTitle("Vote Date", for: .normal)
            }else {
                rsvpBtn.setTitle("Vote Location", for: .normal)
            }
        }
    }
    
    
    //MARK: - Method to check whether the cell is selected or not
    func isCellSelected(_ isSelected: Bool) {
        self.isCellSelected = isSelected
    }
    
    
    //MARK: - Method to set edited model to the existing model in popup and replace existing date with new data in popup vc
    func setModel(_ model: EventModel) {
        if let pollDeadlineTimestamp = model.pollVotingDeadlineTimestamp {
            let date = Date(timeIntervalSince1970: TimeInterval(pollDeadlineTimestamp))
            pollDeadlineMessageLabel.text = "Poll opens until \(date.formattedMonthYearString)"
        }
        
        var dateString = ""
        if model.isDateConfirmed ?? false{
            let date = Date(timeIntervalSince1970: model.dateTimestamp ?? 0.0)
            dateString = date.formattedDateString
        }
        else{
            dateString = "DATE TBD"
        }
        
        titleLabel.text = "\(model.name ?? "") | \(model.startTime ?? "") \(dateString)"
        hostNameLabel.text = "Host: \(model.hostName ?? "")"
        
        let location = model.location
        if location != nil && location != "" {
            addressView.isHidden = false
            if model.isLocationConfirmed ?? false{
                addressLabel.text = location
            }
            else{
                addressLabel.text = "TBD"
            }
        }else {
            addressView.isHidden = true
        }
        
        if let polldeadlineTimestamp = model.pollVotingDeadlineTimestamp {
            let currentTimeStamp = Date().timeIntervalSince1970
            if currentTimeStamp >= polldeadlineTimestamp {
                self.pollDeadlineMessageView.isHidden = true
            } else {
                let timeRemainingInSeconds = Int(polldeadlineTimestamp - currentTimeStamp)
                let hours = timeRemainingInSeconds / 3600
                let minutes = (timeRemainingInSeconds % 3600) / 60
                CommonMethods.showLog(self.TAG, "Poll deadline not reached. \(hours) hours and \(minutes) minutes remaining.")
            }
        }
    }
    
    //MARK: - Method to fetch date poll list of an event from firebase
    private func fetchDatePollList(_ eventId: String, completion: @escaping ([DatePollModel]?) ->Void){
        showProgressHUD()
        CommonMethods.showLog(self.TAG, "first")
        FirebaseAPI.default.fetchDatePollList(eventId) { datePollList in
            self.hideProgressHUD()
            CommonMethods.showLog(self.TAG, "second")
            if let datePollList = datePollList {
                completion(datePollList)
            }
        }
        
    }
    
    //MARK: - Method to fetch location poll list of an event from firebase
    private func fetchLocationPollList(_ eventId: String, completion: @escaping ([Location]?) ->Void){
        showProgressHUD()
        FirebaseAPI.default.fetchLocationPollList(eventId) { locationPollList in
            self.hideProgressHUD()
            if let locationPollList = locationPollList {
                completion(locationPollList)
            }
        }
        
    }
    
    //MARK: - Method to check if user already voted or not for date
    private func checkIfUserAlreadyVotedForDate(_ datePollList: [DatePollModel]){
        for i in 0..<datePollList.count {
            let dateModel = datePollList[i]
            if let userList = dateModel.userList, userList.count > 0 {
                if let userId = userModel?.id {
                    if userList.contains(userId){
                        self.isDateVoted = true
                        self.isCellSelected = true
                        self.dateVotedPosition = i
                        self.previousSelectedIndexPath = IndexPath(row: i, section: 0)
                        break // exit the inner for loop
                    }
                }
            }
            if self.isDateVoted {
                break // exit the outer for loop if a vote is found
            }
        }
        
    }
    
    //MARK: - Method to check if user already voted or not for location
    private func checkIfUserAlreadyVotedForLocation(_ locationList: [Location]){
        for i in 0..<locationList.count {
            let locationModel = locationList[i]
            if let userList = locationModel.userList, userList.count > 0 {
                if let userId = userModel?.id {
                    if userList.contains(userId){
                        self.isLocationVoted = true
                        self.locationVotedPosition = i
                        self.previousSelectedIndexPath = IndexPath(row: i, section: 0)
                        self.isCellSelected = true
                        break // exit the inner for loop
                    }
                }
            }
            if self.isLocationVoted {
                break // exit the outer for loop if a vote is found
            }
        }
    }
    
    //MARK: - Method to add vote in date poll list
    private func addVoteInDatePollList(_ eventId: String, dateId: String, userId: String, position: Int, isEdited: Bool = false){
        showProgressHUD()
        FirebaseAPI.default.addVoteInDatePollUserList(eventId, dateId: dateId, userId: userId) { success, error in
            if success, error == nil {
                self.showDialog(title: Constants.APP_NAME, message: "Vote \(isEdited ? "Edited" : "Added") Successfully") {
                    DispatchQueue.main.async {
                        self.dateVotedPosition = position
                        self.delegate?.voteAdded(true)
                        self.hideProgressHUD()
                        self.tableView.reloadData()
                    }
                }
            }else {
                self.hideProgressHUD()
                self.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "error occured")
            }
        }
    }
    
    //MARK: - Method to add vote in locaition list
    private func addVoteInLocationPollList(_ eventId: String, locationId: String, userId: String, position: Int, isEdited: Bool = false){
        showProgressHUD()
        FirebaseAPI.default.addVoteInLocationPollUserList(eventId, locationId: locationId, userId: userId) { success, error in
            if success, error == nil {
                self.showDialog(title: Constants.APP_NAME, message: "Vote \(isEdited ? "Edited" : "Added") Successfully") {
                    DispatchQueue.main.async {
                        self.locationVotedPosition = position
                        self.delegate?.voteAdded(true)
                        self.hideProgressHUD()
                        self.tableView.reloadData()
                    }
                }
            }else {
                self.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "error occured")
            }
        }
    }
    
    
    //MARK: - IBActions here
    @IBAction func rsvpBtnPressed(_ sender: UIButton){
        if isCellSelected {
            if rsvpBtn.titleLabel?.text == "Vote Date"{
                checkIfUserAlreadyVotedForDate(self.datePollList)
                ///If already voted in date, then you can edit your vote by removing already given vote and adding another vote
                if self.isDateVoted {
                    if let model = eventModel,
                       let userId = userModel?.id,
                       let dateVotedPosition = dateVotedPosition,
                       let dateId = datePollList[dateVotedPosition].id {
                        showProgressHUD()
                        FirebaseAPI.default.removeVoteFromDatePollUserList(model.id ?? "", dateId: dateId, userId: userId) { success, error in
                            if success{
                                if let selectedNewPosition = self.selectedIndex,
                                   let newSelectedDateId = self.datePollList[selectedNewPosition].id{
                                    self.addVoteInDatePollList(model.id ?? "", dateId: newSelectedDateId, userId: userId, position: selectedNewPosition, isEdited: true)
                                }
                            }
                        }
                    }
                }else {
                    ///in this code, you will give your vote for the first time
                    if let model = eventModel,
                       let userId = userModel?.id,
                       let selectedIndex = selectedIndex,
                       let dateId = datePollList[selectedIndex].id {
                        addVoteInDatePollList(model.id ?? "", dateId: dateId, userId: userId, position: selectedIndex)
                    }
                }
            }else if rsvpBtn.titleLabel?.text == "Vote Location"{
                checkIfUserAlreadyVotedForLocation(self.locationList)
                ///If already voted in location, then you can edit your vote by removing already given vote and adding another vote
                if self.isLocationVoted {
                    if let model = eventModel,
                       let userId = userModel?.id,
                       let locationVotedPosition = locationVotedPosition,
                       let locationId = locationList[locationVotedPosition].id {
                        showProgressHUD()
                        FirebaseAPI.default.removeVoteFromLocationPollUserList(model.id ?? "", locationId: locationId, userId: userId) { success, error in
                            if success{
                                if let selectedNewPosition = self.selectedIndex,
                                   let newSelectedLocationId = self.locationList[selectedNewPosition].id{
                                    self.addVoteInLocationPollList(model.id ?? "", locationId: newSelectedLocationId, userId: userId, position: selectedNewPosition, isEdited: true)
                                }
                            }
                        }
                    }
                    
                }else {
                    ///in this code, you will give your vote for the first time
                    if let model = eventModel,
                       let userId = userModel?.id,
                       let selectedIndex = selectedIndex,
                       let locationId = locationList[selectedIndex].id {
                        addVoteInLocationPollList(model.id ?? "", locationId: locationId, userId: userId, position: selectedIndex)
                    }
                }
                
            }else if rsvpBtn.titleLabel?.text == "Confirm Date" {
               
                if let selectedIndex = selectedIndex,
                   let date = datePollList[selectedIndex].date,
                   let model = self.eventModel{
                    self.showProgressHUD()
                    FirebaseAPI.default.fetchEventFirestore(eventID: model.id ?? "") { error, model in
                        if let model = model, error == nil {
                            self.hideProgressHUD()
                            model.date = date
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat="MM/dd/yyyy"
                            let dateString = dateFormatter.date(from: date)
                            let dateTimeStamp  = dateString!.timeIntervalSince1970
                            
                            model.dateTimestamp = dateTimeStamp
                            model.isDateConfirmed = true
                            model.isDatePollCreated = false
                            self.showProgressHUD()
//                            CommonWebServices.editEventFirestore(eventModel: model
//                            ) { status, message, model in
//                                self.hideProgressHUD()
//                                if status == Constants.SUCCESS {
//                                    self.hideProgressHUD()
//                                    self.showDialog(title: Constants.APP_NAME, message: "Date Confirmed Successfully!") {
//                                        self.delegate?.setEditedModel(editedModel, isConfirmed: true)
//                                        self.dismiss(animated: true)
//                                    }
//                                }else if status == Constants.FAILURE {
//                                    self.vc.showDialog(title : Constants.APP_NAME, message: message)
//                                }
//                            }
                            FirebaseAPI.default.editEventFirestore(eventModel: model) { error, editedModel in
                                if error == nil {
                                    self.hideProgressHUD()
                                    self.showDialog(title: Constants.APP_NAME, message: "Date Confirmed Successfully!") {
                                        self.delegate?.setEditedModel(editedModel, isConfirmed: true)
                                        self.dismiss(animated: true)
                                    }
                                }else {
                                    self.showDialog(title: Constants.APP_NAME, message: "\(error?.localizedDescription ?? "some Error occurred")")
                                }
                            }
                        }
                    }
                    
                }
            }else if rsvpBtn.titleLabel?.text == "Confirm Location" {
                if let selectedIndex = selectedIndex,
                   let location = locationList[selectedIndex].location,
                   let model = self.eventModel{
                    self.showProgressHUD()
                    FirebaseAPI.default.fetchEventFirestore(eventID: model.id ?? "") { error, model in
                        if let model = model, error == nil {
                            self.hideProgressHUD()
                            model.location = location
                            model.isLocationConfirmed = true
                            model.isLocationPollCreated = false
                            self.showProgressHUD()
                            FirebaseAPI.default.editEventFirestore(eventModel: model) { error, editedModel in
                                if error == nil {
                                    self.hideProgressHUD()
                                    self.showDialog(title: Constants.APP_NAME, message: "Location Confirmed Successfully!") {
                                        self.delegate?.setEditedModel(editedModel, isConfirmed: true)
                                        self.dismiss(animated: true)
                                    }
                                }else {
                                    self.showDialog(title: Constants.APP_NAME, message: "\(error?.localizedDescription ?? "some Error occurred")")
                                }
                            }
                        }
                    }
                   
                }
            }
            
        }else {
            if datePollList.count == 1 || locationList.count == 1 {
                showDialog(title: Constants.APP_NAME, message: "Please Select \(isDateList ?? true ? "date": "location") to make a vote!")
            }else {
                showDialog(title: Constants.APP_NAME, message: "Please Select \(isDateList ?? true ? "any date": "any location") to make a vote!")
            }
        }
    }
    
    
    @IBAction func crossBtnPressed(_ sender: UIButton){
//        self.delegate?.setEditedModel(self.eventModel ?? EventModel())
        self.dismiss(animated: true)
    }
    
    @IBAction func closeBtnPressed(_ sender: UIButton){
//        self.delegate?.setEditedModel(self.eventModel ?? EventModel())
        self.dismiss(animated: true)
    }
    
}

//MARK: - UITableViewDelegate and UITableViewDataSource Methods
extension VotingPopupVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isDateList ?? true{
            return datePollList.count
        }else {
            return locationList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "VoteTVC") as! VoteTVC
        cell.delegate = self
        cell.configure()
        
        if isDateList ?? true {
            tableViewHeightConstraint.constant = cell.frame.height * CGFloat(datePollList.count)
            cell.configure(with: datePollList, index: indexPath.row)
            
        }else {
            tableViewHeightConstraint.constant = cell.frame.height * CGFloat(locationList.count)
            cell.configure(with: locationList, index: indexPath.row)
            
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? VoteTVC {
             cell.configureCheckMark()
         }
        
         if let previousSelectedIndexPath = previousSelectedIndexPath, previousSelectedIndexPath != indexPath {
             if let cell = tableView.cellForRow(at: previousSelectedIndexPath) as? VoteTVC {
                 cell.checkMarkView.backgroundColor = .white
                 cell.isCellSelected = false
             }
         }

        previousSelectedIndexPath = indexPath
        if isDateList ?? true {
            self.selectedIndex = indexPath.row
        }else {
            self.selectedIndex = indexPath.row
        }
    }
}
