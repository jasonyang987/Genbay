//
//  ChooseCrowdsToEventsViewModel.swift
//  Genbay
//
//  Created by Nap Works on 10/04/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class ChooseCrowdToEventsViewModel{
    let TAG = String(describing: ChooseCrowdToEventsViewModel.self)
    var vc : ChooseCrowdsToEventVC
    
    init(vc: ChooseCrowdsToEventVC) {
        self.vc = vc
    }
    
    func getCrowds(){
        self.vc.showProgressHUD()
        FirebaseAPI.default.getCrowds(userId: self.vc.userData?.id ?? ""){ list in
            self.vc.hideProgressHUD()
            self.vc.crowdList = list ?? []
//            self.checkAndShowMessage()
            self.vc.tableView.reloadData()
        }
    }
    
//    func checkAndShowMessage(){
//        if self.vc.crowdList.count == 0 {
//            self.vc.noDataText.isHidden = false
//        }
//        else{
//            self.vc.noDataText.isHidden = true
//        }
//    }
}
