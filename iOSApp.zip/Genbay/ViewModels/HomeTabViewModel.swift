//
//  HomeTabViewModel.swift
//  Genbay
//
//  Created by Nap Works on 13/04/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class HomeTabViewModel{
    let TAG = String(describing: HomeTabViewModel.self)
    var vc : HomeTabVC
    
    
    
    init(vc: HomeTabVC) {
        self.vc = vc
    }
    
    
    func getUpcomingGuestEvents(_ isShowLoading: Bool){
        if isShowLoading {
            self.vc.showProgressHUD()
        }
        let friendList = AppDelegate.shared.friendList
        CommonMethods.showLog(self.TAG, "friendlist count : \(friendList.count)")

        if friendList.count > 0 && !self.vc.isHomeDataLoaded{
            var userIds : [String] = []
            userIds = friendList.map{$0.id ?? ""}
            CommonMethods.showLog(self.TAG, "useridsare: \(userIds)")
            
            FirebaseAPI.default.getUpcomingGuestEventFirestore(userIds:userIds,userId: self.vc.userModel?.id ?? ""){ list,error in
                self.vc.hideProgressHUD()
                self.vc.eventList = []
                self.vc.eventList = list.sorted{
                    $1.dateTimestamp ?? Double() > $0.dateTimestamp ?? Double()
                }
                self.prepareCalendarEventList()
                if self.vc.eventList.count == 0 {
                    self.vc.noEventsView.isHidden = false
                    self.vc.noEventsLabel.text = "It seems like that you have not been added in any event yet"
                }else {
                    self.vc.noEventsView.isHidden = true
                }
                self.vc.isHomeDataLoaded = true
                self.vc.refreshControl.endRefreshing()
                self.vc.tableView.reloadData()
            }
        }
        else{
            FirebaseAPI.default.getUpcomingGuestEventFirestore(userIds:[],userId: self.vc.userModel?.id ?? ""){ list,error in
                self.vc.hideProgressHUD()
                self.vc.eventList = []
                self.vc.eventList = list.sorted{
                    $1.dateTimestamp ?? Double() > $0.dateTimestamp ?? Double()
                }
                self.prepareCalendarEventList()
                if self.vc.eventList.count == 0 {
                    self.vc.noEventsView.isHidden = false
                    self.vc.noEventsLabel.text = "It seems like that you have not been added in any event yet"
                }else {
                    self.vc.noEventsView.isHidden = true
                }
                self.vc.isHomeDataLoaded = true
                self.vc.tableView.reloadData()
            }
        }
    }
    
    func prepareCalendarEventList(){
        let eventList =  vc.eventList
        var list : [String] = []
        eventList.forEach{ data in
            list.append(data.date ?? "")
        }
        
        self.vc.eventDates = list
        self.vc.calendar.reloadData()
        
        list.forEach{ id in
            CommonMethods.showLog(TAG, "Id : \(id)")
        }
    }
    
}
