//
//  AddDriverVC.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import UIKit

class SignupVC: BaseViewController, UITextFieldDelegate {
    
    let TAG = String(describing: SignupVC.self)

 
    @IBOutlet weak var signInBtn: UIButton!
    @IBOutlet weak var signupBtn: UIButton!
    @IBOutlet weak var confirmPasswordView: UIView!
    @IBOutlet weak var passwordView: UIView!
    @IBOutlet weak var emailView: UIView!
  
    @IBOutlet weak var confirmPasswordText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var emailText: UITextField!
    
    var viewModel : SignupViewModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = SignupViewModel(vc:self)
        setUI()
    }
    
    func setUI(){
        
        signInBtn.underlineButton( text: "Already Have An Account? Login")
        [emailView,passwordView,confirmPasswordView].forEach{view in
            CommonMethods.roundCornerFilled(uiView: view, borderColor: .mainColor, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.7)}

        CommonMethods.setPlaceholderColor(textFields: [emailText,passwordText,confirmPasswordText], color: .darkGray)


        CommonMethods.roundCornerFilled(uiView: signupBtn, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 25.0, borderWidth: 0.0)
        emailText.delegate = self
        passwordText.delegate = self
        confirmPasswordText.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
             if textField == emailText {
                 passwordText.becomeFirstResponder()
             }else if textField == passwordText{
                 confirmPasswordText.becomeFirstResponder()
             }
             else if textField == confirmPasswordText {
                 textField.resignFirstResponder()
             }
             return true
    }
    
    @IBAction func signInButtonClicked(_ sender: Any) {
        CommonMethods.showLog(TAG, "signInButtonClicked")
        do{
                try viewModel?.validate()
                viewModel?.createAccount()
        }
        catch let error as SignupViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }
    
    @IBAction func backButtonPressed(_ sender: Any) {
        CommonMethods.showLog(TAG, "backButtonPressed")
        CommonMethods.dismiss(vc: self)
    }
    
    @IBAction func singInPressed(_ sender: Any) {
        CommonMethods.dismiss(vc: self)
    }
}
