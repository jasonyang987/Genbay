//
//  FirebaseAPI+Users.swift
//  SoulSync
//
//  Created by Nap Works on 28/10/22.
//

import Foundation
import Firebase
import FirebaseFirestore

extension FirebaseAPI {
    
    
    typealias UserCompletion = (UserModel?, Error?) -> Void
    func getUser(_ uid: String, completion: @escaping UserCompletion) {
        if uid.isEmpty{
            completion(nil, nil)
        }else{
            CommonMethods.showLog(TAG, "UID : \(uid)")
            Endpoints.users.child(uid).observeSingleEvent(of: .value) { (snapshot) in
                if let dict = snapshot.value as? [String: Any] {
                    do {
                        let data = try JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted)
                        let user = try JSONDecoder().decode(UserModel.self, from: data)
                        user.id = snapshot.key
                        CommonMethods.showLog(self.TAG, "getUser : \(user)")
                        completion(user, nil)
                    } catch {
                        CommonMethods.showLog(self.TAG, "getUser Error : \(error.localizedDescription)")
                        completion(nil, error)
                    }
                } else {
                    completion(nil, nil)
                }
            }
        }
    }
    
    
    typealias SaveUserCompletion = (Bool, Error?, UserModel?) -> Void
    
    func saveUser(_ user: UserModel,_ type:String, completion: @escaping SaveUserCompletion) {
        var tokens : [String] = user.tokens ?? []
        if let token = UserDefaultsMapper.getObject(key: .fcmToken) as? String{
            tokens.append(token)
        }
        saveUserData(user,type, completion: completion)
    }

    
    func saveUserData(_ user: UserModel,_ type:String,  completion: @escaping SaveUserCompletion){
        var value = user.updateNameParameters
        if type == Constants.IMAGE{
            value = user.updateImageParameters
        }else if type == Constants.NAME{
           value = user.updateNameParameters
        }else if type ==  Constants.USERNAME{
            value = user.updateUsernameParameters
        }else if type == Constants.NOTIFICATION_SETTINGS {
            value = user.notificationSettingsParams
        }
        Endpoints.users.child(uid).updateChildValues(value) { (error, ref) in
            if let error = error {
                completion(false, error, nil)
            }else{
                completion(true, nil, user)
            }
        }
    }


//    func saveService(_ user: UserModel, completion: @escaping SaveUserCompletion) {
//        var tokens : [String] = []
//        if let token = UserDefaultsMapper.getObject(key: .fcmToken) as? String{
//            tokens.append(token)
//        }
//        saveSelectedService(user, completion: completion)
//
//    }
//
//    func saveSelectedService(_ user: UserModel, completion: @escaping SaveUserCompletion){
//        Endpoints.users.child(user.id ?? uid).updateChildValues(user.selectSercviceParameters) { (error, ref) in
//            if let error = error {
//                CommonMethods.showLog("firebase api", "Inside saveselectedService")
//                completion(false, error, nil)
//            }else{
//                CommonMethods.showLog("firebase api", "Inside else saveselectedService ")
//                self.saveSelectedServiceData(user, completion: completion)
//               // completion(true, nil, user)
//            }
//        }
//    }
//
//    func saveSelectedServiceData(_ user: UserModel, completion: @escaping SaveUserCompletion){
//        Endpoints.users.child(user.id ?? uid).child(Constants.SERVICE_DETAILS).updateChildValues(user.selectSercviceDataParameters) { (error, ref) in
//            if let error = error {
//                CommonMethods.showLog("firebase api", "Inside saveselectedServiceData")
//                completion(false, error, nil)
//            }else{
//                CommonMethods.showLog("firebase api", "Inside else saveselectedServiceData")
//
//                completion(true, nil, user)
//            }
//        }
//    }
//
//
//    typealias RemoveUserCompletion = (Error?) -> Void
//    func removeUser(_ uid: String, completion: @escaping RemoveUserCompletion) {
//        Endpoints.admins.child(uid).removeValue { (error, _) in
//            completion(error)
//        }
//    }
//
//
//    func updateTimeFrameCategory( user: UserModel,  completion: @escaping FirebaseCompletion){
//        updateUserData(params: user.profileAvailability, completion)
//    }
//
//    func updateUserData(params : [String: Any], _ completion: @escaping FirebaseCompletion){
//        Endpoints.admins.child(uid).updateChildValues(params) { (error, ref) in
//            completion(error)
////            if let error = error {
////                completion(false, error, nil)
////            }else{
////                completion(true, nil, user)
////            }
//        }
//    }
//
//    typealias CustomerListCompletion = ([CustomerDetailModel]) -> Void
//    func getCustomers(_ uids: [String], completion: @escaping CustomerListCompletion) {
//        let myGroup = DispatchGroup()
//        var list : [CustomerDetailModel] = []
//        for key in uids {
//            myGroup.enter()
//            self.getCustomerDetail(key) { user, error in
//                if let user = user{
//                    list.append(user)
//                }
//                myGroup.leave()
//            }
//        }
//        myGroup.notify(queue: .main) {
//            CommonMethods.showLog(self.TAG, "notify")
//            completion(list)
//        }
//    }
//
    func updateFCMToken(calledToAddToken : Bool, completion: @escaping(Bool, Error?) -> Void) {
        CommonMethods.showLog(self.TAG, "updateFCMToken : \(uid)")
        getUser(uid) { (detail, error) in
            if let error = error{
                CommonMethods.showLog(self.TAG, "updateFCMToken if error")
                completion(false, error)
            }else{
                if let detail = detail{
                    if let token = UserDefaultsMapper.getObject(key: .fcmToken) as? String{
                        if detail.tokens == nil{
                            detail.tokens = []
                        }
                        if var tokens = detail.tokens{
                            if calledToAddToken{
                                if !tokens.contains(token){
                                    tokens.append(token)
                                    self.saveTokens(tokens: tokens, completion: completion)
                                }else{
                                    CommonMethods.showLog(self.TAG, "updateFCMToken tokens contained")
                                    completion(true, nil)
                                }
                            }else{
                                if tokens.contains(token){
                                    if let index = tokens.firstIndex(of: token){
                                        tokens.remove(at: index)
                                        self.saveTokens(tokens: tokens, completion: completion)
                                    }else{
                                        CommonMethods.showLog(self.TAG, "updateFCMToken invalid index")
                                        completion(true, nil)
                                    }
                                }else{
                                    CommonMethods.showLog(self.TAG, "updateFCMToken tokens not contained")
                                    completion(true, nil)
                                }
                            }
                            
                            
//                            if !tokens.contains(token){
//                                tokens.append(token)
//                                CommonMethods.showLog(self.TAG, "updateChildValues tokens : \(tokens)")
//                                Endpoints.users.child(self.uid).updateChildValues(["tokens": tokens]) { (error, ref) in
//                                    CommonMethods.showLog(self.TAG, "updateChildValues error : \(error?.localizedDescription ?? "")")
//                                    CommonMethods.showLog(self.TAG, "updateChildValues ref : \(ref)")
//                                    if let error = error{
//                                        completion(false, error)
//                                    }else{
//                                        completion(true, nil)
//                                    }
//                                }
//                            }else{
//                                completion(true, nil)
//                            }
                        }else{
                            CommonMethods.showLog(self.TAG, "tokens nil")
                            completion(false, nil)
                        }
                    }else{
                        CommonMethods.showLog(self.TAG, "token nil")
                        completion(false, nil)
                    }
                }else{
                    CommonMethods.showLog(self.TAG, "detail nil")
                    completion(false, nil)
                }
            }
        }
        //        if let token = UserDefaultsMapper.getObject(key: .fcmToken) as? String{
        //            Endpoints.users.child(uid).child("tokens").updateChildValues([token: token]) { (error, _) in
        //                if let error = error{
        //                    completion(false, error)
        //                }else{
        //                    completion(true, nil)
        //                }
        //            }
        //        }else{
        //            completion(false, nil)
        //        }
    }
    
    func saveTokens(tokens : [String], completion: @escaping(Bool, Error?) -> Void) {
        CommonMethods.showLog(self.TAG, "saveTokens tokens : \(tokens)")
        Endpoints.users.child(self.uid).updateChildValues(["tokens": tokens]) { (error, ref) in
            CommonMethods.showLog(self.TAG, "saveTokens error : \(error?.localizedDescription ?? "")")
            CommonMethods.showLog(self.TAG, "saveTokens ref : \(ref)")
            if let error = error{
                completion(false, error)
            }else{
                completion(true, nil)
            }
        }
    }

    typealias GetUsersSuccess = ([UserModel]) -> Void
    func getAllUsers(userId:String, completion: @escaping GetUsersSuccess) {
        Endpoints.users
//            .queryOrderedByKey().queryStarting(atValue: startValue).queryLimited(toFirst: UInt(limit))
            .observeSingleEvent(of: .value, with: { snapshot in
                self.handleSearchedUserSnapshot(snapshot: snapshot,userId: userId,completion: completion)
//                let list = self.handleSearchedUserSnapshot(snapshot: snapshot,userId:userId)
//                completion(list)
            }, withCancel: { error in
                completion([])
            })
    }

    func handleUserSnapshot(snapshot : DataSnapshot,userId:String)->[UserModel]{
        
        guard let dict = snapshot.value as? [String: Any] else {
            CommonMethods.showLog(TAG, "handleUserSnapshot Error \(snapshot)")
            return []
        }
        var list: [UserModel] = []
        CommonMethods.showLog(TAG, "SnapDict Count : \(dict.count)")
        for snapDict in dict {
            guard let value = snapDict.value as? [String: Any] else { continue }
            do {
                let data = try JSONSerialization.data(withJSONObject: value, options: .prettyPrinted)
                let detail = try JSONDecoder().decode(UserModel.self, from: data)
                if detail.id != userId && detail.username != nil && detail.username != ""
                {
                    list.append(detail)
                }
                else{
                    CommonMethods.showLog(TAG, "Same ID")
                }
            } catch {
                CommonMethods.showLog(self.TAG, "handleUserSnapshot Error: \(snapDict.key):\(error.localizedDescription)")
                continue
            }
        }
        return list
    }
    
    func handleSearchedUserSnapshot(snapshot : DataSnapshot,userId:String, completion : @escaping GetUsersSuccess){
        
        guard let dict = snapshot.value as? [String: Any] else {
            CommonMethods.showLog(TAG, "handleSearchedUserSnapshot Error \(snapshot)")
            completion([])
            return
        }
        var list: [UserModel] = []
        CommonMethods.showLog(TAG, "SnapDict Count : \(dict.count)")
        let dispatchGroup = DispatchGroup()
        for snapDict in dict {
            guard let value = snapDict.value as? [String: Any] else { continue }
            do {
                let data = try JSONSerialization.data(withJSONObject: value, options: .prettyPrinted)
                let detail = try JSONDecoder().decode(UserModel.self, from: data)
                
                if detail.id != userId && detail.username != nil && detail.username != ""
                {
                    dispatchGroup.enter()
                    let id = detail.id ?? ""
                    self.getDataFromFriends(id){isExists,model in
                        
                        let searchedUserFriendModel = model
                        if isExists{
                            CommonMethods.showLog(self.TAG, "searchedUserFriendModel Data Exists")
                            let acceptedList = searchedUserFriendModel.acceptedList ?? []
                            let pendingList = searchedUserFriendModel.pendingList ?? []
                            let sentList = searchedUserFriendModel.sentList ?? []
                            
                            let isExistInAccepted = self.checkIfExistInList(acceptedList,userId)
                            let isExistInPending = self.checkIfExistInList(pendingList,userId)
                            let isExistInSent = self.checkIfExistInList(sentList,userId)
                            
                            if !isExistInAccepted{
                                if !isExistInSent{
                                    if !isExistInPending{
                                        CommonMethods.showLog(self.TAG, "searchedUserFriendModel Id Kise Vich ni Hai")
                                        detail.friendStatus = .noType
                                        list.append(detail)
                                        dispatchGroup.leave()
                                    }
                                    else{
                                        CommonMethods.showLog(self.TAG, "searchedUserFriendModel Id Pending Vich Hai")
                                        detail.friendStatus = .sent
                                        list.append(detail)
                                        dispatchGroup.leave()
                                    }
                                }
                                else{
                                    CommonMethods.showLog(self.TAG, "searchedUserFriendModel Id Sent Vich Hai")
                                    detail.friendStatus = .pending
                                    list.append(detail)
                                    dispatchGroup.leave()
                                }
                                
                            }
                            else{
                                CommonMethods.showLog(self.TAG, "searchedUserFriendModel Id Accepted Vich Hai")
                                detail.friendStatus = .accepted
                                list.append(detail)
                                dispatchGroup.leave()
                            }
                            
                            
                            
                        }
                        else{
                            CommonMethods.showLog(self.TAG, "searchedUserFriendModel Data Not Exists")
                            detail.friendStatus = .noType
                            list.append(detail)
                            dispatchGroup.leave()
                        }
                    }
                }
                else{
                    CommonMethods.showLog(TAG, "Same ID")
                    continue
                }
            } catch {
                CommonMethods.showLog(self.TAG, "handleUserSnapshot Error: \(snapDict.key):\(error.localizedDescription)")
                continue
            }
            

        }
        
        dispatchGroup.notify(queue: .main) {
            CommonMethods.showLog(self.TAG, "Group Notify")
            completion(list)
        }
        
    }

}
