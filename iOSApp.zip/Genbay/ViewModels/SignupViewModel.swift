//
//  AddDriverViewModel.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class SignupViewModel{
    let TAG = String(describing: SignupViewModel.self)
    var vc : SignupVC
    
    init(vc: SignupVC) {
        self.vc = vc
    }
    
    func validate() throws {
        
        if let email = vc.emailText.text {
            if email.trimAndCheckIsEmpty() {
                throw ValidationError.emailEmpty
            }
        } else {
            throw ValidationError.emailEmpty
        }
        
        if let password = vc.passwordText.text {
            if password.trimAndCheckIsEmpty() {
                throw ValidationError.passwordEmpty
            }else if password.trim().count < 8{
                throw ValidationError.passwordShortLength
            }
        } else {
            throw ValidationError.passwordEmpty
        }
        
        if let confirmPassword = vc.confirmPasswordText.text {
            if confirmPassword.trimAndCheckIsEmpty() {
                throw ValidationError.confirmPasswordEmpty
            }else if confirmPassword.trim().count < 8{
                throw ValidationError.confirmPasswordShortLength
            }
        } else {
            throw ValidationError.confirmPasswordEmpty
        }
        
        if vc.passwordText.text?.trimmingCharacters(in: .whitespaces) != vc.confirmPasswordText.text?.trimmingCharacters(in: .whitespaces){
            throw ValidationError.passwordNotMatched
        }
        
    }
        
        // MARK: - Enums
        enum ValidationError: Error {
            case emailEmpty
            case passwordEmpty
            case passwordShortLength
            case confirmPasswordEmpty
            case confirmPasswordShortLength
            case passwordNotMatched
            
            var localizedDescription: String {
                switch self {
                case .emailEmpty:
                    return "Please enter your email address"
                case .passwordEmpty:
                    return "Please enter your password"
                case .passwordShortLength:
                    return "Password must have 8 characters"
                case .confirmPasswordEmpty:
                    return "Please enter your confirm password"
                case .confirmPasswordShortLength:
                    return "Confirm Password must have 8 characters"
                case .passwordNotMatched:
                    return "Passwords doesn't matched"
                }
            }
        }
    
    func createAccount(){
        vc.showProgressHUD()
        FirebaseAPI.default.createAccount(email: vc.emailText.text?.trim() ?? "", password: vc.passwordText.text?.trim() ?? "") { userData, error in
            self.vc.hideProgressHUD()
            if let error = error{
                self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
            }else{
                if userData != nil{
                    CommonMethods.showLog(self.TAG, "\(userData)")
                    self.vc.showDialog(title: Constants.APP_NAME, message: "You have successfully signed up in \(Constants.APP_NAME)") {
                        UserDefaultsMapper.save(true, forKey: .isLoggedIn)
                        Navigations.goToAddNameVC(calledFrom: Constants.SIGN_UP)
                    }
                }else{
                    self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                }
            }
        }
    }
}
