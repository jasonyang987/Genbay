//
//  AdminLoginModel.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import Foundation



final class LoginViewModel{
    let TAG = String(describing: LoginViewModel.self)
    var vc : LoginVC
    
    init(vc: LoginVC) {
        self.vc = vc
    }
    
    func validate() throws {
            if let email = vc.emailText.text {
                if email.trimAndCheckIsEmpty() {
                    throw ValidationError.emailEmpty
                }
            } else {
                throw ValidationError.emailEmpty
            }
            
            if let password = vc.passwordText.text {
                if password.trimAndCheckIsEmpty() {
                    throw ValidationError.passwordEmpty
                }
            } else {
                throw ValidationError.passwordEmpty
            }
        }
        
        // MARK: - Enums
        enum ValidationError: Error {
            case emailEmpty
            case passwordEmpty
            
            var localizedDescription: String {
                switch self {
                case .emailEmpty:
                    return "Please enter your email address"
                case .passwordEmpty:
                    return "Please enter your password"
                }
            }
        }
    
    func login(){
        vc.showProgressHUD()
        FirebaseAPI.default.login(email: vc.emailText.text?.trimmingCharacters(in: .whitespaces) ?? "", password: vc.passwordText.text?.trimmingCharacters(in: .whitespaces) ?? "") { user, error in
            self.vc.hideProgressHUD()
            if let error = error{
                CommonMethods.showLog(self.TAG, "LoginError : \(error.localizedDescription)")
                self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
            }else{
                if let user = user {
                    do {
                        UserDefaultsMapper.save(true, forKey: .isLoggedIn)
                        if user.notificationSettings == nil {
                            let notificationSettings = NotificationSettingsModel()
                            notificationSettings.muteAllPushNotifications = false
                            notificationSettings.friendRequests = true
                            notificationSettings.inviteToEvents = true
                            notificationSettings.eventAttendanceUpdates = true
                            notificationSettings.newEventMemories = true
                            notificationSettings.discussionComments = true
                            notificationSettings.mentions = true
                            user.notificationSettings = notificationSettings
                            FirebaseAPI.default.saveUser(user, Constants.NOTIFICATION_SETTINGS) { success, error, userModel in
                                if let error = error {
                                    self.vc.showDialog(title: Constants.APP_NAME, message: error.localizedDescription)
                                }
                            }
                        }
                        user.isLoggedIn = true
                        try UserDefaultsMapper.saveUser(user)
                        
                        AppDelegate.shared.mainNavController?.popToRootViewController(animated: false)
                        AppDelegate.shared.getFriends()
                        AppDelegate.shared.getNotifications()
                    } catch {
                        self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
                    }
                }else{
                    self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                }
            }
        }
    }
}
