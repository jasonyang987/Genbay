//
//  BaseViewController.swift
//  TruthAlibi
//
//  Created by Nap Works on 14/02/23.
//

import UIKit
import NVActivityIndicatorView
import EasyTipView

class BaseViewController: UIViewController {
    
    private var indicatorView: NVActivityIndicatorView?
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .darkContent
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
//        navigationItem.backBarButtonItem = UIBarButtonItem(image: UIImage(named: "back_arrow_black"), style: .plain, target: nil, action: nil)
        setupIndicatorView(frame: view.frame)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let indicatorSize: CGFloat = 100
        let midPoint = CGPoint(x: view.frame.midX - indicatorSize / 2, y: view.frame.midY - indicatorSize / 2)
        let viewSize = CGSize(width: indicatorSize, height: indicatorSize)
        indicatorView?.frame = CGRect(origin: midPoint, size: viewSize)
    }
    
    func setupIndicatorView(frame: CGRect) {
        let indicatorSize: CGFloat = 100
        let midPoint = CGPoint(x: frame.midX - indicatorSize / 2, y: frame.midY - indicatorSize / 2)
        let viewSize = CGSize(width: indicatorSize, height: indicatorSize)
        
        indicatorView = NVActivityIndicatorView(frame: CGRect(origin: midPoint, size: viewSize))
        
        indicatorView?.type = .circleStrokeSpin
        indicatorView?.color = .secondaryMainColor
        
        view.addSubview(indicatorView!)
    }
    
    func showProgressHUD() {
        indicatorView?.startAnimating()
        userIteraction(enabled: false)
    }
    
    func hideProgressHUD() {
        indicatorView?.stopAnimating()
        userIteraction(enabled: true)
    }
    
    private func userIteraction(enabled: Bool) {
        view.isUserInteractionEnabled = enabled
    }
    
    func setupTipView(_ tipView: EasyTipView){
        tipView.layer.shadowColor = UIColor.black.cgColor
        tipView.layer.shadowOpacity = 0.27
        tipView.layer.shadowOffset = CGSize(width: 0, height: 0)
        tipView.layer.shadowRadius = 4
        let shadowRect = tipView.bounds.insetBy(dx: -12, dy: -12)
        tipView.layer.shadowPath = UIBezierPath(rect: shadowRect).cgPath
    }
}
