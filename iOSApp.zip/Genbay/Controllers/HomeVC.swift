//
//  HomeViewController.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit
import Kingfisher

class HomeVC: BaseViewController, MyEventDetailVCDelegate {
    func fetchEventsAfterConfirm() {
        
    }
    
    let TAG = String(describing: HomeVC.self)
    var pageVC : HomePVC?
    @IBOutlet weak var profileTabImageView: UIImageView!
    @IBOutlet weak var notifyStatusLabel: UILabel!
    @IBOutlet weak var notifyStatusView: UIView!
    @IBOutlet weak var pagerView: UIView!
    
    var userModel:UserModel?
    var currentIndex: Int = 0
    var navController: UINavigationController?
    var viewModel: HomeViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userModel = UserDefaultsMapper.getUser()
        viewModel = HomeViewModel(vc: self)
        dump(userModel?.notificationSettings)
        profileTabImageView.layer.cornerRadius = profileTabImageView.frame.width / 2.0
        notifyStatusView.layer.cornerRadius = notifyStatusView.frame.width / 2.0
        notifyStatusView.isHidden = true
        let isNotifyTabTapped = UserDefaults.standard.value(forKey: "notifyTabTapped") as? Bool
        
        if isNotifyTabTapped ?? false {
            notifyStatusView.isHidden = true
        }

        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(handleProfileNotification(notification:)), name: .profileNotificationVC, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleNotificationsCount(notification:)), name: .updatedNotificationsCount, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleNotification(notification:)), name: .handleCloudNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleFriendRequestNotification(notification:)), name: .friendRequestNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(friendRequestCancelled(_:)), name: Notification.Name("FRIEND_REQUEST_CANCELLED"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(friendRequestAccepted(_:)), name: Notification.Name("FRIEND_REQUEST_CONFIRMED"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(friendRequestCancelledByUser(_:)), name: Notification.Name("FRIEND_REQUEST_CANCELLED_BY_USER"), object: nil)
        let notifications = AppDelegate.shared.notificationList
        NotificationCenter.default.post(name: .updatedNotificationsCount, object: notifications)
        
        
        let image = userModel?.imageUrl ?? ""
        if image != ""{
            profileTabImageView.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.forceRefresh])
        }
        
        self.setupPageViewController()
    }
    
    @objc func friendRequestCancelled(_ notification: NSNotification){
        viewModel?.getNotifications(userModel?.id ?? "", completion: { notifications in
            if let userInfo = notification.userInfo, let userId = userInfo["userId"] as? String {
                let filter = notifications.filter({$0.info?.userId == userId})
                let sentRequests = filter.filter({ $0.type == "friendRequestSent"})
                sentRequests.forEach { model in
                    let currentMessage = model.info?.message ?? ""

                    let modifiedCurrentMessage = currentMessage.replacingOccurrences(of: "You have new friend request from ", with: "")
                    let newMessage: String = "You have declined friend request of \(modifiedCurrentMessage)"
                    model.info?.message = newMessage
//                    model.info?.timeStamp = "\(Date().timeIntervalSince1970)"
                    self.viewModel?.readNotification(self.userModel?.id ?? "", notificationId: model.id ?? "", info: model.info, type: "friendRequestDeclinedByUser", completion: { success in
                        if success {
                        }
                    })
                }
            }

        })
    }

    @objc func friendRequestAccepted(_ notification: NSNotification){
        viewModel?.getNotifications(userModel?.id ?? "", completion: { notifications in
            if let userInfo = notification.userInfo, let userId = userInfo["userId"] as? String {
                let filter = notifications.filter({$0.info?.userId == userId})
                let sentRequests = filter.filter({ $0.type == "friendRequestSent"})
                sentRequests.forEach { model in
                    let currentMessage = model.info?.message ?? ""

                    let modifiedCurrentMessage = currentMessage.replacingOccurrences(of: "You have new friend request from ", with: "")
                    var newMessage: String = "You have accepted friend request of \(modifiedCurrentMessage)"
                    model.info?.message = newMessage
//                    model.info?.timeStamp = "\(Date().timeIntervalSince1970)"
                    self.viewModel?.readNotification(self.userModel?.id ?? "", notificationId: model.id ?? "", info: model.info, type: "friendRequestAcceptedByUser", completion: { success in
                        if success {
                        }
                    })
                }
            }

        })
    }
    
    @objc func friendRequestCancelledByUser(_ notification: NSNotification){
        if let userInfo = notification.userInfo, let userId = userInfo["userId"] as? String {
            viewModel?.getNotifications(userId, completion: { notifications in
                let cancelledRequests = notifications.filter({ $0.type == "friendRequestSent" && $0.info?.userId == self.userModel?.id})
                CommonMethods.showLog(self.TAG, "CANCELLED_REQUESTS: \(cancelledRequests.count)")
                cancelledRequests.forEach { model in
                    let currentMessage = model.info?.message ?? ""

                    let modifiedCurrentMessage = currentMessage.replacingOccurrences(of: "You have new friend request from ", with: "")
                    let newMessage: String = "The friend request is cancelled by \(modifiedCurrentMessage)"
                    model.info?.message = newMessage
//                    model.info?.timeStamp = "\(Date().timeIntervalSince1970)"
                    self.viewModel?.readNotification(userId, notificationId: model.id ?? "", info: model.info, type: "friendRequestCancelledByUser", completion: { success in
                        if success {
                        }
                    })
                }

            })
        }
      
    }
    
    override func viewDidAppear(_ animated: Bool) {
        handleNotificationData()
    }
    
    func setupPageViewController() {
        for view in self.pagerView.subviews {
            view.removeFromSuperview()
        }
        
        DispatchQueue.main.async {
            self.pageVC = HomePVC()
            let frame = self.pagerView.frame
            CommonMethods.showLog(self.TAG, "frame width : \(frame.width)")
            CommonMethods.showLog(self.TAG, "frame height : \(frame.height)")
            CommonMethods.showLog(self.TAG, "frame size : \(frame.size)")
            CommonMethods.showLog(self.TAG, "frame origin : \(frame.origin)")
            self.pageVC?.view.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.height)
            if let pageVC = self.pageVC{
                self.addChild(pageVC)
                self.pagerView.addSubview(pageVC.view)
                pageVC.didMove(toParent: self)
            }
        }
    }
    
    @IBAction func homeTabBtnPressed(_ sender: UIButton) {
        self.pageVC?.changePage(direction: .reverse, posiiton: 0)
        self.currentIndex = 0
    }
    
    @IBAction func notifyTabBtnPressed(_ sender: UIButton) {
        CommonMethods.showLog(self.TAG, "didTapNotifyTab")
        UserDefaults.standard.setValue(true, forKey: "notifyTabTapped")
        notifyStatusView.isHidden = true
        if self.currentIndex > 1 {
            self.pageVC?.changePage(direction: .reverse, posiiton: 1)
            self.currentIndex = 1
        }else if currentIndex < 1 {
            self.pageVC?.changePage(direction: .forward, posiiton: 1)
            self.currentIndex = 1
        }
    }
    
    @IBAction func plusTabBtnPressed(_ sender: UIButton) {
        CommonMethods.showLog(self.TAG, "didTapPlusTab")
        if self.currentIndex > 2 {
            self.pageVC?.changePage(direction: .reverse, posiiton: 2)
            self.currentIndex = 2
        }else if self.currentIndex < 2 {
            self.pageVC?.changePage(direction: .forward, posiiton: 2)
            self.currentIndex = 2
        }
    }
    
    @IBAction func groupTabBtnPressed(_ sender: UIButton) {
        CommonMethods.showLog(self.TAG, "didTapGroupTab")
        if self.currentIndex == 4 {
            self.pageVC?.changePage(direction: .reverse, posiiton: 3)
            self.currentIndex = 3
        }else if self.currentIndex < 3 {
            self.pageVC?.changePage(direction: .forward, posiiton: 3)
            self.currentIndex = 3
        }
    }
    
    @IBAction func profileTabBtnPressed(_ sender: UIButton) {
        CommonMethods.showLog(self.TAG, "didTapProfileTab")
        self.pageVC?.changePage(direction: .forward, posiiton: 4)
        self.currentIndex = 4
    }
    
    func handleProfileNotificationData(_ updateType:String){
        CommonMethods.showLog(TAG, "handleNotificationData")
        userModel = UserDefaultsMapper.getUser()
        if updateType == Constants.IMAGE{
            let image = userModel?.imageUrl ?? ""
            if image != ""{
                profileTabImageView.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.forceRefresh])
            }
        }
    }
    
    func handleNotificationData(){
        if let notificationData = UserDefaultsMapper.getObject(key: .notificationData) as? String{
            CommonMethods.showLog(TAG, "notificationData : \(notificationData)")
            if !notificationData.isEmpty{
                if let data = CommonMethods.convertStringToJson(jsonString: notificationData){
                    CommonMethods.showLog(TAG, "data : \(data)")
                    if let notificationType = data["type"] as? String{
                        CommonMethods.showLog(TAG, "notificationType : \(notificationType)")
                        if let notificationId = data["notificationId"] as? String,
                           let userId = UserDefaultsMapper.getUser()?.id{
                            CommonMethods.showLog(self.TAG,"Read Notification notificationId : \(notificationId)")
                                                  CommonMethods.showLog(self.TAG, "Read Notification userId : \(userId)")
                            FirebaseAPI.default.EditNotification(userId, notificationId: notificationId, info: nil) {[self] success, error in
                                CommonMethods.showLog(self.TAG, "Read Notification : \(success)")
                                CommonMethods.showLog(self.TAG, "Read Notification error : \(error)")
                                if success{
                                    AppDelegate.shared.getNotifications()
                                }
                            }
                        }
                        
                        
                        switch notificationType{
                        case Constants.FRIEND_REQUEST_SENT, Constants.FRIEND_REQUEST_ACCEPTED:
                            Navigations.goToFriends(navigationController: AppDelegate.shared.mainNavController)
                            break
                        case Constants.EVENT_CREATED, Constants.EVENT_UPDATED:
                            var eventId = data["eventId"] as? String
                            CommonMethods.showLog(TAG, "Event Id  : \(eventId)")
                            Navigations.showMyEventDetailPopup(navVc:AppDelegate.shared.mainNavController,viewController: self,eventId: eventId ?? "",isHost:false, delegate: self, isUpcoming: true)
                            break
                        case Constants.USERS_MENTIONED, Constants.EVENT_COMMENT_ADDED:
                            let eventId = data["eventId"] as? String
                            CommonMethods.showLog(TAG, "Event Id  : \(eventId)")
                            Navigations.goToViewComments(navigationController: AppDelegate.shared.mainNavController, eventId: eventId ?? "")
                            break
                        case Constants.GOING_TO_EVENT:
                            var eventId = data["eventId"] as? String
                            CommonMethods.showLog(TAG, "Event Id  : \(eventId)")
                            Navigations.goToGuestListVC(navigationController:AppDelegate.shared.mainNavController, eventId: eventId ?? "")
                            break
                            
                        case Constants.CO_HOST_INVITE:
                            
                            break
                        
                        case Constants.EVENT_MEMORY_ADDED:
                            var eventId = data["eventId"] as? String
                            CommonMethods.showLog(TAG, "Event Id  : \(eventId)")
                            Navigations.goToEventMemories(eventId: eventId, navigationController: AppDelegate.shared.mainNavController)
                            break
                        default:
                            break
                        }
                        UserDefaultsMapper.save("", forKey: .notificationData)
                    }else{
                        CommonMethods.showLog(TAG, "notificationType nil")
                    }
                }
                else{
                    CommonMethods.showLog(TAG, "Conversion ch panga")
                }
            }
        }
    }
    
}

extension HomeVC{
    @objc func handleNotification(notification: NSNotification) {
        if let value = notification.userInfo as? [String : Any]{
            CommonMethods.showLog(TAG, "handleNotification value : \(value)")
            if let type = value["type"] as? String{
                if type == Constants.HANDLE_NOTIFICATION{
                    handleNotificationData()
                }
            }
        }
    }
    
    @objc func handleProfileNotification(notification: NSNotification) {
        if let value = notification.userInfo as? [String : Any]{
            CommonMethods.showLog(TAG, "handleNotification value : \(value)")
            if let type = value["type"] as? String{
                if type == Constants.UPDATE_HOME{
                    if let updateType = value["updateType"] as? String{
                        handleProfileNotificationData(updateType)
                    }
                    
                }
            }
        }
    }
    
    @objc func handleNotificationsCount(notification: NSNotification){
        CommonMethods.showLog(self.TAG, "I am called here")
        let isNotifyTabTapped = UserDefaults.standard.value(forKey: "notifyTabTapped") as? Bool
        
        if isNotifyTabTapped ?? false {
            notifyStatusView.isHidden = true
        }else {
            if var notifications = notification.object as? [NotificationModel]{
                CommonMethods.showLog(TAG, "handleNotification value count: \(notifications)")
                notifications = notifications.filter({$0.status == 0})
                CommonMethods.showLog(self.TAG, "notifications count: \(notifications.count)")
                if notifications.count > 0 {
                    notifyStatusView.isHidden = false
                    notifyStatusLabel.text = "\(notifications.count)"
                    if notifications.count >= 10 {
                        notifyStatusLabel.text = "10+"
                    }
                }else{
                    notifyStatusView.isHidden = true
                }
            }
        }

        
    }
    
    @objc func handleFriendRequestNotification(notification: NSNotification){
        self.pageVC?.changePage(direction: .forward, posiiton: 3)
        self.currentIndex = 3
    }
    
}
