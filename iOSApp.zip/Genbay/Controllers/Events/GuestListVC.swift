//
//  GuestListVC.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import UIKit

class GuestListVC: BaseViewController, FriendsVCDelegate {
 
    let TAG = String(describing: GuestListVC.self)
    @IBOutlet weak var eventTitleLabel: UILabel!
    @IBOutlet weak var noGuestListView: UIView!
    @IBOutlet weak var guestListTableView: UITableView!
    var eventModel : EventModel?
    var userModel:UserModel?
    var guestList:[UserModel] = []
    var isCalledFromDetail:Bool = false
    var eventId: String = ""
    var viewModel : GuestListViewModel?
//    var isUserUnfriendId: String = ""
    var isHost : Bool?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = GuestListViewModel(vc: self)
        userModel = UserDefaultsMapper.getUser()
        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(self.handleUpdatedGuestList(_:)), name: .updatedGuestList, object: nil)
        self.noGuestListView.isHidden = true
        if isCalledFromDetail {
            isHost = eventModel?.userId == userModel?.id
            let isVisibleToAll = eventModel?.isVisibleToAllSelected ?? false
            
            if isVisibleToAll{
                if isHost ?? false{
                    guestList = AppDelegate.shared.friendList
                    self.viewModel?.checkAndShowMessage()
                }
                else{
                   getFriendList(true)
                }
            }
            else{
                viewModel?.getGuestList()
            }
            
            setUI()
            
        }else {
            self.eventTitleLabel.isHidden = true
            showProgressHUD()
            FirebaseAPI.default.getEventDataWithId(eventID: eventId ?? "") {[self] error, model in
               
                if let model = model, error == nil {
                    eventModel = model
                    isHost = eventModel?.userId == userModel?.id
                    let isVisibleToAll = eventModel?.isVisibleToAllSelected ?? false
                    
                    if isVisibleToAll{
                        if isHost ?? false{
                            self.hideProgressHUD()
                            guestList = AppDelegate.shared.friendList
                        }
                        else{
                           getFriendList(true)
                        }
                    }
                    else{
                        viewModel?.getGuestList()
                    }
                    
                    setUI()
                   
                }else {
                    self.hideProgressHUD()
                    self.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "")
                }
            }
        }
    
    }
    
    @objc func handleUpdatedGuestList(_ notification: Notification) {
        if let updatedGuestList = notification.object as? [UserModel] {
            self.guestList = updatedGuestList
            if self.guestList.count == 0{
                self.noGuestListView.isHidden = false
            }
            else{
                self.noGuestListView.isHidden = true
            }
            self.guestListTableView.reloadData()
            
            showProgressHUD()
            CommonMethods.showLog(self.TAG, "wao updated here")

            let name = "\(userModel?.firstName ?? "") \(userModel?.lastName ?? "")"
            FirebaseAPI.default.getUpcomingHostEventFirestore(name:name,userId: userModel?.id ?? ""){ list, error in
                CommonMethods.showLog(self.TAG, "wao updated here inside firebaseapi")

                self.hideProgressHUD()
                NotificationCenter.default.post(name: .updatedEventsList, object: list)
            }
            CommonMethods.showLog(self.TAG, "updatedguestlist: \(updatedGuestList)")
        }
    }
    
    func sendUpdatedGuestListToGuestListVC(_ guestList: [UserModel]) {
        CommonMethods.showLog(self.TAG, "gueslistis: \(guestList)")
    }
    
    func getFriendList(_ isShowLoading:Bool){
        if isShowLoading{
            self.showProgressHUD()
        }
        FirebaseAPI.default.getFriends(userId: eventModel?.userId ?? ""){ acceptedList , pendingList in
            self.hideProgressHUD()
            self.guestList = []
//            self.guestList = acceptedList ?? []
            acceptedList?.forEach{ data in
//                if data.id != self.userModel?.id {
//                    self.guestList.append(data)
//                }
                self.guestList.append(data)
            }
            self.viewModel?.checkAndShowMessage()
            CommonMethods.showLog(self.TAG, "guestList count : \(self.guestList.count)")
            self.guestListTableView.reloadData()
        }
    }
    
    private func setUI(){
        
        navigationController?.navigationBar.isHidden = true
        
        let nib = UINib(nibName: "GuestTVC", bundle: nil)
        guestListTableView.register(nib, forCellReuseIdentifier: "GuestTVC")
        guestListTableView.delegate = self
        guestListTableView.dataSource = self
        noGuestListView.isHidden = true
        
        var dateString = ""
        if eventModel?.isDateConfirmed ?? false{
            let date = Date(timeIntervalSince1970: eventModel?.dateTimestamp ?? 0.0)
    //        let date = Date(timeIntervalSince1970: TimeInterval(date) ?? TimeInterval())
             dateString = date.formattedMonthYearString
        }
        else{
            dateString = "DATE TBD"
        }
        eventTitleLabel.isHidden = false
        self.viewModel?.checkAndShowMessage()
        eventTitleLabel.text = "\(eventModel?.name ?? "") | \(dateString)"
    }

    @IBAction func backBtnPressed(_ sender: UIButton){
        navigationController?.popViewController(animated: true)
    }

}

extension GuestListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return guestList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GuestTVC", for: indexPath) as! GuestTVC
        cell.selectionStyle = .none
        cell.configure(data:guestList[indexPath.row],pos: indexPath.row, model: eventModel ?? EventModel())
        return cell
    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 100
//    }
}

//extension Notification.Name {
//    static let updatedGuestList = Notification.Name("updatedGuestList")
//    static let updatedGuestListFromCrowd = Notification.Name("updatedGuestListFromCrowd")
//}
