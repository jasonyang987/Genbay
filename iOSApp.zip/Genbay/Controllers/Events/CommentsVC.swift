//
//  CommentsVC.swift
//  Genbay
//
//  Created by Nap Works on 05/04/23.
//

import UIKit
import DropDown
import Firebase

class CommentsVC: BaseViewController {
    let TAG = String(describing: CommentsVC.self)
    
    @IBOutlet weak var eventTitleLabel: UILabel!
    @IBOutlet weak var commentsTableView: UITableView!
    @IBOutlet weak var noCommentsView: UIView!
    @IBOutlet weak var commentText: UITextField!
    @IBOutlet weak var addCommentView: UIView!
    @IBOutlet weak var postBtnView: UIView!
    @IBOutlet weak var postBtn: UIButton!
//    var mentionsIndexes = [Int: Int]()
    var eventTitle: String = ""
    var eventDate: String = ""
    private var mentionCharater = "@"
    var userModel:UserModel?
    var guestList: [UserModel] = []
    var eventModel : EventModel?
    var eventId : String?
    var commentList : [CommentModel] = []
    var viewModel : CommentsViewModel?
    let dropDown = DropDown()
    var isHost : Bool?
    var allGuestList: [UserModel] = []
    var isFirstMentioned: Bool = false
    var isMentioned: Bool = false
    var mentions: [String] = []
    var isUsernameSelected: Bool = false
    var guestNames: [String] = []
    var guestUserNames: [String] = []
    var guestImages: [String] = []
    var isMentionInProgress = false
    var oeObjects: [OEObject]?
    var theFilteredList = [String]()
    var theFilteredGuestList = [UserModel]()
    var mentionsIndexes = [Int: Int]()
    var isMentioning = Bool()
    var mentionQuery = String()
    var startMentionIndex = Int()
    var calledFromDetail: Bool = false
    
    var textCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = CommentsViewModel(vc: self)
        userModel = UserDefaultsMapper.getUser()
        noCommentsView.isHidden = true
        CommonMethods.roundCornerFilled(uiView: addCommentView,
                                        borderColor: .black,
                                        backgroundColor: .white,
                                        cornerRadius: 0,
                                        borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: postBtnView,
                                        borderColor: .clear,
                                        backgroundColor: .secondaryMainColor,
                                        cornerRadius: 10,
                                        borderWidth: 0)
        CommonMethods.setPlaceholderColor(textFields: [commentText], color: .gray)
        if calledFromDetail {
            eventTitleLabel.text = "\(eventTitle) | \(eventDate)"
        }else {
            eventTitleLabel.isHidden = true
        }
        CommonMethods.showLog(self.TAG, "EVENT_TITLE, EVENT_DATE: \(eventTitle) \(eventDate)")
        showProgressHUD()
        FirebaseAPI.default.getEventDataWithId(eventID: eventId ?? "") { error, model in
//            self.eventView.isHidden = false
            if let model = model, error == nil {
                self.eventModel = model
                self.setData()
               
            }else {
                self.hideProgressHUD()
                self.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "")
            }
        }
        
        
        

    }
    
    func addDataIntoList(commentModel : CommentModel){
        self.commentList.append(commentModel)
        self.commentsTableView.reloadData()

    }
    
    func setData(){
        isHost = eventModel?.userId == userModel?.id
        
        let isVisibleToAll = eventModel?.isVisibleToAllSelected ?? false
        
        if isVisibleToAll{
            if isHost ?? false{
                guestList = AppDelegate.shared.friendList
                let userId = userModel?.id ?? ""
                guestList = guestList.filter({$0.id ?? "" != userId})
                allGuestList = guestList
                self.getAllGuestNames()
            }
            else{
               getFriendList(true)
            }
        }
        else{
            viewModel?.getGuestList()
        }
        setUI()
        viewModel?.getCommentList()
        
    }
    
    func getFriendList(_ isShowLoading:Bool){
        CommonMethods.showLog(TAG, "getFriendList")
        if isShowLoading{
            self.showProgressHUD()
        }
        FirebaseAPI.default.getFriends(userId: eventModel?.userId ?? ""){ acceptedList , pendingList in
            self.hideProgressHUD()
            self.guestList = []
            acceptedList?.forEach{ data in
                self.guestList.append(data)
            }
//            let userId = self.userModel?.id ?? ""
//            self.guestList = self.guestList.filter({$0.id ?? "" != userId})
            self.allGuestList = self.guestList
            self.getAllGuestNames()
            self.viewModel?.checkAndShowMessage()
            self.commentsTableView.reloadData()
            CommonMethods.showLog(self.TAG, "GUEST LIST COUNT : \(self.allGuestList.count)")
        }
    }
    
    private func setUI(){
        let nib = UINib(nibName: "CommentTVC", bundle: nil)
        commentsTableView.register(nib, forCellReuseIdentifier: "CommentTVC")
        commentsTableView.delegate = self
        commentsTableView.dataSource = self
        
        var dateString = ""
        if eventModel?.isDateConfirmed ?? false{
            let date = Date(timeIntervalSince1970: eventModel?.dateTimestamp ?? 0.0)
            dateString = date.formattedMonthYearString
        }
        else{
            dateString = "DATE TBD"
        }
        eventTitleLabel.isHidden = false
        eventTitleLabel.text = "\(eventModel?.name ?? "") | \(dateString)"
        commentText.delegate = self
        commentText.returnKeyType = .done
    }

    @IBAction func backBtnPressed(_ sender: UIButton){
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func postBtnPressed(_ sender: UIButton){
        if let commentText = commentText.text?.trimmingCharacters(in: .whitespaces) {
            CommonMethods.showLog(self.TAG, "commentText : \(commentText)")
            if commentText == ""{
                showDialog(title: Constants.APP_NAME, message: "Please write something...")
            }else {
                showProgressHUD()
                var commentModel = CommentModel()
                commentModel.userId = userModel?.id ?? ""
                commentModel.comment = commentText
                commentModel.createdAt = Date().timeIntervalSince1970.rounded()
                commentModel.userModel = self.userModel
                
                CommonWebServices.addComment(userId: userModel?.id ?? "", eventId: eventModel?.id ?? "", createdAt: Date().timeIntervalSince1970.rounded(), comment: commentText) { status, message, model in
                    self.hideProgressHUD()
                    if status == Constants.SUCCESS {
                        self.commentText.text = ""
                        self.noCommentsView.isHidden = true
                        self.commentText.resignFirstResponder()
                        self.commentList.insert(commentModel, at: 0)
                        self.commentsTableView.reloadData()
                    }else if status == Constants.SESSION_OUT {
                        self.showDialog(title: Constants.APP_NAME, message: message) {
                            CommonMethods.sessionOut()
                        }
                    }else {
                        self.showDialog(title: Constants.APP_NAME, message: message)                    }
                }
//                FirebaseAPI.default.commentPost(eventId: eventModel?.id ?? "", commentModel: commentModel) { (commentModel,error) in
//                    if error != nil && error != ""{
//                        CommonMethods.showLog(self.TAG, "onCommentAdded error : \(error)")
//                        self.showDialog(title: Constants.APP_NAME, message: error ?? Constants.COMMON_ERROR_MESSAGE, confirmation: nil, completion: nil)
//                    }else{
//                        self.commentText.text = ""
//                        self.noCommentsView.isHidden = true
//                        self.commentText.resignFirstResponder()
//                        self.commentList.insert(commentModel, at: 0)
//                        //                self.commentList.append(commentModel)
//                        self.commentsTableView.reloadData()
//                        //              NotificationCenter.default.post(name: NSNotification.Name(rawValue: "onPostLikedHome"), object: nil, userInfo: ["PostModel":postModel])
//                    }
//                }
            }
            
        }
    }
}

extension CommentsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 10
        return commentList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CommentTVC", for: indexPath) as! CommentTVC
        cell.selectionStyle = .none
        cell.configure(data:commentList[indexPath.row],guestList:allGuestList)
        return cell
    }
}

extension CommentsVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        commentText.resignFirstResponder()
        return true
    }
    
    func getAllGuestNames(){
        CommonMethods.showLog(self.TAG, "getAllGuestNames")
        let group = DispatchGroup()
        guestList = allGuestList
        var coHostIds = eventModel?.acceptedCoHostInvites ?? []
        if eventModel?.userId != userModel?.id {
            CommonMethods.showLog(self.TAG, "I AM A GUEST")
            coHostIds.append(eventModel?.userId ?? "")
        }

        for id in coHostIds {
            group.enter()
            FirebaseAPI.default.getUser(id) { [weak self] model, error in
                guard let self = self, let model = model, error == nil else {
                    return
                }
                self.guestList.append(model)
                group.leave()
            }
        }
  
        group.notify(queue: .main) {
            if self.eventModel?.userId != self.userModel?.id {
                CommonMethods.showLog(self.TAG, "I AM A GUEST REMOVING MYSELF, LIST COUNT : \(self.guestList.count)")
                CommonMethods.showLog(self.TAG, "DATA : \(self.guestList[0].firstName)")
                self.guestList = self.guestList.filter { $0.id ?? "" != self.userModel?.id ?? ""}
            }

            self.guestNames = self.guestList.map { $0.username ?? ""}
            self.guestUserNames = self.guestList.map { $0.username ?? ""}
            self.guestImages = self.guestList.map { $0.imageUrl ?? ""}
            CommonMethods.showLog(self.TAG, "After Removing : \(self.guestList.count)")
        }
    }

    
    func textFieldDidChangeSelection(_ textField: UITextField) {
        theFilteredGuestList = guestList
        CommonMethods.showLog(self.TAG, "I AM A GUEST REMOVING MYSELF, LIST COUNT : \(self.theFilteredGuestList.count)")
        CommonMethods.showLog(self.TAG, "DATA : \(self.theFilteredGuestList[0].firstName)")

        if let text = commentText.text {
            if text.count == 0 {
                dropDown.hide()
            }
            
            let words = text.components(separatedBy: .whitespaces)
            if let lastWord = words.last, lastWord.contains("@") {
                let mentionRange = lastWord.range(of: "@")
                if let mentionStart = mentionRange?.lowerBound {
                    let mentionQuery = lastWord[mentionStart..<lastWord.endIndex]
                    if mentionQuery.count == 1 {
                        self.mentionQuery = "@"
                        textCount = textField.text?.count ?? 0
                        theFilteredGuestList = guestList
                        CommonMethods.showLog(self.TAG, "GUESTLISTCOUNT: \(theFilteredGuestList.count)")
                        guestImages = theFilteredGuestList.map { $0.imageUrl ?? "" }
                        guestUserNames = theFilteredGuestList.map { $0.username ?? ""}
                        
                        showDialog()
                    }else if mentionQuery == "@guests" && textCount != 8{
                        self.mentionQuery = String(mentionQuery)
                        addMentionToTextField(name: "guests")
                        self.mentionQuery = ""
                        self.isMentioning = false
                        self.theFilteredList = guestList.map{$0.username ?? ""}
                        
                    }
                    else if mentionQuery.count > 1 {
                        self.mentionQuery = String(mentionQuery)
                        textCount = textField.text?.count ?? 0
                        theFilteredGuestList = guestList
                        theFilteredGuestList = theFilteredGuestList.filter { ($0.username ?? "").contains(mentionQuery.replacingOccurrences(of: "@", with: "").lowercased()) }
                        guestImages = theFilteredGuestList.map { $0.imageUrl ?? "" }
                        guestUserNames = theFilteredGuestList.map { $0.username ?? ""}
                        guestUserNames = guestUserNames.filter { $0.lowercased().contains(mentionQuery.replacingOccurrences(of: "@", with: "").lowercased()) }
                        showDialog()
                    }
                }
            }

         
        }
    }

    
    func showDialog(){
        dropDown.textColor = UIColor.black
        dropDown.selectedTextColor = .black
        dropDown.textFont = UIFont.systemFont(ofSize: 15)
        dropDown.backgroundColor = UIColor.white
        dropDown.selectionBackgroundColor = .white
        dropDown.cellHeight = 60
        dropDown.anchorView = commentsTableView
        dropDown.direction = .bottom
        dropDown.dataSource = guestUserNames
        CommonMethods.showLog(self.TAG, "COUNTGUESTUSERNAME: | \(guestUserNames.count)")
        let width = self.view.frame.width
        dropDown.width = width - 20
        dropDown.cellNib = UINib(nibName: "SpinnerCell", bundle: nil)
        dropDown.customCellConfiguration = { (index: Index, item: String, cell: DropDownCell) -> Void in
            guard let cell = cell as? SpinnerCell else { return }
            cell.guestImage.layer.cornerRadius = cell.guestImage.frame.width / 2
            cell.guestImage.clipsToBounds = true
            
            if index >= 0 && index < self.guestImages.count{
                cell.guestImage.kf.setImage(with: URL(string: self.guestImages[index]),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
            }else {
                CommonMethods.showLog(self.TAG, "Index: not found")
            }
            
        }
        dropDown.show()
        
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            addMentionToTextField(name: guestUserNames[index])
            self.mentionQuery = ""
            self.isMentioning = false
//            self.getAllGuestNames()
//            self.theFilteredList = guestList.map{$0.username ?? ""}
            
        }
        
    }
    

    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        CommonMethods.showLog(self.TAG, "textFieldDidBeginEditing")
    }
    
     func addMentionToTextField(name: String) {
        mentionsIndexes[self.startMentionIndex] = name.count
         CommonMethods.showLog(self.TAG, "MentionQuery: \(self.mentionQuery)")
         let originalText = commentText.text ?? ""
         var newText = ""
         if self.mentionQuery.contains("@"){
             if commentText.text!.contains("@") && commentText.text!.count == 1{
                 CommonMethods.showLog(self.TAG, "MentionQuery If ")
                 commentText.text = "@\(name) "
                 textCount = commentText.text?.count ?? 0
                 handleBoldText()
             }
             else if self.mentionQuery == "@guests"{
                 CommonMethods.showLog(self.TAG, "MentionQuery Guests ")
                 commentText.text = self.mentionQuery
                 commentText.text?.append(" ")
                 textCount = commentText.text?.count ?? 0
                 handleBoldText()
             }
             else {
                 CommonMethods.showLog(self.TAG, "MentionQuery Else ")
                 commentText.text = commentText.text?.replacingOccurrences(of: self.mentionQuery, with: "@")
                 commentText.text?.append("\(name) ")
                 textCount = commentText.text?.count ?? 0
                 
             }
         }
    }
    
    func handleBoldText(){
        // Define the regular expression to match @names
        let regex = try! NSRegularExpression(pattern: "@\\w+", options: [])
//        let regex = try! NSRegularExpression(pattern: "@\\w+@\\w+", options: [])

        // Define the attributes for bold and dark black text
        let boldAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: commentText.font!.pointSize),
        .foregroundColor: UIColor.black
        ]

        // Create an attributed string from the text field's text
        let attributedText = NSMutableAttributedString(string: commentText.text!)

        // Find all matches of the regular expression in the text
        let matches = regex.matches(in: commentText.text!, options: [], range: NSRange(location: 0, length: commentText.text!.count))

        // Loop through the matches and apply the attributes
        for match in matches {
        attributedText.addAttributes(boldAttributes, range: match.range)
        }

        // Set the text field's attributed text
        commentText.attributedText = attributedText
    }

}

extension String {
    func findMentionText() -> [String] {
        var arr_hasStrings:[String] = []
        let regex = try? NSRegularExpression(pattern: "(@[a-zA-Z0-9_\\p{Arabic}\\p{N}]*)", options: [])
        if let matches = regex?.matches(in: self, options:[], range:NSMakeRange(0, self.count)) {
            for match in matches {
                arr_hasStrings.append(NSString(string: self).substring(with: NSRange(location:match.range.location, length: match.range.length )))
            }
        }
        return arr_hasStrings
    }
}

