//
//  AddNameVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit

class AddNameVC: BaseViewController, UITextFieldDelegate {
    
    let TAG = String(describing: AddNameVC.self)


    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var lastNameText: UITextField!
    @IBOutlet weak var firstNameText: UITextField!
    @IBOutlet weak var firstNameView: UIView!
    @IBOutlet weak var lastNameView: UIView!
    
    @IBOutlet weak var nextBtn: UIButton!
    
    var userModel : UserModel?, calledFrom = ""
    var viewModel : AddNameViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        viewModel = AddNameViewModel(vc: self)

        setUI()
    }
    
    func setUI(){
        
        if calledFrom == Constants.PROFILE{
            backView.isHidden = false
            firstNameText.text = userModel?.firstName
            lastNameText.text = userModel?.lastName
            nextBtn.setTitle("Update", for: .normal)
        }
        else{
            backView.isHidden = true
        }
        
        [firstNameView,lastNameView].forEach{view in
            CommonMethods.roundCornerFilled(uiView: view, borderColor: .mainColor, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.7)}

        CommonMethods.setPlaceholderColor(textFields: [firstNameText,lastNameText], color: .darkGray)


        CommonMethods.roundCornerFilled(uiView: nextBtn, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 25.0, borderWidth: 0.0)
        
        firstNameText.delegate = self
           lastNameText.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           if textField == firstNameText {
               lastNameText.becomeFirstResponder()
           }else if textField == lastNameText {
               textField.resignFirstResponder()
           }
           return true
           
       }
    
    
    @IBAction func backButtonPressed(_ sender: Any) {
        CommonMethods.dismiss(vc: self)
    }
    
    
    
    @IBAction func nextButtonPressed(_ sender: Any) {
        userModel?.firstName = firstNameText.text?.trim()
        userModel?.lastName = lastNameText.text?.trim()
        do{
                try viewModel?.validate()
                viewModel?.updateData()
        }
        catch let error as AddNameViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }
    


}
