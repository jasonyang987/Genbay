//
//  FirebaseAPI.swift
//  SoulSync
//
//  Created by Nap Works on 28/10/22.
//

import Foundation
import Firebase
import FirebaseFirestore

class FirebaseAPI {
    
    // MARK: - Properties
    let TAG = String(describing : FirebaseAPI.self)
    static let `default` = FirebaseAPI()
    var uid: String {
        return Auth.auth().currentUser?.uid ?? ""
    }
    var email: String {
        return Auth.auth().currentUser?.email ?? ""
    }
//    var chatListners : [ListnerModel] = []
    // MARK: - Types
    
    typealias FirebaseCompletion = (Error?) -> Void
    
    enum Endpoints {
        static let users = Database.database().reference().child("users")
        static let friends = Database.database().reference().child("friends")
        static let test = Database.database().reference().child("test")
        static let crowds = Database.database().reference().child("crowds")
        static let events = Database.database().reference().child("events")
        static let eventComments = Database.database().reference().child("event_comments")
        
        static let eventsFirestore = Firestore.firestore().collection("events")
        static let notificationsFirestore = Firestore.firestore().collection("notifications")
        static let eventCommentsFirestore = Firestore.firestore().collection("events_comments")
        
        
        static let posts = Database.database().reference().child("posts")
        static let party = Database.database().reference().child("party")
        static let postLikes = Database.database().reference().child("post_likes")
        static let postComments = Database.database().reference().child("post_comments")
        static let notifications = Database.database().reference().child("notifications")
        static let userPictures = Storage.storage().reference().child("user-pictures")
        static let crowdPictures = Storage.storage().reference().child("crowd-pictures")
        static let eventMemoryPictures = Storage.storage().reference().child("event-memory-pictures")
    }
    
    static func getEventPicturesReference(eventId: String) -> StorageReference {
        return Endpoints.eventMemoryPictures.child(eventId)
    }
    
    typealias LoginCompletion = (UserModel?, Error?) -> Void
    func login(email : String, password : String, completion: @escaping LoginCompletion) {
        Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
            if let error = error {
                CommonMethods.showLog(self.TAG, "error \(error)")
                completion(nil, error)
            } else {
                if let uid = result?.user.uid {
                    self.updateFCMToken(calledToAddToken: true) { success, error in
                        CommonMethods.showLog(self.TAG, "updateFCMToken success : \(success) error : \(error?.localizedDescription ?? "")")
                        if success{
                            UserDefaultsMapper.save(true, forKey: .isTokenUpdated)
                        }
                        self.getUser(uid) { (user, error) in
                            completion(user, error)
                        }
                    }
                }else {
                    completion(nil, nil)
                }
            }
        }
    }

    typealias CreateAccountCompletion = (UserModel?, Error?) -> Void
    
    func createAccount(email : String, password : String, completion: @escaping CreateAccountCompletion) {
        Auth.auth().createUser(withEmail: email, password: password) { (result, error) in
            if let error = error {
                completion(nil, error)
            }
            else {
                if let uid = result?.user.uid {
                    let user = UserModel(email: email)
                    user.id = uid
                    user.isLoggedIn = true
                    
                    Endpoints.users.child(uid).updateChildValues(user.firebaseRegisterParameters) { (error, result) in
                        if let error = error {
                            completion(nil, error)
                        } else {
                            try? UserDefaultsMapper.saveUser(user)
                            
                            completion(user, error)
                        }
                    }
                } else {
                    completion(nil, nil)
                }
            }
        }
    }

    typealias ResetPasswordCompletion = (Bool, Error?) -> Void
    func resetPassword(email : String, completion: @escaping ResetPasswordCompletion) {
        Auth.auth().sendPasswordReset(withEmail: email) { error in
            if let error = error {
                completion(false, error)
            } else {
                completion(true, nil)
            }
        }
    }
//
//    func updateEmail(email : String, completion : @escaping(Bool, String)->()){
//        Auth.auth().currentUser?.updateEmail(to: email) { error in
//            if let error = error{
//                completion(false, error.localizedDescription)
//            }else{
//                completion(true, "")
//            }
//        }
//    }
//    
    func changePassword(password : String, completion : @escaping(Bool, String)->()){
        Auth.auth().currentUser?.updatePassword(to: password) { error in
            if let error = error{
                completion(false, error.localizedDescription)
            }else{
                completion(true, "")
            }
        }
    }
//    
//    func checkSocialMediaSignin(_ fromLogin : Bool, userData : UserModel, credential : AuthCredential, completion : @escaping LoginCompletionResponse){
//        CommonMethods.showLog(TAG, "checkSocialMediaSignin called fromLogin : \(fromLogin)")
//        CommonMethods.showLog(TAG, "checkSocialMediaSignin credential.provider : \(credential.provider)")
//        self.checkEmailExists(ref: Endpoints.users, email: userData.email ?? "") { userExists in
//            CommonMethods.showLog(self.TAG, "checkEmailExists userExists : \(userExists)")
////            if userExists{
////                completion(false, false, "This account is already linked with customer account. Please try different email.", nil, nil)
////            }else{
//                /*
//                 1. Bool = Check Need to navigate to signup
//                 2. Bool = Login/Signup Success or not
//                 3. String = Api Response
//                 4. UserModel = User data
//                 5. AuthCredential = Social Media Auth Credentials
//                 */
//                self.signinWithCredential(fromLogin, userData: userData, credential: credential, completion: completion)
////            }
//        }
////        checkEmailExists(ref: Endpoints.admins, email: userData.email ?? "") { adminExists in
////            CommonMethods.showLog(self.TAG, "checkEmailExists adminExists : \(adminExists)")
////            if adminExists{
////                self.signinWithCredential(fromLogin, userData: userData, credential: credential, completion: completion)
////            }else{
////                self.checkEmailExists(ref: Endpoints.users, email: userData.email ?? "") { userExists in
////                    CommonMethods.showLog(self.TAG, "checkEmailExists userExists : \(userExists)")
////                    if userExists{
////                        completion(false, false, "This account is already linked with customer account. Please try different email.", nil, nil)
////                    }else{
////                        /*
////                         1. Bool = Check Need to navigate to signup
////                         2. Bool = Login/Signup Success or not
////                         3. String = Api Response
////                         4. UserModel = User data
////                         5. AuthCredential = Social Media Auth Credentials
////                         */
////                        self.signinWithCredential(fromLogin, userData: userData, credential: credential, completion: completion)
////                    }
////                }
////            }
////        }
//    }
//    
    func checkUsernameExists(ref : DatabaseReference, username : String, completion : @escaping(Bool)->()){
        CommonMethods.showLog(self.TAG, "checkEmailExists email : \(email)")
        CommonMethods.showLog(self.TAG, "checkEmailExists ref : \(ref)")
        ref.queryOrdered(byChild: "username")
            .queryEqual(toValue: username)
            .observeSingleEvent(of: .value, with: { snapshot in
                guard let dict = snapshot.value as? [String: Any] else {
                    completion(false)
                    return
                }
                if dict.count > 0{
                    completion(true)
                }else{
                    completion(false)
                }
            })
    }
//    
//    func login(vc : BaseViewController, email : String, password : String, completion : @escaping LoginCompletionResponse){
//        CommonMethods.showLog(TAG, "EMAIL : \(email)")
//        CommonMethods.showLog(TAG, "Password : \(password)")
//        let credential = EmailAuthProvider.credential(withEmail: email, password: password)
//        signinWithCredential(true, userData: UserModel(email: email), credential: credential, completion: completion)
//    }
//    
//    func signinWithCredential(_ fromLogin : Bool, userData : UserModel, credential : AuthCredential, completion : @escaping LoginCompletionResponse){
//        CommonMethods.showLog(TAG, "signinWithCredential called fromLogin : \(fromLogin)")
//        CommonMethods.showLog(TAG, "signinWithCredential credential.provider : \(credential.provider)")
//        if let user = Auth.auth().currentUser{
//            CommonMethods.showLog(TAG, "signinWithCredential uid : \(user.uid)")
//            CommonMethods.showLog(TAG, "signinWithCredential email : \(user.email ?? "")")
//            CommonMethods.showLog(TAG, "signinWithCredential displayName : \(user.displayName ?? "")")
//            //            self.printProviderData()
//            let matchedProvider = user.providerData.filter { $0.providerID == credential.provider }
//            CommonMethods.showLog(TAG, "signinWithCredential matchedProvider : \(matchedProvider.count)")
//            if matchedProvider.count > 0{
//                self.handleAfterSigninSuccess(fromLogin, provider: credential.provider, userData: userData, completion: completion)
//            }else{
//                Auth.auth().currentUser?.link(with: credential, completion: { authResult, error in
//                    if let error = error {
//                        CommonMethods.showLog(self.TAG, "signinWithCredential : error :\(error.localizedDescription)")
//                        completion(false, false, error.localizedDescription, nil, nil)
//                    } else {
//                        CommonMethods.showLog(self.TAG, "signinWithCredential : success")
//                        self.handleAfterSigninSuccess(fromLogin, provider: credential.provider, userData: userData, completion: completion)
//                    }
//                })
//            }
//        }else{
//            CommonMethods.showLog(TAG, "signinWithCredential user null")
//            Auth.auth().signIn(with: credential) { authResult, error in
//                if let error = error {
//                    CommonMethods.showLog(self.TAG, "signinWithCredential : error :\(error.localizedDescription)")
//                    completion(false, false, error.localizedDescription, nil, nil)
//                } else {
//                    CommonMethods.showLog(self.TAG, "signinWithCredential : success")
//                    self.handleAfterSigninSuccess(fromLogin, provider: credential.provider, userData: userData, completion: completion)
//                }
//            }
//        }
//    }
//    
//    func handleAfterSigninSuccess(_ fromLogin : Bool, provider : String, userData : UserModel, completion : @escaping LoginCompletionResponse){
//        if let user = Auth.auth().currentUser{
//            CommonMethods.showLog(self.TAG, "handleAfterSigninSuccess uid : \(user.uid)")
////            completion(false, true, "", nil, nil)
//            getUser(uid) { user, error in
//                if let error = error{
//                    completion(false, false, error.localizedDescription, nil, nil)
//                }else{
//                    if let user = user{
//                        try? UserDefaultsMapper.saveUser(user)
//                        completion(false, true, "", nil, nil)
//                    }else{
//                        userData.id = self.uid
//                        userData.createdAt = Date()
//                        userData.updatedAt = Date()
//                        //Additional
////                        userData.selectedService = "Spotify"
//                        Endpoints.users.child(self.uid).updateChildValues(userData.firebaseRegisterParameters) { (error, result) in
//                            if let error = error {
//                                completion(false, false, error.localizedDescription, nil, nil)
//                            } else {
////                                UserDefaultsMapper.savePassword(password)
//                                try? UserDefaultsMapper.saveUser(userData)
//                                completion(false, true, "", userData, nil)
//                            }
//                        }
//                        //                        FirestoreConnector.shared.save(data: userData, to: .Users(userId: user.uid)) { result in
//                        //                            switch result {
//                        //                            case .success:
//                        //                                UserDefaultsManager.saveUser(userData)
//                        //                                self.createCustomer { success, message in
//                        //                                    completion(false, success, message, nil, nil)
//                        //                                }
//                        //                                break
//                        //                            case .failure(let error):
//                        //                                completion(false, false, error.localizedDescription, nil, nil)
//                        //                            }
//                        //                        }
//                        //                        }
//                    }
//                }
//            }
//        }else{
//            CommonMethods.showLog(self.TAG, "handleAfterSigninSuccess uid null")
//            completion(false, false, Constants.COMMON_ERROR_MESSAGE, nil, nil)
//        }
//    }
    
}
