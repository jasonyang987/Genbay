//
//  MyWebviewDialogVC.swift
//  Gamaloto
//
//  Created by Nap Works on 20/05/21.
//

import UIKit
import WebKit

class MyWebviewDialogVC: UIViewController, WKNavigationDelegate {
    
    let TAG = String(describing: MyWebviewDialogVC.self)
    
    var urlString = ""
    var webView: WKWebView!,
        delegate : ButtonPressedDelegate?
    
    @IBOutlet weak var mainHeight: NSLayoutConstraint!
    @IBOutlet weak var loading: UIActivityIndicatorView!
    @IBOutlet weak var webViewContainer: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        CommonMethods.showLog(TAG, "urlString : \(urlString)")
//        CommonMethods.roundCornerFilled(uiView: self.view, borderColor: .white, backgroundColor: .white, cornerRadius: 10.0, borderWidth: 0.0)
////        CommonMethods.backgroundStyle(uiView: self.view)
//        loading.color = UIColor.primaryColorShade
//        loading.startAnimating()
//        loading.isHidden = false
//        CommonMethods.showLog(TAG, "URL : \(urlString)")
    }
    
    @IBAction func backButtonPressed(_ sender: Any) {
        CommonMethods.dismiss(vc: self)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let url = URL(string: urlString)
        let request = URLRequest(url: url!)
        let webView = WKWebView(frame: self.webViewContainer.frame)
        webView.backgroundColor = .transparent
        webView.navigationDelegate = self
        _ = webView.clearsContextBeforeDrawing
        webView.load(request)
        webView.allowsBackForwardNavigationGestures = true
        webViewContainer.addSubview(webView)
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        CommonMethods.showLog(TAG, "didFinish")
        CommonMethods.showLog(TAG, "didFinish url : \(webView.url?.absoluteString ?? "")")
        loading.stopAnimating()
        loading.isHidden = true
        checkAndFinish(webView: webView)
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        CommonMethods.showLog(TAG, "didStartProvisionalNavigation")
        CommonMethods.showLog(TAG, "didStart url : \(webView.url?.absoluteString ?? "")")
        loading.startAnimating()
        loading.isHidden = false
//        checkAndFinish(webView: webView)
    }
    
    func checkAndFinish(webView : WKWebView) {
        if let url = webView.url?.absoluteString{
            CommonMethods.showLog(TAG, "URL : \(url)")
//            self.delegate?.onProcessComplete(calledFrom: .websiteLogin)
//            CommonMethods.dismiss(vc: self)
                
//            if url == Constants.APP_LOGIN_SUCCESS_URL{
//                dismiss(animated: true) {
//                    self.delegate?.onProcessComplete(calledFrom: .websiteLogin)
//                }
//            }
        }
    }
}
