//
//  ForgotPasswordVC.swift
//  TruthAlibi
//
//  Created by Nap Works on 21/02/23.
//

import UIKit

class ForgotPasswordVC: BaseViewController, UITextFieldDelegate {
    
    let TAG = String(describing: ForgotPasswordVC.self)

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var sendOtpBtn: UIButton!
    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var emailView: UIView!
    
    var viewModel : ForgotPasswordViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = ForgotPasswordViewModel(vc: self)
        setUI()

    }
    
    func setUI(){
        
        if Constants.FILL_STATIC_FORM{
            emailText.text = "manvir@napworks.in"
        }
        
            CommonMethods.roundCornerFilled(uiView: emailView, borderColor: .mainColor, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        
        CommonMethods.setPlaceholderColor(textFields: [emailText], color: .darkGray)
        
        
        CommonMethods.roundCornerFilled(uiView: sendOtpBtn, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 25.0, borderWidth: 0.0)
        emailText.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func sendOtpButtonPressed(_ sender: Any) {
        CommonMethods.showLog(TAG, "sendOtpButtonPressed")
        do{
            try viewModel?.validate()
            viewModel?.resetPassword()
        }
        catch let error as ForgotPasswordViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }
    
    @IBAction func backButtonPressed(_ sender: Any) {
        CommonMethods.dismiss(vc: self)
    }
    
    
}
