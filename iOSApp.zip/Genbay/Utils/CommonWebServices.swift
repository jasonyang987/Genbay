//
//  CommonWebServices.swift
//  Genbay
//
//  Created by Nap Works on 13/12/23.
//

import Foundation
import Alamofire

class CommonWebServices{
    
    static let TAG = String(describing: CommonWebServices.self)
    static let appBaseUrl : URL = URL(string: Constants.BASE_URL)!
    static let userDefaults = UserDefaults.standard
    static var userData = UserDefaultsMapper.getUser()
    //
    
    //MARK: - Initial Headers
    static var headers : HTTPHeaders = [
        "Content-Type": "application/json",
//        "Authorization":"MXaSirfQoc6MlXuDSipzX6sYlBJFT6GHYG7%fsGlb",
    ]
    //MARK: - Set Header Method for the APIs that are using auth of logged in user in the header of the API request....
//    static func setHeader() {
//        userData = UserDefaultsMapper.getUser()
//        if userData?.email != ""{
//            self.headers = [
//                "Content-Type": "application/json",
//                "Authorization":"MXaSirfQoc6MlXuDSipzX6sYlBJFT6GHYG7%fsGlb",
//                "auth": userData?.auth ?? ""
//            ]
//        }else{
//            self.headers = [
//                "Content-Type": "application/json",
//                "Authorization":"MXaSirfQoc6MlXuDSipzX6sYlBJFT6GHYG7%fsGlb"
//            ]
//        }
//    }
    
    //MARK: - All Completions
    typealias LoginCompletion = (String, String, UserModel) -> Void
    typealias CommonModelCompletion = (String, String, CommonModel) -> Void
     
 
    //MARK: - 4. Send Forgot Password OTP API if user has forgot their password,
    static func sendFriendRequest(userId: String,receiverId: String, completion : @escaping CommonModelCompletion){

        let url = "\(appBaseUrl)sendFriendRequestSentNew"
        
        let params = ["userId": userId,
                      "receiverId": receiverId
        ] as [String : Any]
        
        
        CommonMethods.showLog(TAG, "Header in sendFriendRequest: \(headers)")
        CommonMethods.showLog(TAG, "params in sendFriendRequest: \(params)")
        let request = AF.request(url, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers)
        request.responseDecodable(of: CommonModel.self) { response in
            guard let result = response.value else {
                CommonMethods.showLog(TAG, "inside guard")
                completion(Constants.FAILURE, Constants.COMMON_ERROR_MESSAGE,CommonModel())
                return
            }
            if result.status == Constants.GO_TO_RESPONSE {
                completion(Constants.SUCCESS, result.message ?? "",result)
            }else if result.status == Constants.FAILURE_RESPONSE {
                completion(Constants.FAILURE, result.message ?? "", CommonModel())
            }else {
                completion(Constants.SESSION_OUT, Constants.COMMON_ERROR_MESSAGE,CommonModel())
            }
        }
    }
    
    static func confirmFriendRequest(userId: String,receiverId: String, completion : @escaping CommonModelCompletion){

        let url = "\(appBaseUrl)friendRequestAcceptedNew"
        
        let params = ["userId": userId,
                      "receiverId": receiverId
        ] as [String : Any]
        
        
        CommonMethods.showLog(TAG, "Header in confirmFriendRequest: \(headers)")
        CommonMethods.showLog(TAG, "params in confirmFriendRequest: \(params)")
        let request = AF.request(url, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers)
        request.responseDecodable(of: CommonModel.self) { response in
            guard let result = response.value else {
                CommonMethods.showLog(TAG, "inside guard")
                completion(Constants.FAILURE, Constants.COMMON_ERROR_MESSAGE,CommonModel())
                return
            }
            if result.status == Constants.GO_TO_RESPONSE {
                completion(Constants.SUCCESS, result.message ?? "",result)
            }else if result.status == Constants.FAILURE_RESPONSE {
                completion(Constants.FAILURE, result.message ?? "", CommonModel())
            }else {
                completion(Constants.SESSION_OUT, Constants.COMMON_ERROR_MESSAGE,CommonModel())
            }
        }
    }
    
    static func convertToString(_ array: [String]) -> String? {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: array, options: [])
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                return jsonString
            }
        } catch {
            print("Error converting array to JSON string: \(error)")
        }
        return nil
    }
    
    static func createNewEventFirestore(eventModel: EventModel,
                                        completion : @escaping CommonModelCompletion){
        var selectedMembers = "[]"
        var selectedCrowds = "[]"
        var acceptedCoHostInvites = "[]"
        var goingList = "[]"
        var pendingCoHostInvites = "[]"

        if let jsonString = convertToString(eventModel.selectedMembers ?? []) {
            print("JSON string: \(jsonString)")
            selectedMembers = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }

        if let jsonString = convertToString(eventModel.selectedCrowds ?? []) {
            print("JSON string: \(jsonString)")
            selectedCrowds = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }

        if let jsonString = convertToString(eventModel.acceptedCoHostInvites ?? []) {
            print("JSON string: \(jsonString)")
            acceptedCoHostInvites = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }

        if let jsonString = convertToString(eventModel.goingList ?? []) {
            print("JSON string: \(jsonString)")
            goingList = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }

        if let jsonString = convertToString(eventModel.pendingCoHostInvites ?? []) {
            print("JSON string: \(jsonString)")
            pendingCoHostInvites = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }
        
        let url = "\(appBaseUrl)eventCreatedNew"
        
        let params = ["id":eventModel.id,
                      "userId": eventModel.userId,
                      "title": eventModel.name,
                      "date": eventModel.date,
                      "startTime": eventModel.startTime,
                      "startTimestamp": eventModel.startTimestamp,
                      "dateTimestamp": eventModel.dateTimestamp,
                      "createdAt": eventModel.createdAt,
                      "updatedAt": eventModel.updatedAt,
                      "description": eventModel.description,
                      "isDateConfirmed": eventModel.isDateConfirmed,
                      "isDatePollCreated": eventModel.isDatePollCreated,
                      "isLocationConfirmed": eventModel.isLocationConfirmed,
                      "isLocationPollCreated": eventModel.isLocationPollCreated,
                      "isVisibleToAllSelected": eventModel.isVisibleToAllSelected,
                      "location": eventModel.location,
                      "name": eventModel.name,
                      "pollVotingDeadlineTime": eventModel.pollVotingDeadlineTime,
                      "pollVotingDeadlineTimestamp": eventModel.pollVotingDeadlineTimestamp,
                      "selectedMembers": selectedMembers,
                      "selectedCrowds": selectedCrowds,
                      "acceptedCoHostInvites": acceptedCoHostInvites,
                      "goingList": goingList,
                      "pendingCoHostInvites": pendingCoHostInvites
        ] as [String : Any]
        
        
        CommonMethods.showLog(TAG, "Header in createNewEventFirestore: \(headers)")
        CommonMethods.showLog(TAG, "params in createNewEventFirestore: \(params)")
        let request = AF.request(url, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers)
        request.responseDecodable(of: CommonModel.self) { response in
            CommonMethods.showLog(self.TAG, "RESPONSE IN CREATE NEW EVENT: \(response)")
            guard let result = response.value else {
                CommonMethods.showLog(TAG, "inside guard : \(response)")
                completion(Constants.FAILURE, Constants.COMMON_ERROR_MESSAGE,CommonModel())
                return
            }
            if result.status == Constants.GO_TO_RESPONSE {
                completion(Constants.SUCCESS, result.message ?? "",result)
            }else if result.status == Constants.FAILURE_RESPONSE {
                completion(Constants.FAILURE, result.message ?? "", CommonModel())
            }else {
                completion(Constants.SESSION_OUT, Constants.COMMON_ERROR_MESSAGE,CommonModel())
            }
        }
    }
    
    static func addEventMemory(userId: String,eventId: String,createdAt:Double,description:String,imagesList:[String], completion : @escaping CommonModelCompletion){
        
        var selectedImagesList = "[]"
        
        if let jsonString = convertToString(imagesList) {
            print("JSON string: \(jsonString)")
            selectedImagesList = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }

        let url = "\(appBaseUrl)addMemoryToEventNew"
        
        let params = ["userId": userId,
                      "eventId": eventId,
                      "createdAt": createdAt,
                      "description": description,
                      "imagesList": selectedImagesList
        ] as [String : Any]
        
        
        CommonMethods.showLog(TAG, "Header in addEventMemory : \(headers)")
        CommonMethods.showLog(TAG, "params in addEventMemory : \(params)")
        let request = AF.request(url, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers)
        request.responseDecodable(of: CommonModel.self) { response in
            
            guard let result = response.value else {
                CommonMethods.showLog(TAG, "inside guard : \(response)")
                completion(Constants.FAILURE, Constants.COMMON_ERROR_MESSAGE,CommonModel())
                return
            }
            if result.status == Constants.GO_TO_RESPONSE {
                completion(Constants.SUCCESS, result.message ?? "",result)
            }else if result.status == Constants.FAILURE_RESPONSE {
                completion(Constants.FAILURE, result.message ?? "", CommonModel())
            }else {
                completion(Constants.SESSION_OUT, Constants.COMMON_ERROR_MESSAGE,CommonModel())
            }
        }
    }
    
    static func goingList(userId: String,eventId: String,type:String, completion : @escaping CommonModelCompletion){
        
        let url = "\(appBaseUrl)goingListNew"
        
        let params = ["userId": userId,
                      "eventId": eventId,
                      "type": type
        ] as [String : Any]
        
        
        CommonMethods.showLog(TAG, "Header in goingList : \(headers)")
        CommonMethods.showLog(TAG, "params in goingList : \(params)")
        let request = AF.request(url, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers)
        request.responseDecodable(of: CommonModel.self) { response in
            CommonMethods.showLog(self.TAG, "RESPONSE IN GOING LIST: \(response)")
            guard let result = response.value else {
                CommonMethods.showLog(TAG, "inside guard : \(response)")
                completion(Constants.FAILURE, Constants.COMMON_ERROR_MESSAGE,CommonModel())
                return
            }
            if result.status == Constants.GO_TO_RESPONSE {
                completion(Constants.SUCCESS, result.message ?? "",result)
            }else if result.status == Constants.FAILURE_RESPONSE {
                completion(Constants.FAILURE, result.message ?? "", CommonModel())
            }else {
                completion(Constants.SESSION_OUT, Constants.COMMON_ERROR_MESSAGE,CommonModel())
            }
        }
    }
    
    static func addComment(userId: String,eventId: String,createdAt:Double, comment: String, completion : @escaping CommonModelCompletion){
        
        let url = "\(appBaseUrl)addCommentInEventDiscussionNew"
        
        let params = ["userId": userId,
                      "eventId": eventId,
                      "createdAt": createdAt,
                      "comment": comment
        ] as [String : Any]
        
        
        CommonMethods.showLog(TAG, "Header in goingList : \(headers)")
        CommonMethods.showLog(TAG, "params in goingList : \(params)")
        let request = AF.request(url, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers)
        request.responseDecodable(of: CommonModel.self) { response in
            CommonMethods.showLog(self.TAG, "RESPONSE IN GOING LIST: \(response)")
            guard let result = response.value else {
                CommonMethods.showLog(TAG, "inside guard : \(response)")
                completion(Constants.FAILURE, Constants.COMMON_ERROR_MESSAGE,CommonModel())
                return
            }
            if result.status == Constants.GO_TO_RESPONSE {
                completion(Constants.SUCCESS, result.message ?? "",result)
            }else if result.status == Constants.FAILURE_RESPONSE {
                completion(Constants.FAILURE, result.message ?? "", CommonModel())
            }else {
                completion(Constants.SESSION_OUT, Constants.COMMON_ERROR_MESSAGE,CommonModel())
            }
        }
    }
    
    static func editEventFirestore(eventModel: EventModel,
                                        completion : @escaping CommonModelCompletion){
        CommonMethods.showLog(self.TAG, "PENDING_CO_HOST: \(eventModel.pendingCoHostInvites)")
        var selectedMembers = "[]"
        var selectedCrowds = "[]"
        var acceptedCoHostInvites = "[]"
        var goingList = "[]"
        var pendingCoHostInvites = "[]"

        if let jsonString = convertToString(eventModel.selectedMembers ?? []) {
            print("JSON string: \(jsonString)")
            selectedMembers = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }

        if let jsonString = convertToString(eventModel.selectedCrowds ?? []) {
            print("JSON string: \(jsonString)")
            selectedCrowds = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }

        if let jsonString = convertToString(eventModel.acceptedCoHostInvites ?? []) {
            print("JSON string: \(jsonString)")
            acceptedCoHostInvites = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }

        if let jsonString = convertToString(eventModel.goingList ?? []) {
            print("JSON string: \(jsonString)")
            goingList = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }

        if let jsonString = convertToString(eventModel.pendingCoHostInvites ?? []) {
            print("JSON string: \(jsonString)")
            pendingCoHostInvites = jsonString
        } else {
            print("Conversion to JSON string failed.")
        }
        
        let url = "\(appBaseUrl)eventUpdatedNew"
        
        let params = ["eventId":eventModel.id,
                      "userId": eventModel.userId,
                      "title": eventModel.name,
                      "date": eventModel.date,
                      "startTime": eventModel.startTime,
                      "startTimestamp": eventModel.startTimestamp,
                      "dateTimestamp": eventModel.dateTimestamp,
                      "createdAt": eventModel.createdAt,
                      "updatedAt": eventModel.updatedAt,
                      "description": eventModel.description,
                      "isDateConfirmed": eventModel.isDateConfirmed,
                      "isDatePollCreated": eventModel.isDatePollCreated,
                      "isLocationConfirmed": eventModel.isLocationConfirmed,
                      "isLocationPollCreated": eventModel.isLocationPollCreated,
                      "isVisibleToAllSelected": eventModel.isVisibleToAllSelected,
                      "location": eventModel.location,
                      "name": eventModel.name,
                      "pollVotingDeadlineTime": eventModel.pollVotingDeadlineTime,
                      "pollVotingDeadlineTimestamp": eventModel.pollVotingDeadlineTimestamp,
                      "selectedMembers": selectedMembers,
                      "selectedCrowds": selectedCrowds,
                      "acceptedCoHostInvites": acceptedCoHostInvites,
                      "goingList": goingList,
                      "pendingCoHostInvites": pendingCoHostInvites
        ] as [String : Any]
        
        
        CommonMethods.showLog(TAG, "Header in editEventFirestore: \(headers)")
        CommonMethods.showLog(TAG, "params in editEventFirestore: \(params)")
        let request = AF.request(url, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers)
        request.responseDecodable(of: CommonModel.self) { response in
            guard let result = response.value else {
                CommonMethods.showLog(TAG, "inside guard : \(response)")
                completion(Constants.FAILURE, Constants.COMMON_ERROR_MESSAGE,CommonModel())
                return
            }
            if result.status == Constants.GO_TO_RESPONSE {
                completion(Constants.SUCCESS, result.message ?? "",result)
            }else if result.status == Constants.FAILURE_RESPONSE {
                completion(Constants.FAILURE, result.message ?? "", CommonModel())
            }else {
                completion(Constants.SESSION_OUT, Constants.COMMON_ERROR_MESSAGE,CommonModel())
            }
        }
    }
    

}
