//
//  GroupTabVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit

class EventsVC: BaseViewController, MyEventDetailVCDelegate {
 
    
    let TAG = String(describing: EventsVC.self)
    @IBOutlet weak var upcomingBtnView: UIView!
    @IBOutlet weak var pastBtnView: UIView!
    @IBOutlet weak var asBothBtnView: UIView!
    @IBOutlet weak var asGuestBtnView: UIView!
    @IBOutlet weak var asHostBtnView: UIView!
    @IBOutlet weak var upcomingBtn: UIButton!
    @IBOutlet weak var pastBtn: UIButton!
    @IBOutlet weak var asBothBtn: UIButton!
    @IBOutlet weak var asGuestBtn: UIButton!
    @IBOutlet weak var asHostBtn: UIButton!
    @IBOutlet weak var eventsTableView: UITableView!
    @IBOutlet weak var noEventsView: UIView!
    @IBOutlet weak var upcomingPastView: UIView!
    @IBOutlet weak var guestHostView: UIView!
    @IBOutlet weak var noEventsLabel: UILabel!
    @IBOutlet weak var pageTitle: UILabel!
    
    let regularFont = UIFont.systemFont(ofSize: 14, weight: .regular)
    let boldFont = UIFont.systemFont(ofSize: 14, weight: .bold)
    var eventList: [EventModel] = []
    var calledFrom : String = ""
    var userModel: UserModel?
    var isUpcoming: Bool = true
    var isHost: Bool = false
    var isBoth: Bool = true
    var upcomingBtnPressed: Bool = true
    var pastBtnPressed: Bool = false
    var asBothBtnPressed: Bool = true
    var asGuestBtnPressed: Bool = false
    var asHostBtnPressed: Bool = false
    var isCoHost: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        let nib = UINib(nibName: "EventTVC", bundle: nil)
        eventsTableView.register(nib, forCellReuseIdentifier: "EventTVC")
        eventsTableView.delegate = self
        eventsTableView.dataSource = self
        
        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(handleNotification(notification:)), name: .eventVC, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.handleUpdatedEventsList(_:)), name: .updatedEventsList, object: nil)
        setUI()
    }
    
    func handleNotificationData(_ type:String,_ eventModel:EventModel){
        CommonMethods.showLog(TAG, "handleNotificationData")
        for (index, data) in eventList.enumerated() {
            CommonMethods.showLog(TAG, "Item \(index): \(data)")
            if data.id == eventModel.id{
                if type == Constants.DELETE_EVENT{
                    eventList.remove(at: index)
                }
                else{
                    eventList[index] = eventModel
                    self.checkAndShowMessage()
                }
                
            }
        }
        self.eventsTableView.reloadData()
    }
    
    func checkAndShowMessage(){
        var message = ""
        if isHost {
            message = "It seems like that you have not been created an event yet"
        }
        else {
            message = "It seems like that you have not been added in any event yet"
        }
        if self.eventList.count == 0 {
            self.noEventsView.isHidden = false
            self.noEventsLabel.text = message
        }else {
            self.noEventsView.isHidden = true
        }
    }
    
    //MARL: - delegate method to fetch events after host date or location confirmation
    func fetchEventsAfterConfirm() {
        if calledFrom == Constants.VIEW_EVENT{
            upcomingPastView.isHidden = false
            guestHostView.isHidden = false
            pageTitle.text = "Your Events"
            getUpcomingHostEvents()
        }
        else{
            upcomingPastView.isHidden = true
            guestHostView.isHidden = true
            pageTitle.text = "Events For \(eventList[0].date ?? "")"
        }
    }
    
    private func setUI(){
        CommonMethods.roundCornerFilled(uiView: upcomingBtnView, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: asBothBtnView, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: asHostBtnView, borderColor: .clear, backgroundColor: .white, cornerRadius: 0, borderWidth: 0)
        asHostBtn.titleLabel?.font = regularFont
        
        noEventsView.isHidden = true
        
        if calledFrom == Constants.VIEW_EVENT{
            upcomingPastView.isHidden = false
            guestHostView.isHidden = false
            pageTitle.text = "Your Events"
            getAllUpcomingEvents()
        }
        else{
            upcomingPastView.isHidden = true
            guestHostView.isHidden = true
            pageTitle.text = "Events For \(eventList[0].date ?? "")"
        }
    }

    private func getPastGuestEvents(){
        showProgressHUD()
        let friendList = AppDelegate.shared.friendList
        var userIds : [String] = []
        friendList.forEach{ data in
            CommonMethods.showLog(self.TAG, "IDS : \(data.id ?? "")")
            userIds.append(data.id ?? "")
        }
        FirebaseAPI.default.getPastGuestEventFirestore(userIds: userIds,userId: userModel?.id ?? ""){list,error in
            self.hideProgressHUD()
            self.eventList = list.sorted{
                $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
            }
            if self.eventList.count == 0 {
                self.noEventsView.isHidden = false
                self.noEventsLabel.text = "It seems like that you have not been added in any event yet"
            }else {
                self.noEventsView.isHidden = true
            }
            self.eventsTableView.reloadData()
            
        }
    }
    
    func getUpcomingHostEvents(){
        showProgressHUD()
        var coHostList = [EventModel]()
        let name = "\(userModel?.firstName ?? "") \(userModel?.lastName ?? "")"
        FirebaseAPI.default.getUpcomingHostEventFirestore(name:name,userId: userModel?.id ?? ""){list,error in
            self.eventList = list.sorted{
                $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
            }
            FirebaseAPI.default.getUpcomingCoHostEventFirestore(userId: self.userModel?.id ?? ""){list,error in
                self.hideProgressHUD()
                coHostList = list.sorted{
                    $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
                }
                let calendar = Calendar.current
                let currentDate = Date()
                let startOfCurrentDay = calendar.startOfDay(for: currentDate)
                let startOfCurrentDayTimestamp = startOfCurrentDay.timeIntervalSince1970
                self.eventList += coHostList.filter({$0.dateTimestamp ?? 0 >= startOfCurrentDayTimestamp})
                if self.eventList.count == 0 {
                    self.noEventsView.isHidden = false
                    self.noEventsLabel.text = "It seems like that you have not been created an event yet"
                }else {
                    self.noEventsView.isHidden = true
                }
                self.eventsTableView.reloadData()
            }
        }
    }

    func getPastHostEvents(){
        showProgressHUD()
        var coHostList = [EventModel]()
        let name = "\(userModel?.firstName ?? "") \(userModel?.lastName ?? "")"
        FirebaseAPI.default.getPastHostEventFirestore(name:name,userId: userModel?.id ?? ""){list,error in
            self.eventList = list.sorted{
                $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
            }
            
            FirebaseAPI.default.getUpcomingCoHostEventFirestore(userId: self.userModel?.id ?? ""){list,error in
                self.hideProgressHUD()
                coHostList = list.sorted{
                    $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
                }
                let calendar = Calendar.current
                let currentDate = Date()
                let startOfCurrentDay = calendar.startOfDay(for: currentDate)
                let startOfCurrentDayTimestamp = startOfCurrentDay.timeIntervalSince1970
                self.eventList += coHostList.filter({$0.dateTimestamp ?? 0 < startOfCurrentDayTimestamp})
                if self.eventList.count == 0 {
                    self.noEventsView.isHidden = false
                    self.noEventsLabel.text = "It seems like that you have not been created an event yet"
                }else {
                    self.noEventsView.isHidden = true
                }
                self.eventsTableView.reloadData()
            }

        }
    }
  
    private func getUpcomingGuestEvents(){
        showProgressHUD()
        let friendList = AppDelegate.shared.friendList
        var userIds : [String] = []
        friendList.forEach{ data in
            CommonMethods.showLog(self.TAG, "IDS : \(data.id ?? "")")
            userIds.append(data.id ?? "")
        }
        FirebaseAPI.default.getUpcomingGuestEventFirestore(userIds:userIds,userId: userModel?.id ?? ""){list,error in
            self.hideProgressHUD()
            self.eventList = list.sorted{
                $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
            }
            if self.eventList.count == 0 {
                self.noEventsView.isHidden = false
                self.noEventsLabel.text = "It seems like that you have not been added in any event yet"
            }else {
                self.noEventsView.isHidden = true
            }
            self.eventsTableView.reloadData()
        }
    }
    
    private func getAllUpcomingEvents(){
        showProgressHUD()
        var coHostList = [EventModel]()
        let name = "\(userModel?.firstName ?? "") \(userModel?.lastName ?? "")"
        FirebaseAPI.default.getUpcomingHostEventFirestore(name:name,userId: userModel?.id ?? ""){list,error in
            self.eventList = list.sorted{
                $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
            }
            
            FirebaseAPI.default.getUpcomingCoHostEventFirestore(userId: self.userModel?.id ?? ""){list,error in
                coHostList = list.sorted{
                    $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
                }
                let calendar = Calendar.current
                let currentDate = Date()
                let startOfCurrentDay = calendar.startOfDay(for: currentDate)
                let startOfCurrentDayTimestamp = startOfCurrentDay.timeIntervalSince1970
                self.eventList += coHostList.filter({$0.dateTimestamp ?? 0 >= startOfCurrentDayTimestamp})
                
                let friendList = AppDelegate.shared.friendList
                var userIds : [String] = []
                friendList.forEach{ data in
                    userIds.append(data.id ?? "")
                }
                FirebaseAPI.default.getUpcomingGuestEventFirestore(userIds:userIds,userId: self.userModel?.id ?? ""){list,error in
                    self.hideProgressHUD()
                    self.eventList += list.sorted{
                        $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
                    }
                    if self.eventList.count == 0 {
                        self.noEventsView.isHidden = false
                        self.noEventsLabel.text = "It seems like that you have not been created or added in any event yet"
                    }else {
                        self.noEventsView.isHidden = true
                    }
                    self.eventsTableView.reloadData()
                }
            }
            
           
        }
    }
    
    private func getAllPastEvents(){
        showProgressHUD()
        var coHostList = [EventModel]()
        let name = "\(userModel?.firstName ?? "") \(userModel?.lastName ?? "")"
        FirebaseAPI.default.getPastHostEventFirestore(name:name,userId: userModel?.id ?? ""){list,error in
            self.eventList = list.sorted{
                $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
            }
            
            FirebaseAPI.default.getUpcomingCoHostEventFirestore(userId: self.userModel?.id ?? ""){list,error in
                coHostList = list.sorted{
                    $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
                }
                let calendar = Calendar.current
                let currentDate = Date()
                let startOfCurrentDay = calendar.startOfDay(for: currentDate)
                let startOfCurrentDayTimestamp = startOfCurrentDay.timeIntervalSince1970
                self.eventList += coHostList.filter({$0.dateTimestamp ?? 0 < startOfCurrentDayTimestamp})
                let friendList = AppDelegate.shared.friendList
                var userIds : [String] = []
                friendList.forEach{ data in
                    userIds.append(data.id ?? "")
                }
                FirebaseAPI.default.getPastGuestEventFirestore(userIds: userIds,userId: self.userModel?.id ?? ""){list,error in
                    self.hideProgressHUD()
                    self.eventList += list.sorted{
                        $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
                    }
                    if self.eventList.count == 0 {
                        self.noEventsView.isHidden = false
                        self.noEventsLabel.text = "It seems like that you have not been created or added in any event yet"
                    }else {
                        self.noEventsView.isHidden = true
                    }
                    self.eventsTableView.reloadData()

                }
            }
            
        }
    }
    
    private func changeBtnBackgroundAndLabel(view1: UIView, view2: UIView, btn1: UIButton, btn2: UIButton){
        CommonMethods.roundCornerFilled(uiView: view1, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: view2, borderColor: .white, backgroundColor: .white, cornerRadius: 0, borderWidth: 0)
        btn1.titleLabel?.font = boldFont
        btn2.titleLabel?.font = regularFont
    }
    
    private func handleButtonClick(view1: UIView, view2: UIView, view3: UIView, btn1: UIButton, btn2: UIButton, btn3: UIButton){
        CommonMethods.roundCornerFilled(uiView: view1, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: view2, borderColor: .white, backgroundColor: .white, cornerRadius: 0, borderWidth: 0)
        CommonMethods.roundCornerFilled(uiView: view3, borderColor: .white, backgroundColor: .white, cornerRadius: 0, borderWidth: 0)
        btn1.titleLabel?.font = boldFont
        btn2.titleLabel?.font = regularFont
        btn3.titleLabel?.font = regularFont
    }

    @IBAction func backPressed(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func upcomingBtnPressed(_ sender: UIButton) {
        if upcomingBtnPressed {
            return
        }else {
            isUpcoming = true
            changeBtnBackgroundAndLabel(view1: upcomingBtnView, view2: pastBtnView, btn1: upcomingBtn, btn2: pastBtn)
            if isBoth {
                getAllUpcomingEvents()
            }else if isHost {
                getUpcomingHostEvents()
            }else {
                getUpcomingGuestEvents()
            }
            upcomingBtnPressed = true
            pastBtnPressed = false
        }
     
    }
    
    @IBAction func pastBtnPressed(_ sender: UIButton) {
        CommonMethods.showLog(self.TAG, "isHost: \(isHost)")
        if pastBtnPressed {
            return
        }else {
            isUpcoming = false
            changeBtnBackgroundAndLabel(view1: pastBtnView, view2: upcomingBtnView, btn1: pastBtn, btn2: upcomingBtn)
            CommonMethods.showLog(self.TAG, "isHost: \(isHost)")
            if isBoth {
                CommonMethods.showLog(self.TAG, "getting all past events")
                getAllPastEvents()
            }else if isHost {
                getPastHostEvents()
                CommonMethods.showLog(self.TAG, "getting host past events")

            }else {
                getPastGuestEvents()
                CommonMethods.showLog(self.TAG, "getting guest past events")
            }
            upcomingBtnPressed = false
            pastBtnPressed = true

        }
 
    }
    
    
    @IBAction func asBothBtnPressed(_ sender: UIButton) {
        if asBothBtnPressed {
            return
        }else {
            isHost = true
            isBoth = true
            handleButtonClick(view1: asBothBtnView, view2: asHostBtnView, view3: asGuestBtnView, btn1: asBothBtn, btn2: asHostBtn, btn3: asGuestBtn)
            if isUpcoming {
                getAllUpcomingEvents()
            }else {
                getAllPastEvents()
            }
            
            asBothBtnPressed = true
            asGuestBtnPressed = false
            asHostBtnPressed = false
        }
     
  
    }
    
    @IBAction func asGuestBtnPressed(_ sender: UIButton) {
        if asGuestBtnPressed {
            return
        }else {
            isHost = false
            isBoth = false
            handleButtonClick(view1: asGuestBtnView, view2: asHostBtnView, view3: asBothBtnView, btn1: asGuestBtn, btn2: asHostBtn, btn3: asBothBtn)
            if isUpcoming {
                getUpcomingGuestEvents()
            }else {
                getPastGuestEvents()
            }
            
            asBothBtnPressed = false
            asGuestBtnPressed = true
            asHostBtnPressed = false
        }
       
    }
    
    @IBAction func asHostBtnPressed(_ sender: UIButton) {
        isHost = true
        isBoth = false
        if asHostBtnPressed {
            return
        }else {
            handleButtonClick(view1: asHostBtnView, view2: asGuestBtnView, view3: asBothBtnView, btn1: asHostBtn, btn2: asGuestBtn, btn3: asBothBtn)
            if isUpcoming {
                getUpcomingHostEvents()
            }else {
                getPastHostEvents()
            }
            
            asBothBtnPressed = false
            asGuestBtnPressed = false
            asHostBtnPressed = true
        }
        
        CommonMethods.showLog(self.TAG, "isHost: \(isHost)")
      
    }
}

extension EventsVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return eventList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventTVC", for: indexPath) as! EventTVC
        cell.selectionStyle = .none
        if let userId = userModel?.id {
            if eventList[indexPath.row].userId == userId{
                isHost = true
            }else {
                isHost = false
            }
            
            if let acceptedCoHostInvites = eventList[indexPath.row].acceptedCoHostInvites {
                if acceptedCoHostInvites.contains(userId){
                    isHost = true
                }
            }
        }
        
        
       
        cell.configure(data:eventList[indexPath.row])
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        CommonMethods.showLog(self.TAG, "eventId: \(eventList[indexPath.row].id)")
        Navigations.showMyEventDetailPopup(navVc:self.navigationController,viewController: self,eventId:eventList[indexPath.row].id ?? "",isHost:isHost, delegate: self, isUpcoming: isUpcoming)
    }
    
}

extension EventsVC: EventDetailVCDelegate {
    func pushToMemoriesVC(vc: UIViewController, eventTitle: String, eventDate: String) {
        guard let memoriesVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MemoriesVC") as? MemoriesVC else {
            return
        }
        memoriesVC.eventTitle = eventTitle
        memoriesVC.eventDate = eventDate
        navigationController?.pushViewController(memoriesVC, animated: true)
        vc.dismiss(animated: true)
    }
    
    func pushToCommentsVC(vc: UIViewController, eventTitle: String, eventDate: String) {
        guard let commentsVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CommentsVC") as? CommentsVC else {
            return
        }
        commentsVC.eventTitle = eventTitle
        commentsVC.eventDate = eventDate
        navigationController?.pushViewController(commentsVC, animated: true)
        vc.dismiss(animated: true)
    }
    
    func pushToGuestListVC(vc: UIViewController, eventTitle: String, eventDate: String) {
        guard let guestListVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "GuestListVC") as? GuestListVC else {
            return
        }
//        guestListVC.eventTitle = eventTitle
//        guestListVC.eventDate = eventDate
        navigationController?.pushViewController(guestListVC, animated: true)
        vc.dismiss(animated: true)
    }
}
extension EventsVC{
    
    @objc func handleNotification(notification: NSNotification) {
        if let value = notification.userInfo as? [String : Any]{
            CommonMethods.showLog(TAG, "handleNotification value : \(value)")
            if let type = value["type"] as? String{
                if type == Constants.UPDATE_EVENT{
                    if let eventModel = value["eventModel"] as? EventModel{
                        handleNotificationData(type,eventModel)
                    }
                }else if type == Constants.DELETE_EVENT{
                    if let eventModel = value["eventModel"] as? EventModel{
                        handleNotificationData(type,eventModel)
                    }
                }
            }
        }
    }
    
    @objc func handleUpdatedEventsList(_ notification: Notification) {
        if let updatedEventsList = notification.object as? [EventModel] {
            self.eventList = updatedEventsList
            self.eventsTableView.reloadData()
            CommonMethods.showLog(self.TAG, "updatedguestlist: \(updatedEventsList)")
        }
    }
    
}
