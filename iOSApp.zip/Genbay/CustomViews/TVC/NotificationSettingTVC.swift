//
//  NotificationSettingTVC.swift
//  Genbay
//
//  Created by Nap Works on 22/08/23.
//

import UIKit

class NotificationSettingTVC: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
