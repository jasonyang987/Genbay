//
//  AdminLoginModel.swift
//  TruthAlibi
//
//  Created by Nap Works on 14/02/23.
//

import Foundation
import UIKit
import Firebase

class UserModel: Codable{
    
    // MARK: - Properties
    
    var id: String?
    var firstName: String?
    var lastName: String?
    var email: String?
    var imageUrl: String?
    var username: String?
    var createdAt: Date?
    var updatedAt: Date?
    var isDeleted: Bool?
    var isLoggedIn: Bool?
    var isSelected: Bool = false
    var tokens: [String]?
    var friendStatus : FriendRequestType?
    var notificationSettings: NotificationSettingsModel?
    
    enum CodingKeys: String, CodingKey {
        case id
        case firstName
        case lastName
        case email
        case imageUrl
        case username
        case createdAt = "created_at"
        case updatedAt = "updated_at"
        case isDeleted
        case isLoggedIn
        case isSelected
        case tokens
        case friendStatus
        case notificationSettings
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(String.self, forKey: .id)
        firstName = try container.decodeIfPresent(String.self, forKey: .firstName)
        lastName = try container.decodeIfPresent(String.self, forKey: .lastName)
        email = try container.decodeIfPresent(String.self, forKey: .email)
        imageUrl = try container.decodeIfPresent(String.self, forKey: .imageUrl)
        username = try container.decodeIfPresent(String.self, forKey: .username)
        let mCreatedAt = try container.decodeIfPresent(Double.self, forKey: .createdAt)
        let mUpdatedAt = try container.decodeIfPresent(Double.self, forKey: .updatedAt)
        createdAt = Date(timeIntervalSince1970: mCreatedAt ?? 0.0)
        updatedAt = Date(timeIntervalSince1970: mUpdatedAt ?? 0.0)
        isDeleted = try container.decodeIfPresent(Bool.self, forKey: .isDeleted)
        tokens = try container.decodeIfPresent([String].self, forKey: .tokens)
        isLoggedIn = try container.decodeIfPresent(Bool.self, forKey: .isLoggedIn)
        isSelected = try container.decodeIfPresent(Bool.self, forKey: .isSelected) ?? false
        friendStatus = try container.decodeIfPresent(FriendRequestType.self, forKey: .friendStatus)
        notificationSettings = try container.decodeIfPresent(NotificationSettingsModel.self, forKey: .notificationSettings)
    }
    
    init()
    {
        
    }
    
    init(email: String){
        self.email = email
        self.createdAt = Date()
        self.updatedAt = Date()
        self.isDeleted = false
    }
    
    init(firstName: String,lastName:String, email: String){
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.createdAt = Date()
        self.updatedAt = Date()
        self.isDeleted = false
    }
    
    init(firstName: String,lastName:String, gender: String, dob: String){
        self.firstName = firstName
        self.lastName = lastName
        self.createdAt = Date()
        self.updatedAt = Date()
    }
    
    var firebaseRegisterParameters: [String: Any] {
        return [
            "id":id ?? "",
            "email": email ?? "",
            "createdAt": Int(createdAt?.timeIntervalSince1970 ?? 0),
            "updatedAt": Int(updatedAt?.timeIntervalSince1970 ?? 0),
            "isDeleted":isDeleted ?? false,
            
        ]
    }
    
    var changeDeleteStatus:[String:Any]{
        return[
            "isDeleted": true
        ]
    }
    
    var notificationSettingsParams:[String:Any]{
        return[
            "notificationSettings": notificationSettings?.notificationSettingsParameters ?? "",
//            "tokens":tokens
        ]
    }
    
//    var tokenParams:[String:Any]{
//        return[
//            "tokens":tokens
//        ]
//    }
    
    var updateNameParameters: [String: Any] {
        return [
            "firstName": firstName ?? "",
            "lastName": lastName ?? "",
            "updatedAt": Int(Date().timeIntervalSince1970),
//            "tokens": tokens
        ]
    }
    
    var updateUsernameParameters: [String: Any] {
        return [
            "username": username ?? "",
            "updatedAt": Int(Date().timeIntervalSince1970),
//            "tokens": tokens
        ]
    }
    
    var updateImageParameters: [String: Any] {
        return [
            "imageUrl": imageUrl ?? "",
            "updatedAt": Int(Date().timeIntervalSince1970),
//            "tokens": tokens
        ]
    }
}

class NotificationSettingsModel: Codable{
    var muteAllPushNotifications: Bool?
    var friendRequests: Bool?
    var inviteToEvents: Bool?
    var eventAttendanceUpdates: Bool?
    var newEventMemories: Bool?
    var discussionComments: Bool?
    var mentions: Bool?

    
    enum CodingKeys: CodingKey {
        case muteAllPushNotifications
        case friendRequests
        case inviteToEvents
        case eventAttendanceUpdates
        case newEventMemories
        case discussionComments
        case mentions
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.muteAllPushNotifications = try container.decodeIfPresent(Bool.self, forKey: .muteAllPushNotifications)
        self.friendRequests = try container.decodeIfPresent(Bool.self, forKey: .friendRequests)
        self.inviteToEvents = try container.decodeIfPresent(Bool.self, forKey: .inviteToEvents)
        self.eventAttendanceUpdates = try container.decodeIfPresent(Bool.self, forKey: .eventAttendanceUpdates)
        self.newEventMemories = try container.decodeIfPresent(Bool.self, forKey: .newEventMemories)
        self.discussionComments = try container.decodeIfPresent(Bool.self, forKey: .discussionComments)
        self.mentions = try container.decodeIfPresent(Bool.self, forKey: .mentions)
    }
    
    init()
    {
        
    }

    var notificationSettingsParameters: [String: Any] {
        return [
            "muteAllPushNotifications": muteAllPushNotifications ?? true,
            "friendRequests": friendRequests ?? true,
            "inviteToEvents": inviteToEvents ?? true,
            "eventAttendanceUpdates": eventAttendanceUpdates ?? true,
            "newEventMemories": newEventMemories ?? true,
            "discussionComments": discussionComments ?? true,
            "mentions": mentions ?? true
            
        ]
    }

}

