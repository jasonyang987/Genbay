//
//  CrowdModel.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import Foundation
import UIKit
import Firebase

class CrowdModel: Codable{
    
    // MARK: - Properties
    
    var id: String?
    var userId: String?
    var name: String?
    var imageUrl: String?
    var description: String?
    var membersList: [String]?
    var createdAt: Date?
    var updatedAt: Date?
    var isSelected: Bool = false
    
    enum CodingKeys: String, CodingKey {
        case id
        case userId
        case membersList
        case name
        case imageUrl
        case description
        case isSelected
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(String.self, forKey: .id)
        userId = try container.decodeIfPresent(String.self, forKey: .userId)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        imageUrl = try container.decodeIfPresent(String.self, forKey: .imageUrl)
        description = try container.decodeIfPresent(String.self, forKey: .description)
        membersList = try container.decodeIfPresent([String].self, forKey: .membersList)
        isSelected = try container.decodeIfPresent(Bool.self, forKey: .isSelected) ?? false
        let mCreatedAt = try container.decodeIfPresent(Double.self, forKey: .createdAt)
        let mUpdatedAt = try container.decodeIfPresent(Double.self, forKey: .updatedAt)
        createdAt = Date(timeIntervalSince1970: mCreatedAt ?? 0.0)
        updatedAt = Date(timeIntervalSince1970: mUpdatedAt ?? 0.0)
    }
    
    init()
    {
        
    }
    
    var createCrowdParameters: [String: Any] {
        return [
            "id":id ?? "",
            "userId": userId ?? "",
            "name": name ?? "",
            "description": description ?? "",
            "imageUrl": imageUrl ?? "",
            "createdAt": Int(createdAt?.timeIntervalSince1970 ?? 0),
            "updatedAt": Int(updatedAt?.timeIntervalSince1970 ?? 0)
        ]
    }
}

