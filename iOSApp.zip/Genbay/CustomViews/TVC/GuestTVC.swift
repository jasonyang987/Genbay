//
//  GuestTVC.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import UIKit

class GuestTVC: UITableViewCell {

    @IBOutlet weak var guestView: UIView!
    
    @IBOutlet weak var guestImageView: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var guestImage: UIImageView!
    @IBOutlet weak var goingLabelWidthConstraint: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func configure(data : UserModel?,pos:Int, model: EventModel){
        CommonMethods.roundCornerFilled(uiView: guestView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        guestImageView.layer.cornerRadius = guestImageView.frame.width / 2.0
        guestImage.layer.cornerRadius = guestImage  .frame.width / 2.0
        
//        dataInCell = data
        nameLabel.text = "\(data?.firstName ?? "") \(data?.lastName ?? "")"
        let image = data?.imageUrl ?? ""
        if image != ""{
            guestImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
        
        if let goingList = model.goingList {
            if let userId = data?.id {
                if goingList.contains(userId){
                    goingLabelWidthConstraint.constant = 55.0
                }else {
                    goingLabelWidthConstraint.constant = 0.0
                }
            }
        }
    }
    
    
    @IBAction func moreBtnPressed(_ sender: UIButton) {
    }
    
}
