//
//  AddImageVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit
import Kingfisher

class AddImageVC: BaseViewController {
    
    let TAG = String(describing: AddImageVC.self)

    @IBOutlet weak var uploadText: UILabel!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var userImage: UIImageView!
    
    var userModel : UserModel?
    var viewModel : AddImageViewModel?
    var isImageSelected = false
    var calledFrom = ""
    
    private lazy var cameraPickerController: UIImagePickerController = {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .camera
        pickerController.cameraDevice = .front
        pickerController.allowsEditing = true
        return pickerController
    }()
    private lazy var photoLibraryPickerController: UIImagePickerController = {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .photoLibrary
        pickerController.allowsEditing = true
        return pickerController
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        viewModel = AddImageViewModel(vc: self)
        setUI()
    }
    
    func setUI(){
        if calledFrom == Constants.PROFILE{
            backView.isHidden = false
            uploadText.text = "Change Profile Picture"
            nextBtn.setTitle("Update", for: .normal)
            let image = userModel?.imageUrl ?? ""
            if image != ""{
                userImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.forceRefresh])
            }
            userImage.layer.cornerRadius = userImage.frame.width / 2
        }
        else{
            backView.isHidden = true
        }
        CommonMethods.roundCornerFilled(uiView: nextBtn, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 25.0, borderWidth: 0.0)
    }

    @IBAction func nextButtonPressed(_ sender: Any) {
        viewModel?.checkAndUploadData()
    }
    
    
    @IBAction func addImagePressed(_ sender: Any) {
        CommonMethods.showLog(TAG, "addImagePressed")
        presentCameraPhotoLibraryAlert(camera: { [unowned self] _ in
            guard UIImagePickerController.isSourceTypeAvailable(.camera) else { return }
            self.present(self.cameraPickerController, animated: true, completion: nil)
        }, library: { [unowned self] _ in
            guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else { return }
            self.present(self.photoLibraryPickerController, animated: true, completion: nil)
            }, sender: userImage)
    }
    
    
    @IBAction func backButtonPressed(_ sender: Any) {
        CommonMethods.dismiss(vc: self)
    }
}
extension AddImageVC : UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.editedImage] as? UIImage
            ?? info[.originalImage] as? UIImage else { return }
        isImageSelected = true
        userImage.image = image
        userImage.layer.cornerRadius = userImage.frame.width / 2
        dismiss(animated: true, completion: nil)
    }
}
