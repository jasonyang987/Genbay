//
//  AddUsernameViewModel.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class AddUsernameViewModel{
    let TAG = String(describing: AddUsernameViewModel.self)
    var vc : AddUsernameVC
    
    init(vc: AddUsernameVC) {
        self.vc = vc
    }
    
    func validate() throws {
        
        if let userName = vc.usernameText.text {
            if userName.trimAndCheckIsEmpty() {
                throw ValidationError.userNameEmpty
            }else if userName.contains("@"){
                throw ValidationError.invalidUsername
            }
        } else {
            throw ValidationError.userNameEmpty
        }
    }
        
        // MARK: - Enums
        enum ValidationError: Error {
            case userNameEmpty
            case invalidUsername
            
            var localizedDescription: String {
                switch self {
                case .userNameEmpty:
                    return "Please enter your username"
                case .invalidUsername:
                    return "Username cannot contain @ symbol."
                }
            }
        }
    
    func updateData(){
        if let user = vc.userModel{
            vc.showProgressHUD()
            FirebaseAPI.default.checkUsernameExists(ref: FirebaseAPI.Endpoints.users, username:user.username ?? "") { userExists in
                CommonMethods.showLog(self.TAG, "checkUsernameExists usernameSiExists : \(userExists)")
                if userExists{
                    self.vc.hideProgressHUD()
                    self.vc.userModel?.username = ""
                    self.vc.showDialog(title:Constants.APP_NAME,message: "Username is already taken. Please try different username.")
                }
                else{
                    FirebaseAPI.default.saveUser(user,Constants.USERNAME) { (success, error, user) in
                        self.vc.hideProgressHUD()
                        if success{
                            if let user = user {
                                do{
                                    try UserDefaultsMapper.saveUser(user)
                                    Navigations.goToAddImageVC(calledFrom: Constants.SIGN_UP)
//                                    self.vc.showDialog(title: Constants.APP_NAME, message: "Profile updated successfully") {
//                                        Navigations.goToAddImageVC(calledFrom: Constants.SIGN_UP)
//                                    }
                                }catch{
                                    CommonMethods.showLog(self.TAG, "saveUser error : \(error.localizedDescription)")
                                }
                                
                            }
                        }else{
                            if let error = error{
                                self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
                            }else{
                                self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                            }
                        }
                    }
                }
            }
        }
        else{
            CommonMethods.showLog(TAG, "Model is null")
        }
    }
}
