//
//  Constants.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import Foundation
import UIKit


struct Constants{
    
    static let GOOGLE_MAP_API_KEY = "AIzaSyCyj1_v1Vxaz7_rVYT0Gvun8sk08l3T2j0"
    static let FEEDBACK_URL = "https://forms.gle/VyfWcqbPNvRFviW99"
    
    static let FILL_STATIC_FORM = false
//    static let IS_EMAIL_LIVE = false
    static let APP_NAME = "Genbay"
    static let ADD_FRIEND = "add_friend"
    static let ADD_MEMBERS = "add_members"
    static let REMOVE_MEMBERS = "remove_members"
    static let CROWD_DETAIL = "crowd_detail"
    static let EVENT_DATE = "event_date"
    static let EVENT_POLL_VOTING_DEADLINE = "event_poll_voting_deadline"
    static let EVENT_START_TIME = "event_start_time"
    static let EDIT_EVENT = "edit_event"
    static let UPDATE_EVENT = "update_event"
    static let DELETE_EVENT = "delete_event"
    static let UPDATE_HOME_FROM_APP_DELEGATE = "update_home_from_app_delegate"
    static let SHOW_CALENDAR_EVENT = "show_caledar_event"
    static let VIEW_EVENT = "view_event"
    
    
    
    
    static let ABOUT_US_URL = "https://bluegrassthc.com/"
    static let PRIVACY_POLICY_URL = "https://bluegrassthc.com/shipping-policy/"
    static let TERMS_AND_CONDITIONS_URL = "https://bluegrassthc.com/elementor-1074/"
    static let BASE_URL = "https://us-central1-genbay-116d4.cloudfunctions.net/"
    static let PROFILE = "profile"
    static let SIGN_UP = "sign_up"
    static let SPLASH = "splash"
    static let NAME = "name"
    static let TOKEN = "token"
    static let IMAGE = "image"
    static let USERNAME = "username"
    static let NOTIFICATION_SETTINGS = "notificationSettings"
    static let DATE = "date"
    static let LOCATION = "location"
    
    
    
    
    static let MANAGE_DRIVERS = "Manage Drivers"
    static let LOGOUT = "logout"
    static let REQUEST_FROM = "ios"
    static let COMMON_ERROR_MESSAGE = "Some error occured, Please try again."
    static let GO_TO_RESPONSE = 1
    static let FAILURE_RESPONSE = 0
    static let SESSION_OUT_RESPONSE = 10
    static let ADMIN = "admin"
    static let DRIVER = "driver"
    static let CUSTOMER = "customer"
    static let ASSIGN_DRIVER = "assign_driver"
    static let DELIVERY_ORDERS = "delivery_orders"
    static let ORDERS = "orders"
    static let COMPLETED = "completed"
    static let PICKED_UP = "pickedup"
    static let DELIEVERED = "delivered"
    static let ASSIGNED = "assigned"
    static let ORDERED = "ordered"
    static let SUCCESS = "success"
    static let FAILURE = "failure"
    static let SESSION_OUT = "session_out"
    static let ON_THE_WAY = "on the way"
    static let PICKED_UP_TEXT = "picked up"
    static let ALL = "all"
    static let DELETE_DRIVER = "delete_driver"
    static let EDIT_DRIVER = "edit_driver"
    static let ADD_DRIVER = "add_driver"
    static let ACCOUNT_DETAILS = "account_details"
    static let CHANGE_PASSWORD = "change_password"
    static let ABOUT_US = "aboutUs"
    static let PRIVACY_POLICY = "privacyPolicy"
    static let TERMS_AND_CONDITIONS = "termsAndCondition"
    
    static let FORGOT_PASSWORD = "forgot_password"
    static let CUSTOMER_LOGIN = "customer_login"
    static let HANDLE_NOTIFICATION = "handle_notification"
    static let ORDER_STATUS_NOTI_TYPE = "order_status"
    static let UPDATE_LOCATION = "update_location"
    static let UPDATE_ORDER_STATUS = "update_order_status"
    static let ADMIN_HOME = "admin_home"
    static let UPDATE_HOME = "update_home"
    static let UPDATE_CROWD = "update_crowd"
    static let UPDATE_CROWD_MEMBERS = "update_crowd_members"
    // Notification Types
    static let FRIEND_REQUEST_SENT = "friendRequestSent"
    static let FRIEND_REQUEST_ACCEPTED = "friendRequestAccepted"
    static let EVENT_CREATED = "eventCreated"
    static let EVENT_UPDATED = "eventUpdated"
    static let USERS_MENTIONED = "userMentioned"
    static let EVENT_COMMENT_ADDED = "eventCommentAdded"
    static let CO_HOST_INVITE = "coHostInvite"
    static let CO_HOST_INVITE_ACCEPTED = "coHostInviteAccepted"
    static let CO_HOST_INVITE_DECLINED = "coHostInviteDeclined"
    static let FRIEND_REQEUEST_ACCEPTED_BY_USER = "friendRequestAcceptedByUser"
    static let FRIEND_REQEUEST_DECLINED_BY_USER = "friendRequestDeclinedByUser"
    static let FRIEND_REQEUEST_CANCELLED_BY_USER = "friendRequestCancelledByUser"
    static let GOING_TO_EVENT = "goingToEvent"
    static let EVENT_MEMORY_ADDED = "eventMemoryAdded"
    
    
    static let IS_COMPLETED_TUTORIAL = "isCompletedTutorial"
    static let QUICK_TOUR_TO_NEW_USER = "quickTourToNewUser"
    public static let RADIUS_VALUE = 8.0
    public static let USER_LAT = "user_lat"
    public static let USER_LNG = "user_lng"
    public static let PRODUCTS = "products"
    public static let PRODUCTS_TEXT = "Products"
    public static let GALLERY = "gallery"
    public static let CAMERA = "camera"
    public static let GOING = "going"
    public static let NOT_GOING = "not_going"
   

}

func body(_ text: String, color: UIColor = .black, alignment: NSTextAlignment = .natural) -> NSMutableAttributedString {
    let style = NSMutableParagraphStyle()
    style.lineSpacing = 3
    style.alignment = alignment
    let attributes: [NSAttributedString.Key: Any] = [.foregroundColor: color, .paragraphStyle: style]
    return NSMutableAttributedString(string: text, attributes: attributes)
}

func title1(_ text: String, color: UIColor = .black) -> NSMutableAttributedString {
    let style = NSMutableParagraphStyle()
    style.lineSpacing = 72
    let attributes: [NSAttributedString.Key: Any] = [.foregroundColor: color, .font: UIFont.boldSystemFont(ofSize: 24.0)]
    return NSMutableAttributedString(string: text, attributes: attributes)
}



