//
//  FirebaseApi+Crowds.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import Foundation
import Firebase
import FirebaseFirestore

extension FirebaseAPI {
    
    typealias CreateCrowdCompletion = (Error?, CrowdModel) -> Void
    func createNewCrowd(crowdModel : CrowdModel, completion: @escaping CreateCrowdCompletion) {
        let autoID = Endpoints.posts.childByAutoId().key!
        CommonMethods.showLog(TAG, "createNewCrowd autoID : \(autoID)")
        let model = crowdModel
        model.id = autoID
        Endpoints.crowds.child(autoID).updateChildValues(model.createCrowdParameters) { error, dbRef in
            completion(error, model)
        }
    }
    
    func updateCrowd(crowdModel: CrowdModel, completion: @escaping (String?) -> Void) {
        guard let crowdID = crowdModel.id else {
            completion("Crowd ID is missing.")
            return
        }
        
        let crowdParameters = crowdModel.createCrowdParameters
        
        Endpoints.crowds.child(crowdID).updateChildValues(crowdParameters) { error, dbRef in
            if let error = error {
                completion("Failed to update crowd: \(error.localizedDescription)")
            } else {
                completion(nil)
            }
        }
    }

    
    typealias GetCrowdsCompletion = ([CrowdModel]?) -> Void
    func getCrowds(userId:String, completion: @escaping GetCrowdsCompletion) {
        Endpoints.crowds.queryOrdered(byChild: "userId")
            .queryEqual(toValue: userId)
            .observeSingleEvent(of: .value, with: { snapshot in
            CommonMethods.showLog(self.TAG, "snapshot : \(snapshot)")
                self.handleCrowdsSnapshot(snapshot: snapshot,userId: userId,completion: completion)
            }, withCancel: { error in
                completion([])
            })
    }
    
    func handleCrowdsSnapshot(snapshot : DataSnapshot,userId:String, completion : @escaping GetCrowdsCompletion){
        
        guard let dict = snapshot.value as? [String: Any] else {
            CommonMethods.showLog(TAG, "handleCrowdsSnapshot Error \(snapshot)")
            completion([])
            return
        }
        var list: [CrowdModel] = []
        CommonMethods.showLog(TAG, "SnapDict Count : \(dict.count)")
        for snapDict in dict {
            guard let value = snapDict.value as? [String: Any] else { continue }
            do {
                let data = try JSONSerialization.data(withJSONObject: value, options: .prettyPrinted)
                let detail = try JSONDecoder().decode(CrowdModel.self, from: data)
                list.append(detail)
            } catch {
                CommonMethods.showLog(self.TAG, "handleCrowdsSnapshot Error: \(snapDict.key):\(error.localizedDescription)")
                continue
            }
        }
        completion(list)
    }
    
    func getCrowdsWithMembers(userId:String, completion: @escaping GetCrowdsCompletion) {
        Endpoints.crowds.queryOrdered(byChild: "userId")
            .queryEqual(toValue: userId)
            .observeSingleEvent(of: .value, with: { snapshot in
            CommonMethods.showLog(self.TAG, "snapshot : \(snapshot)")
                if snapshot.value != nil {
                    self.handleCrowdsWithMemberSnapshot(snapshot: snapshot,userId: userId,completion: completion)
                }
                else{
                    completion([])
                }
            }, withCancel: { error in
                completion([])
            })
    }
    
    
    
    func handleCrowdsWithMemberSnapshot(snapshot : DataSnapshot,userId:String, completion : @escaping GetCrowdsCompletion){
        
        guard let dict = snapshot.value as? [String: Any] else {
            CommonMethods.showLog(TAG, "handleCrowdsWithMemberSnapshot Error Guard \(snapshot)")
            completion([])
            return
        }
        var list: [CrowdModel] = []
        CommonMethods.showLog(TAG, "SnapDict Count : \(dict.count)")
        for snapDict in dict {
            guard let value = snapDict.value as? [String: Any] else { continue }
            do {
                let data = try JSONSerialization.data(withJSONObject: value, options: .prettyPrinted)
                let detail = try JSONDecoder().decode(CrowdModel.self, from: data)
                if detail.membersList?.count ?? 0 > 0{
                    list.append(detail)
                }
                
            } catch {
                CommonMethods.showLog(self.TAG, "handleCrowdsWithMemberSnapshot Error: \(snapDict.key):\(error.localizedDescription)")
                continue
            }
        }
        
        completion(list)
        
    }
    
    typealias GetFriendsToAddIntoCrowdCompletion = ([UserModel]?) -> Void
    func getFriendsToAddIntoCrowd(crowdId:String,userId:String, completion: @escaping GetFriendsToAddIntoCrowdCompletion) {
        getFriends(userId: userId){acceptedList,pendingList in
            let list = acceptedList ?? []
            Endpoints.crowds.child(crowdId)
                .observeSingleEvent(of: .value, with: { snapshot in
                CommonMethods.showLog(self.TAG, "snapshot : \(snapshot)")
                    self.handlefriendToAddIntoCrowdSnapshot(snapshot: snapshot,userId: userId,completion: completion,acceptedList: list)
                }, withCancel: { error in
                    completion([])
                })
        }
        
    }
    
    func handlefriendToAddIntoCrowdSnapshot(snapshot : DataSnapshot,userId:String, completion : @escaping GetFriendsToAddIntoCrowdCompletion,acceptedList:[UserModel]){
        
        guard let dict = snapshot.value as? [String: Any] else {
            CommonMethods.showLog(TAG, "handlefriendToAddIntoCrowdSnapshot Error \(snapshot)")
            completion([])
            return
        }
        var acceptedList = acceptedList
        var finalList : [UserModel] = []
        CommonMethods.showLog(TAG, "SnapDict Count : \(dict.count)")
        let dispatchGroup = DispatchGroup()
        do {
            let data = try JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted)
            let detail = try JSONDecoder().decode(CrowdModel.self, from: data)
            let memberList = detail.membersList ?? []
            if memberList.count > 0{
               
                for (index, data) in acceptedList.enumerated() {
                    dispatchGroup.enter()
                    CommonMethods.showLog(TAG, "Item \(index): \(data)")
                    var idExist = false
                    if (memberList.contains(data.id ?? "")){
                        CommonMethods.showLog(TAG, "clickedUserId hegi aa")
                        idExist = true
                    }
                    
                    if !idExist{
                        finalList.append(data)
                    }
                    dispatchGroup.leave()
                }
                
            }
            else{
                finalList = acceptedList
                completion(finalList)
            }
            
            
        } catch {
            CommonMethods.showLog(self.TAG, "handlefriendToAddIntoCrowdSnapshot Error: \(error.localizedDescription)")
        }
        
        dispatchGroup.notify(queue: .main) {
            CommonMethods.showLog(self.TAG, "Group Notify")
            completion(finalList)
        }
    }
    
    typealias GetFriendsToRemoveFromCrowdCompletion = ([UserModel]?) -> Void
    func getFriendsToRemoveFromCrowd(crowdId:String,userId:String, completion: @escaping GetFriendsToRemoveFromCrowdCompletion) {
        getFriends(userId: userId){acceptedList,pendingList in
            let list = acceptedList ?? []
            Endpoints.crowds.child(crowdId)
                .observeSingleEvent(of: .value, with: { snapshot in
                CommonMethods.showLog(self.TAG, "snapshot : \(snapshot)")
                    self.handlefriendToRemoveFromCrowdSnapshot(snapshot: snapshot,userId: userId,completion: completion,acceptedList: list)
                }, withCancel: { error in
                    completion([])
                })
        }
        
    }
    
    
    
    func handlefriendToRemoveFromCrowdSnapshot(snapshot : DataSnapshot,userId:String, completion : @escaping GetFriendsToRemoveFromCrowdCompletion,acceptedList:[UserModel]){
        
        guard let dict = snapshot.value as? [String: Any] else {
            CommonMethods.showLog(TAG, "handlefriendToRemoveFromCrowdSnapshot Error \(snapshot)")
            completion([])
            return
        }
        var acceptedList = acceptedList
        var finalList : [UserModel] = []
        CommonMethods.showLog(TAG, "SnapDict Count : \(dict.count)")
        let dispatchGroup = DispatchGroup()
        do {
            let data = try JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted)
            let detail = try JSONDecoder().decode(CrowdModel.self, from: data)
            let memberList = detail.membersList ?? []
            if memberList.count > 0{
               
                for (index, data) in acceptedList.enumerated() {
                    dispatchGroup.enter()
                    CommonMethods.showLog(TAG, "Item \(index): \(data)")
                    var idExist = false
                    if (memberList.contains(data.id ?? "")){
                        CommonMethods.showLog(TAG, "clickedUserId hegi aa")
                        idExist = true
                    }
                    
                    
                    if idExist{
                        finalList.append(data)
                       
                    }
                    dispatchGroup.leave()
                }
                
            }
            else{
                completion(finalList)
            }
            
            
        } catch {
            CommonMethods.showLog(self.TAG, "handlefriendToRemoveFromCrowdSnapshot Error: \(error.localizedDescription)")
        }
        
        dispatchGroup.notify(queue: .main) {
            CommonMethods.showLog(self.TAG, "Group Notify")
            completion(finalList)
        }
    }
    
    typealias GetMembersCompletion = (CrowdModel,[UserModel]?) -> Void
    func getMembersList(crowdId:String,userId:String, completion: @escaping GetMembersCompletion){
        Endpoints.crowds.child(crowdId)
            .observeSingleEvent(of: .value, with: { snapshot in
            CommonMethods.showLog(self.TAG, "snapshot : \(snapshot)")
                self.handleMemberSnapshot(snapshot: snapshot,userId: userId,completion: completion)
            }, withCancel: { error in
                completion(CrowdModel(),[])
            })
    }
    
    func handleMemberSnapshot(snapshot : DataSnapshot,userId:String, completion : @escaping GetMembersCompletion){
        
        guard let dict = snapshot.value as? [String: Any] else {
            CommonMethods.showLog(TAG, "handleMemberSnapshot Error \(snapshot)")
            completion(CrowdModel(),[])
            return
        }
        
        var list : [UserModel] = []
        var crowdModel : CrowdModel = CrowdModel()
        
        CommonMethods.showLog(TAG, "SnapDict Count : \(dict.count)")
        let dispatchGroup = DispatchGroup()
        do {
            let data = try JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted)
            let detail = try JSONDecoder().decode(CrowdModel.self, from: data)
            crowdModel = detail
            let memberList = detail.membersList ?? []
            if memberList.count > 0{
               
                for (index, id) in memberList.enumerated() {
                    dispatchGroup.enter()
                    CommonMethods.showLog(TAG, "Item \(index): \(data)")
                    self.getUser(id) { (user, error) in
                        CommonMethods.showLog(self.TAG, "Data Fetch")
                        user?.friendStatus = .accepted
                        list.append(user ?? UserModel())
                        dispatchGroup.leave()
                    }
                }
            }
            else{
                completion(detail,list)
            }
            
            
        } catch {
            CommonMethods.showLog(self.TAG, "handleMemberSnapshot Error: \(error.localizedDescription)")
        }
        
        dispatchGroup.notify(queue: .main) {
            CommonMethods.showLog(self.TAG, "Group Notify")
            completion(crowdModel,list)
        }
    }
    
    typealias UpdateMembersToCrowdCompletion = (Bool,String) -> Void
    func updateMembersToCrowd(crowdId:String,membersList:[String], completion: @escaping UpdateMembersToCrowdCompletion) {
        Endpoints.crowds.child(crowdId).updateChildValues(["membersList":membersList]) { error,dbRef in
            if error != nil{
                completion(false,error?.localizedDescription ?? Constants.COMMON_ERROR_MESSAGE)
            }
            else{
                completion(true,"")
            }
        }
    }
    
    typealias CheckCrowdExistInEventCompletion = ([EventModel],String) -> Void
    func checkCrowdExistInEvent(calledFrom:String,selectedList:[UserModel],crowdId:String, completion: @escaping CheckCrowdExistInEventCompletion){
        CommonMethods.showLog(self.TAG, "checkCrowdExistInEvent")
        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let refrence = Endpoints.eventsFirestore.whereField("selectedCrowds", arrayContains: crowdId)
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "checkCrowdExistInEvent Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "checkCrowdExistInEvent Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            if calledFrom == Constants.ADD_MEMBERS{
                                CommonMethods.showLog(self.TAG, "Event Id : \(eventModel.id ?? "")")
                                var selectedMemberList = eventModel.selectedMembers ?? []
                                selectedList.forEach{ data in
                                    selectedMemberList.append(data.id ?? "")
                                }
                                
                                Endpoints.eventsFirestore.document(eventModel.id ?? "").updateData(["selectedMembers":selectedMemberList]) { error in
                                    if let error = error {
                                        print("Error adding document: \(error)")
                                    } else {
                                        print("Document Edited")
                                    }
                                    dispatchGroup.leave()
                                }
                            }
                            else{
                                let selectedMemberList = eventModel.selectedMembers ?? []
                                var finalList : [String] = selectedMemberList
                                
                                selectedList.reversed().forEach{ data in
                                    for(index,memberId) in selectedMemberList.enumerated(){
                                        if data.id == memberId{
                                            CommonMethods.showLog(self.TAG, "data id: \(data.id)")
                                            CommonMethods.showLog(self.TAG, "member id: \(memberId)")
                                            CommonMethods.showLog(self.TAG, "index: \(index)")
                                            eventModel.goingList?.forEach({ id in
                                                if id == memberId {
                                                    CommonMethods.showLog(self.TAG, "id matched to be removed with id: \(id)")
                                                    FirebaseAPI.default.removeFromGoingList(eventModel.id ?? "", userId: memberId) { success, error in
                                                        if error != nil {
                                                            CommonMethods.showLog(self.TAG, "error while removing member from goingList: \(error?.localizedDescription)")
                                                        }
                                                    }
                                                }
                                            })
                                            finalList.remove(at: index)
                                            break
                                        }
                                    }
                                }
                                
                                Endpoints.eventsFirestore.document(eventModel.id ?? "").updateData(["selectedMembers":finalList]) { error in
                                    if let error = error {
                                        print("Error adding document: \(error)")
                                    } else {
                                        print("Document Edited")
                                    }
                                    dispatchGroup.leave()
                                }
                            }
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list,"")
                    }
                }
                else{
                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "checkCrowdExistInEvent Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    
    func deleteCrowd(crowdId: String, completion: @escaping (Error?) -> Void) {
        let ref = Endpoints.crowds.child(crowdId)
        ref.removeValue { error, ref in
            if let error = error {
                completion(error)
            }else {
                completion(nil)
            }
        }
    }

    
}
