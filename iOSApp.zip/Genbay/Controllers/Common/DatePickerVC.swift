//
//  DatePickerVC.swift
//  Soul Sync
//
//  Created by Nap Works on 26/10/22.
//

import UIKit

class DatePickerVC: BaseViewController {

    let TAG = String(describing:DatePickerVC.self)
    
    var delegate : DateSelectionDelegate?, pageTitle = "", minDate : Date?, maxDate : Date?, mode : UIDatePicker.Mode = .date, currentDate : Date?,doneTitle = "Done",calledFrom = ""
    
    @IBOutlet weak var doneBtn: UIButton!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var bottomView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLbl.text = pageTitle
        doneBtn.setTitle(doneTitle, for: .normal)
        CommonMethods.roundParticularCornerFilled(uiView: bottomView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0, corners: [.layerMinXMinYCorner, .layerMaxXMinYCorner])
        CommonMethods.roundCornerFilled(uiView: closeButton, borderColor: .lightBackground, backgroundColor: .lightBackground, cornerRadius: closeButton.frame.height / 2.0, borderWidth: 0.0)
        CommonMethods.roundCornerFilled(uiView: doneBtn, borderColor: .mainColor, backgroundColor: .mainColor, cornerRadius: doneBtn.frame.height / 2.0, borderWidth: 0.0)
        if let minDate = minDate{
            datePicker.minimumDate = minDate
        }
        
        if let maxDate = maxDate{
            datePicker.maximumDate = maxDate
        }
        
        datePicker.datePickerMode = mode
        datePicker.overrideUserInterfaceStyle = .light
        
        if let currentDate = currentDate{
            datePicker.date = currentDate
        }
        
        
    }
        
    @IBAction func closeButtonPressed(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    @IBAction func doneBtnPressed(_ sender: Any) {
        self.dismiss(animated: true) {
            self.delegate?.onDateSelected(calledFrom:self.calledFrom,date: self.datePicker.date)
        }
    }
    
    @IBAction func outsideTouched(_ sender: Any) {
        self.dismiss(animated: true)
    }
}
