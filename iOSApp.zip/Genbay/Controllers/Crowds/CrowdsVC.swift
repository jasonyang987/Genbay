//
//  CrowdsVC.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import UIKit
import DropDown

class CrowdsVC: BaseViewController, ShowInstructionsVCDelegate {
   
    let TAG = String(describing: CrowdsVC.self)

    @IBOutlet weak var noDataText: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var createCrowdBtn: UIButton!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var mainView: UIView!
    var userModel : UserModel?
    var crowdList:[CrowdModel] = []
    var viewModel: CrowdsViewModel?
    @IBOutlet weak var tapToContinueLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        noDataText.isHidden = true
        
        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(handleNotification(notification:)), name: .crowdVC, object: nil)
        viewModel = CrowdsViewModel(vc: self)
        setUI()
        getCrowds()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        checkAndShowTutorial()
    }
    
    ///Method to check if user has completed the tutorial, if not, then show the tutorial
    func checkAndShowTutorial(){
        let isCompletedTutorial = UserDefaults.standard.bool(forKey: Constants.IS_COMPLETED_TUTORIAL)
        if isCompletedTutorial {
            tapToContinueLabel.isHidden = true
        }else {
            Navigations.showInstructionsVC(self, delegate: self, calledFrom: "CrowdsVC")
            tapToContinueLabel.isHidden = false
        }
    }
    
    ///ShowInstructionsVC Delegate Method
    func navigate() {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "CreateEventTabVC") as! CreateEventTabVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func getCrowds(){
        self.showProgressHUD()
        FirebaseAPI.default.getCrowds(userId: userModel?.id ?? ""){ list in
            self.hideProgressHUD()
            self.crowdList = list ?? []
            self.crowdList = self.crowdList.sorted{
                $1.createdAt?.timeIntervalSince1970 ?? Double() > $0.createdAt?.timeIntervalSince1970 ?? Double()
            }

            self.checkAndShowMessage()
            self.tableView.reloadData()
        }
    }
    
    func checkAndShowMessage(){
        if crowdList.count == 0 {
            noDataText.isHidden = false
        }
        else{
            noDataText.isHidden = true
        }
    }
    
    func setUI(){
        createCrowdBtn.layer.cornerRadius = 20.0
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .transparent
        tableView.register(UINib(nibName: "FriendsTVC", bundle: nil), forCellReuseIdentifier: "FriendsTVC")
        
    }
    
    func showDialog(pos: Int, contentView:UIView?){
        CommonMethods.showLog(self.TAG, "pos is: \(pos)")
        let dropDown = DropDown()
        dropDown.textColor = UIColor.black
        dropDown.selectedTextColor = .black
        dropDown.textFont = UIFont.systemFont(ofSize: 15)
        dropDown.backgroundColor = UIColor.white
        dropDown.selectionBackgroundColor = .white
        dropDown.cellHeight = 35
        dropDown.anchorView = contentView
        dropDown.dataSource = ["Edit Crowd", "Delete Crowd"]
        let width = self.view.frame.width / 1.6
        let xWidth = (contentView?.frame.width ?? 0) - width
        let yWidth = (contentView?.frame.height ?? 0) / 1.5
        dropDown.width = width
        dropDown.bottomOffset = CGPoint(x: xWidth , y: yWidth)
        dropDown.cellNib = UINib(nibName: "MyCell", bundle: nil)
        dropDown.show()
        
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            if item == "Edit Crowd"{
                Navigations.goToEditCrowd(navigationController: navigationController, model: crowdList[pos], delegate: self)
                CommonMethods.showLog(self.TAG, "Edit Crowd")
            }else{
                viewModel?.deleteCrowdFromDatabase(crowdList[pos])
            }
        }
        
    }
    
    @IBAction func backPressed(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func createNewCrowdPressed(_ sender: Any) {
        Navigations.goToCreateCrowd(navigationController: navigationController)
    }
    
    func handleNotificationData(_ crowdModel:CrowdModel){
        CommonMethods.showLog(TAG, "handleNotificationData")
        crowdList.append(crowdModel)
        checkAndShowMessage()
        tableView.reloadData()
    }
    
}
extension CrowdsVC : UITableViewDelegate, UITableViewDataSource, FriendsOptionPressedDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return crowdList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendsTVC", for: indexPath) as! FriendsTVC
        cell.selectionStyle = .none
        cell.isCalledFromCrowd = true
        cell.delegate = self
        cell.configure(data:crowdList[indexPath.row], position: indexPath.row)
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        Navigations.goToCrowdDetail(navigationController: navigationController,crowdId:crowdList[indexPath.row].id ?? "")
    }
    
    ///not required here
    func onFriendOptionsPressed(pos: Int?, userModel: UserModel?, contentView: UIView?) {
        
    }
    
    
    func onCrowdOptionsPressed(pos: Int?, contentView: UIView?) {
        showDialog(pos: pos ?? 0, contentView: contentView)
    }
}

extension CrowdsVC: CreateCrowdVCDelegate{
    
    @objc func handleNotification(notification: NSNotification) {
        if let value = notification.userInfo as? [String : Any]{
            CommonMethods.showLog(TAG, "handleNotification value : \(value)")
            if let type = value["type"] as? String{
                if type == Constants.UPDATE_CROWD{
                    if let crowdModel = value["crowdModel"] as? CrowdModel{
                        handleNotificationData(crowdModel)
                    }
                    
                }
            }
        }
    }
    
    func onCrowdUpdation() {
        self.getCrowds()
    }
    
}
