//
//  NotificationSettingModel.swift
//  Genbay
//
//  Created by Nap Works on 22/08/23.
//

import Foundation

struct NotificationSettingModel {
    let title: String
    let type: NotificationSettingType
    var isOn: Bool
}

