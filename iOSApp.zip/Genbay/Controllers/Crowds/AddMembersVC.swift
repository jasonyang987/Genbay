//
//  AddMembersVC.swift
//  Genbay
//
//  Created by Nap Works on 07/04/23.
//

import UIKit

class AddMembersVC: BaseViewController, UITextFieldDelegate {
    let TAG = String(describing: AddMembersVC.self)
    
   
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var noDataMessage: UILabel!
    @IBOutlet weak var buttonText: UILabel!
    @IBOutlet weak var buttonView: UIView!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var pageTitle: UILabel!
    @IBOutlet weak var searchText: UITextField!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnSearch: UIButton!
    
    var usersList : [UserModel] = []
    var searchUsersList : [UserModel] = []
    var userData: UserModel?
    var viewModel :AddMemberViewModel?
    
    
    var calledFrom = "" , delegate : UpdateMembersDelegate?
    var crowdModel : CrowdModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        noDataMessage.isHidden = true
        userData = UserDefaultsMapper.getUser()
        viewModel = AddMemberViewModel(vc: self)
        searchText.delegate = self
        self.mainView.isHidden = true
        if calledFrom == Constants.REMOVE_MEMBERS{
            pageTitle.text = crowdModel?.name ?? ""
            buttonText.text = "Confirm Remove"
            viewModel?.getFriendsToRemoveFromCrowd()
        }
        else{
            pageTitle.text = "Your Friends"
            buttonText.text = "Confirm Add"
            viewModel?.getFriendsToAddIntoCrowd()
        }
        
        
        CommonMethods.setPlaceholderColor(textFields: [searchText], color: .black)

        setUI()
        
    }
    
    
    
    func setUI(){
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .transparent
        tableView.register(UINib(nibName: "AddMembersTVC", bundle: nil), forCellReuseIdentifier: "AddMembersTVC")
        
        CommonMethods.roundCornerFilled(uiView: searchView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        CommonMethods.roundCornerFilled(uiView: buttonView, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 20.0, borderWidth: 0.0)
    }
    

    @IBAction func backPressed(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func cancelPressed(_ sender: Any) {
        
    }
    
    
    @IBAction func searchButtonPressed(_ sender: Any) {
        let searchText = searchText.text?.trimmingCharacters(in: .whitespaces) ?? ""
        if searchText == ""{
            showDialog(title:Constants.APP_NAME,message: "Enter text to search.")
        }
        else{
            self.showProgressHUD()
            usersList = []
            
            
            searchUsersList.forEach{ data in
                let username = data.username ?? ""
                CommonMethods.showLog(TAG, "username \(username)")
                CommonMethods.showLog(TAG, "searchText \(searchText.lowercased())")
                if username.starts(with: searchText.lowercased()){
                    usersList.append(data)
                }
            }
            
            if usersList.count == 0{
                noDataMessage.text = "No User Found"
                noDataMessage.isHidden = false
            }
            else{
                noDataMessage.isHidden = true
            }
            self.hideProgressHUD()
            self.tableView.reloadData()
            
        }
    }
    
    
    @IBAction func addRemoveButtonPressed(_ sender: Any) {
        var selectedList : [UserModel] = []
        var membersList = crowdModel?.membersList ?? []

        for(index,data) in usersList.enumerated(){
            if data.isSelected ?? false{
                if calledFrom == Constants.REMOVE_MEMBERS{
                    if let index = membersList.firstIndex(of: data.id ?? "") {
                        membersList.remove(at: index)
                    }
                }
                else{
                    membersList.append(data.id ?? "")
                }
                selectedList.append(data)
            }
        }
        
        CommonMethods.showLog(TAG, "selectedList count : \(selectedList.count)")
        CommonMethods.showLog(TAG, "membersList count : \(membersList.count)")
        
        if selectedList.count == 0{
            showDialog(title: Constants.APP_NAME, message: "Choose at least one friend")
        }
        else{
            crowdModel?.membersList = membersList
//          viewModel?.checkCrowdIdExistInEvent(selectedList:selectedList)
            viewModel?.updateMembersToCrowd(selectedList: selectedList)
        }
    }
    
    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        
        var searchText  = textField.text! + string
        
        CommonMethods.showLog(TAG, "Search Text : \(searchText)")
        CommonMethods.showLog(TAG, "String : \(string)")
        
        if string  == "" {
            searchText = (searchText as String).substring(to: searchText.index(before: searchText.endIndex))
        }
        CommonMethods.showLog(TAG, "Search Text After : \(searchText)")
        
        if searchText == "" {
            self.usersList = []
            self.usersList = searchUsersList
            noDataMessage.isHidden = true
            tableView.reloadData()
        }
        
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        self.usersList = []
        self.usersList = searchUsersList
        noDataMessage.isHidden = true
        tableView.reloadData()
        return true
    }
    
}

extension AddMembersVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 10
        return usersList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddMembersTVC", for: indexPath) as! AddMembersTVC
        cell.selectionStyle = .none
        cell.configure(calledFrom:Constants.ADD_MEMBERS,data:usersList[indexPath.row],position: indexPath.row)
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        usersList[indexPath.row].isSelected = !(usersList[indexPath.row].isSelected ?? false)
        self.tableView.reloadRows(at: [IndexPath(row: indexPath.row, section: 0)], with: .none)
        
    }
    
}
