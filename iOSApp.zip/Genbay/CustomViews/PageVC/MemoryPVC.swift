//
//  MemoryPVC.swift
//  Genbay
//
//  Created by Nap Works on 01/05/23.
//

import UIKit

protocol MemoryPVCDelegate{
    func setCurrentIndex(_ index: Int?)
}

class MemoryPVC: UIPageViewController, MemoryImageVCDelegate {
    
    let TAG = String(describing: MemoryPVC.self)
    var indexDelegate: MemoryPVCDelegate?
//  var viewPagerList : [ProductsPagerModel] = []
    var pageControl : UIPageControl?
    var viewController : UIViewController?
    var images: [UIImage]? = []
    var customDelegate : ViewPagerDelegate?
    
    var identifier: [String] = ["MemoryImageVC"]
    var currentPageIndex = 0
    var pages: [UIViewController] = [UIViewController]()
    
    override init(transitionStyle style: UIPageViewController.TransitionStyle, navigationOrientation: UIPageViewController.NavigationOrientation, options: [UIPageViewController.OptionsKey : Any]? = nil) {
        super.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        self.delegate = self
        MemoryImageVC.delegate = self
        if let images = images {
            for i in 0..<images.count {
                pages = [
                    MemoryImageVC.getInstance(index: i, images: images)
                ]
            }
            if images.count > 0 {
                setViewControllers([pages[0]], direction: .forward, animated: false, completion: nil)
                self.isPagingEnabled = true
            }
        }
      
    }
    
    func updateImages(_ newImages: [UIImage], direction: UIPageViewController.NavigationDirection, index: Int?) {
        self.images = newImages
        self.pages = []
        for i in 0..<newImages.count {
            pages.append(MemoryImageVC.getInstance(index: i, images: images ?? []))
        }
        if let index = index {
            setViewControllers([pages[index]], direction: direction, animated: false, completion: nil)
            self.isPagingEnabled = true
        }else {
            return
        }

    }
    
    func setMemoryImages(_ memoryImages: [String], direction: UIPageViewController.NavigationDirection) {
        self.pages = []
        for i in 0..<memoryImages.count {
            pages.append(MemoryImageVC.getInstance(index: i, imageStrings: memoryImages))
        }
        setViewControllers([pages[0]], direction: direction, animated: false, completion: nil)
        self.isPagingEnabled = true
    }
    
    func removeImageAndVC(_ index: Int?) {
        CommonMethods.showLog(self.TAG, "index: \(index)")
        if let index = index, index >= 0, index < images?.count ?? 0 {
            // Remove the item at the specified index
            images?.remove(at: index)
            
            if let images = images, images.count > 0 {
                // Determine the new index of the currently selected image
                let newIndex = (index == 0) ? 0 : (index - 1)
                
                // Update the images in the UI
                updateImages(images, direction: .reverse, index: newIndex)
                
                // Update the index of the currently selected image
                indexDelegate?.setCurrentIndex(newIndex)
            } else {
                // There are no more images to display, so clear the UI
                updateImages([], direction: .reverse, index: nil)
                indexDelegate?.setCurrentIndex(nil)
            }
        } else {
            // Invalid index, so do nothing
            return
        }

//        if index >= 0 {
//            self.images?.remove(at: index)
//            if index == 0 && self.images?.count == 1 {
//                self.updateImages(self.images ?? [], direction: .reverse, index: nil)
//                self.indexDelegate?.setCurrentIndex(nil)
//            }else {
//                self.updateImages(self.images ?? [], direction: .reverse, index: index-1)
//                self.indexDelegate?.setCurrentIndex(index-1)
//            }
//        }else {
//            return
//        }
//
    }
 
    func changePage(direction: UIPageViewController.NavigationDirection, posiiton: Int, imageStrings: [String]? = nil) {
//        CommonMethods.showLog(TAG, "changePage")
        if images?.count ?? 0 > 1 {
            setViewControllers([pages[posiiton]], direction: direction, animated: true, completion: nil)
        }
        
        if let imageStrings = imageStrings {
            if imageStrings.count > 1 {
                setViewControllers([pages[posiiton]], direction: direction, animated: true, completion: nil)
            }
        }
    }
}

extension MemoryPVC: UIPageViewControllerDataSource, UIPageViewControllerDelegate {

    
    func pageViewController(_: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
//        CommonMethods.showLog(TAG, "viewControllerBefore")
        
        if pages.count > 1{
            guard let viewControllerIndex = pages.firstIndex(of: viewController) else {
                return nil
            }
            
            let previousIndex = viewControllerIndex - 1
            

            guard previousIndex >= 0 else {
                return pages.last
            }
            
//            CommonMethods.showLog(self.TAG, "currentIndex: \(previousIndex)")
            
            guard pages.count > previousIndex else {
                return nil
            }
            

            
            return pages[previousIndex]
        }else{
            return nil
        }
    }
    
    func pageViewController(_: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
//        CommonMethods.showLog(TAG, "viewControllerAfter")
        if pages.count > 1{
            guard let viewControllerIndex = pages.firstIndex(of: viewController) else {
                return nil
            }
            
            let nextIndex = viewControllerIndex + 1
            guard pages.count != nextIndex else {
                return pages.first
            }
            
            guard pages.count > nextIndex else {
                return nil
            }
            
//            CommonMethods.showLog(self.TAG, "currentIndex: \(nextIndex)")
            
            return pages[nextIndex]
        }else{
            return nil
        }
    }
    
    func presentationIndex(for _: UIPageViewController) -> Int {
//        CommonMethods.showLog(TAG, "presentationIndex")
        guard let firstViewController = viewControllers?.first,
            let firstViewControllerIndex = pages.firstIndex(of: firstViewController)
        else {
//            CommonMethods.showLog(TAG, "Else Case")
                return 0
        }
//        CommonMethods.showLog(TAG, "presentationIndex firstViewControllerIndex : \(firstViewControllerIndex)")
        return firstViewControllerIndex
    }
    
//    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
////        CommonMethods.showLog(TAG, "didFinishAnimating finished : \(finished)")
////        CommonMethods.showLog(TAG, "didFinishAnimating completed : \(completed)")
//        if (!completed)
//        {
//            return
//        }
//        let index = pageViewController.viewControllers!.first!.view.tag
//        CommonMethods.showLog(self.TAG, "index is: \(index)")
////        customDelegate?.onPageChanged(type: viewPagerList[index].type ?? "")
////        CommonMethods.showLog(TAG, "didFinishAnimating TYPE : \(viewPagerList[index].type)")
////        CommonMethods.showLog(TAG, "didFinishAnimating index : \(index)")
//    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        guard completed, let currentViewController = pageViewController.viewControllers?.first,
              let currentIndex = pages.firstIndex(of: currentViewController) else {
            return
        }
        // The page at index `currentIndex` is now displayed
//        print("Current index: \(currentIndex)")
        self.indexDelegate?.setCurrentIndex(currentIndex)
    }

}
