//
//  CreatePollVC.swift
//  Genbay
//
//  Created by Nap Works on 30/03/23.
//

import Foundation
import UIKit

class CreatePollVC: BaseViewController,DateSelectionDelegate, LocationSelectionDelegate {
    
    

    let TAG = String(describing:CreatePollVC.self)
    
    var delegate : PollSelectionDelegate?, pageTitle = "",type=""
    @IBOutlet weak var createBtn: UIButton!
    @IBOutlet weak var createBtnView: UIView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var datesTableView: UITableView!
    @IBOutlet weak var tableViewHeightConstraint: NSLayoutConstraint!
    
    
    var tableViewHeight: CGFloat {
        datesTableView.layoutIfNeeded()

        return datesTableView.contentSize.height
    }
    
    
    var dateList: [DatePollModel] = []
    var locationList: [Location] = []
    var selectedIndex: IndexPath?
    var long: Double?
        var lat: Double?

    override func viewDidLoad() {
        super.viewDidLoad()
        titleLbl.text = pageTitle
                
        CommonMethods.roundCornerFilled(uiView: bottomView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        CommonMethods.roundCornerFilled(uiView: createBtnView, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 20.0, borderWidth: 1.0)
        view.backgroundColor = .black.withAlphaComponent(0.3)
        
        datesTableView.register(UINib(nibName: "PollTVC", bundle: nil), forCellReuseIdentifier: "PollTVC")
        datesTableView.delegate = self
        datesTableView.dataSource = self
        
        if type == Constants.LOCATION{
            if locationList.count == 0 {
                datesTableView.isHidden = true
            }else {
                datesTableView.isHidden = false
                datesTableView.reloadData()
            }
        }
        else{
            if dateList.count == 0 {
                datesTableView.isHidden = true
            }else {
                datesTableView.isHidden = false
                datesTableView.reloadData()
            }
        }
        
    }
        
    @IBAction func closeButtonPressed(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    @IBAction func createBtnPressed(_ sender: Any) {
        if type == Constants.DATE {
//            if dateList.count == 0 {
//                showDialog(title:Constants.APP_NAME,message: "You have not selected any date, Unable to create poll!")
//            }else {
//                showDialog(title:Constants.APP_NAME,message: "Poll Created!") {
                    self.dismiss(animated: true) {
                        self.delegate?.onPollDateSelected(dates: self.dateList)
                    }
//                }
//            }
        }else if type == Constants.LOCATION {
//            if locationList.count == 0 {
//                showDialog(title:Constants.APP_NAME,message: "You have not selected any location, Unable to create poll!")
//            }else {
//                showDialog(title:Constants.APP_NAME,message: "Poll Created!") {
                    self.dismiss(animated: true){
                        self.delegate?.onPollLocationSelected(list: self.locationList)
                    }
//                }
//
//            }
        }

    }
    
    
    @IBAction func addButtonPressed(_ sender: Any) {
        if type == Constants.DATE{
            if dateList.count == 3 {
                showDialog(title: Constants.APP_NAME, message: "Cannot add more than 3 dates")
            }else {
                Navigations.showDatePicker(calledFrom: "", viewController: self, delegate : self, pageTitle: "Date of Event", minDate: Date(), maxDate: nil, mode: .date)
            }
        }else if type == Constants.LOCATION {
            if locationList.count == 3 {
                showDialog(title: Constants.APP_NAME, message: "Cannot add more than 3 locations")
            }else {
                Navigations.showAddLocationVC(viewController: self, delegate: self)
//                Navigations.showLocationVC(viewController: self, delegate: self)
            }
          
        }
    }
    
    func onDateSelected(calledFrom: String, date: Date) {
        CommonMethods.showLog(TAG, "onDateSelected: \(date)")
//        startTimeTimeStamp = date.timeIntervalSince1970
        let dateString = CommonMethods.getFormattedDate(timeStamp: date.timeIntervalSince1970, format: "MM/dd/yyyy")
        self.dateList.append(DatePollModel(date: dateString,dateTimestamp: date.timeIntervalSince1970, vote: 0,userList: []))
        self.dateList = self.dateList.sorted {
            $1.dateTimestamp ?? 0.0 > $0.dateTimestamp ?? 0.0
        }
        self.datesTableView.isHidden = false
        DispatchQueue.main.async {
            self.datesTableView.reloadData()
            self.tableViewHeightConstraint.constant = self.tableViewHeight
        }
    }
    
    func onLocationSelected(location: Location) {
        CommonMethods.showLog(TAG, "onLocationSelected: \(location)")
        if location.location != nil && location.location != "" {
            self.locationList.append(location)
            self.datesTableView.isHidden = false
            DispatchQueue.main.async {
                self.datesTableView.reloadData()
                self.tableViewHeightConstraint.constant = self.tableViewHeight
            }
        }
    }
     
    
//    func onLocationSelected(location: Location) {
//        CommonMethods.showLog(TAG, "onLocationSelected: \(location)")
//        if location.fullAddress != nil {
//            self.locationList.append(location)
//            self.datesTableView.isHidden = false
//            self.datesTableView.reloadData()
//        }
//
//    }
//
//    func sendDateList(dates: [String]?) {
//
//    }
//
//    func sendLocationList(locations: [Location]?) {
//    }
    
    
}

extension CreatePollVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? PollTVC {
            cell.configureCheckMark()
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if type == Constants.DATE {
            return dateList.count
        }else if type == Constants.LOCATION {
            return locationList.count
        }else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PollTVC") as? PollTVC else {
            return UITableViewCell()
        }
        cell.delegate = self
        if type == Constants.DATE {
            cell.configureDates(dateModel: dateList[indexPath.row], tag: indexPath.row)
        }else if type == Constants.LOCATION {
            cell.configureLocations(locationList[indexPath.row], tag: indexPath.row)
        }

        return cell
    }
}


extension CreatePollVC: PollTVCDelegate {
    func deleteDateOrLocation(tag: Int) {
        if type == Constants.DATE {
            CommonMethods.showLog(self.TAG, "date deleted at \(tag)")
            self.dateList.remove(at: tag)
            if self.dateList.count == 0 {
                self.datesTableView.isHidden = true
            }else {
                self.datesTableView.isHidden = false
            }
            DispatchQueue.main.async {
                self.datesTableView.reloadData()
                self.tableViewHeightConstraint.constant = self.tableViewHeight
            }
        }else if type == Constants.LOCATION {
            CommonMethods.showLog(self.TAG, "location deleted at \(tag)")
            self.locationList.remove(at: tag)
            if self.locationList.count == 0 {
                self.datesTableView.isHidden = true
            }else {
                self.datesTableView.isHidden = false
            }
            DispatchQueue.main.async {
                self.datesTableView.reloadData()
                self.tableViewHeightConstraint.constant = self.tableViewHeight
            }
        }

    }

}
