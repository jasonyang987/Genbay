//
//  VisibleToAllTVC.swift
//  Genbay
//
//  Created by Nap Works on 18/04/23.
//

import UIKit

class VisibleToAllTVC: UITableViewCell {
    
    
    @IBOutlet weak var selectedImageView: UIImageView!
    @IBOutlet weak var orLabel: UILabel!
    @IBOutlet weak var selectCrowdLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(isSelected:Bool, count: Int){
        selectCrowdLabel.isHidden = count == 0
//        orLabel.isHidden = count == 0

        if isSelected {
            selectedImageView.image = UIImage(named: "friend_selected")
        }
        else{
            selectedImageView.image = UIImage(named: "friend_unselected")
        }
        
        
    }
    
}
