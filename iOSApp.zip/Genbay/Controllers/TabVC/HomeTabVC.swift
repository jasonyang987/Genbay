//
//  HomeTabVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit
import FSCalendar

class HomeTabVC: BaseViewController, ShowInstructionsVCDelegate {
 
    
    let TAG = String(describing: HomeTabVC.self)
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var viewEventsBtn: UIButton!
    @IBOutlet weak var calendarBtn: UIButton!
    @IBOutlet weak var newsFeedBtn: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var calendarView: UIView!
    @IBOutlet weak var newsfeedView: UIView!
    @IBOutlet weak var noEventsView: UIView!
    @IBOutlet weak var noEventsLabel: UILabel!
    @IBOutlet weak var tableStackView: UIStackView!
    @IBOutlet weak var calendarMainView: UIView!
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var headerDateLabel: UILabel!
    @IBOutlet weak var leftImage: UIImageView!
    @IBOutlet weak var rightImage: UIImageView!
    var refreshControl = UIRefreshControl()
    var isHomeDataLoaded:Bool = false
    @IBOutlet weak var filterLabel: UILabel!
    
    var eventDates = ["2023-04-20", "2023-04-14", "2023-04-12"]
    
    var eventList : [EventModel] = []
    var userModel:UserModel?
    
    var viewModel : HomeTabViewModel?
    
    let regularFont = UIFont.systemFont(ofSize: 14, weight: .regular)
    let boldFont = UIFont.systemFont(ofSize: 14, weight: .bold)
    @IBOutlet weak var tapToContinueLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = HomeTabViewModel(vc: self)
        userModel = UserDefaultsMapper.getUser()
        noEventsView.isHidden = true
        AppDelegate.shared.mainNavController = navigationController

        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(handleNotification(notification:)), name: .homeNotificationVC, object: nil)
        
//      FirebaseAPI.default.getPastGuestEvents(userId: "du8zsOcuuSMf4xXaS7WoTDAXYOk1")
        
        setUI()
        viewModel?.getUpcomingGuestEvents(true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        checkAndShowTutorial()
    }
    
    ///Method to check if user has completed the tutorial, if not, then show the tutorial...
    func checkAndShowTutorial(){
        let isCompletedTutorial = UserDefaults.standard.bool(forKey: Constants.IS_COMPLETED_TUTORIAL)
//        UserDefaults.standard.removeObject(forKey: Constants.IS_COMPLETED_TUTORIAL)
        CommonMethods.showLog(self.TAG, "isCompletedTutorial: \(isCompletedTutorial)")
       if isCompletedTutorial {
            tapToContinueLabel.isHidden = true
        }else{
            Navigations.showInstructionsVC(self, delegate: self, calledFrom: "HomeTabVC")
            tapToContinueLabel.isHidden = false
        }
    }
    
    /// ShowInstructionsVC Delegate Method
    func navigate() {
        let friendsTabVC = self.storyboard?.instantiateViewController(withIdentifier: "FriendsTabVC") as! FriendsTabVC
        navigationController?.pushViewController(friendsTabVC, animated: true)
    }
    
    
    func setUI(){
        
        CommonMethods.roundCornerFilled(uiView: calendarMainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20, borderWidth: 1)
        
        changeBtnBackgroundAndLabel(view1: newsfeedView, view2: calendarView, btn1: newsFeedBtn, btn2: calendarBtn)
        
        calendar.register(FSCalendarCell.self, forCellReuseIdentifier: "cell")
        calendar.appearance.titleOffset = CGPoint(x: 0, y: 0)
        calendar.appearance.weekdayTextColor = .black
        calendar.appearance.weekdayFont = UIFont.boldSystemFont(ofSize: 14)
        calendar.appearance.headerDateFormat = ""
        calendar.firstWeekday = 2
        calendar.calendarWeekdayView.weekdayLabels.forEach { label in
            label.text = String(label.text?.dropLast() ?? "")
        }
        calendar.scrollEnabled = true
        calendar.delegate = self
        calendar.dataSource = self
        
        
        
        let nib = UINib(nibName: "EventTVC", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "EventTVC")
        tableView.delegate = self
        tableView.dataSource = self
        refreshControl.tintColor = .secondaryMainColor
        
        if #available(iOS 10.0, *) {
            tableView.refreshControl = refreshControl
        } else {
            tableView.addSubview(refreshControl)
        }
        refreshControl.addTarget(self, action: #selector(onRefresh(_:)), for: .valueChanged)
        CommonMethods.roundCornerFilled(uiView: calendarView, borderColor: .black, backgroundColor: .white, cornerRadius: 0, borderWidth: 0)
        CommonMethods.roundCornerFilled(uiView: newsfeedView, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: viewEventsBtn, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 20, borderWidth: 1)
    }
    
    @objc func onRefresh(_ sender : Any) {
        CommonMethods.showLog(TAG, "onRefresh")
        handleNotificationData(false)
    }
    
    func handleNotificationData(_ isShowLoading: Bool = true){
        
        CommonMethods.showLog(TAG, "handleNotificationData")
        isHomeDataLoaded = false
        viewModel?.getUpcomingGuestEvents(isShowLoading)
    }
    
    
    
    //MARK: - IBActions
    
    @IBAction func leftBtnPressed(_ sender: UIButton){
        changeCalendarMonth(byValue: -1)
    }
    
    @IBAction func rightBtnPressed(_ sender: UIButton){
        changeCalendarMonth(byValue: 1)
    }
    
    @IBAction func filterBtnPressed(_ sender: UIButton){
        eventDates = ["2023-04-20", "2023-04-14", "2023-04-11"]
        calendar.reloadData()
    }
    
    
    
    @IBAction func viewEventsPressed(_ sender: Any) {
        Navigations.goToEvents(navigationController: navigationController,calledFrom: Constants.VIEW_EVENT)
    }
    
    
    @IBAction func newsfeedPressed(_ sender: Any) {
        changeBtnBackgroundAndLabel(view1: newsfeedView, view2: calendarView, btn1: newsFeedBtn, btn2: calendarBtn)
        tableStackView.isHidden = false
    }
    
    @IBAction func calendarPressed(_ sender: Any) {
        changeBtnBackgroundAndLabel(view1: calendarView, view2: newsfeedView, btn1: calendarBtn, btn2: newsFeedBtn)
        tableStackView.isHidden = true
    }
    
    //MARK: - Helper Methods
    private func changeBtnBackgroundAndLabel(view1: UIView, view2: UIView, btn1: UIButton, btn2: UIButton){
        CommonMethods.roundCornerFilled(uiView: view1, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: view2, borderColor: .white, backgroundColor: .white, cornerRadius: 0, borderWidth: 0)
        btn1.titleLabel?.font = boldFont
        btn2.titleLabel?.font = regularFont
    }
    
    func changeCalendarMonth(byValue value: Int){
        var calendar = Calendar.current
        calendar.timeZone = TimeZone.current
        let nextMonth = calendar.date(byAdding: .month, value: value, to: self.calendar.currentPage)!
        self.calendar.setCurrentPage(nextMonth, animated: true)
    }
    
    func changeHeaderDate(from date: Date){
        DispatchQueue.main.async{
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMMM yyyy"
            let dateString = dateFormatter.string(from: date)
            self.headerDateLabel.text = dateString
        }
    }
    
    func changeCellBackgroundOfCurrentMonth(cellDate: Date, calendarDate: Date, cell: FSCalendarCell){
        let currentMonth = Calendar.current.component(.month, from: calendarDate)
        let cellMonth = Calendar.current.component(.month, from: cellDate)
        if cellMonth == currentMonth {
            cell.backgroundColor = .white
        } else {
            cell.backgroundColor = .calendarCellSecondaryColor
        }
    }
    
    
}

//MARK: - FSCalendar Delegate And DateSource Methods
extension HomeTabVC: FSCalendarDelegateAppearance, FSCalendarDelegate, FSCalendarDataSource {
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        CommonMethods.showLog(self.TAG, "date is: \(date.formattedMonthYearString)")
        
        if eventDates.contains(date.formattedMonthYearString){
            CommonMethods.showLog(TAG, "Date Exists")
            var list : [EventModel] = []
            eventList.forEach{ data in
                if data.date == date.formattedMonthYearString{
                    list.append(data)
                }
            }
            CommonMethods.showLog(TAG, "Particular Date Event Count : \(list.count)")
            Navigations.goToEvents(navigationController: navigationController,eventList:list,calledFrom: Constants.SHOW_CALENDAR_EVENT)
            
        }
        else{
            CommonMethods.showLog(TAG, "Date Not Exists")
            self.showDialog(title:Constants.APP_NAME,message: "It seems like that there is no event on this date.")
        }
    }
    
    func calendar(_ calendar: FSCalendar, cellFor date: Date, at position: FSCalendarMonthPosition) -> FSCalendarCell {
        let cell = calendar.dequeueReusableCell(withIdentifier: "cell", for: date, at: position)
        cell.layer.borderWidth = 0.4
        cell.layer.borderColor = UIColor.calendarCellBorderColor.cgColor
        cell.contentMode = .center
        cell.titleLabel.frame = cell.bounds
        calendar.appearance.titleOffset = CGPoint(x: 0.0, y: 0.0)
        changeCellBackgroundOfCurrentMonth(cellDate: date, calendarDate: calendar.currentPage, cell: cell)
        changeHeaderDate(from: calendar.currentPage)
        return cell
    }
    
    func calendarCurrentPageDidChange(_ calendar: FSCalendar) {
        for cell in calendar.visibleCells() {
            guard let date = calendar.date(for: cell) else { continue }
            changeHeaderDate(from: calendar.currentPage)
            changeCellBackgroundOfCurrentMonth(cellDate: date, calendarDate: calendar.currentPage, cell: cell)
        }
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        
        if eventDates.contains(date.formattedMonthYearString) {
            return 1
        }
        return 0
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, eventDefaultColorsFor date: Date) -> [UIColor]? {
        
        if eventDates.contains(date.formattedMonthYearString) {
            return [.mainColor]
        }
        
        return [UIColor.white]
    }
    
}

extension HomeTabVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return eventList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventTVC", for: indexPath) as! EventTVC
        cell.selectionStyle = .none
        CommonMethods.showLog(self.TAG, "eventId: \(eventList[indexPath.row].id)")
        cell.configure(data:eventList[indexPath.row])
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        Navigations.showMyEventDetailPopup(navVc:self.navigationController,viewController: self,eventId:eventList[indexPath.row].id ?? "",isHost:false, delegate: nil, isUpcoming: true)
    }
    
    //    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    //        return 140
    //    }
    
}


extension HomeTabVC{
    
    @objc func handleNotification(notification: NSNotification) {
        if let value = notification.userInfo as? [String : Any]{
            CommonMethods.showLog(TAG, "handleNotification value : \(value)")
            if let type = value["type"] as? String{
                if type == Constants.UPDATE_HOME_FROM_APP_DELEGATE{
                    handleNotificationData()
                    CommonMethods.showLog(self.TAG, "hhe method called")
                }
            }
        }
    }
    
}

