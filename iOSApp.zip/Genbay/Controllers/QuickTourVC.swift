//
//  QuickTourVC.swift
//  Genbay
//
//  Created by Nap Works on 17/05/23.
//

import UIKit

class QuickTourVC: UIViewController {

    @IBOutlet weak var quickTourBtnView: UIView!
    @IBOutlet weak var quickTourBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        CommonMethods.roundCornerFilled(uiView: quickTourBtnView, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 20, borderWidth: 1)
    }
    
    
    @IBAction func quickTourBtnPressed(_ sender: UIButton){
        let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        
        navigationController?.pushViewController(homeVC, animated: true)
    }
}
