//
//  AddMemberViewModel.swift
//  Genbay
//
//  Created by Nap Works on 07/04/23.
//

import Foundation
import UIKit
import FirebaseCore

final class AddMemberViewModel{
    let TAG = String(describing: AddMemberViewModel.self)
    var vc : AddMembersVC
    
    
    
    init(vc: AddMembersVC) {
        self.vc = vc
    }
    
    
    func getFriendsToAddIntoCrowd(){
        self.vc.showProgressHUD()
        FirebaseAPI.default.getFriendsToAddIntoCrowd(crowdId: self.vc.crowdModel?.id ?? "", userId: self.vc.userData?.id ?? ""){ usersList in
            self.vc.hideProgressHUD()
            self.vc.usersList = usersList ?? []
            self.vc.searchUsersList = usersList ?? []
            self.checkAndShowMessage()
            CommonMethods.showLog(self.TAG, "usersList count : \(self.vc.usersList.count)")
            self.vc.tableView.reloadData()
        }
    }
    
    func getFriendsToRemoveFromCrowd(){
        self.vc.showProgressHUD()
        FirebaseAPI.default.getFriendsToRemoveFromCrowd(crowdId: self.vc.crowdModel?.id ?? "", userId: self.vc.userData?.id ?? ""){ usersList in
            self.vc.hideProgressHUD()
            self.vc.usersList = usersList ?? []
            self.vc.searchUsersList = usersList ?? []
            self.checkAndShowMessage()
            CommonMethods.showLog(self.TAG, "usersList count : \(self.vc.usersList.count)")
            self.vc.tableView.reloadData()
        }
    }
    
    func checkAndShowMessage(){
        var message = ""
        if self.vc.calledFrom == Constants.ADD_MEMBERS{
            message = "It seems like that you added all friends to crowd."
        }
        else{
            message = "It seems like that you haven't added any friend to crowd yet."
        }
        if self.vc.usersList.count == 0 {
            self.vc.noDataMessage.text = message
            self.vc.noDataMessage.isHidden = false
            self.vc.mainView.isHidden = true
        }
        else{
            self.vc.noDataMessage.isHidden = true
            self.vc.mainView.isHidden = false
        }
    }
    
    func updateMembersToCrowd(selectedList:[UserModel]){
        self.vc.showProgressHUD()
        FirebaseAPI.default.updateMembersToCrowd(crowdId: self.vc.crowdModel?.id ?? "", membersList:self.vc.crowdModel?.membersList ?? []){ success,error in
            self.vc.hideProgressHUD()
            if success{
                FirebaseAPI.default.getGuestListFirestore(userIds: self.vc.crowdModel?.membersList?.reversed() ?? []) { guestList in
                    
                    let updatedGuestList = guestList
                    NotificationCenter.default.post(name: .updatedGuestList, object: updatedGuestList)
                }
                self.checkCrowdIdExistInEvent(selectedList: selectedList)
            }
            else{
                self.vc.showDialog(title:Constants.APP_NAME,message: error)
            }
        }
    }
    
    func checkCrowdIdExistInEvent(selectedList:[UserModel]){
        CommonMethods.showLog(TAG, "Crowd Id : \(self.vc.crowdModel?.id)")
        FirebaseAPI.default.checkCrowdExistInEvent(calledFrom:self.vc.calledFrom,selectedList: selectedList,crowdId:self.vc.crowdModel?.id ?? ""){ list,error in
            CommonMethods.showLog(self.TAG, "list count : \(list.count)")
            
            NotifyData.notifyCrowdDetailVC(actionType:self.vc.calledFrom,selectedUsersList:selectedList)
            
            CommonMethods.dismiss(vc: self.vc)
            
        }
    }
}
