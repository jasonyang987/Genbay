//
//  Mentions.swift
//  Genbay
//
//  Created by Nap Works on 31/08/23.
//

import Foundation
import UIKit

public protocol OEMentionsDelegate {
    func mentionSelected(id: Int, name: String)
}

public class OEMentions: NSObject, UITextFieldDelegate {
    var textField: UITextField?
    var containerView: UIView?
    var oeObjects: [OEObject]?
    var theFilteredList = [OEObject]()
    var mentionsIndexes = [Int: Int]()
    var isMentioning = Bool()
    var mentionQuery = String()
    var startMentionIndex = Int()
    private var mentionCharater = "@"
    var delegate: OEMentionsDelegate?

    public func textFieldDidEndEditing(_ textField: UITextField) {
        self.mentionQuery = ""
        self.isMentioning = false
    }

    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString text: String) -> Bool {
        let str = String(textField.text ?? "")
        var lastCharacter = "nothing"

        if !str.isEmpty && range.location != 0 {
            lastCharacter = String(str[str.index(before: str.endIndex)])
        }

        if mentionsIndexes.count != 0 {
            for (index, length) in mentionsIndexes {
                if case index ... index + length = range.location {
                    textField.replace(textField.textRange(from: textField.position(from: textField.beginningOfDocument, offset: index)!, to: textField.position(from: textField.beginningOfDocument, offset: index + length)!)!, withText: "")
                    mentionsIndexes.removeValue(forKey: index)
                }
            }
        }

        if isMentioning {
            if text == " " || (text.count == 0 && self.mentionQuery == "") { // If Space or delete the "@"
                self.mentionQuery = ""
                self.isMentioning = false
            } else if text.count == 0 {
                self.mentionQuery.remove(at: self.mentionQuery.index(before: self.mentionQuery.endIndex))
                self.filterList(query: self.mentionQuery)
            } else {
                self.mentionQuery += text
                self.filterList(query: self.mentionQuery)
            }
        } else {
            /* (Beginning of textField) OR (space then @) */
            if text == self.mentionCharater && (range.location == 0 || lastCharacter == " ") {
                self.isMentioning = true
                self.startMentionIndex = range.location
                theFilteredList = oeObjects!
            }
        }

        return true
    }

    // Add a mention name to the UITextField
    public func addMentionToTextField(name: String) {
        mentionsIndexes[self.startMentionIndex] = name.count

        if let textField = textField {
            let range = textField.textRange(from: textField.position(from: textField.beginningOfDocument, offset: self.startMentionIndex)!, to: textField.position(from: textField.beginningOfDocument, offset: self.startMentionIndex)!)
            textField.replace(range!, withText: "@" + name)
        }
    }

    // MARK: - Utilities

    public func filterList(query: String) {
        theFilteredList.removeAll()

        if query.isEmpty {
            theFilteredList = oeObjects!
        }

        if let myOEobjects = oeObjects {
            for object in myOEobjects {
                if object.name?.lowercased().contains(query.lowercased()) ?? false {
                    theFilteredList.append(object)
                }
            }
        }
    }
}

// Rest of the code remains the same

extension UITextField {
    // Same as before
}


extension UITextField
{
    public func textRangeFromNSRange(range:NSRange) -> UITextRange?
    {
        let beginning = self.beginningOfDocument
        guard let start = self.position(from: beginning, offset: range.location), let end = self.position(from: start, offset: range.length) else { return nil}
        return self.textRange(from: start, to: end)
    }
}

public class OEObject {
    
    var id:Int?
    var name:String?
    
    public init(id:Int, name:String){
        self.id = id
        self.name = name
    }
    
}
