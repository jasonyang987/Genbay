//
//  ChooseCrowdsTVC.swift
//  Genbay
//
//  Created by Nap Works on 10/04/23.
//

import UIKit



class ChooseCrowdsTVC: UITableViewCell {
    
    let TAG = String(describing: ChooseCrowdsTVC.self)
    @IBOutlet weak var selectedImageView: UIImageView!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var lineView: UIView!
    var dataInCell : CrowdModel?
    var clickedPos : Int?

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
    func configure(data : CrowdModel?,position:Int, count: Int){
        userImage.layer.cornerRadius = userImage.frame.width/2
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        dataInCell = data
        clickedPos = position
        name.text = "\(dataInCell?.name ?? "")"
        let image = dataInCell?.imageUrl ?? ""
        if image != ""{
            userImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
        
        if dataInCell?.isSelected ?? false{
            selectedImageView.image = UIImage(named: "friend_selected")
        }
        else{
            selectedImageView.image = UIImage(named: "friend_unselected")
        }
        
        lineView.isHidden = position == count - 1
        
        
    }
    
    func configure(data : UserModel?,position:Int, count: Int){
        userImage.layer.cornerRadius = userImage.frame.width/2
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        clickedPos = position
        name.text = "\(data?.firstName ?? "") \(data?.lastName ?? "")"
        let image = data?.imageUrl ?? ""
        if image != ""{
            userImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
                
        if data?.isSelected ?? false{
            selectedImageView.image = UIImage(named: "friend_selected")
        }
        else{
            selectedImageView.image = UIImage(named: "friend_unselected")
        }
        
//        lineView.isHidden = position == count - 1
        
    }
    
}
