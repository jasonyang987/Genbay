//
//  CreateEventMemoryViewModel.swift
//  Genbay
//
//  Created by Nap Works on 15/04/23.
//

import Foundation

final class CreateEventMemoryViewModel {
    let TAG = String(describing: CreateEventMemoryViewModel.self)
    var vc : CreateEventMemoryVC
    
    init(vc: CreateEventMemoryVC) {
        self.vc = vc
    }
    
    func validate() throws {
        
        if let desc = vc.eventDescription.text {
            if desc.trimAndCheckIsEmpty() {
                throw ValidationError.descriptionEmpty
            }
        } else {
            throw ValidationError.descriptionEmpty
        }
        
    }
    
    // MARK: - Enums
    enum ValidationError: Error {
        case descriptionEmpty
        
        var localizedDescription: String {
            switch self {
            case .descriptionEmpty:
                return "Please enter event memory description."
            }
        }
        
    }
    
    func getEventMemories(){
        self.vc.showProgressHUD()
        
    }
    
    func createEventMemory(){
        var userData = UserDefaultsMapper.getUser()
        if let images = vc.pageVC?.images ,
           images.count > 0,
           let eventId = vc.eventModel?.id,
           let userId = userData?.id{
            CommonMethods.showLog(self.TAG, "memory images are : \(images) with count: \(images.count)")
            let group = DispatchGroup()
            let ref = FirebaseAPI.StorageRefenrenceType.eventMemoryPicture
            var imageList: [String] = []
            DispatchQueue.main.async {
                images.forEach { image in
                    CommonMethods.showLog(self.TAG, "REF : \(ref)")
                    
                    group.enter()
                    let imageName = "\(UUID().uuidString)_\(generateTimestamp())"
                    self.vc.showProgressHUD()
                    FirebaseAPI.default.uploadEventMemoryImage(name: imageName , image: image, eventId: eventId, reference: ref) { (error, imageURLString) in
                        if let imageString = imageURLString, error == nil {
                            self.vc.hideProgressHUD()
                            CommonMethods.showLog(self.TAG, "imageString: \(imageString)")
                            imageList.append(imageString)
                            CommonMethods.showLog(self.TAG, "imageList: \(imageList)")

                        }else {
                            CommonMethods.showLog(self.TAG, "Error : \(error)")
                            self.vc.hideProgressHUD()
                            self.vc.showDialog(title: Constants.APP_NAME,message: error?.localizedDescription ?? "Some Error Occurred while upload images")
                        }
                        
                        group.leave()
                    }
                }
                
                group.notify(queue: DispatchQueue.main){
                    CommonMethods.showLog(self.TAG, "memoryList : \(imageList.count)")
                    CommonMethods.showLog(self.TAG, "userId : \(userId)")
                    let eventMemory = EventMemoryModel()
                    eventMemory.userId = userId
                    eventMemory.eventId = eventId
                    eventMemory.createdAt = Date().timeIntervalSince1970
                    eventMemory.images = imageList
                    eventMemory.description = self.vc.eventDescription.text == self.vc.placeholderText ? "" : self.vc.eventDescription.text
                    self.vc.showProgressHUD()
                    CommonWebServices.addEventMemory(userId: eventMemory.userId ?? "", eventId: eventMemory.eventId ?? "", createdAt: Date().timeIntervalSince1970, description: eventMemory.description ?? "", imagesList: eventMemory.images ?? []){ status, message, model in
                        self.vc.hideProgressHUD()
                        if status == Constants.SUCCESS {
                            self.vc.showDialog(title: Constants.APP_NAME, message: "Memory uploaded successfully!") {
                                self.vc.navigationController?.popViewController(animated: true)
                                self.vc.delegate?.getEventMemories()
                            }
                        }else if status == Constants.FAILURE {
                            self.vc.showDialog(title : Constants.APP_NAME, message: message)
                        }
                    }
                }
            }
    
        }else{
            self.vc.showDialog(title: Constants.APP_NAME, message: "Please choose images to be uploaded")
        }
    }
}

func generateTimestamp() -> String {
    let currentTime = Int(Date().timeIntervalSince1970)
    return String(currentTime)
}
