const functions = require("firebase-functions");
const admin = require("firebase-admin");
const Constants = require("./Constants");
if (Constants.IS_LOCAL_FUNCTION) {
    var serviceAccount = require("/Users/napworks/Documents/Certificates/genbay-admin-sdk.json");
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        databaseURL: "http://127.0.0.1:9001/?ns=genbay-116d4-default-rtdb"
    });
} else {
    admin.initializeApp();
}

const User = require("./User")
const FriendRequest = require("./FriendRequest")
const TestData = require("./TestData")
const Events = require("./Events")
const CommonMethods = require("./CommonMethods");
const { user } = require("firebase-functions/v1/auth");


//! This is notifications collections reference in the firestore database.
const notifications = admin.firestore().collection("notifications");

//! This function will send a notification to all the members of the event when an event is created.

/**
 * this method will be called every day at 12:00 AM and it will check for the invalid tokens and remove them from the database.
 * It will help to avoid unnecessary errors related to invalid tokens.
 * As because the invalid tokens are not removed from the database, so the user will not get the notifications and delays in the notifications will occur.
*/

// exports.cleanupInvalidTokens = functions.https.onRequest(async (req, res) => {
//     const usersRef = admin.database().ref('/users');
//     const usersSnapshot = await usersRef.once('value');
//     const users = usersSnapshot.val();
//     if (users) {
//         for (const userId of Object.keys(users)) {
//             const tokens = users[userId].tokens || [];
//             tokens.forEach((token) => {
//                 verifyFCMToken(token)
//                     .then(result => {
//                         console.log(`Token ${token} for user ${userId} is still valid.`);
//                     })
//                     .catch(err => {
//                         console.error(`Token ${token} for user ${userId} is invalid. Removing..`);
//                         admin.database().ref(`/users/${userId}/tokens/${token}`).remove();
//                     })
//             });
//         }

//         res.status(200).send("Tokens cleaned up successfully.");
//     }

// });

exports.cleanupInvalidTokens = functions.pubsub.schedule('0 8 * * *').onRun(async (context) => {
    const usersRef = admin.database().ref('/users');
    const usersSnapshot = await usersRef.once('value');
    const users = usersSnapshot.val();

    if (users) {
        for (const userId of Object.keys(users)) {
            let tokens = users[userId].tokens || [];
            tokens.forEach((token) => {
                verifyFCMToken(token)
                    .then(result => {
                        console.log(`Token ${token} for user ${userId} is still valid.`);
                    })
                    .catch(err => {
                        console.error(`Token ${token} for user ${userId} is invalid. Removing..`);
                        tokens = tokens.filter(t => t !== token);
                        admin.database().ref(`/users/${userId}/tokens`).set(tokens).then(() => {
                            console.log("Token removed successfully.");
                        }).catch((error) => {
                            console.log("Error removing token: ", error);
                        });
                        // admin.database().ref(`/users/${userId}/tokens/${token}`).remove();
                    })
            });
        }
    }

    return true;
});

function verifyFCMToken(fcmToken) {
    return admin.messaging().send({
        token: fcmToken
    }, true)
}


function sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, type, userId) {
    let notificationSettings = memberDetail.notificationSettings
    const notificationRef = notifications.doc(memberId).collection("notificationsList");
    let autoId = notificationRef.doc().id;
    eventData.hostName = `${userDetail.firstName} ${userDetail.lastName}`

    const data = {
        type: type,
        message: body,
        userImage: userDetail.imageUrl,
        visibleTo: memberId,
        userId: userId,
        // eventData: JSON.stringify(eventData),
        eventId: eventData.id,
        timeStamp: String(Date.now()),
        notificationId: autoId
    };

    const newNotification = {
        type: type,
        info: data,
        id: autoId,
        status: 0,
    };
    notificationRef.doc(autoId).set(newNotification);
    const notificationObj = { notificationSettings: 'someValue' };

    if (type == Constants.CO_HOST_INVITE) {
        if (notificationSettings != undefined) {
            if (notificationSettings.muteAllPushNotifications == true) {
                console.log("User has turned off event invite notifications.");
            } else {
                console.log("Settings exist");
                CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
            }
        } else {
            console.log("muteAllPushNotifications Settings not exist");
            CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }

    }
    else if (type == Constants.EVENT_CREATED || type == Constants.EVENT_UPDATED) {
        if (notificationSettings != undefined) {
            if (notificationSettings.inviteToEvents == false || notificationSettings.muteAllPushNotifications == true) {
                console.log("User has turned off event invite notifications.");
            } else {
                console.log("EVENT_CREATED Notification Send Hon Lgi");
                CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
            }
        } else {
            console.log("inviteToEvents Settings not exist");
            CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }

    }
    else if (type == Constants.EVENT_COMMENT_ADDED) {
        if (notificationSettings != undefined) {
            if (notificationSettings.discussionComments == false || notificationSettings.muteAllPushNotifications == true) {
                console.log("User has turned off discussion comments notifications.");
                // return null;
            } else {
                console.log("EVENT_COMMENT_ADDED Notification Send Hon Lgi");
                CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
            }
        } else {
            console.log("discussionComments Settings not exist");
            CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
    }
    else if (type == Constants.USER_MENTIONED) {
        if (notificationSettings != undefined) {
            if (notificationSettings.mentions == false || notificationSettings.muteAllPushNotifications == true) {
                console.log("User has turned off mention notifications.");
                // return null;
            } else {
                console.log("USER_MENTIONED Notification Send Hon Lgi");
                CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
            }
        } else {
            console.log("mentions Settings not exist");
            CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
    }
    else if (type == Constants.EVENT_MEMORY_ADDED) {
        if (notificationSettings != undefined) {
            if (notificationSettings.newEventMemories == false || notificationSettings.muteAllPushNotifications == true) {
                console.log("User has turned off event memories notifications.");
                // return null;
            }
            else {
                CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
            }
        } else {
            console.log("newEventMemories Settings not exist");
            CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
    }
    else if (type == Constants.GOING_TO_EVENT) {
        if (notificationSettings != undefined) {
            if (notificationSettings.eventAttendanceUpdates == false || notificationSettings.muteAllPushNotifications == true) {
                console.log("User has turned off event attendance updates notifications.");
                // return null;
            } else {
                CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
            }
        } else {
            console.log("eventAttendanceUpdates Settings not exist");
            CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
    }
}

// exports.eventCreated = functions.firestore
//     .document("/events/{eventId}")
//     .onCreate((snapshot, context) => {
//         const eventData = snapshot.data();
//         console.log("eventData : ", eventData);
//         User.getUserData('users', eventData.userId, function (userSuccess, userDetail) {
//             console.log("users success : ", userSuccess);
//             if (userSuccess) {
//                 let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                 let body = `${userDetail.firstName} ${userDetail.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
//                 if (eventData.isVisibleToAllSelected) {
//                     User.getUserFriends('friends', userDetail.id, function (friendsSuccess, friendList) {
//                         console.log("Friends success : ", friendsSuccess);
//                         if (friendsSuccess) {
//                             if (friendList.length > 0) {
//                                 friendList.forEach((memberId) => {
//                                     User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                         console.log("Member success : ", memberSuccess + " " + memberId);
//                                         if (memberSuccess) {
//                                             sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_CREATED, eventData.userId)
//                                         } else {
//                                             console.log("Error While Getting Member Data");
//                                         }
//                                     });
//                                 })
//                             }
//                         } else {
//                             console.log("Error While Getting Friend List");
//                         }
//                     });
//                 }
//                 else {
//                     const selectedMembers = eventData.selectedMembers;
//                     if (selectedMembers.length > 0) {
//                         selectedMembers.forEach((memberId) => {
//                             User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                 console.log("Member success : ", memberSuccess);
//                                 if (memberSuccess) {
//                                     console.log("MemberId : " + memberId)
//                                     sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_CREATED, eventData.userId)
//                                 } else {
//                                     console.log("Error While Getting Member Data");
//                                 }
//                             });
//                         })
//                     }
//                 }

//                 ///// CoHost Notifications
//                 const invitedCoHosts = eventData.pendingCoHostInvites;

//                 if (invitedCoHosts.length > 0) {
//                     let body = `${userDetail.firstName} ${userDetail.lastName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`
//                     invitedCoHosts.forEach((memberId) => {
//                         User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                             console.log("Member success : ", memberSuccess);
//                             if (memberSuccess) {
//                                 sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.CO_HOST_INVITE, eventData.userId)
//                             } else {
//                                 console.log("Error While Getting Member Data");
//                             }
//                         });
//                     })
//                 }
//                 else {
//                     console.log("Invited CoHost Empty");
//                 }

//             } else {
//                 console.log("Error While Getting User Data");
//             }
//         });
//         return true;
//     })

// exports.eventUpdated = functions.firestore
//     .document("/events/{eventId}")
//     .onUpdate((snapshot, context) => {
//         const eventData = snapshot.after.data();
//         const eventName = eventData.name;
//         const beforeEventData = snapshot.before.data();

//         ///// Going Notification
//         if (eventData.goingList.length > 0) {
//             // if (eventData.goingList.length > beforeEventData.goingList.length) {
//             const newGoingUsers = eventData.goingList.filter((user) => {
//                 return !beforeEventData.goingList.includes(user);
//             });
//             console.log("New Going Users are: ", newGoingUsers);
//             let hosts = eventData.acceptedCoHostInvites
//             hosts.push(eventData.userId)
//             //earlier only the host was getting the notification of going members, but now all the co-hosts will get the notification
//             hosts.forEach((hostId) => {
//                 User.getUserData('users', hostId, function (hostSuccess, hostDetail) {
//                     console.log("hostSuccess : ", hostSuccess);
//                     if (hostSuccess) {
//                         if (newGoingUsers.length > 0) {
//                             newGoingUsers.forEach((goingUserId) => {
//                                 User.getUserData('users', goingUserId, function (goingUserSuccess, goingUserDetail) {
//                                     console.log("goingUserSuccess : ", goingUserSuccess);
//                                     if (goingUserSuccess) {
//                                         let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                                         let body = `${goingUserDetail.firstName} ${goingUserDetail.lastName} is going to ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                         sendNotificationFromServer(hostId, body, hostDetail, eventData, goingUserDetail, Constants.GOING_TO_EVENT, eventData.userId)
//                                     } else {
//                                         console.log("Error While Getting Member Data");
//                                     }
//                                 });
//                             })
//                         }
//                         else {
//                             console.log("New Going Users Empty");
//                         }
//                     } else {
//                         console.log("Error While Getting Host Data");
//                     }
//                 });
//             });
//             // } else {
//             // console.log("No new user added in the event going list.");
//             // }
//         } else {
//             console.log("No user in the event going list.");
//         }

//         /// Other Change In Event
//         User.getUserData('users', eventData.userId, function (userSuccess, userDetail) {
//             console.log("users success : ", userSuccess);
//             if (userSuccess) {
//                 let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                 let body = `${userDetail.firstName} ${userDetail.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`


//                 // Pending Co-Host Notificaition
//                 if (eventData.pendingCoHostInvites.length > 0) {
//                     // if (
//                     //     eventData.pendingCoHostInvites.length >
//                     //     beforeEventData.pendingCoHostInvites.length
//                     // ) {
//                     const newCoHostInvites = eventData.pendingCoHostInvites.filter(
//                         (member) => {
//                             return !beforeEventData.pendingCoHostInvites.includes(member);
//                         }
//                     );
//                     console.log("New co-host invites are: ", newCoHostInvites);
//                     if (newCoHostInvites.length > 0) {
//                         let body = `${userDetail.firstName} ${userDetail.lastName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`
//                         newCoHostInvites.forEach((memberId) => {
//                             User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                 console.log("Member success : ", memberSuccess);
//                                 if (memberSuccess) {
//                                     sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.CO_HOST_INVITE, eventData.userId)
//                                 } else {
//                                     console.log("Error While Getting Member Data");
//                                 }
//                             });
//                         })
//                     }
//                     else {
//                         console.log("No new co-host invites.");
//                     }
//                     // } else {
//                     //     console.log("No new co-host invite added in the event.");
//                     // }
//                 } else {
//                     console.log("Pending Co-Host Empty");
//                 }

//                 // 
//                 if (eventData.isVisibleToAllSelected == true) {
//                     if (beforeEventData.isVisibleToAllSelected == true && eventData.isVisibleToAllSelected == true) {
//                         // Same Data 
//                         console.log("Before and now data are same (VISIBLE TO ALL)");
//                     }
//                     else {
//                         console.log("Before and now data are not same (VISIBLE TO ALL)");
//                         User.getUserFriends('friends', userDetail.id, function (friendsSuccess, friendList) {
//                             console.log("Friends success : ", friendsSuccess);
//                             if (friendsSuccess) {
//                                 if (friendList.length > 0) {
//                                     friendList.forEach((memberId) => {
//                                         User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                             console.log("Member success : ", memberSuccess + " " + memberId);
//                                             if (memberSuccess) {
//                                                 sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
//                                             } else {
//                                                 console.log("Error While Getting Member Data");
//                                             }
//                                         });
//                                     })
//                                 }
//                             } else {
//                                 console.log("Error While Getting Friend List");
//                             }
//                         });
//                     }
//                 }
//                 else {
//                     // if (
//                     //     eventData.selectedMembers.length >
//                     //     beforeEventData.selectedMembers.length
//                     // ) {
//                     const newSelectedMembers = eventData.selectedMembers.filter(
//                         (member) => {
//                             return !beforeEventData.selectedMembers.includes(member);
//                         }
//                     );
//                     console.log("New selected members are: ", newSelectedMembers);
//                     if (newSelectedMembers.length > 0) {
//                         let body = `${userDetail.firstName} ${userDetail.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
//                         newSelectedMembers.forEach((memberId) => {
//                             User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                 console.log("Member success : ", memberSuccess);
//                                 if (memberSuccess) {
//                                     sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
//                                 } else {
//                                     console.log("Error While Getting Member Data");
//                                 }
//                             });
//                         })
//                     }
//                     else {
//                         console.log("No new Member Selected.");
//                     }
//                     // } else {
//                     // console.log("No new member added in the event.");
//                     // }
//                 }


//                 if (beforeEventData.dateTimestamp != eventData.dateTimestamp ||
//                     beforeEventData.description != eventData.description ||
//                     beforeEventData.location != eventData.location ||
//                     beforeEventData.name != eventData.name ||
//                     beforeEventData.startTimestamp != eventData.startTimestamp) {
//                     if (eventData.isVisibleToAllSelected == true) {
//                         User.getUserFriends('friends', userDetail.id, function (friendsSuccess, friendList) {
//                             console.log("Friends success : ", friendsSuccess);
//                             if (friendsSuccess) {
//                                 if (friendList.length > 0) {
//                                     friendList.forEach((memberId) => {
//                                         User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                             console.log("Member success : ", memberSuccess + " " + memberId);
//                                             if (memberSuccess) {
//                                                 let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                                                 let body = `${userDetail.firstName} ${userDetail.lastName} updated ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                                 sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
//                                             } else {
//                                                 console.log("Error While Getting Member Data");
//                                             }
//                                         });
//                                     })
//                                 }
//                             } else {
//                                 console.log("Error While Getting Friend List");
//                             }
//                         });
//                     }
//                     else {
//                         const selectedMembers = eventData.selectedMembers;
//                         if (selectedMembers.length > 0) {
//                             selectedMembers.forEach((memberId) => {
//                                 User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                     console.log("Member success : ", memberSuccess);
//                                     if (memberSuccess) {
//                                         console.log("MemberId : " + memberId)
//                                         let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                                         let body = `${userDetail.firstName} ${userDetail.lastName} updated ${eventData.name} | ${eventData.startTime} ${dateString}`

//                                         sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
//                                     } else {
//                                         console.log("Error While Getting Member Data");
//                                     }
//                                 });
//                             })
//                         }
//                     }
//                 }
//                 else {
//                     console.log("Before and now data are same");
//                 }


//                 // if (eventData.isVisibleToAllSelected == true) {
//                 //     User.getUserFriends('friends', userDetail.id, function (friendsSuccess, friendList) {
//                 //         console.log("Friends success : ", friendsSuccess);
//                 //         if (friendsSuccess) {
//                 //             if (friendList.length > 0) {
//                 //                 friendList.forEach((memberId) => {
//                 //                     User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                 //                         console.log("Member success : ", memberSuccess + " " + memberId);
//                 //                         if (memberSuccess) {
//                 //                             sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
//                 //                         } else {
//                 //                             console.log("Error While Getting Member Data");
//                 //                         }
//                 //                     });
//                 //                 })
//                 //             }
//                 //         } else {
//                 //             console.log("Error While Getting Friend List");
//                 //         }
//                 //     });
//                 // } else {
//                 //     if (
//                 //         eventData.selectedMembers.length >
//                 //         beforeEventData.selectedMembers.length
//                 //     ) {
//                 //         const newSelectedMembers = eventData.selectedMembers.filter(
//                 //             (member) => {
//                 //                 return !beforeEventData.selectedMembers.includes(member);
//                 //             }
//                 //         );
//                 //         console.log("New selected members are: ", newSelectedMembers);
//                 //         if (newSelectedMembers.length > 0) {
//                 //             let body = `${userDetail.firstName} ${userDetail.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
//                 //             newSelectedMembers.forEach((memberId) => {
//                 //                 User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                 //                     console.log("Member success : ", memberSuccess);
//                 //                     if (memberSuccess) {
//                 //                         sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
//                 //                     } else {
//                 //                         console.log("Error While Getting Member Data");
//                 //                     }
//                 //                 });
//                 //             })
//                 //         }
//                 //         else {
//                 //             console.log("No new Member Selected.");
//                 //         }
//                 //     } else {
//                 //         console.log("No new member added in the event.");
//                 //     }
//                 // }

//             } else {
//                 console.log("Error While Getting User Data");
//             }
//         });

//         return true;
//     });


// exports.addCommentInEventDiscussion = functions.firestore
//     .document("/events/{eventId}/event_comments/{commentId}")
//     .onCreate((snapshot, context) => {

//         const commentData = snapshot.data();
//         let eventId = context.params.eventId;
//         console.log("addCommentInEventDiscussion");
//         Events.getEventData(eventId, function (eventDataSuccess, eventData) {
//             console.log("eventDataSuccess : ", eventDataSuccess);
//             if (eventDataSuccess) {
//                 console.log("eventData is: ", eventData);
//                 console.log("commentData is: ", commentData);
//                 User.getUserData('users', commentData.userId, function (userSuccess, userDetail) {
//                     console.log("userSuccess : ", userSuccess);
//                     console.log("userDetail : ", userDetail);
//                     if (userSuccess) {
//                         let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                         let body = `${userDetail.firstName} ${userDetail.lastName} commented in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`

//                         let coHosts = eventData.acceptedCoHostInvites
//                         let selectedMembers = eventData.goingList

//                         console.log("MEMBERS DATA : ", selectedMembers.length);
//                         var finalMembers = selectedMembers.concat(coHosts)
//                         console.log("MEMBERS DATA AFTER");
//                         console.log("Commented User Id : " + commentData.userId)
//                         console.log("Event User Id : " + eventData.userId)
//                         if (commentData.userId != eventData.userId) {
//                             finalMembers.push(eventData.userId)
//                             finalMembers = finalMembers.filter(memberId => memberId !== commentData.userId);
//                             console.log("selectedMembers are: ", finalMembers);
//                         }
//                         console.log("MEMBERS COUNT : ", finalMembers.length);
//                         if (finalMembers.length > 0) {
//                             finalMembers.forEach((memberId) => {
//                                 User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                     console.log("Member success : ", memberSuccess);
//                                     if (memberSuccess) {
//                                         console.log("MemberId : " + memberId)
//                                         sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_COMMENT_ADDED, userDetail.id)
//                                     } else {
//                                         console.log("Error While Getting Member Data");
//                                     }
//                                 });
//                             })
//                         }
//                         //notify the mentioned users
//                         let comment = commentData.comment
//                         const regex = /@(\w+)/g;
//                         if (comment.match(regex)) {
//                             let mentionedUsers = comment.match(regex).map((user) => user.slice(1));
//                             if (mentionedUsers.length > 0) {
//                                 if (mentionedUsers.includes('guests')) {
//                                     if (eventData.isVisibleToAllSelected == true) {
//                                         //// If Else Lgana id kdni ode base te 
//                                         User.getUserFriends('friends', eventData.userId, function (friendsSuccess, friendList) {
//                                             console.log("Friends success : ", friendsSuccess);
//                                             if (friendsSuccess) {
//                                                 if (friendList.length == 0) {
//                                                     friendList = []
//                                                 }
//                                                 let allMembers = friendList.concat(coHosts)
//                                                 if (commentData.userId != eventData.userId) {
//                                                     allMembers.push(eventData.userId)
//                                                     allMembers = allMembers.filter(memberId => memberId !== commentData.userId);
//                                                 }

//                                                 if (allMembers.length > 0) {
//                                                     allMembers.forEach((memberId) => {
//                                                         User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                                             console.log("Member success : ", memberSuccess + " " + memberId);
//                                                             if (memberSuccess) {
//                                                                 // Notification send krni mention Vali
//                                                                 let body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                                                 sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.USER_MENTIONED, userDetail.id)
//                                                             } else {
//                                                                 console.log("Error While Getting Member Data");
//                                                             }
//                                                         });
//                                                     })
//                                                 }
//                                             } else {
//                                                 console.log("Error While Getting Friend List");
//                                             }
//                                         });
//                                     }
//                                     else {
//                                         let selectedMembers = eventData.selectedMembers
//                                         let allMembers = selectedMembers.concat(coHosts)
//                                         if (commentData.userId != eventData.userId) {
//                                             allMembers.push(eventData.userId)
//                                             allMembers = allMembers.filter(memberId => memberId !== commentData.userId);
//                                         }
//                                         console.log("selectedMembers are: ", allMembers);
//                                         if (allMembers.length > 0) {
//                                             allMembers.forEach((memberId) => {
//                                                 User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                                     console.log("Member success : ", memberSuccess);
//                                                     if (memberSuccess) {
//                                                         console.log("MemberId : " + memberId)
//                                                         let body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                                         sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.USER_MENTIONED, userDetail.id)
//                                                     } else {
//                                                         console.log("Error While Getting Member Data");
//                                                     }
//                                                 });
//                                             })
//                                         }
//                                     }
//                                 } else {
//                                     console.log("mentionedUsers are: ", mentionedUsers);
//                                     mentionedUsers.forEach((mentionedId) => {
//                                         User.getUserDataFromUsername(mentionedId, function (mentionUserSuccess, mentionedUserId) {
//                                             console.log("mentionUserSuccess : ", mentionUserSuccess);
//                                             // console.log("mentionedUserDetail : ", mentionedUserDetail.notificationSettings.mentions)
//                                             if (mentionUserSuccess) {
//                                                 const userId = Object.keys(mentionedUserId)[0];
//                                                 console.log("mentionedUserId : ", userId)
//                                                 User.getUserData('users', userId, function (mentionedUserInnerSuccess, mentionedUserInnerDetail) {
//                                                     console.log("Member success : ", mentionedUserInnerSuccess);
//                                                     if (mentionedUserInnerSuccess) {
//                                                         let body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                                         sendNotificationFromServer(userId, body, userDetail, eventData, mentionedUserInnerDetail, Constants.USER_MENTIONED, userDetail.id)
//                                                     } else {
//                                                         console.log("Error While Getting Member Data");
//                                                     }
//                                                 });
//                                                 // sendNotificationFromServer(mentionedId, body, userDetail, eventData, mentionedUserDetail, Constants.USER_MENTIONED, userDetail.id)
//                                             } else {
//                                                 console.log("Error While Getting mentionUser Data");
//                                             }
//                                         });
//                                     })
//                                 }
//                             }
//                             else {
//                                 console.log("No Mention Inside in comment");
//                             }
//                         }
//                         else {
//                             console.log("No Mention in comment");
//                         }
//                     } else {
//                         console.log("Error While Getting User Data");
//                     }
//                 });
//             } else {
//                 console.log("Error While Getting Event Data");
//             }
//         });
//         return true;
//     });

// exports.addMemoryToEvent = functions.firestore
//     .document("/events/{eventId}/event_memories/{memoryId}")
//     .onCreate((snapshot, context) => {
//         const memoryData = snapshot.data();
//         Events.getEventData(memoryData.eventId, function (eventDataSuccess, eventData) {
//             console.log("addMemoryToEvent eventDataSuccess : ", eventDataSuccess);
//             if (eventDataSuccess) {
//                 console.log("addMemoryToEvent eventData is: ", eventData);
//                 console.log("addMemoryToEvent memoryData is: ", memoryData);
//                 User.getUserData('users', memoryData.userId, function (userSuccess, userDetail) {
//                     console.log("userSuccess : ", userSuccess);
//                     console.log("userDetail : ", userDetail);
//                     if (userSuccess) {
//                         let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                         let body = `${userDetail.firstName} ${userDetail.lastName} has added a memory to ${eventData.name} | ${eventData.startTime} ${dateString}`
//                         let coHosts = eventData.acceptedCoHostInvites
//                         if (eventData.isVisibleToAllSelected == true) {
//                             User.getUserFriends('friends', eventData.userId, function (friendsSuccess, friendList) {
//                                 console.log("Friends success : ", friendsSuccess);
//                                 if (friendsSuccess) {
//                                     if (friendList.length == 0) {
//                                         friendList = []
//                                     }
//                                     let allMembers = friendList.concat(coHosts)
//                                     if (memoryData.userId != eventData.userId) {
//                                         allMembers.push(eventData.userId)
//                                         allMembers = allMembers.filter(memberId => memberId !== memoryData.userId);
//                                     }

//                                     if (allMembers.length > 0) {
//                                         allMembers.forEach((memberId) => {
//                                             User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                                 console.log("Member success : ", memberSuccess + " " + memberId);
//                                                 if (memberSuccess) {
//                                                     sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_MEMORY_ADDED, userDetail.id)
//                                                 } else {
//                                                     console.log("Error While Getting Member Data");
//                                                 }
//                                             });
//                                         })
//                                     }
//                                 } else {
//                                     console.log("Error While Getting Friend List");
//                                 }
//                             });
//                         }
//                         else {
//                             let selectedMembers = eventData.selectedMembers
//                             let allMembers = selectedMembers.concat(coHosts)
//                             if (memoryData.userId != eventData.userId) {
//                                 allMembers.push(eventData.userId)
//                                 allMembers = allMembers.filter(memberId => memberId !== memoryData.userId);
//                             }
//                             console.log("selectedMembers are: ", allMembers);
//                             if (allMembers.length > 0) {
//                                 allMembers.forEach((memberId) => {
//                                     User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                         console.log("Member success : ", memberSuccess);
//                                         if (memberSuccess) {
//                                             console.log("MemberId : " + memberId)
//                                             sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_MEMORY_ADDED, userDetail.id)
//                                         } else {
//                                             console.log("Error While Getting Member Data");
//                                         }
//                                     });
//                                 })
//                             }
//                         }

//                     } else {
//                         console.log("Error While Getting User Data");
//                     }
//                 });
//             } else {
//                 console.log("addMemoryToEvent Error While Getting Event Data");
//             }
//         });
//         return true;
//     });


function sendFriendNotificationFromServer(title, body, friendData, userData, type) {
    let notificationSettings = friendData.notificationSettings
    const notificationRef = notifications.doc(friendData.id).collection("notificationsList");
    let autoId = notificationRef.doc().id;

    const data = {
        type: type,
        message: body,
        userImage: userData.imageUrl,
        visibleTo: friendData.id,
        userId: userData.id,
        timeStamp: String(Date.now()),
        notificationId: autoId,
    };

    const newNotification = {
        type: type,
        info: data,
        id: autoId,
        status: 0,
    };
    notificationRef.doc(autoId).set(newNotification);

    if (type == Constants.FRIEND_REQUEST_SENT || type == Constants.FRIEND_REQUEST_ACCEPTED) {
        if (notificationSettings.friendRequests == false || notificationSettings.muteAllPushNotifications == true) {
            console.log("User has turned off event invite notifications.");
        } else {
            CommonMethods.sendNotification(title, body, data, friendData.tokens, type);
        }
    }
}

// exports.friendRequestSent = functions.database
//     .ref("/friends/{userId}/pendingList/{index}")
//     .onCreate((snapshot, context) => {
//         const friendIndex = context.params.index;
//         const userId = context.params.userId;
//         console.log("userId is: ", userId);
//         console.log("friendIndex is: ", friendIndex);

//         User.getList(Constants.PENDING_LIST, userId, function (pendingListSuccess, pendingList) {
//             console.log("pendingListSuccess  : ", pendingListSuccess);
//             if (pendingListSuccess) {
//                 if (pendingList.length > 0) {
//                     const friendId = pendingList[friendIndex];
//                     User.getUserData('users', userId, function (userSuccess, userDetail) {
//                         console.log("userSuccess  : ", userSuccess + " " + userSuccess);
//                         if (userSuccess) {
//                             User.getUserData('users', friendId, function (friendSuccess, friendData) {
//                                 console.log("friendSuccess  : ", friendSuccess);
//                                 if (friendSuccess) {
//                                     let body = `${friendData.firstName} ${friendData.lastName} sent you a friend request`
//                                     sendFriendNotificationFromServer("Friend Request", body, friendData, userDetail, Constants.FRIEND_REQUEST_SENT)

//                                 } else {
//                                     console.log("Error While Getting Friend Data");
//                                 }
//                             });
//                         } else {
//                             console.log("Error While Getting User Data");
//                         }
//                     });
//                 }
//                 else {
//                     console.log(`Pending friend requests not found for user ${userId}`);
//                     // return null;
//                 }

//             } else {
//                 console.log("Error While Getting Pending List");
//             }
//         });
//         return true;
//     });

// exports.friendRequestAccepted = functions.database
//     .ref("/friends/{userId}/pendingList")
//     .onUpdate((snapshot, context) => {
//         const pendingListBefore = snapshot.before.val();
//         const pendingListAfter = snapshot.after.val();
//         const userId = context.params.userId;
//         console.log("userId is: ", userId);
//         const removedId = pendingListBefore.filter((id) => {
//             return !pendingListAfter.includes(id);
//         });
//         const finalRemovedId = removedId.toString();
//         console.log("Removed id is: ", finalRemovedId);
//         User.getList(Constants.ACCEPTED_LIST, userId, function (acceptedListSuccess, acceptedList) {
//             console.log("acceptedListSuccess  : ", acceptedListSuccess);
//             if (acceptedListSuccess) {
//                 if (acceptedList.length > 0) {
//                     if (acceptedList.includes(finalRemovedId)) {
//                         console.log(`User ${finalRemovedId} is a friend of user ${userId}`);
//                         User.getUserData('users', userId, function (userSuccess, userData) {
//                             console.log("userSuccess  : ", userSuccess);
//                             if (userSuccess) {
//                                 User.getUserData('users', finalRemovedId, function (removedUserSuccess, removedUser) {
//                                     console.log("removedUserSuccess  : ", removedUserSuccess);
//                                     if (removedUserSuccess) {
//                                         let body = `${userData.firstName} ${userData.lastName} has accepted your friend request!`
//                                         sendFriendNotificationFromServer("Friend Request Accepted", body, userData, removedUser, Constants.FRIEND_REQUEST_ACCEPTED)

//                                         // Events.getListOfEvents(userData.id, function (listSuccess, listData) {
//                                         //     if (listSuccess) {
//                                         //         const userEvents = listData.docs.map((doc) => doc.data());
//                                         //         if (userEvents.length > 0) {
//                                         //             // listData.forEach((doc) => {
//                                         //             //     console.log(`${doc.id} => ${JSON.stringify(doc.data())}`);
//                                         //             // });

//                                         //             userEvents.forEach((eventData) => {
//                                         //                 User.getUserData('users', finalRemovedId, function (memberSuccess, memberDetail) {
//                                         //                     console.log("Member success : ", memberSuccess + " " + memberId);
//                                         //                     if (memberSuccess) {
//                                         //                         let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                                         //                         let body = `${userData.firstName} ${userData.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                         //                         sendNotificationFromServer(finalRemovedId, body, userData, eventData, memberDetail, Constants.EVENT_CREATED, eventData.userId)
//                                         //                     } else {
//                                         //                         console.log("Error While Getting Member Data");
//                                         //                     }
//                                         //                 });
//                                         //             });
//                                         //         }
//                                         //         else {
//                                         //             console.log("User has not created any event.");
//                                         //         }
//                                         //     }
//                                         //     else {
//                                         //         console.log("Error While Getting Data List");
//                                         //     }
//                                         // });
//                                     } else {
//                                         console.log("Error While Getting Removed User Data");
//                                     }
//                                 });
//                             } else {
//                                 console.log("Error While Getting User Data");
//                             }
//                         });
//                     } else {
//                         console.log("Friend request not accepted.");
//                     }
//                 }
//                 else {
//                     console.log(`Accepted friend requests not found for user ${userId}`);
//                     // return null;
//                 }

//             } else {
//                 console.log("Error While Getting Pending List");
//             }
//         });
//         return true;
//     });

// exports.friendRequestAcceptedOne = functions.database
//     .ref("/friends/{userId}/pendingList")
//     .onDelete((snapshot, context) => {
//         const pendingList = snapshot.val();
//         console.log("pendingList is: ", pendingList);
//         const userId = context.params.userId;
//         if (pendingList.length > 1) {
//             return null;
//         } else {
//             const finalRemovedId = pendingList.toString();
//             console.log("Removed id is: ", finalRemovedId);
//             User.getList(Constants.ACCEPTED_LIST, userId, function (acceptedListSuccess, acceptedList) {
//                 console.log("acceptedListSuccess  : ", acceptedListSuccess);
//                 if (acceptedListSuccess) {
//                     if (acceptedList.length > 0) {
//                         if (acceptedList.includes(finalRemovedId)) {
//                             console.log(`User ${finalRemovedId} is a friend of user ${userId}`);
//                             User.getUserData('users', userId, function (userSuccess, userData) {
//                                 console.log("userSuccess  : ", userSuccess);
//                                 if (userSuccess) {
//                                     User.getUserData('users', finalRemovedId, function (removedUserSuccess, removedUser) {
//                                         console.log("removedUserSuccess  : ", removedUserSuccess);
//                                         if (removedUserSuccess) {
//                                             let body = `${userData.firstName} ${userData.lastName} has accepted your friend request!`
//                                             sendFriendNotificationFromServer("Friend Request Accepted", body, userData, removedUser, Constants.FRIEND_REQUEST_ACCEPTED)
//                                             // Events.getListOfEvents(userData.id, function (listSuccess, listData) {
//                                             //     if (listSuccess) {
//                                             //         const userEvents = listData.docs.map((doc) => doc.data());
//                                             //         if (userEvents.length > 0) {
//                                             //             // listData.forEach((doc) => {
//                                             //             //     console.log(`${doc.id} => ${JSON.stringify(doc.data())}`);
//                                             //             // });

//                                             //             userEvents.forEach((eventData) => {
//                                             //                 User.getUserData('users', finalRemovedId, function (memberSuccess, memberDetail) {
//                                             //                     console.log("Member success : ", memberSuccess + " " + memberId);
//                                             //                     if (memberSuccess) {
//                                             //                         let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                                             //                         let body = `${userData.firstName} ${userData.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                             //                         sendNotificationFromServer(finalRemovedId, body, userData, eventData, memberDetail, Constants.EVENT_CREATED, eventData.userId)
//                                             //                     } else {
//                                             //                         console.log("Error While Getting Member Data");
//                                             //                     }
//                                             //                 });
//                                             //             });
//                                             //         }
//                                             //         else {
//                                             //             console.log("User has not created any event.");
//                                             //         }
//                                             //     }
//                                             //     else {
//                                             //         console.log("Error While Getting Data List");
//                                             //     }
//                                             // });
//                                         } else {
//                                             console.log("Error While Getting Removed User Data");
//                                         }
//                                     });
//                                 } else {
//                                     console.log("Error While Getting User Data");
//                                 }
//                             });
//                         } else {
//                             console.log("Friend request not accepted.");
//                         }
//                     }
//                     else {
//                         console.log(`Accepted friend requests not found for user ${userId}`);
//                         // return null;
//                     }

//                 } else {
//                     console.log("Error While Getting Pending List");
//                 }
//             });
//         }
//         return true;
//     });

// // exports.eventCreated = functions.firestore
// //     .document("/events/{eventId}")
// //     .onCreate(async (snapshot, context) => {
// //         const eventData = snapshot.data();
// //         const eventName = eventData.name;
// //         const user = await getUserWithId(eventData.userId);
// //         if (eventData.isVisibleToAllSelected == true) {
// //             const selectedMembers = await getUserFriends(eventData.userId);
// //             await sendEventNotification(
// //                 user,
// //                 eventData,
// //                 selectedMembers,
// //                 eventName,
// //                 "created"
// //             );
// //         } else {
// //             const selectedMembers = eventData.selectedMembers;
// //             await sendEventNotification(
// //                 user,
// //                 eventData,
// //                 selectedMembers,
// //                 eventName,
// //                 "created"
// //             );
// //         }
// //         const invitedCoHosts = eventData.pendingCoHostInvites;
// //         if (invitedCoHosts.length > 0) {
// //             await sendCoHostInviteNotification(user, eventData, invitedCoHosts, eventName);
// //         }
// //         return true;
// //     });




// /**
//  ** MARK: -  This function will send a notification to newly added members in the event when an event is updated or to all the friends if the event is visible to all.
//  */
// // exports.eventUpdated = functions.firestore
// //     .document("/events/{eventId}")
// //     .onUpdate(async (snapshot, context) => {
// //         const eventData = snapshot.after.data();
// //         const eventName = eventData.name;
// //         const beforeEventData = snapshot.before.data();
// //         const user = await getUserWithId(eventData.userId);
// //         if (eventData.isVisibleToAllSelected == true) {
// //             const selectedMembers = await getUserFriends(eventData.userId);
// //             await sendEventNotification(
// //                 user,
// //                 eventData,
// //                 selectedMembers,
// //                 eventName,
// //                 "updated"
// //             );
// //         } else {
// //             if (
// //                 eventData.selectedMembers.length >
// //                 beforeEventData.selectedMembers.length
// //             ) {
// //                 const newSelectedMembers = eventData.selectedMembers.filter(
// //                     (member) => {
// //                         return !beforeEventData.selectedMembers.includes(member);
// //                     }
// //                 );
// //                 console.log("New selected members are: ", newSelectedMembers);
// //                 await sendEventNotification(
// //                     user,
// //                     eventData,
// //                     newSelectedMembers,
// //                     eventName,
// //                     "updated"
// //                 );
// //             } else {
// //                 console.log("No new member added in the event.");
// //             }
// //         }

// //         if (eventData.pendingCoHostInvites.length > 0) {
// //             if (
// //                 eventData.pendingCoHostInvites.length >
// //                 beforeEventData.pendingCoHostInvites.length
// //             ) {
// //                 const newCoHostInvites = eventData.pendingCoHostInvites.filter(
// //                     (member) => {
// //                         return !beforeEventData.pendingCoHostInvites.includes(member);
// //                     }
// //                 ); ``
// //                 console.log("New co-host invites are: ", newCoHostInvites);
// //                 await sendCoHostInviteNotification(
// //                     user,
// //                     eventData,
// //                     newCoHostInvites,
// //                     eventName
// //                 );
// //             } else {
// //                 console.log("No new co-host invite added in the event.");
// //             }
// //         }

// //         if (eventData.goingList.length > 0) {
// //             if (eventData.goingList.length > beforeEventData.goingList.length) {
// //                 const newGoingUsers = eventData.goingList.filter((user) => {
// //                     return !beforeEventData.goingList.includes(user);
// //                 });
// //                 console.log("New Going Users are: ", newGoingUsers);
// //                 let hosts = eventData.acceptedCoHostInvites
// //                 hosts.push(eventData.userId)
// //                 //earlier only the host was getting the notification of going members, but now all the co-hosts will get the notification
// //                 hosts.forEach(async (hostId) => {
// //                     await sendNotificationOfGoingMembersToEventHost(hostId, eventData, eventName, newGoingUsers)
// //                 });
// //             } else {
// //                 console.log("No new user added in the event going list.");
// //             }
// //         } else {
// //             console.log("No user in the event going list.");
// //         }
// //         return true;
// //     });



// //*This function will be called when a user sends a friend request to another user.
// // exports.friendRequestSent = functions.database
// //     .ref("/friends/{userId}/pendingList/{index}")
// //     .onCreate(async (snapshot, context) => {
// //         const friendIndex = context.params.index;
// //         const userId = context.params.userId;
// //         console.log("userId is: ", userId);
// //         console.log("friendIndex is: ", friendIndex);
// //         try {
// //             const pendingListRef = admin
// //                 .database()
// //                 .ref(`/friends/${userId}/pendingList`);
// //             const pendingListSnapshot = await pendingListRef.once("value");
// //             const pendingList = pendingListSnapshot.val();
// //             if (!pendingList) {
// //                 console.log(`Pending friend requests not found for user ${userId}`);
// //                 return null;
// //             } else {
// //                 const friendId = pendingList[friendIndex];
// //                 const user = await getUserWithId(userId);
// //                 const friend = await getUserWithId(friendId);
// //                 const tokens = user.tokens;
// //                 const notificationSettings = user.notificationSettings;

// //                 console.log("Tokens are: ", tokens);
// //                 //!This is the payload which will be sent to the client.
// //                 const notificationRef = notifications.doc(userId).collection("notificationsList");
// //                 let autoId = notificationRef.doc().id;
// //                 const data = {
// //                     type: "friendRequestSent",
// //                     message: `${friend.firstName} ${friend.lastName} sent you a friend request`,
// //                     userImage: friend.imageUrl,
// //                     visibleTo: userId,
// //                     userId: friendId,
// //                     timeStamp: String(Date.now()),
// //                     notificationId: autoId,
// //                 };
// //                 //!This is the message object which will be sent to the client.
// //                 const payload = {
// //                     notification: {
// //                         title: "Friend Request",
// //                         body: `${friend.firstName} ${friend.lastName} sent you a friend request`,
// //                         sound: "default",
// //                         badge: "0",
// //                     },
// //                     data: data,
// //                 };

// //                 const newNotification = {
// //                     type: "friendRequestSent",
// //                     info: payload.data,
// //                     id: autoId,
// //                     status: 0,
// //                 };
// //                 notificationRef.doc(autoId).set(newNotification);
// //                 if (notificationSettings.friendRequests == false) {
// //                     console.log("User has turned off friend request notifications.");
// //                     // return null;
// //                 } else {
// //                     admin
// //                         .messaging()
// //                         .sendToDevice(tokens, payload)
// //                         .then(function (response) {
// //                             console.log("Successfully sent message:", response.results);
// //                         })
// //                         .catch(function (error) {
// //                             console.error("Error sending message:", error);
// //                         });
// //                 }
// //             }
// //         } catch (error) {
// //             console.log("Error sending message:", error);
// //         }

// //         return true;
// //     });

// //*This function will be called when a user accepts a friend request.
// // exports.friendRequestAccepted = functions.database
// //     .ref("/friends/{userId}/pendingList")
// //     .onUpdate(async (snapshot, context) => {
// //         const pendingListBefore = snapshot.before.val();
// //         const pendingListAfter = snapshot.after.val();
// //         const userId = context.params.userId;
// //         console.log("userId is: ", userId);
// //         const removedId = pendingListBefore.filter((id) => {
// //             return !pendingListAfter.includes(id);
// //         });
// //         const finalRemovedId = removedId.toString();
// //         console.log("Removed id is: ", finalRemovedId);
// //         await notifyUserAfterFriendRequestAccepted(userId, finalRemovedId);
// //     });

// /**
//  * This method will be called when there is only one friend request left in the pending list. Because friendRequestAccepted method is not working for only one friend request.
//  */
// // exports.friendRequestAcceptedOne = functions.database
// //     .ref("/friends/{userId}/pendingList")
// //     .onDelete(async (snapshot, context) => {
// //         const pendingList = snapshot.val();
// //         console.log("pendingList is: ", pendingList);
// //         const userId = context.params.userId;
// //         if (pendingList.length > 1) {
// //             return null;
// //         } else {
// //             const finalRemovedId = pendingList.toString();
// //             console.log("Removed id is: ", finalRemovedId);
// //             await notifyUserAfterFriendRequestAccepted(userId, finalRemovedId);
// //         }
// //     });

// // exports.addMemoryToEvent = functions.firestore
// //     .document("/events/{eventId}/event_memories/{memoryId}")
// //     .onCreate(async (snapshot, context) => {
// //         const memoryData = snapshot.data();
// //         const eventData = await getEventData(memoryData.eventId);
// //         console.log("eventData is: ", eventData);
// //         console.log("memoryData is: ", memoryData);

// //         let coHosts = eventData.acceptedCoHostInvites
// //         let user = await getUserWithId(memoryData.userId);

// //         if (memoryData.userId != eventData.userId) {
// //             if (eventData.isVisibleToAllSelected == true) {
// //                 let selectedMembers = await getUserFriends(eventData.userId)
// //                 let finalMembers = selectedMembers.concat(coHosts)
// //                 finalMembers.push(eventData.userId)
// //                 finalMembers = finalMembers.filter(memberId => memberId !== memoryData.userId);
// //                 console.log("selectedMembers are: ", finalMembers);
// //                 await sendEventMemoryNotification(user, eventData, finalMembers,
// //                     eventData.name
// //                 );
// //             } else {
// //                 let selectedMembers = eventData.selectedMembers
// //                 let finalMembers = selectedMembers.concat(coHosts)
// //                 finalMembers.push(eventData.userId)
// //                 finalMembers = finalMembers.filter(memberId => memberId !== memoryData.userId);
// //                 console.log("selectedMembers are: ", finalMembers);
// //                 await sendEventMemoryNotification(
// //                     user,
// //                     eventData,
// //                     finalMembers,
// //                     eventData.name
// //                 );
// //             }
// //         } else {
// //             if (eventData.isVisibleToAllSelected == true) {
// //                 const selectedMembers = await getUserFriends(eventData.userId);
// //                 let finalMembers = selectedMembers.concat(coHosts)
// //                 await sendEventMemoryNotification(
// //                     user,
// //                     eventData,
// //                     finalMembers,
// //                     eventData.name
// //                 );
// //             } else {
// //                 const selectedMembers = eventData.selectedMembers;
// //                 let finalMembers = selectedMembers.concat(coHosts)
// //                 await sendEventMemoryNotification(
// //                     user,
// //                     eventData,
// //                     finalMembers,
// //                     eventData.name
// //                 );
// //                 //send notification to selected members about the event memory
// //             }
// //         }

// //         return true;
// //     });

// // exports.addCommentInEventDiscussion = functions.firestore
// //     .document("/events/{eventId}/event_comments/{commentId}")
// //     .onCreate(async (snapshot, context) => {

// //         const commentData = snapshot.data();
// //         const eventData = await getEventData(context.params.eventId);
// //         console.log("eventData is: ", eventData);
// //         console.log("commentData is: ", commentData);

// //         //notify going list users and host about the comment
// //         const user = await getUserWithId(commentData.userId);

// //         let coHosts = eventData.acceptedCoHostInvites
// //         let selectedMembers = eventData.goingList
// //         let finalMembers = selectedMembers.concat(coHosts)
// //         if (commentData.userId != eventData.userId) {
// //             finalMembers.push(eventData.userId)
// //             finalMembers = finalMembers.filter(memberId => memberId !== commentData.userId);
// //             console.log("selectedMembers are: ", finalMembers);
// //         }
// //         await sendEventCommentDiscussionNotification(user, eventData, finalMembers, eventData.name)

// //         //notify the mentioned users
// //         let comment = commentData.comment
// //         let mentionedUsers = comment.match(/@\w+/g).map((user) => user.slice(1));
// //         if (mentionedUsers.length > 0) {
// //             if (mentionedUsers.includes('guests')) {
// //                 if (commentData.userId == eventData.userId) {
// //                     if (eventData.isVisibleToAllSelected == true) {
// //                         const selectedMembers = await getUserFriends(eventData.userId);
// //                         //send notification to all friends about the event mention
// //                         let allMembers = selectedMembers.concat(coHosts)
// //                         await sendMentionNotificationToMentionedIds(user, eventData, allMembers, eventData.name)

// //                     } else {
// //                         const selectedMembers = eventData.selectedMembers;
// //                         //send notification to selected members about the event mention
// //                         let allMembers = selectedMembers.concat(coHosts)
// //                         await sendMentionNotificationToMentionedIds(user, eventData, allMembers, eventData.name)
// //                     }
// //                 } else {
// //                     if (eventData.isVisibleToAllSelected == true) {
// //                         let selectedMembers = await getUserFriends(eventData.userId)
// //                         let allMembers = selectedMembers.concat(coHosts)
// //                         allMembers.push(eventData.userId)
// //                         allMembers = allMembers.filter(memberId => memberId !== commentData.userId);
// //                         console.log("selectedMembers are: ", allMembers);
// //                         await sendMentionNotificationToMentionedIds(user, eventData, allMembers, eventData.name)
// //                     } else {
// //                         let selectedMembers = eventData.selectedMembers
// //                         let allMembers = selectedMembers.concat(coHosts)
// //                         allMembers.push(eventData.userId)
// //                         allMembers = allMembers.filter(memberId => memberId !== commentData.userId);
// //                         console.log("selectedMembers are: ", allMembers);
// //                         await sendMentionNotificationToMentionedIds(user, eventData, allMembers, eventData.name)
// //                     }
// //                 }
// //             } else {
// //                 console.log("mentionedUsers are: ", mentionedUsers);
// //                 await sendMentionNotification(user, eventData, mentionedUsers, eventData.name)
// //             }
// //         }
// //         return true;
// //     });

// /**
//  * This method will be used to verify the FCM Tokens of all the users in the database.
//  * It will verify and remove the invalid tokens from the database.
//  * As the function will send token in dry run mode, so the user will not get the notification.
//  * It will only validate the token and remove the invalid tokens from the database.
// */

// /**
// * Method to get event data using the given eventId.
// */
// // async function getEventData(eventId) {
// //     // Reference to the event document
// //     const eventRef = admin.firestore().collection("events").doc(eventId);

// //     try {
// //         // Get the event data
// //         const eventSnapshot = await eventRef.get();
// //         if (eventSnapshot.exists) {
// //             const eventData = eventSnapshot.data();
// //             return eventData;
// //         } else {
// //             throw new Error("Event not found.");
// //         }
// //     } catch (error) {
// //         throw error;
// //     }
// // }
// //* Method to get the user with the given userId.
// // async function getUserWithId(userId) {
// //     const userRef = admin.database().ref(`/users/${userId}`);
// //     const userSnapshot = await userRef.once("value");
// //     const user = userSnapshot.val();
// //     if (!user) {
// //         console.log(`User not found for id ${userId}`);
// //         return null;
// //     } else {
// //         // console.log("User", user);
// //         return user;
// //     }
// // }

// /**
//  *  Method to get the user friends with the given userId.
// */
// // // async function getUserFriends(userId) {
// // //     const userFriendsRef = admin
// // //         .database()
// // //         .ref(`/friends/${userId}/acceptedList`);
// // //     const userFriendsSnapshot = await userFriendsRef.once("value");
// // //     const userFriends = userFriendsSnapshot.val();
// // //     if (!userFriends) {
// // //         console.log(`Friends not found for user ${userId}`);
// // //         return null;
// // //     } else {
// // //         // console.log("User Friends", userFriends);
// // //         return userFriends;
// // //     }
// // // }

// // //* Method to send event notification to the selected members.
// // async function sendEventNotification(
// //     user,
// //     eventData,
// //     selectedMembers,
// //     eventName,
// //     status
// // ) {
// //     try {
// //         selectedMembers.forEach((memberId) => {
// //             sendEventNotificationToMember(
// //                 user,
// //                 memberId,
// //                 eventData,
// //                 eventName,
// //                 status
// //             );
// //         });
// //     } catch (error) {
// //         console.log("Error sending message:", error);
// //     }
// // }


// // //* Method to send event notification to a member with the given memberId.
// // async function sendEventNotificationToMember(
// //     user,
// //     memberId,
// //     eventData,
// //     eventName,
// //     status
// // ) {
// //     const member = await getUserWithId(memberId);
// //     const tokens = member.tokens;
// //     const notificationSettings = member.notificationSettings
// //     console.log(`tokens ${tokens}`);

// //     var dateString = "";
// //     if (eventData.isDateConfirmed == true) {
// //         let dateTimestamp = eventData.dateTimestamp;
// //         const dateObj = new Date(dateTimestamp * 1000); // Convert to milliseconds
// //         const formattedDate = dateObj.toLocaleDateString("en-US", {
// //             weekday: "long",
// //             month: "2-digit",
// //             day: "2-digit",
// //             year: "numeric",
// //         });
// //         dateString = formattedDate;
// //     } else {
// //         dateString = "TBD";
// //     }
// //     //!This is the payload which will be sent to the client.
// //     const notificationRef = notifications.doc(memberId).collection("notificationsList");
// //     let autoId = notificationRef.doc().id;
// //     const data = {
// //         type: status == "created" ? "eventCreated" : "eventUpdated",
// //         message: `${user.firstName} ${user.lastName} invited you in this ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //         userImage: user.imageUrl,
// //         visibleTo: memberId,
// //         userId: eventData.userId,
// //         eventData: JSON.stringify(eventData),
// //         timeStamp: String(Date.now()),
// //         notificationId: autoId,
// //     };

// //     const payload = {
// //         notification: {
// //             title: String(eventName),
// //             body: `${user.firstName} ${user.lastName} invited you in this ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //             sound: "default",
// //             badge: "0",
// //         },
// //         data: data,
// //     };

// //     const newNotification = {
// //         type: status == "created" ? "eventCreated" : "eventUpdated",
// //         info: payload.data,
// //         id: autoId,
// //         status: 0,
// //     };

// //     await notificationRef.doc(autoId).set(newNotification);
// //     if (notificationSettings.inviteToEvents == false || notificationSettings.muteAllPushNotifications == true) {
// //         console.log("User has turned off event invite notifications.");
// //         // return null;
// //     } else {
// //         admin
// //             .messaging()
// //             .sendToDevice(tokens, payload)
// //             .then(function (response) {
// //                 console.log("Successfully sent message:", response);
// //             })
// //             .catch(function (error) {
// //                 console.error("Error sending message:", error);
// //             });
// //     }
// // }

// // async function sendCoHostInviteNotification(
// //     user,
// //     eventData,
// //     selectedCoHostInvites,
// // ) {
// //     try {
// //         selectedCoHostInvites.forEach((memberId) => {
// //             sendEventCoHostInviteNotificationToMember(
// //                 user,
// //                 memberId,
// //                 eventData,
// //                 eventName
// //             );
// //         });
// //     } catch (error) {
// //         console.log("Error sending message:", error);
// //     }
// // }

// //* Method to send notifications of events of a user when a friend request is accepted.
// // async function notifyAcceptedUserAboutUserEvents(user, finalRemovedId) {
// //     //!Start
// //     const userEventsRef = admin
// //         .firestore()
// //         .collection("events")
// //         .where("dateTimestamp", ">", Date.now() / 1000)
// //         .where("userId", "==", user.id);
// //     const userEventsSnapshot = await userEventsRef.get();
// //     const userEvents = userEventsSnapshot.docs.map((doc) => doc.data());
// //     console.log("userEvents is: ", userEvents);
// //     if (userEvents.length > 0) {
// //         userEvents.forEach((event) => {
// //             sendEventNotificationToMember(
// //                 user,
// //                 finalRemovedId,
// //                 event,
// //                 event.name,
// //                 "created"
// //             );
// //         });
// //     } else {
// //         console.log("User has not created any event.");
// //     }
// //     //!End
// // }

// // //* Method to send notification to the user after a friend request is accepted.
// // async function notifyUserAfterFriendRequestAccepted(userId, finalRemovedId) {
// //     try {
// //         const acceptedListRef = admin
// //             .database()
// //             .ref(`/friends/${userId}/acceptedList`);
// //         const acceptedListSnapshot = await acceptedListRef.once("value");
// //         const acceptedList = acceptedListSnapshot.val();
// //         if (!acceptedList) {
// //             console.log(`accepted friend requests not found for user ${userId}`);
// //             return null;
// //         } else {
// //             if (acceptedList.includes(finalRemovedId)) {
// //                 console.log(`User ${finalRemovedId} is a friend of user ${userId}`);
// //                 const removedUser = await getUserWithId(finalRemovedId);
// //                 const tokens = removedUser.tokens;
// //                 const notificationSettings = removedUser.notificationSettings;
// //                 console.log(`tokens ${tokens}`);
// //                 const user = await getUserWithId(userId);
// //                 //!This is the payload which will be sent to the client.
// //                 const notificationRef = notifications.doc(finalRemovedId).collection("notificationsList");
// //                 let autoId = notificationRef.doc().id;
// //                 const data = {
// //                     type: "friendRequestAccepted",
// //                     message: `${user.firstName} ${user.lastName} has accepted your friend request!`,
// //                     userImage: user.imageUrl,
// //                     visibleTo: finalRemovedId,
// //                     userId: userId,
// //                     timeStamp: String(Date.now()),
// //                     notificationId: autoId,
// //                 };
// //                 //!This is the message object which will be sent to the client.
// //                 const payload = {
// //                     notification: {
// //                         title: "Friend Request Accepted",
// //                         body: `${user.firstName} ${user.lastName} has accepted your friend request!`,
// //                         sound: "default",
// //                         badge: "0",
// //                     },
// //                     data: data,
// //                 };
// //                 const newNotification = {
// //                     type: "friendRequestAccepted",
// //                     info: payload.data,
// //                     id: autoId,
// //                     status: 0,
// //                 };
// //                 await notificationRef.doc(autoId).set(newNotification);
// //                 if (notificationSettings.friendRequests == false || notificationSettings.muteAllPushNotifications == true) {
// //                     console.log("User has turned off friend request notifications.");
// //                     // return null;
// //                 } else {
// //                     admin
// //                         .messaging()
// //                         .sendToDevice(tokens, payload)
// //                         .then(function (response) {
// //                             console.log("Successfully sent message:", response);
// //                         })
// //                         .catch(function (error) {
// //                             console.error("Error sending message:", error);
// //                         });
// //                 }

// //                 await notifyAcceptedUserAboutUserEvents(user, finalRemovedId);
// //             } else {
// //                 console.log("Friend request not accepted.");
// //             }
// //         }
// //     } catch (error) {
// //         console.log("Error sending message:", error);
// //     }

// //     return true;
// // }


// // async function sendEventCoHostInviteNotificationToMember(
// //     user,
// //     memberId,
// //     eventData,
// //     eventName
// // ) {
// //     const member = await getUserWithId(memberId);
// //     const tokens = member.tokens;
// //     const notificationSettings = member.notificationSettings;
// //     console.log(`tokens ${tokens}`);
// //     tokens.forEach((token) => {
// //         console.log(`Token is ${token}`);
// //     });

// //     var dateString = "";
// //     if (eventData.isDateConfirmed == true) {
// //         let dateTimestamp = eventData.dateTimestamp;
// //         const dateObj = new Date(dateTimestamp * 1000); // Convert to milliseconds
// //         const formattedDate = dateObj.toLocaleDateString("en-US", {
// //             weekday: "long",
// //             month: "2-digit",
// //             day: "2-digit",
// //             year: "numeric",
// //         });
// //         dateString = formattedDate;
// //     } else {
// //         dateString = "TBD";
// //     }

// //     const notificationRef = notifications.doc(memberId).collection("notificationsList");
// //     let autoId = notificationRef.doc().id;
// //     const data = {
// //         type: "coHostInvite",
// //         message: `${user.firstName} ${user.lastName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //         userImage: user.imageUrl,
// //         visibleTo: memberId,
// //         userId: eventData.userId,
// //         eventData: JSON.stringify(eventData),
// //         timeStamp: String(Date.now()),
// //         notificationId: autoId,
// //     };

// //     const payload = {
// //         notification: {
// //             title: String(eventName),
// //             body: `${user.firstName} ${user.lastName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //             sound: "default",
// //             badge: "0",
// //         },
// //         data: data,
// //     };

// //     const newNotification = {
// //         type: "coHostInvite",
// //         info: payload.data,
// //         id: autoId,
// //         status: 0,
// //     };
// //     await notificationRef.doc(autoId).set(newNotification);
// //     // message.data.info = JSON.stringify(message.data.info);
// //     if (notificationSettings.muteAllPushNotifications == true) {
// //         console.log("User has turned off all push notifications.");
// //         // return null;
// //     } else {
// //         admin
// //             .messaging()
// //             .sendToDevice(tokens, payload)
// //             .then(function (response) {
// //                 console.log("Successfully sent message:", response);
// //             })
// //             .catch(function (error) {
// //                 console.error("Error sending message:", error);
// //             });
// //     }
// // }

// // /* 
// // In this method, host id of event host and the user ids of event going list users will be used and host will be notified about the users who are going to the event.
// // */
// // async function sendNotificationOfGoingMembersToEventHost(
// //     hostId,
// //     eventData,
// //     eventName,
// //     goingUsers
// // ) {
// //     const host = await getUserWithId(hostId);
// //     const tokens = host.tokens;
// //     const notificationSettings = host.notificationSettings;

// //     console.log(`tokens ${tokens}`);

// //     tokens.forEach((token) => {
// //         console.log(`Token is ${token}`);
// //     });

// //     goingUsers.forEach(async (memberId) => {
// //         const user = await getUserWithId(memberId);
// //         var dateString = "";
// //         if (eventData.isDateConfirmed == true) {
// //             let dateTimestamp = eventData.dateTimestamp;
// //             const dateObj = new Date(dateTimestamp * 1000); // Convert to milliseconds
// //             const formattedDate = dateObj.toLocaleDateString("en-US", {
// //                 weekday: "long",
// //                 month: "2-digit",
// //                 day: "2-digit",
// //                 year: "numeric",
// //             });
// //             dateString = formattedDate;
// //         } else {
// //             dateString = "TBD";
// //         }
// //         //!This is the payload which will be sent to the client.
// //         //Jason Yang has invited you to be a co-host for Wine Tasting | 7:00 PM Thursday 1/5
// //         const notificationRef = notifications.doc(hostId).collection("notificationsList");
// //         let autoId = notificationRef.doc().id;
// //         const data = {
// //             type: "goingToEvent",
// //             message: `${user.firstName} ${user.lastName} is going to ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //             userImage: user.imageUrl,
// //             visibleTo: hostId,
// //             userId: eventData.userId,
// //             eventData: JSON.stringify(eventData),
// //             timeStamp: String(Date.now()),
// //             notificationId: autoId,
// //         };
// //         //!This is the message object which will be sent to the client.
// //         const payload = {
// //             notification: {
// //                 title: String(eventName),
// //                 body: `${user.firstName} ${user.lastName} is going to ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //                 sound: "default",
// //                 badge: "0",
// //             },
// //             data: data,
// //         };

// //         const newNotification = {
// //             type: "goingToEvent",
// //             info: payload.data,
// //             id: autoId,
// //             status: 0,
// //         };
// //         await notificationRef.doc(autoId).set(newNotification);
// //         // message.data.info = JSON.stringify(message.data.info);
// //         if (notificationSettings.eventAttendanceUpdates == false || notificationSettings.muteAllPushNotifications == true) {
// //             console.log("User has turned off event attendance updates notifications.");
// //             // return null;
// //         } else {
// //             admin
// //                 .messaging()
// //                 .sendToDevice(tokens, payload)
// //                 .then(function (response) {
// //                     console.log("Successfully sent message:", response);
// //                 })
// //                 .catch(function (error) {
// //                     console.error("Error sending message:", error);
// //                 });
// //         }
// // 
// //     });
// // }
// // 
// // async function sendEventMemoryNotification(
// //     user,
// //     eventData,
// //     selectedMembers,
// //     eventName
// // ) {
// //     try {
// //         selectedMembers.forEach((memberId) => {
// //             sendEventMemoryNotificationToMember(user, memberId, eventData, eventName);
// //         });
// //     } catch (error) {
// //         console.log("Error sending message:", error);
// //     }
// // }

// // //* Method to send event notification to a member with the given memberId.
// // async function sendEventMemoryNotificationToMember(
// //     user,
// //     memberId,
// //     eventData,
// //     eventName
// // ) {
// //     const member = await getUserWithId(memberId);
// //     const tokens = member.tokens;
// //     const notificationSettings = member.notificationSettings;
// //     console.log(`tokens ${tokens}`);
// //     tokens.forEach((token) => {
// //         console.log(`Token is ${token}`);
// //     });

// //     var dateString = "";
// //     if (eventData.isDateConfirmed == true) {
// //         let dateTimestamp = eventData.dateTimestamp;
// //         const dateObj = new Date(dateTimestamp * 1000); // Convert to milliseconds
// //         const formattedDate = dateObj.toLocaleDateString("en-US", {
// //             weekday: "long",
// //             month: "2-digit",
// //             day: "2-digit",
// //             year: "numeric",
// //         });
// //         dateString = formattedDate;
// //     } else {
// //         dateString = "TBD";
// //     }
// //     //!This is the payload which will be sent to the client.
// //     //!This is the document reference of the document with document id: - memberId.
// //     const notificationRef = notifications.doc(memberId).collection("notificationsList");
// //     let autoId = notificationRef.doc().id;

// //     const data = {
// //         type: "eventMemoryAdded",
// //         message: `${user.firstName} ${user.lastName} has added a memory to ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //         userImage: user.imageUrl,
// //         visibleTo: memberId,
// //         userId: user.id,
// //         eventData: JSON.stringify(eventData),
// //         timeStamp: String(Date.now()),
// //         notificationId: autoId,
// //     };
// //     //!This is the message object which will be sent to the client.
// //     const payload = {
// //         notification: {
// //             title: String(eventName),
// //             body: `${user.firstName} ${user.lastName} has added a memory to ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //             sound: "default",
// //             badge: "0",
// //         },
// //         data: data,
// //     };

// //     //!This is the notification object which will be stored in the firestore notifications collection inside the memberDocRef document.
// //     const newNotification = {
// //         type: "eventMemoryAdded",
// //         info: payload.data,
// //         id: autoId,
// //         status: 0,
// //     };
// //     await notificationRef.doc(autoId).set(newNotification);
// //     // message.data.info = JSON.stringify(message.data.info);
// //     if (notificationSettings.newEventMemories == false || notificationSettings.muteAllPushNotifications == true) {
// //         console.log("User has turned off event memories notifications.");
// //         // return null;
// //     } else {
// //         admin
// //             .messaging()
// //             .sendToDevice(tokens, payload)
// //             .then(function (response) {
// //                 console.log("Successfully sent message:", response);
// //             })
// //             .catch(function (error) {
// //                 console.error("Error sending message:", error);
// //             });
// //     }
// // }

// //This method is helping method to be used for sending event comment discussion notifications..
// // async function sendEventCommentDiscussionNotification(user, eventData, selectedMembers, eventName) {
// //     try {
// //         selectedMembers.forEach((memberId) => {
// //             sendEventCommentDiscussionNotificationToMember(user, memberId, eventData, eventName);

// //         });
// //     } catch (error) {
// //         console.log("Error sending message:", error);
// //     }
// // }

// // //This method will be used to send notification about the comment added by a member or the host in an event discussion. The notification will be send to all the going list members if host has added a comment. If a going list members has added a comment, then all other going list members and the host will be notified
// // async function sendEventCommentDiscussionNotificationToMember(user, memberId, eventData, eventName) {
// //     const member = await getUserWithId(memberId);
// //     // const user = await getUserWithId(userId);
// //     const tokens = member.tokens;
// //     const notificationSettings = member.notificationSettings;

// //     tokens.forEach((token) => {
// //         console.log(`Token is ${token}`);
// //     });
// //     var dateString = "";
// //     if (eventData.isDateConfirmed == true) {
// //         let dateTimestamp = eventData.dateTimestamp;
// //         const dateObj = new Date(dateTimestamp * 1000); // Convert to milliseconds
// //         const formattedDate = dateObj.toLocaleDateString("en-US", {
// //             weekday: "long",
// //             month: "2-digit",
// //             day: "2-digit",
// //             year: "numeric",
// //         });
// //         dateString = formattedDate;
// //     } else {
// //         dateString = "TBD";
// //     }
// //     const notificationRef = notifications.doc(memberId).collection("notificationsList");
// //     // await memberDocRef.set({ id: memberId }, { merge: true });
// //     // const notificationRef = memberDocRef.collection("notificationsList");
// //     let autoId = notificationRef.doc().id;

// //     const data = {
// //         type: "eventCommentAdded",
// //         message: `${user.firstName} ${user.lastName} commented in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //         userImage: user.imageUrl,
// //         visibleTo: memberId,
// //         userId: user.id,
// //         eventData: JSON.stringify(eventData),
// //         timeStamp: String(Date.now()),
// //         notificationId: autoId,
// //     };

// //     const payload = {
// //         notification: {
// //             title: String(eventName),
// //             body: `${user.firstName} ${user.lastName} commented in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //             sound: "default",
// //             badge: "0",
// //         },
// //         data: data,
// //     };

// //     const newNotification = {
// //         type: "eventCommentAdded",
// //         info: payload.data,
// //         id: autoId,
// //         status: 0,
// //     };

// //     await notificationRef.doc(autoId).set(newNotification);

// //     if (notificationSettings.discussionComments == false || notificationSettings.muteAllPushNotifications == true) {
// //         console.log("User has turned off discussion comments notifications.");
// //         // return null;
// //     } else {
// //         admin
// //             .messaging()
// //             .sendToDevice(tokens, payload)
// //             .then(function (response) {
// //                 console.log("Successfully sent message:", response);
// //             })
// //             .catch(function (error) {
// //                 console.error("Error sending message:", error);
// //             });
// //     }
// // }

// //This method will be used to get the user id with the given username.This method is used to get the user id of the user who is mentioned in the event discussion.
// // async function getUserIdWithUsername(username) {
// //     const userRef = admin.database().ref(`/users`).orderByChild("username").equalTo(username);
// //     const userSnapshot = await userRef.once("value");
// //     const user = userSnapshot.val();

// //     if (!user) {
// //         console.log(`User not found for username ${username}`);
// //         return null;
// //     } else {
// //         // Get the user ID by extracting the first (and only) key from the user object
// //         const userId = Object.keys(user)[0];
// //         console.log(`User ID for ${username} is ${userId}`);
// //         return userId;
// //     }
// // }

// // //This is the method which will take the mentioned user's usernames array and send notification to all the mentioned users.
// // async function sendMentionNotification(user, eventData, mentionedUsers, eventName) {
// //     try {
// //         mentionedUsers.forEach(async (username) => {
// //             let mentionedId = await getUserIdWithUsername(username);
// //             console.log("Mentioned User: ", mentionedId);
// //             sendMentionNotificationToMember(user, mentionedId, eventData, eventName);
// //         });
// //     } catch (error) {
// //         console.log("Error sending message:", error);
// //     }
// // }

// // //This is the method which will take the mentioned user's ids array and send notification to all the mentioned users.
// // async function sendMentionNotificationToMentionedIds(user, eventData, mentionedUserIds, eventName) {
// //     try {
// //         mentionedUserIds.forEach((id) => {
// //             sendMentionNotificationToMember(user, id, eventData, eventName);
// //         });
// //     } catch (error) {
// //         console.log("Error sending message:", error);
// //     }
// // }

// /**
//  * This method will be used to send notification to the user who is mentioned in the event discussion.
// */
// // async function sendMentionNotificationToMember(user, mentionedId, eventData, eventName) {
// //     let TAG = "sendMentionNotificationToMember";
// //     console.log("Mentioned User Id: ", mentionedId);
// //     const mentionedUser = await getUserWithId(mentionedId);
// //     const tokens = mentionedUser.tokens;
// //     const notificationSettings = mentionedUser.notificationSettings;
// //     console.log(`${TAG} notificationSettings ${notificationSettings}`);
// //     console.log(`${TAG} tokens ${tokens}`);

// //     var dateString = "";
// //     if (eventData.isDateConfirmed == true) {
// //         let dateTimestamp = eventData.dateTimestamp;
// //         const dateObj = new Date(dateTimestamp * 1000); // Convert to milliseconds
// //         const formattedDate = dateObj.toLocaleDateString("en-US", {
// //             weekday: "long",
// //             month: "2-digit",
// //             day: "2-digit",
// //             year: "numeric",
// //         });
// //         dateString = formattedDate;
// //     } else {
// //         dateString = "TBD";
// //     }

// //     const notificationRef = notifications.doc(mentionedId).collection("notificationsList");
// //     //  memberDocRef.set({ id: mentionedId }, { merge: true });
// //     // const notificationRef = memberDocRef.collection("notificationsList");
// //     let autoId = notificationRef.doc().id;

// //     const data = {
// //         type: "userMentioned",
// //         message: `${user.firstName} ${user.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //         userImage: user.imageUrl,
// //         visibleTo: mentionedId,
// //         userId: user.id,
// //         eventData: JSON.stringify(eventData),
// //         timeStamp: String(Date.now()),
// //         notificationId: autoId,
// //     };

// //     const payload = {
// //         notification: {
// //             title: String(eventName),
// //             body: `${user.firstName} ${user.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`,
// //             sound: "default",
// //             badge: "0",
// //         },
// //         data: data
// //     };

// //     const newNotification = {
// //         type: "userMentioned",
// //         info: data,
// //         id: autoId,
// //         status: 0,
// //     };

// //     const options = {
// //         priority: "high",
// //     }

// //     await notificationRef.doc(autoId).set(newNotification);

// //     if (notificationSettings.mentions == false || notificationSettings.muteAllPushNotifications == true) {
// //         console.log("User has turned off mention notifications.");
// //         // return null;
// //     } else {
// //         admin
// //             .messaging()
// //             .sendToDevice(tokens, payload, options)
// //             .then(function (response) {
// //                 console.log("Successfully sent message:", response);
// //             })
// //             .catch(function (error) {
// //                 console.error("Error sending message:", error);
// //             });
// //     }

// // }

// // async function getNotificationSettingsOfUser(userId) {
// //     const notificationRef = admin.database().ref(`/users/${userId}/notificationSettings`);
// //     const notificationSnapShot = await notificationRef.once("value");
// //     const notificationSettings = notificationSnapShot.val();
// //     if (!notificationSettings) {
// //         console.log(`Notification settings not found for user ${userId}`);
// //         return null;
// //     } else {
// //         console.log("Notification settings", notificationSettings);
// //         return notificationSettings;
// //     }
// // }



/////// TESTING METHODS


// // if (Constants.IS_LOCAL_FUNCTION) {
exports.eventCreatedNew = functions.https.onRequest((request, response) => {
    console.log("Check Function");
    console.log("Start" + request.body.userId);
    let eventData = TestData.addTestEventInDatabase(request, response)
    User.getUserData('users', eventData.userId, function (userSuccess, userDetail) {
        console.log("users success : ", userSuccess);
        if (userSuccess) {
            let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
            // let body = `${userDetail.firstName} ${userDetail.lastName} invited you in this ${eventData.name} | ${eventData.startTime} ${dateString}`
            let body;
            if (userDetail.lastName !== "") {
                body = `${userDetail.firstName} ${userDetail.lastName} invited you in this ${eventData.name} | ${eventData.startTime} ${dateString}`
            }
            else {
                body = `${userDetail.firstName} invited you in this ${eventData.name} | ${eventData.startTime} ${dateString}`
            }
            if (eventData.isVisibleToAllSelected) {
                User.getUserFriends('friends', userDetail.id, function (friendsSuccess, friendList) {
                    console.log("Friends success : ", friendsSuccess);
                    if (friendsSuccess) {
                        if (friendList.length > 0) {
                            friendList.forEach((memberId) => {
                                User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                                    console.log("Member success : ", memberSuccess + " " + memberId);
                                    if (memberSuccess) {
                                        sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_CREATED, eventData.userId)
                                        response.send({ "status": 1, message: "Event Created Successfully" });
                                    } else {
                                        console.log("Error While Getting Member Data");
                                        response.send({ "status": 0, message: "Invalid Data" });
                                    }
                                });
                            })
                        }
                    } else {
                        console.log("Error While Getting Friend List");
                        response.send({ "status": 0, message: "Invalid Data" });
                    }
                });
            }
            else {
                const selectedMembers = eventData.selectedMembers;
                if (selectedMembers.length > 0) {
                    selectedMembers.forEach((memberId) => {
                        User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                            console.log("Member success : ", memberSuccess);
                            if (memberSuccess) {
                                console.log("MemberId : " + memberId)
                                sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_CREATED, eventData.userId)
                                response.send({ "status": 1, message: "Event Created Successfully" });
                            } else {
                                console.log("Error While Getting Member Data");
                                response.send({ "status": 0, message: "Invalid Data" });
                            }
                        });
                    })
                }
                else {
                    response.send({ "status": 1, message: "Event Created Successfully" });
                }
            }

            ///// CoHost Notifications
            const invitedCoHosts = eventData.pendingCoHostInvites;

            if (invitedCoHosts.length > 0) {
                // let body = `${userDetail.firstName} ${userDetail.lastName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`
                let body;
                if (userDetail.lastName !== "") {
                    body = `${userDetail.firstName} ${userDetail.lastName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`
                }
                else {
                    body = `${userDetail.firstName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`
                }
                invitedCoHosts.forEach((memberId) => {
                    User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                        console.log("Member success : ", memberSuccess);
                        if (memberSuccess) {
                            sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.CO_HOST_INVITE, eventData.userId)
                        } else {
                            console.log("Error While Getting Member Data");
                            response.send({ "status": 0, message: "Invalid Data" });
                        }
                    });
                })
            }
            else {
                console.log("Invited CoHost Empty");
            }



        } else {
            console.log("Error While Getting User Data");
            response.send({ "status": 0, message: "Invalid Data" });
        }
    });

    // response.send({ "success": true });
});

exports.sendFriendRequestSentNew = functions.https.onRequest((request, response) => {
    console.log("Check Function sendFriendRequestSentNew");

    // let userId = request.body.userId;
    // let receiverId = request.body.receiverId
    // console.log("Sender Id : " + userId);
    // console.log("Receiver Id : " + receiverId);
    // FriendRequest.checkAlreadyExistOrNot(Constants.ACCEPTED_LIST, userId, receiverId, function (isExistInAccepted) {
    //     if (isExistInAccepted) {
    //         console.log("Already Friend")
    //         // callback(0, "Already added to friends.")
    //         response.send({ "status": 0, message: "Already added to friends." });
    //     }
    //     else {
    //         console.log("Not Friend, Check In Pending")
    //         FriendRequest.checkAlreadyExistOrNot(Constants.PENDING_LIST, userId, receiverId, function (isExistInPending) {
    //             if (isExistInPending) {
    //                 console.log("Already In Pending List")
    //                 // callback(0, "You have already got request from this user.Check pending requests")
    //                 response.send({ "status": 0, message: "You have already got request from this user.Check pending requests" });
    //             }
    //             else {
    //                 console.log("Not Friend, Check In Sent")
    //                 FriendRequest.checkAlreadyExistOrNot(Constants.SENT_LIST, userId, receiverId, function (isExistInSent) {
    //                     if (isExistInSent) {
    //                         console.log("Already In Sent List")
    //                         // callback(0, "You have already sent friend request to this user.")
    //                         response.send({ "status": 0, message: "You have already sent friend request to this user." });
    //                     }
    //                     else {
    //                         console.log("Add Data")
    //                         FriendRequest.addDataToPendingList(userId, receiverId, function (isAddedToDatabase) {
    //                             if (isAddedToDatabase) {
    //                                 FriendRequest.addDataToSentList(userId, receiverId, function (isAddedToSentDatabase) {
    //                                     if (isAddedToSentDatabase) {
    //                                         User.getUserData('users', userId, function (userSuccess, userDetail) {
    //                                             console.log("userSuccess  : ", userSuccess + " " + userDetail);
    //                                             if (userSuccess) {
    //                                                 User.getUserData('users', receiverId, function (friendSuccess, friendData) {
    //                                                     console.log("friendSuccess  : ", friendSuccess + " " + friendData);
    //                                                     if (friendSuccess) {
    //                                                         let body = `${userDetail.firstName} ${userDetail.lastName} sent you a friend request`
    //                                                         sendFriendNotificationFromServer("Friend Request", body, friendData, userDetail, Constants.FRIEND_REQUEST_SENT)
    //                                                         // callback(1, "Friend Request Sent successfully.")
    //                                                         response.send({ "status": 1, message: "Friend Request Sent successfully." });
    //                                                     } else {
    //                                                         console.log("Error While Getting Friend Data");
    //                                                         // callback(0, "Invalid Data.")
    //                                                         response.send({ "status": 0, message: "Invalid Data." });
    //                                                     }
    //                                                 });
    //                                             } else {
    //                                                 console.log("Error While Getting User Data");
    //                                                 // callback(0, "Invalid Data.")
    //                                                 response.send({ "status": 0, message: "Invalid Data." });
    //                                             }
    //                                         });
    //                                     }
    //                                 })

    //                             }
    //                         })
    //                     }
    //                 })

    //             }
    //         })
    //     }
    // })

    FriendRequest.sendRequest(request, response, function (status, message) {
        response.send({ "status": status, "message": message });
    })
});

exports.friendRequestAcceptedNew = functions.https.onRequest((request, response) => {
    console.log("friendRequestAcceptedNew");
    FriendRequest.acceptRequest(request, response, function (status, message) {
        response.send({ "status": status, "message": message });
    })
});

exports.addMemoryToEventNew = functions.https.onRequest((request, response) => {
    console.log("addMemoryToEventNew");
    Events.addMemory(request, response, function (status, message) {
        response.send({ "status": status, "message": message });
    })
});

exports.goingListNew = functions.https.onRequest((request, response) => {
    console.log("goingListNew");
    Events.goingList(request, response, function (status, message) {
        response.send({ "status": status, "message": message });
    })
});

exports.eventUpdatedNew = functions.https.onRequest((request, response) => {
    console.log("eventUpdatedNew");
    Events.updateEvent(request, response, function (status, message) {
        response.send({ "status": status, "message": message });
    })
});

exports.addCommentInEventDiscussionNew = functions.https.onRequest((request, response) => {
    console.log("addCommentInEventDiscussionNew");
    Events.addCommentInEventDiscussion(request, response, function (status, message) {
        response.send({ "status": status, "message": message });
    })
});

// exports.addCommentInEventDiscussion = functions.firestore
//     .document("/events/{eventId}/event_comments/{commentId}")
//     .onCreate((snapshot, context) => {

//         const commentData = snapshot.data();
//         let eventId = context.params.eventId;
//         console.log("addCommentInEventDiscussion");
//         Events.getEventData(eventId, function (eventDataSuccess, eventData) {
//             console.log("eventDataSuccess : ", eventDataSuccess);
//             if (eventDataSuccess) {
//                 console.log("eventData is: ", eventData);
//                 console.log("commentData is: ", commentData);
//                 User.getUserData('users', commentData.userId, function (userSuccess, userDetail) {
//                     console.log("userSuccess : ", userSuccess);
//                     console.log("userDetail : ", userDetail);
//                     if (userSuccess) {
//                         let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
//                         let body = `${userDetail.firstName} ${userDetail.lastName} commented in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`

//                         let coHosts = eventData.acceptedCoHostInvites
//                         let selectedMembers = eventData.goingList

//                         console.log("MEMBERS DATA : ", selectedMembers.length);
//                         var finalMembers = selectedMembers.concat(coHosts)
//                         console.log("MEMBERS DATA AFTER");
//                         console.log("Commented User Id : " + commentData.userId)
//                         console.log("Event User Id : " + eventData.userId)
//                         if (commentData.userId != eventData.userId) {
//                             finalMembers.push(eventData.userId)
//                             finalMembers = finalMembers.filter(memberId => memberId !== commentData.userId);
//                             console.log("selectedMembers are: ", finalMembers);
//                         }
//                         console.log("MEMBERS COUNT : ", finalMembers.length);
//                         if (finalMembers.length > 0) {
//                             finalMembers.forEach((memberId) => {
//                                 User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                     console.log("Member success : ", memberSuccess);
//                                     if (memberSuccess) {
//                                         console.log("MemberId : " + memberId)
//                                         sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_COMMENT_ADDED, userDetail.id)
//                                     } else {
//                                         console.log("Error While Getting Member Data");
//                                     }
//                                 });
//                             })
//                         }
//                         //notify the mentioned users
//                         let comment = commentData.comment
//                         const regex = /@(\w+)/g;
//                         if (comment.match(regex)) {
//                             let mentionedUsers = comment.match(regex).map((user) => user.slice(1));
//                             if (mentionedUsers.length > 0) {
//                                 if (mentionedUsers.includes('guests')) {
//                                     if (eventData.isVisibleToAllSelected == true) {
//                                         //// If Else Lgana id kdni ode base te 
//                                         User.getUserFriends('friends', eventData.userId, function (friendsSuccess, friendList) {
//                                             console.log("Friends success : ", friendsSuccess);
//                                             if (friendsSuccess) {
//                                                 if (friendList.length == 0) {
//                                                     friendList = []
//                                                 }
//                                                 let allMembers = friendList.concat(coHosts)
//                                                 if (commentData.userId != eventData.userId) {
//                                                     allMembers.push(eventData.userId)
//                                                     allMembers = allMembers.filter(memberId => memberId !== commentData.userId);
//                                                 }

//                                                 if (allMembers.length > 0) {
//                                                     allMembers.forEach((memberId) => {
//                                                         User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                                             console.log("Member success : ", memberSuccess + " " + memberId);
//                                                             if (memberSuccess) {
//                                                                 // Notification send krni mention Vali
//                                                                 let body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                                                 sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.USER_MENTIONED, userDetail.id)
//                                                             } else {
//                                                                 console.log("Error While Getting Member Data");
//                                                             }
//                                                         });
//                                                     })
//                                                 }
//                                             } else {
//                                                 console.log("Error While Getting Friend List");
//                                             }
//                                         });
//                                     }
//                                     else {
//                                         let selectedMembers = eventData.selectedMembers
//                                         let allMembers = selectedMembers.concat(coHosts)
//                                         if (commentData.userId != eventData.userId) {
//                                             allMembers.push(eventData.userId)
//                                             allMembers = allMembers.filter(memberId => memberId !== commentData.userId);
//                                         }
//                                         console.log("selectedMembers are: ", allMembers);
//                                         if (allMembers.length > 0) {
//                                             allMembers.forEach((memberId) => {
//                                                 User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
//                                                     console.log("Member success : ", memberSuccess);
//                                                     if (memberSuccess) {
//                                                         console.log("MemberId : " + memberId)
//                                                         let body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                                         sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.USER_MENTIONED, userDetail.id)
//                                                     } else {
//                                                         console.log("Error While Getting Member Data");
//                                                     }
//                                                 });
//                                             })
//                                         }
//                                     }
//                                 } else {
//                                     console.log("mentionedUsers are: ", mentionedUsers);
//                                     mentionedUsers.forEach((mentionedId) => {
//                                         User.getUserDataFromUsername(mentionedId, function (mentionUserSuccess, mentionedUserId) {
//                                             console.log("mentionUserSuccess : ", mentionUserSuccess);
//                                             // console.log("mentionedUserDetail : ", mentionedUserDetail.notificationSettings.mentions)
//                                             if (mentionUserSuccess) {
//                                                 const userId = Object.keys(mentionedUserId)[0];
//                                                 console.log("mentionedUserId : ", userId)
//                                                 User.getUserData('users', userId, function (mentionedUserInnerSuccess, mentionedUserInnerDetail) {
//                                                     console.log("Member success : ", mentionedUserInnerSuccess);
//                                                     if (mentionedUserInnerSuccess) {
//                                                         let body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
//                                                         sendNotificationFromServer(userId, body, userDetail, eventData, mentionedUserInnerDetail, Constants.USER_MENTIONED, userDetail.id)
//                                                     } else {
//                                                         console.log("Error While Getting Member Data");
//                                                     }
//                                                 });
//                                                 // sendNotificationFromServer(mentionedId, body, userDetail, eventData, mentionedUserDetail, Constants.USER_MENTIONED, userDetail.id)
//                                             } else {
//                                                 console.log("Error While Getting mentionUser Data");
//                                             }
//                                         });
//                                     })
//                                 }
//                             }
//                             else {
//                                 console.log("No Mention Inside in comment");
//                             }
//                         }
//                         else {
//                             console.log("No Mention in comment");
//                         }
//                     } else {
//                         console.log("Error While Getting User Data");
//                     }
//                 });
//             } else {
//                 console.log("Error While Getting Event Data");
//             }
//         });
//         return true;
//     });

// exports.eventCreatedOld = functions.https.onRequest(async (request, response) => {
//     console.log("eventCreatedOld");
//     console.log("eventCreatedOld Start" + request.query.userId);
//     // let eventData = TestData.addTestEventInDatabase(request.query.userId)
//     // const eventName = eventData.name;
//     // const user = await getUserWithId(eventData.userId);
//     // if (eventData.isVisibleToAllSelected == true) {
//     //     const selectedMembers = await getUserFriends(eventData.userId);
//     //     await sendEventNotification(
//     //         user,
//     //         eventData,
//     //         selectedMembers,
//     //         eventName,
//     //         "created"
//     //     );
//     // } else {
//     //     const selectedMembers = eventData.selectedMembers;
//     //     await sendEventNotification(
//     //         user,
//     //         eventData,
//     //         selectedMembers,
//     //         eventName,
//     //         "created"
//     //     );
//     // }
//     // const invitedCoHosts = eventData.pendingCoHostInvites;
//     // if (invitedCoHosts.length > 0) {
//     //     await sendCoHostInviteNotification(user, eventData, invitedCoHosts, eventName);
//     // }

//     response.send({ "success": true });
// });

// exports.testComment = functions.https.onRequest((request, response) => {
//     console.log("testComment");
//     console.log("testComment userId" + request.query.userId);
//     console.log("testComment comment" + request.query.comment);
//     TestData.addTestCommentEventInDatabase(request.query.userId, request.query.comment)

//     response.send({ "success": true });
// });

// exports.sendTestNotification = functions.https.onRequest(async (request, response) => {
//     console.log("sendTestNotification");
//     console.log("sendTestNotification token" + request.query.token);
//     let token = request.query.token

//     const payload = {
//         notification: {
//             title: "Genbay",
//             body: "This is test notification",
//             sound: "default",
//             badge: "0",
//         },
//         // data: data,
//     };

//     admin
//         .messaging()
//         .sendToDevice(token, payload)
//         .then(function (response) {
//             console.log("Successfully sent message:", response);
//             if (response.failureCount > 0) {
//                 const errorMessage = response.results[0].error;
//                 console.error(`FCM Error: ${errorMessage}`);
//             }
//         })
//         .catch(function (error) {
//             console.error("Error sending message:", error);
//         });

//     response.send({ "success": true });
// });

// exports.checkParticularTokenValid = functions.https.onRequest(async (request, response) => {
//     console.log("checkParticularTokenValid");
//     console.log("checkParticularTokenValid token : " + request.query.token);
//     let token = request.query.token
//     verifyFCMToken(token)
//         .then(result => {
//             console.log(`Token is valid.`);
//         })
//         .catch(err => {
//             console.error(`Token is invalid.`);
//         });
//     response.send({ "success": true });
// });

// exports.checkTokensFromDatabase = functions.https.onRequest(async (request, response) => {
//     console.log("checkTokensFromDatabase");
//     const usersRef = admin.database().ref('/users');
//     User.getAllUserData(function (success, data) {
//         console.log("getAllUserData success : ", success);
//         console.log("Count : " + data)
//         if (success) {
//             if (data) {
//                 for (const userId of Object.keys(data)) {
//                     let tokens = data[userId].tokens || [];
//                     tokens.forEach((token) => {
//                         verifyFCMToken(token)
//                             .then(result => {
//                                 console.log(`Token ${token} for user ${userId} is still valid.`);
//                             })
//                             .catch(err => {
//                                 console.error(`Token ${token} for user ${userId} is invalid. Removing..`);
//                                 tokens = tokens.filter(t => t !== token);
//                                 admin.database().ref(`/users/${userId}/tokens`).set(tokens).then(() => {
//                                     console.log("Token removed successfully.");
//                                 }).catch((error) => {
//                                     console.log("Error removing token: ", error);
//                                 });
//                                 // admin.database().ref(`/users/${userId}/tokens/${token}`).remove();
//                             })
//                     });
//                 }
//             }
//         } else {
//             console.log("Error While Getting AllUsers Data");
//         }

//     });


//     response.send({ "success": true });
// });
// // }