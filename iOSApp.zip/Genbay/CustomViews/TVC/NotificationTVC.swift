//
//  NotificationTVC.swift
//  Genbay
//
//  Created by Nap Works on 10/05/23.
//

import UIKit
import Kingfisher

enum AcceptActionType {
    case coHostInvite
    case friendRequest

}

protocol NotificationTVCDelegate: AnyObject {
    func onButtonPressed(_ index: Int, isAccepted: Bool, type: AcceptActionType )
}

class NotificationTVC: UITableViewCell {
    
    let TAG = String(describing: NotificationTVC.self)
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var userImageView: UIImageView!
    
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var acceptBtn: UIButton!
    @IBOutlet weak var declineBtn: UIButton!
    @IBOutlet weak var buttonsView: UIView!
    var timer: Timer?
    var notificationType: String = ""
    var eventId: String = ""
    var viewController: NotificationTabVC?
//    var eventData: String = ""
//    var eventId: String = ""
    var index: Int = 0
    var delegate: NotificationTVCDelegate?
    var status: Int = 0
    var userModel: UserModel = UserModel()
    var sentUserId: String = ""
    override func awakeFromNib() {
        super.awakeFromNib()
        userImageView.layer.cornerRadius = userImageView.frame.width/2
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        stopTimer()
        timeLabel.text = nil
    }
    
    func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    
    func configure(with model: NotificationModel, index: Int){
        self.userModel = UserDefaultsMapper.getUser() ?? UserModel()
        self.index = index
        self.status = model.status ?? 0

//        self.eventData = model.info?.eventData ?? ""
        self.eventId = model.info?.eventId ?? ""
        self.sentUserId = model.info?.userId ?? ""
        [acceptBtn, declineBtn].forEach { button in
            if let button = button {
                CommonMethods.roundCornerFilled(uiView: button, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 20, borderWidth: 1)
            }
        }
        mainView.layer.applySketchShadow(color: .black, alpha: 0.25, x: 0, y: 4, blur: 4, spread: 0)
        if model.status == 1 {
            messageLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        }else {
            messageLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        }
        
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .black, backgroundColor: .white, cornerRadius: 0.0, borderWidth: 1.0)
        
        if let message = model.info?.message {
            messageLabel.text = message.replacingOccurrences(of: "  ", with: "")
        }
        
        if let type = model.type {
            self.notificationType = type
            if type == Constants.FRIEND_REQUEST_SENT {
                if self.status == 1 {
                    buttonsView.isHidden = true
                }else {
                    buttonsView.isHidden = false
                }
            }
            else if type == Constants.CO_HOST_INVITE {
                buttonsView.isHidden = false
            }
            else {
                buttonsView.isHidden = true
            }
        }
        
        if let timeStamp = Double(model.info?.timeStamp ?? "") {
            setTimeAgo(timeStamp)
            timer?.invalidate()
            timer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] timer in
                guard let self = self else { return }
                self.setTimeAgo(timeStamp)
            }
        }
        if let image = model.info?.userImage {
            if image != ""{
                userImageView.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
            }
        }
        
    }
    
    func setTimeAgo(_ timeStamp: Double){
        let date = Date(timeIntervalSince1970: Double(timeStamp / 1000))
        let timeAgo = timeAgoSinceDate(date)
        timeLabel.text = timeAgo
    }
    
    func timeAgoSinceDate(_ date: Date) -> String {
        let calendar = Calendar.current
        let now = Date()
        let components = calendar.dateComponents([.second, .minute, .hour, .day, .weekOfYear], from: date, to: now)
        
        if let week = components.weekOfYear, week > 0 {
            return "\(week) week\(week > 1 ? "s" : "") ago"
        }
        
        if let day = components.day, day > 0 {
            return "\(day) day\(day > 1 ? "s" : "") ago"
        }
        
        if let hour = components.hour, hour > 0 {
            return "\(hour) hour\(hour > 1 ? "s" : "") ago"
        }
        
        if let minute = components.minute, minute > 0 {
            return "\(minute) minute\(minute > 1 ? "s" : "") ago"
        }
        
        if let second = components.second, second > 0 {
            return "\(second) second\(second > 1 ? "s" : "") ago"
        }
        
        return "Just now"
    }
    
    @IBAction func acceptBtnPressed(_ sender: UIButton){
        CommonMethods.showLog(self.TAG, "STATUS: \(status)")

//        if status == 1 {
//            return
//        }else {
            if notificationType == "friendRequestSent"{
                CommonMethods.showLog(self.TAG, "Accepting Friend Request")
                self.confirmFriendRequest(self.sentUserId)
            }else {
//                let eventId = self.getEventId(self.eventData)
                CommonMethods.showLog(self.TAG, "eventId: \(eventId)")
                if eventId != "" {
                    CommonMethods.showLog(self.TAG, "eventId is: \(eventId)")
                    viewController?.showProgressHUD()
                    let user = UserDefaultsMapper.getUser()
                    FirebaseAPI.default.acceptCoHostInvitation(eventId, userId: user?.id ?? "") { success, error in
                        self.viewController?.hideProgressHUD()
                        if let error = error {
                            
                        }else {
                            self.delegate?.onButtonPressed(self.index, isAccepted: true, type: .coHostInvite)
//                            Navigations.goToEvents(navigationController: self.viewController?.navigationController ?? UINavigationController(), calledFrom: Constants.VIEW_EVENT)
                        }
                    }
                }else {
                    viewController?.showDialog(message: "Event Id is incorrect!")
                }
              
            }
//        }
    }

    @IBAction func declineBtnPressed(_ sender: UIButton){
        CommonMethods.showLog(self.TAG, "STATUS: \(status)")
//        if status == 1 {
//            return
//        }else {
            if notificationType == "friendRequestSent"{
                CommonMethods.showLog(self.TAG, "Cancelling Friend Request")
                self.cancelFriendRequest(self.sentUserId)
            }else {
//                let eventId = self.getEventId(self.eventData)
                if eventId != "" {
                    CommonMethods.showLog(self.TAG, "eventId is: \(eventId)")
                    viewController?.showProgressHUD()
                    let user = UserDefaultsMapper.getUser()
                    FirebaseAPI.default.declineCoHostInvitation(eventId, userId: user?.id ?? "") { success, error in
                        self.viewController?.hideProgressHUD()
                        if let error = error {
                            self.viewController?.showDialog(title: Constants.APP_NAME, message: error.localizedDescription)
                        }else {
                            self.delegate?.onButtonPressed(self.index, isAccepted: false, type: .coHostInvite)
                        }
                    }
                }else {
                    viewController?.showDialog(message: "Event Id is incorrect!")
                }
            }
//        }
      
    }
    
    
    func getEventId(_ jsonString: String)->String {
        if let jsonData = jsonString.data(using: .utf8) {
            do {
                // Parse the JSON data
                if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                    // Access the "id" field
                    if let id = json["id"] as? String {
                        return id
                    } else {
                        return ""
                    }
                } else {
                    return ""
                }
            } catch {
                return ""
            }
        } else {
            return ""
        }
    }
    
    func cancelFriendRequest(_ clickedUserId: String){
        viewController?.showProgressHUD()
        FirebaseAPI.default.cancelFriendRequest(clickedUserId: clickedUserId, userId: self.userModel.id ?? ""){ success,message in
            self.viewController?.hideProgressHUD()
            if success{
                self.delegate?.onButtonPressed(self.index, isAccepted: false, type: .friendRequest)
            }
            else{
                self.viewController?.showDialog(title: Constants.APP_NAME,message: message)
            }
        }
    }
    
    func confirmFriendRequest(_ clickedUserId: String){
        viewController?.showProgressHUD()
        CommonWebServices.confirmFriendRequest(userId: self.userModel.id ?? "", receiverId: clickedUserId) { status, message, model in
            self.viewController?.hideProgressHUD()
            if status == Constants.SUCCESS {
                self.delegate?.onButtonPressed(self.index, isAccepted: true, type: .friendRequest)
            }else if status == Constants.FAILURE {
                self.viewController?.showDialog(title: Constants.APP_NAME,message: message)
            }
        }
//        FirebaseAPI.default.confirmFriendRequest(clickedUserId: clickedUserId, userId: self.userModel.id ?? ""){ success,message in
//            self.viewController?.hideProgressHUD()
//            if success{
//                self.delegate?.onButtonPressed(self.index, isAccepted: true, type: .friendRequest)
//            }
//            else{
//                self.viewController?.showDialog(title: Constants.APP_NAME,message: message)
//            }
//
//        }
    }
}
