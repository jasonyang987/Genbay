//
//  ChangePasswordVC.swift
//  TruthAlibi
//
//  Created by Nap Works on 21/02/23.
//

import UIKit

class ChangePasswordVC: BaseViewController, UITextFieldDelegate {
    
    let TAG = String(describing: ChangePasswordVC.self)

    @IBOutlet weak var currentPasswordTitle: UILabel!
    @IBOutlet weak var newPasswordText: UITextField!
    @IBOutlet weak var changePasswordBtn: UIButton!
    @IBOutlet weak var confirmNewPasswordText: UITextField!
    @IBOutlet weak var confirmNewPasswordView: UIView!
    @IBOutlet weak var newPasswordView: UIView!
    @IBOutlet weak var currentPasswordText: UITextField!
    @IBOutlet weak var currentPasswordView: UIView!
    
    var viewModel : ChangePasswordViewModel?,userModel : UserModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        viewModel = ChangePasswordViewModel(vc: self)
        setUI()
    }
    
    func setUI(){
        
        if Constants.FILL_STATIC_FORM{
            currentPasswordText.text = "Qwerty@123"
            newPasswordText.text = "Qwerty@123"
            confirmNewPasswordText.text = "Qwerty@123"
            
        }
        
        [currentPasswordView,newPasswordView,confirmNewPasswordView].forEach{view in
            CommonMethods.roundCornerFilled(uiView: view, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)}
        
        CommonMethods.setPlaceholderColor(textFields: [currentPasswordText,newPasswordText,confirmNewPasswordText], color: .darkGray)
        
        
        CommonMethods.roundCornerFilled(uiView: changePasswordBtn, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 25.0, borderWidth: 0.0)
        
        currentPasswordText.delegate = self
        newPasswordText.delegate = self
        confirmNewPasswordText.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
                if textField == currentPasswordText {
                    newPasswordText.becomeFirstResponder()
                }else if textField == newPasswordText{
                    confirmNewPasswordText.becomeFirstResponder()
                }else if textField == confirmNewPasswordText {
                    textField.resignFirstResponder()
                }
                return true
       }

    @IBAction func changePasswordClicked(_ sender: Any) {
        CommonMethods.showLog(TAG, "changePasswordClicked")
        do{
            try viewModel?.validate()
            viewModel?.changePassword()
        }
        catch let error as ChangePasswordViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }
    @IBAction func backButtonPressed(_ sender: Any) {
        CommonMethods.dismiss(vc: self)
    }
}
