//
//  EventMemoryModel.swift
//  Genbay
//
//  Created by Nap Works on 15/04/23.
//

import Foundation

class EventMemoryModel: Codable {
    var id: String?
    var eventId: String?
    var images: [String]?
    var description: String?
    var createdAt: Double?
    var userId: String?
    
    enum Codingkeys: CodingKey {
        case id
        case eventId
        case images
        case description
        case createdAt
        case userId
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(String.self, forKey: .id)
        eventId = try container.decodeIfPresent(String.self, forKey: .eventId)
        images = try container.decodeIfPresent([String].self, forKey: .images)
        description = try container.decodeIfPresent(String.self, forKey: .description)
        createdAt = try container.decodeIfPresent(Double.self, forKey: .createdAt)
        userId = try container.decodeIfPresent(String.self, forKey: .userId)
    }
    
    init(){
        
    }
    
    var createEventMemoryParameters: [String: Any] {
        return [
             "id": id ?? "",
             "eventId": eventId ?? "",
             "images": images ?? [],
             "description": description ?? "",
             "createdAt": createdAt ?? 0,
             "userId": userId ?? ""
        ]
    }

    
}
