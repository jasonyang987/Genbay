//
//  MemoryViewModel.swift
//  Genbay
//
//  Created by Nap Works on 17/04/23.
//

import Foundation

final class MemoryViewModel {
    let TAG = String(describing: MemoryViewModel.self)
    var vc : MemoriesVC
    
    init(vc: MemoriesVC) {
        self.vc = vc
    }
    

    
    func getEventMemories(){
        self.vc.showProgressHUD()
        if let model = self.vc.eventModel {
            FirebaseAPI.default.getEventMemoriesFirestore(eventId: model.id ?? "") { list in
                CommonMethods.showLog(self.TAG, "list is: \(list)")
                self.vc.hideProgressHUD()
                self.vc.eventMemoriesList = list
                if self.vc.eventMemoriesList.count == 0 {
                    self.vc.noMemoriesView.isHidden = false
                }else {
                    self.vc.noMemoriesView.isHidden = true
                }
                self.vc.memoriesCollectionView.reloadData()
            }
        }
    }
    
}
