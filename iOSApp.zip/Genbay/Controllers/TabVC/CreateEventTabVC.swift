//
//  PlusTabVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit
import DropDown

class CreateEventTabVC: BaseViewController,UITextViewDelegate, DateSelectionDelegate, ChooseCrowdForEventDelegate, PollSelectionDelegate, ShowInstructionsVCDelegate, IndividualFriendsPopupVCDelegate {
  
    
    let TAG = String(describing: CreateEventTabVC.self)
    
    @IBOutlet weak var createLocationPollButton: UIButton!
    @IBOutlet weak var pollVotingDeadlineText: UITextField!
    @IBOutlet weak var pollVotingView: UIView!
    @IBOutlet weak var createDatePollBtn: UIButton!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var spinnerView: UIView!
    @IBOutlet weak var eventDescriptionText: UITextView!
    @IBOutlet weak var pageTitle: UILabel!
    @IBOutlet weak var locationText: UITextField!
    @IBOutlet weak var dateText: UITextField!
    @IBOutlet weak var startTimeView: UIView!
    @IBOutlet weak var startTimeText: UITextField!
    @IBOutlet weak var spinnerText: UITextField!
    @IBOutlet weak var eventNameView: UIView!
    @IBOutlet weak var eventNameText: UITextField!
    @IBOutlet weak var postBtn: UIButton!
    @IBOutlet weak var deleteView: UIView!
    @IBOutlet weak var addLocationView: UIView!
    @IBOutlet weak var createPollView: UIView!
    @IBOutlet weak var deleteEventBtn: UIButton!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var inviteCoHostView: UIView!
    @IBOutlet weak var inviteCoHostText: UITextField!
    var calledFrom = "",eventModel:EventModel?
    var crowdList:[CrowdModel] = []
    var datePollList :[DatePollModel] = [],locationList:[Location] = []
    var selectedCrowdList:[String] = [], selectedMembersList : [String] = []
    var userData:UserModel?
    var viewModel:CreateEventTabViewModel?
    
    var dateTimestamp = 0.0 , startTimeTimeStamp = 0.0, datePollDeadlineTimestamp = 0.0

    var locationModel :Location?
    var isVisibleToAllSelected : Bool?
    var inviteFriends: [String] = []
    var inviteFriendsAsCoHost: [UserModel] = []
    
    var friendsList: [UserModel] = []

    @IBOutlet weak var tapToContinueLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        userData = UserDefaultsMapper.getUser()
        viewModel = CreateEventTabViewModel(vc: self)
      
        
        setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        friendsList = AppDelegate.shared.friendList
//        if calledFrom != Constants.EDIT_EVENT{
            self.mainView.isHidden = true
            isVisibleToAllSelected = false
            viewModel?.getCrowds()
//        }
        checkAndShowTutorial()
    }
    
    ///Method to check if user has completed the tutorial, if not, then show the tutorial...
    func checkAndShowTutorial(){
        let isCompletedTutorial = UserDefaults.standard.bool(forKey: Constants.IS_COMPLETED_TUTORIAL)
        if isCompletedTutorial {
            tapToContinueLabel.isHidden = true
        }else {
            Navigations.showInstructionsVC(self, delegate: self, calledFrom: "CreateEventTabVC")
            tapToContinueLabel.isHidden = false
        }
    }
    
    ///ShowInstructionsVC Delegate Method
    func navigate() {
        UserDefaults.standard.set(true, forKey: Constants.IS_COMPLETED_TUTORIAL)
        UserDefaults.standard.synchronize()
        navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func showEventsPressed(_ sender: Any) {
//        Navigations.goToEvents(navigationController: navigationController)
    }
    
    @IBAction func postButtonPressed(_ sender: Any) {
        CommonMethods.showLog(self.TAG, "inviteFriends: \(inviteFriends)")
        do{
            CommonMethods.showLog(TAG, "Poll Deadline Timestamp : \(eventModel?.pollVotingDeadlineTimestamp), \(datePollDeadlineTimestamp)")
            try viewModel?.validate()
            if calledFrom == Constants.EDIT_EVENT{
                viewModel?.editEvent()
            }
            else{
                viewModel?.createEvent()
            }

        }
        catch let error as CreateEventTabViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }
    
    
    @IBAction func pollVotingDeadlinePressed(_ sender: Any) {
        var maxDate : Date?
        if datePollList.count > 0{
            maxDate = CommonMethods.getFullDateFromString(dateString: datePollList[0].date ?? "")
        }
        
        
        Navigations.showDatePicker(calledFrom:Constants.EVENT_POLL_VOTING_DEADLINE,viewController: self, delegate : self, pageTitle: "Poll Voting Deadline", minDate: Date(), maxDate: maxDate?.timeIntervalSince1970 == 0.0 ? nil : maxDate , mode: .date)
    }
    
    
    @IBAction func deleteEventPressed(_ sender: Any) {
        viewModel?.deleteEvent()
    }
    
    
    
    @IBAction func datePressed(_ sender: Any) {
        Navigations.showDatePicker(calledFrom:Constants.EVENT_DATE,viewController: self, delegate : self, pageTitle: "Event Date", minDate: Date(), maxDate: nil, mode: .date)
    }
    
    
    @IBAction func startTimePressed(_ sender: Any) {
        Navigations.showDatePicker(calledFrom:Constants.EVENT_START_TIME,viewController: self, delegate: self, pageTitle: "Start Time", minDate: nil, maxDate: nil, mode: .time)
    }
    
    @IBAction func createPollPressed(_ sender: Any) {
        Navigations.showCreatePoll(viewController: self, delegate: self, pageTitle: "Date Poll",type:Constants.DATE,dateList:datePollList,locationList:locationList)
    }
    
    @IBAction func addLocationPressed(_ sender: Any) {
//      Navigations.showCreatePoll(viewController: self, delegate: self, pageTitle: "Add Location",type:Constants.LOCATION)
        Navigations.showCreatePoll(viewController: self, delegate: self, pageTitle: "Add Location",type:Constants.LOCATION,dateList:datePollList,locationList:locationList)
    }
    
    
    
    
    @IBAction func spinnerViewPressed(_ sender: Any) {
        friendsList = AppDelegate.shared.friendList
        if friendsList.count > 0 || crowdList.count > 0{
            if crowdList.count>0{
                var isAnyMemberExist = false
                for i in 0..<crowdList.count{
                    let data = crowdList[i]
                    if data.membersList?.count ?? 0>0{
                        isAnyMemberExist = true
                        break
                    }
                }
                
                if isAnyMemberExist{
                    Navigations.showChooseCrowdDialog(viewController: self, delegate:self,crowdList:crowdList,isVisibleToAllSelected:isVisibleToAllSelected ?? false, selectedMembers: self.selectedMembersList)
                }
                else{
                    showDialog(title: Constants.APP_NAME, message: "You have not added any friend , members in crowd or crowd yet.")
                }
            }
            else{
                Navigations.showChooseCrowdDialog(viewController: self, delegate:self,crowdList:crowdList,isVisibleToAllSelected:isVisibleToAllSelected ?? false, selectedMembers: self.selectedMembersList)
            }
        }
        else{
            showDialog(title: Constants.APP_NAME, message: "You have not added any friend or crowd yet.")
        }
    }
    
    @IBAction func inviteAsCoHostSpinnerPressed(_ sender: UIButton){
        friendsList = AppDelegate.shared.friendList
        if friendsList.count > 0{
            Navigations.showIndividualFriendsPopup(viewController: self, delegate: self, selectedFriends: inviteFriends, selectedCoHosts: self.inviteFriendsAsCoHost)
        }
        else{
            showDialog(title: Constants.APP_NAME, message: "You have not added any friend yet.Add friends first.")
        }
    }
    
    
    func onPollDateSelected(dates: [DatePollModel]?) {
        CommonMethods.showLog(TAG, "onPollDateSelected")
        CommonMethods.showLog(TAG, "list count : \(dates?.count)")
        datePollList = dates ?? []
        setDatePollUI()
        setPollingDeadlineUI()
    }
    
    
    func onPollLocationSelected(list: [Location]?) {
        CommonMethods.showLog(TAG, "onPollLocationSelected")
        CommonMethods.showLog(TAG, "list count : \(list?.count)")
        locationList = list ?? []
        setLocationPollUI()
        setPollingDeadlineUI()
    }
    
    func setDatePollUI(){
        if datePollList.count == 0{
            createDatePollBtn.setTitle("Create Poll (optional) ", for: .normal)
        }
        else{
            createDatePollBtn.setTitle("Edit Poll", for: .normal)
        }
    }
    
    func setLocationPollUI(){
        if locationList.count == 0{
            createLocationPollButton.setTitle("Create Poll (optional) ", for: .normal)
        }
        else{
            createLocationPollButton.setTitle("Edit Poll", for: .normal)
        }
    }
    
    func setPollingDeadlineUI(){
        if datePollList.count == 0 && locationList.count == 0{
            datePollDeadlineTimestamp = 0.0
            pollVotingView.isHidden = true
        }
        else{
            pollVotingView.isHidden = false
        }
    }
    
    func onDateSelected(calledFrom:String,date: Date) {
        CommonMethods.showLog(TAG, "onDateSelected date : \(date), calledFrom : \(calledFrom)")

        if calledFrom == Constants.EVENT_START_TIME{
            startTimeTimeStamp = date.timeIntervalSince1970
            startTimeText.text = CommonMethods.getFormattedDate(timeStamp: date.timeIntervalSince1970, format: "h:mm a")
        }
        else if calledFrom == Constants.EVENT_DATE{
            dateTimestamp = date.timeIntervalSince1970
            dateText.text = CommonMethods.getFormattedDate(timeStamp: date.timeIntervalSince1970, format: "MM/dd/yyyy")
        }
        else if calledFrom == Constants.EVENT_POLL_VOTING_DEADLINE{
            datePollDeadlineTimestamp = date.timeIntervalSince1970
            pollVotingDeadlineText.text = CommonMethods.getFormattedDate(timeStamp: date.timeIntervalSince1970, format: "MM/dd/yyyy")
        }
    }
    
    func setUI(){
        
        if calledFrom == Constants.EDIT_EVENT{
            pageTitle.text = "Edit Event"
            CommonMethods.showLog(TAG, "EDIT_EVENT")
            eventNameText.text = eventModel?.name
            startTimeText.text = eventModel?.startTime
            dateText.text = eventModel?.date
            locationText.text = eventModel?.location
            pollVotingDeadlineText.text = eventModel?.pollVotingDeadlineTime
            eventDescriptionText.text = eventModel?.description
            
            selectedCrowdList = eventModel?.selectedCrowds ?? []
            selectedMembersList = eventModel?.selectedMembers ?? []
            inviteFriends = eventModel?.pendingCoHostInvites ?? []
            
            var spinnerText = ""
            isVisibleToAllSelected = eventModel?.isVisibleToAllSelected ?? false
            if isVisibleToAllSelected ?? false{
                self.spinnerText.text = "Visible To All Friends"
            }
            else{
                if crowdList.count == 0 && selectedMembersList.count != 0 {
                    spinnerText = "Visible to Individual Friends"
                }else {
                    crowdList.forEach{ data in
                        if selectedCrowdList.count > 0{
                            if selectedCrowdList.contains(data.id ?? ""){
                                CommonMethods.showLog(TAG, "selectedCrowdList hegi aa")
                                data.isSelected = true
                                if spinnerText == ""{
                                    spinnerText = data.name ?? ""
                                }
                                else{
                                    spinnerText = "\(spinnerText), \(data.name ?? "")"
                                }
                            }
                        }
                        
                    }
                }
                
                
                self.spinnerText.text = spinnerText
            }
            
            
            CommonMethods.showLog(TAG, "Poll Deadline Timestamp : \(eventModel?.pollVotingDeadlineTimestamp)")
            
            startTimeTimeStamp = eventModel?.startTimestamp ?? 0.0
            dateTimestamp = eventModel?.dateTimestamp ?? 0.0
            datePollDeadlineTimestamp = eventModel?.pollVotingDeadlineTimestamp ?? 0.0
//            locationModel = eventModel?.location
            CommonMethods.showLog(TAG, "Poll Deadline Timestamp 12: \(datePollDeadlineTimestamp)")

            eventDescriptionText.textColor = .black
            
            backView.isHidden = false
            postBtn.setTitle("Confirm Changes", for: .normal)
            deleteView.isHidden = false
            
            FirebaseAPI.default.fetchDatePollList(eventModel?.id ?? "") { datePollList in
                if let datePollList = datePollList {
                    if datePollList.count > 0 {
                        self.datePollList = datePollList
                    }else {
                        self.datePollList = []
                    }
                }
            }
            
            FirebaseAPI.default.fetchLocationPollList(eventModel?.id ?? "") { locationList in
                if let locationList = locationList {
                    if locationList.count > 0 {
                        self.locationList = locationList
                    }else {
                        self.locationList = []
                    }
                }
            }
            
            CommonMethods.showLog(self.TAG, "datePollList: \(datePollList)")
            CommonMethods.showLog(self.TAG, "locationList: \(locationList)")
        }
        else{
            eventDescriptionText.textColor = .darkGray
            pageTitle.text = "Create Event"
            backView.isHidden = true
            postBtn.setTitle("Post", for: .normal)
            deleteView.isHidden = true
        }
        
        
        eventDescriptionText.delegate = self
        
        
        postBtn.layer.cornerRadius = 20.0
        deleteEventBtn.layer.cornerRadius = 20.0
        CommonMethods.roundCornerFilled(uiView: createPollView, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 20.0, borderWidth: 0.0)
        CommonMethods.roundCornerFilled(uiView: addLocationView, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 20.0, borderWidth: 0.0)
        
        CommonMethods.setPlaceholderColor(textFields: [eventNameText,spinnerText,startTimeText,dateText,locationText,pollVotingDeadlineText, inviteCoHostText], color: .darkGray)
        
        setDatePollUI()
        setLocationPollUI()
        setPollingDeadlineUI()
    }
    
    
   
    
    func onCrowdsSelected(type:String,selectedCrowdList:[String]?,selectedMembersList:[String]?,selectedTitle:String,
                          crowdList:[CrowdModel],isVisibleToAllSelected:Bool){
        CommonMethods.showLog(TAG, "onCrowdsSelected")
        CommonMethods.showLog(TAG, "SelectedMembersList : \(selectedMembersList)")
        if type == "Success"{
            spinnerText.text = selectedTitle
            self.crowdList = crowdList
            self.isVisibleToAllSelected = isVisibleToAllSelected
            self.selectedMembersList = selectedMembersList ?? []
            self.selectedCrowdList = selectedCrowdList ?? []
        }
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == .darkGray {
                textView.text = nil
            textView.textColor = .black
        }
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            CommonMethods.showLog(TAG, "textViewDidEndEditing")
            textView.text = "Event Description"
            textView.textColor = .darkGray

        }
    }
    
    func textViewDidChange(_ textView: UITextView) {
            if textView.text.isEmpty {
                textView.text = "Event Description"
                textView.textColor = UIColor.darkGray
                textView.resignFirstResponder()
            } else {
                textView.textColor = UIColor.black
            }
        }

    @IBAction func backBtnPressed(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    func onFriendsSelection(_ friends: [String], isCellSelected: Bool) {
        self.inviteFriends = friends
    }
    
    func onCoHostsSelection(_ coHosts: [UserModel], isCellSelected: Bool) {
        self.inviteFriendsAsCoHost = coHosts
        self.inviteCoHostText.text = coHosts.map({$0.firstName ?? ""}).joined(separator: ", ")
    }
    
}
