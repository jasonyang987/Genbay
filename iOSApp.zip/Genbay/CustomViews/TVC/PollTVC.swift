//
//  PollTVC.swift
//  Genbay
//
//  Created by Nap Works on 06/04/23.
//

import UIKit

protocol PollTVCDelegate: AnyObject {
    func deleteDateOrLocation(tag: Int)
}

class PollTVC: UITableViewCell {

    @IBOutlet weak var dateView: UIView!
    @IBOutlet weak var checkMarkView: UIView!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var deleteBtn: UIButton!
    weak var delegate: PollTVCDelegate?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureDates(dateModel: DatePollModel, tag: Int){
        CommonMethods.roundCornerFilled(uiView: dateView, borderColor: .black, backgroundColor: .white, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: checkMarkView, borderColor: .black, backgroundColor: .white, cornerRadius: checkMarkView.frame.width / 2.0, borderWidth: 1.5)
        dateLabel.text = dateModel.date
        checkMarkView.backgroundColor = .white
        deleteBtn.tag = tag
    }
    
    func configureLocations(_ model: Location, tag: Int){
        CommonMethods.roundCornerFilled(uiView: dateView, borderColor: .black, backgroundColor: .white, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: checkMarkView, borderColor: .black, backgroundColor: .white, cornerRadius: checkMarkView.frame.width / 2.0, borderWidth: 1.5)
        dateLabel.text = model.location
        deleteBtn.tag = tag
    }
    
    func configureCheckMark(){
        checkMarkView.backgroundColor = (checkMarkView.backgroundColor == .white) ? .systemBlue : .white
    }
    
    @IBAction func deleteBtnPressed(_ sender: UIButton){
            self.delegate?.deleteDateOrLocation(tag: sender.tag)
    }
}
