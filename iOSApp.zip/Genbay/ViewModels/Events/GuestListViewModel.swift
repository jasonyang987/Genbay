//
//  GuestListViewModel.swift
//  Genbay
//
//  Created by Nap Works on 12/04/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class GuestListViewModel{
    let TAG = String(describing: GuestListViewModel.self)
    var vc : GuestListVC
    
    
    
    init(vc: GuestListVC) {
        self.vc = vc
    }
    
    
    func getGuestList(){
        CommonMethods.showLog(self.TAG, "List Size : \(self.vc.eventModel?.selectedMembers?.count)")
        self.vc.showProgressHUD()
        FirebaseAPI.default.getGuestListFirestore(userIds:self.vc.eventModel?.selectedMembers ?? []){list in
            self.vc.hideProgressHUD()
            self.vc.guestList = list
            CommonMethods.showLog(self.vc.TAG, "Guest List Count : \(self.vc.guestList.count)")
//          self.vc.guestList = guestList.sorted{
//              $0.dateTimestamp ?? Double() > $1.dateTimestamp ?? Double()
//          }

            self.checkAndShowMessage()
            self.vc.guestListTableView.reloadData()
        }
    }
    
    func checkAndShowMessage(){
        if self.vc.guestList.count == 0{
            self.vc.noGuestListView.isHidden = false
        }
        else{
            self.vc.noGuestListView.isHidden = true
        }
    }
}
