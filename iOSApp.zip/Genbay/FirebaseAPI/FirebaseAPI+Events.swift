//
//  FirebaseAPI+Events.swift
//  Genbay
//
//  Created by Nap Works on 31/03/23.
//

import Foundation
import Firebase
import FirebaseFirestore

extension FirebaseAPI {
    
    
    
    typealias CreateEventCompletion = (Error?, EventModel) -> Void
    func createNewEvent(eventModel : EventModel, completion: @escaping CreateEventCompletion) {
        let autoID = Endpoints.events.childByAutoId().key!
        CommonMethods.showLog(TAG, "createNewEvent autoID : \(autoID)")
        let model = eventModel
        model.id = autoID
        Endpoints.events.child(autoID).updateChildValues(model.createEventParameters) { error, dbRef in
            completion(error, model)
        }
    }
    
    //    typealias CreateEventCompletion = (Error?, EventModel) -> Void
    func createNewEventFirestore(eventModel : EventModel, completion: @escaping CreateEventCompletion) {
        let autoId = Endpoints.eventsFirestore.document().documentID
        CommonMethods.showLog(TAG, "createNewEvent autoID : \(autoId)")
        let model = eventModel
        model.id = autoId
        Endpoints.eventsFirestore.document(autoId).setData(eventModel.createEventParameters) { error in
            if let error = error {
                print("Error adding document: \(error)")
            } else {
                print("createNewEventFirestore added")
            }
            self.createDatePollInEvent(eventModel: model, completion: completion)
            //            completion(error, model)
        }
    }

    func removeUnfriendUserFromEventSelectedMembers(_ eventId: String, clickedUserId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["selectedMembers": FieldValue.arrayRemove([clickedUserId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func removeSelectedMembersOfDeletedCrowd(_ eventId: String, userId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["selectedMembers": FieldValue.arrayRemove([userId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func removeDeletedCrowdFromEventSelectedCrowds(_ eventId: String, crowdId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["selectedCrowds": FieldValue.arrayRemove([crowdId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func removeUnfriendUserFromEventGoingList(_ eventId: String, clickedUserId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["goingList": FieldValue.arrayRemove([clickedUserId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func createDatePollInEvent(eventModel : EventModel, completion: @escaping CreateEventCompletion) {
        let list = eventModel.datePollList ?? []
        if list.count > 0{
            
            Endpoints.eventsFirestore.document(eventModel.id ?? "").collection("datePollList").getDocuments() { (snapshot,error) in
                if let document = snapshot {
                    CommonMethods.showLog(self.TAG, "VALUE Document Data : \(document.documents.count)")
                    if document.documents.count > 0{
                        for document in document.documents {
                            document.reference.delete()
                        }
                    }
                    
                    CommonMethods.showLog(self.TAG, "DatePollList Count : \(list.count)")
                    
                    for(index,data) in list.enumerated(){
                        let autoId = Endpoints.eventsFirestore.document(eventModel.id ?? "").collection("datePollList").document().documentID
                        
                        var model = data
                        model.id = autoId
                        CommonMethods.showLog(self.TAG, "createDatePollInEvent autoID : \(autoId)")
                        Endpoints.eventsFirestore.document(eventModel.id ?? "").collection("datePollList").document(autoId).setData(model.firebaseDateParameters) { error in
                            if let error = error {
                                print("Error adding document: \(error)")
                                completion(error,eventModel)
                            } else {
                                print("createDatePollInEvent added")
                                if index == list.count - 1{
                                    self.createLocationPollInEvent(eventModel: eventModel, completion: completion)
                                }
                                //                completion(nil, model)
                            }
                        }
                    }
                }
            }
            
        }
        else{
            if eventModel.locationList?.count ?? 0>0{
                self.createLocationPollInEvent(eventModel: eventModel, completion: completion)
            }
            else{
                completion(nil,eventModel)
            }
        }
    }
    
    func createLocationPollInEvent(eventModel : EventModel, completion: @escaping CreateEventCompletion) {
        let list = eventModel.locationList ?? []
        if list.count>0{
            
            Endpoints.eventsFirestore.document(eventModel.id ?? "").collection("locationPollList").getDocuments() { (snapshot,error) in
                if let document = snapshot {
                    CommonMethods.showLog(self.TAG, "VALUE Document Data: \(document.documents.count)")
                    if document.documents.count > 0{
                        for document in document.documents {
                            document.reference.delete()
                        }
                    }
                    
                    for(index,data) in list.enumerated(){
                        let autoId = Endpoints.eventsFirestore.document(eventModel.id ?? "").collection("locationPollList").document().documentID
                        
                        var model = data
                        model.id = autoId
                        CommonMethods.showLog(self.TAG, "createLocationPollInEvent autoID : \(autoId)")
                        Endpoints.eventsFirestore.document(eventModel.id ?? "").collection("locationPollList").document(autoId).setData(model.firebaseLocationParameters) { error in
                            if let error = error {
                                print("Error adding document: \(error)")
                                completion(error,eventModel)
                            } else {
                                print("createLocationPollInEvent added")
                                if index == list.count - 1{
                                    completion(nil, eventModel)
                                }
                            }
                        }
                    }
                }
            }
        }
        else{
            completion(nil, eventModel)
        }
    }
    
    func addVoteInDatePollUserList(_ eventId: String, dateId: String, userId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId).collection("datePollList").document(dateId)
        
        ref.updateData(["userList": FieldValue.arrayUnion([userId])]) { error in
            if let error = error{
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    
    func addVoteInLocationPollUserList(_ eventId: String, locationId: String, userId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId).collection("locationPollList").document(locationId)
        
        ref.updateData(["userList": FieldValue.arrayUnion([userId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func removeVoteFromDatePollUserList(_ eventId: String, dateId: String, userId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId).collection("datePollList").document(dateId)
        
        ref.updateData(["userList": FieldValue.arrayRemove([userId])]) { error in
            if let error = error{
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func removeVoteFromLocationPollUserList(_ eventId: String, locationId: String, userId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId).collection("locationPollList").document(locationId)
        
        ref.updateData(["userList": FieldValue.arrayRemove([userId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func addisGoingInGoingList(_ eventId: String, userId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["goingList": FieldValue.arrayUnion([userId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func removeFromGoingList(_ eventId: String, userId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["goingList": FieldValue.arrayRemove([userId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    
    func fetchDatePollList(_ eventId: String, completion: @escaping ([DatePollModel]?) -> Void){
        let ref = Endpoints.eventsFirestore.document(eventId).collection("datePollList")
        //start
        
        let dispatchGroup = DispatchGroup()
        
        ref.addSnapshotListener{ documentSnapshot, error in
            var list : [DatePollModel] = []
            guard documentSnapshot != nil else {
              print("Error fetching document: \(error!)")
              return
            }
            
            if let document = documentSnapshot {
                if document.documents.count > 0{
                    list = []
                    for document in document.documents {
                        dispatchGroup.enter()
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let model = try JSONDecoder().decode(DatePollModel.self, from: data)
                            list.append(model)
                            dispatchGroup.leave()
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
//                        listener.remove()
                        completion(list)
                    }
                }
                else{
//                    listener.remove()
                    completion(list)
                }
            } else {
                print("Document added")
//                listener.remove()
                completion(list)
            }
            
            
        }
        
//        ref.getDocuments() { (snapshot,error) in
//            if let document = snapshot {
//                if document.documents.count > 0{
//                    for document in document.documents {
//                        dispatchGroup.enter()
//                        do {
//                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
//                            let model = try JSONDecoder().decode(DatePollModel.self, from: data)
//                            list.append(model)
//                            dispatchGroup.leave()
//                        } catch {
//                            CommonMethods.showLog(self.TAG, "Error")
//                            continue
//                        }
//                    }
//
//                    dispatchGroup.notify(queue: .main) {
//                        completion(list)
//                    }
//                }
//                else{
//                    completion(list)
//                }
//            } else {
//                print("Document added")
//                completion(list)
//            }
//        }
    }
    func fetchLocationPollList(_ eventId: String, completion: @escaping ([Location]?) -> Void ){
        let ref = Endpoints.eventsFirestore.document(eventId).collection("locationPollList")
        //start
        let dispatchGroup = DispatchGroup()
        ref.addSnapshotListener{ documentSnapshot, error in
            print("Listener Works")
            var list : [Location] = []
            guard documentSnapshot != nil else {
              print("Error fetching document: \(error!)")
              return
            }
            
            if let document = documentSnapshot {
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let model = try JSONDecoder().decode(Location.self, from: data)
                            list.append(model)
                            dispatchGroup.leave()
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
//                        listener.remove()
                        completion(list)
                    }
                }
                else{
//                    listener.remove()
                    completion(list)
                }
            } else {
//                listener.remove()
                completion(list)
            }
        }
        
//        ref.getDocuments() { (snapshot,error) in
//            if let document = snapshot {
//                if document.documents.count > 0{
//                    for document in document.documents {
//                        dispatchGroup.enter()
//                        do {
//                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
//                            let model = try JSONDecoder().decode(Location.self, from: data)
//                            list.append(model)
//                            dispatchGroup.leave()
//                        } catch {
//                            CommonMethods.showLog(self.TAG, "Error")
//                            continue
//                        }
//                    }
//
//                    dispatchGroup.notify(queue: .main) {
//                        completion(list)
//                    }
//                }
//                else{
//                    completion(list)
//                }
//            } else {
//                completion(list)
//            }
//        }
    }
    
    
    func editEventFirestore(eventModel : EventModel, completion: @escaping CreateEventCompletion) {
        //        let autoId = Endpoints.eventsFirestore.document().documentID
        //        CommonMethods.showLog(TAG, "createNewEvent eventId : \(model.id)")
        //        let model = eventModel
        //        model.id = autoId
        CommonMethods.showLog(TAG, "editEvent eventId : \(eventModel.id)")
        Endpoints.eventsFirestore.document(eventModel.id ?? "").setData(eventModel.createEventParameters) { error in
            if let error = error {
                print("Error adding document : \(error)")
            } else {
                print("Document Edited")
            }
            self.createDatePollInEvent(eventModel: eventModel, completion: completion)
            //            completion(error, eventModel)
        }
    }
    
    
    func deleteEventFirestore(eventModel : EventModel, completion: @escaping CreateEventCompletion) {
        CommonMethods.showLog(TAG, "editEvent eventId : \(eventModel.id)")
        Endpoints.eventsFirestore.document(eventModel.id ?? "").delete{error in
            if let error = error {
                print("Error adding document: \(error)")
            } else {
                print("Document Edited")
            }
            completion(error, eventModel)
            
        }
    }
    
    
    //MARK: - Method to get host events from firestore with live update using addSnapshotListener
    typealias GetUpcomingEventsSuccess = ([EventModel], String) -> Void
    func getUpcomingHostEventFirestore(name : String,userId:String, completion: @escaping GetUpcomingEventsSuccess){
        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let calendar = Calendar.current
        let currentDate = Date()
        let startOfCurrentDay = calendar.startOfDay(for: currentDate)
        let startOfCurrentDayTimestamp = startOfCurrentDay.timeIntervalSince1970
        
        let refrence = Endpoints.eventsFirestore.whereField("dateTimestamp", isGreaterThanOrEqualTo: startOfCurrentDayTimestamp)
            .whereField("userId", in: [userId])

        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "VALUE Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "VALUE Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            eventModel.hostName = name
                            self.getEventDatePollList(eventModel:eventModel){ datePollList in
                                eventModel.datePollList = datePollList
                                self.getEventLocationPollList(eventModel:eventModel){ locationList in
                                    eventModel.locationList = locationList
                                    list.append(eventModel)
                                    dispatchGroup.leave()
                                }
                            }
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list,"")
                    }
                }
                else{
                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "VALUE Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    func getUpcomingCoHostEventFirestore(userId:String, completion: @escaping GetUpcomingEventsSuccess){
        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let calendar = Calendar.current
        let currentDate = Date()
        let startOfCurrentDay = calendar.startOfDay(for: currentDate)
        let startOfCurrentDayTimestamp = startOfCurrentDay.timeIntervalSince1970
        
        let refrence = Endpoints.eventsFirestore
            .whereField("acceptedCoHostInvites", arrayContains: userId)
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "VALUE Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "VALUE Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            self.getUser(eventModel.userId ?? "") { (user, error) in
                                let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
                                eventModel.hostName = name
                                self.getEventDatePollList(eventModel:eventModel){ datePollList in
                                    eventModel.datePollList = datePollList
                                    self.getEventLocationPollList(eventModel:eventModel){ locationList in
                                        eventModel.locationList = locationList
                                        list.append(eventModel)
                                        dispatchGroup.leave()
                                    }
                                }
                            }
                           
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list,"")
                    }
                }
                else{
                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "VALUE Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    func getUpcomingEventFirestore(name : String, userId:String, completion: @escaping GetUpcomingEventsSuccess){
        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let refrence = Endpoints.eventsFirestore
            .whereField("dateTimestamp", isGreaterThan: Date().timeIntervalSince1970)
            .whereField("userId", isEqualTo: userId)
        
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "VALUE Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "VALUE Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            eventModel.hostName = name
                            self.getEventDatePollList(eventModel:eventModel){ datePollList in
                                eventModel.datePollList = datePollList
                                self.getEventLocationPollList(eventModel:eventModel){ locationList in
                                    eventModel.locationList = locationList
                                    list.append(eventModel)
                                    dispatchGroup.leave()
                                }
                            }
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list,"")
                    }
                }
                else{
                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "VALUE Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    
    typealias GetAllHostEventsSuccess = ([EventModel],String) -> Void
    func getAllHostEventFirestore(name : String,userId:String, completion: @escaping GetUpcomingEventsSuccess){
        
        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let refrence = Endpoints.eventsFirestore.whereField("userId", isEqualTo: userId)
        
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "VALUE Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "VALUE Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            eventModel.hostName = name
                            self.getEventDatePollList(eventModel:eventModel){ datePollList in
                                eventModel.datePollList = datePollList
                                self.getEventLocationPollList(eventModel:eventModel){ locationList in
                                    eventModel.locationList = locationList
                                    list.append(eventModel)
                                    dispatchGroup.leave()
                                }
                            }
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list,"")
                    }
                }
                else{
                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "VALUE Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    typealias GetDatePollListSuccess = ([DatePollModel]) -> Void
    func getEventDatePollList(eventModel:EventModel, completion: @escaping GetDatePollListSuccess){
        CommonMethods.showLog(TAG, "getEventDatePollList")
        var list : [DatePollModel] = []
        let dispatchGroup = DispatchGroup()
        let refrence = Endpoints.eventsFirestore.document(eventModel.id ?? "").collection("datePollList")
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "VALUE Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "VALUE Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let model = try JSONDecoder().decode(DatePollModel.self, from: data)
                            
                            list.append(model)
                            dispatchGroup.leave()
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list)
                    }
                }
                else{
                    completion(list)
                }
            } else {
                CommonMethods.showLog(self.TAG, "VALUE Document does not exist")
                completion(list)
            }
        }
    }
    
    typealias GetLocationPollListSuccess = ([Location]) -> Void
    func getEventLocationPollList(eventModel:EventModel, completion: @escaping GetLocationPollListSuccess){
        CommonMethods.showLog(TAG, "getEventLocationPollList")
        var list : [Location] = []
        let dispatchGroup = DispatchGroup()
        let refrence = Endpoints.eventsFirestore.document(eventModel.id ?? "").collection("locationPollList")
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "VALUE Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "VALUE Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let model = try JSONDecoder().decode(Location.self, from: data)
                            
                            list.append(model)
                            dispatchGroup.leave()
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list)
                    }
                }
                else{
                    completion(list)
                }
            } else {
                CommonMethods.showLog(self.TAG, "VALUE Document does not exist")
                completion(list)
            }
        }
    }
    
    typealias CommentPostSuccess = (CommentModel,String?) -> Void
    func commentPost(eventId:String,commentModel:CommentModel, completion: @escaping CommentPostSuccess) {
        
        let autoId = Endpoints.eventsFirestore.document(eventId).collection("event_comments").document().documentID
        CommonMethods.showLog(TAG, "commentPost autoID : \(autoId)")
        
        var model = commentModel
        model.commentId = autoId
        CommonMethods.showLog(TAG, "commentPost autoID : \(model.commentParameters)")
        Endpoints.eventsFirestore.document(eventId).collection("event_comments").document(autoId).setData(model.commentParameters) { error in
            if let error = error {
                print("Error adding document: \(error)")
                completion(model, error.localizedDescription)
            } else {
                print("Document added")
                completion(model, "")
            }
        }
    }
    
    typealias GetEventComments = ([CommentModel], String?) -> Void
    func getEventComments(_ eventId: String, completion: @escaping GetEventComments) {
        var commentList : [CommentModel] = []
        let dispatchGroup = DispatchGroup()
        let refrence = Endpoints.eventsFirestore.document(eventId).collection("event_comments")
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "getEventComments Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "getEventComments Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            var commentModel = try JSONDecoder().decode(CommentModel.self, from: data)
                            self.getUser(commentModel.userId ?? "") { (user, error) in
                                commentModel.userModel = user
                                commentList.append(commentModel)
                                dispatchGroup.leave()
                            }
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(commentList,"")
                    }
                }
                else{
                    completion(commentList,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "getEventComments Document does not exist")
                completion(commentList,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    typealias GetPastHostEventsSuccess = ([EventModel],String) -> Void
    func getPastHostEventFirestore(name : String,userId:String, completion: @escaping GetPastHostEventsSuccess){
        
        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let calendar = Calendar.current
        let currentDate = Date()
        let startOfCurrentDay = calendar.startOfDay(for: currentDate)
        let startOfCurrentDayTimestamp = startOfCurrentDay.timeIntervalSince1970
        let refrence = Endpoints.eventsFirestore.whereField("dateTimestamp", isLessThan: startOfCurrentDayTimestamp).whereField("userId", in: [userId])
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "getPastHostEventFirestore Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "getPastHostEventFirestore Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            eventModel.hostName = name
                            list.append(eventModel)
                            dispatchGroup.leave()
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list,"")
                    }
                }
                else{
                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "getPastHostEventFirestore Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    typealias GetUpcomingGuestEventsSuccess = ([EventModel],String) -> Void
    func getUpcomingGuestEventFirestore(userIds:[String],userId:String, completion: @escaping GetUpcomingGuestEventsSuccess){
        CommonMethods.showLog(self.TAG, "getUpcomingGuestEventFirestore")
        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let calendar = Calendar.current
        let currentDate = Date()
        let startOfCurrentDay = calendar.startOfDay(for: currentDate)
        let startOfCurrentDayTimestamp = startOfCurrentDay.timeIntervalSince1970
        let refrence = Endpoints.eventsFirestore.whereField("dateTimestamp", isGreaterThanOrEqualTo: startOfCurrentDayTimestamp).whereField("selectedMembers", arrayContains: userId)
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "getUpcomingGuestEventFirestore Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "getUpcomingGuestEventFirestore Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            self.getUser(eventModel.userId ?? "") { (user, error) in
                                let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
                                eventModel.hostName = name
                                list.append(eventModel)
                                dispatchGroup.leave()
                            }
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        if userIds.count > 0{
                            self.getUpcomingGuestEventVisibleToAllFirestore(userIds: userIds, userId: userId, completion: completion,list:list)
                        }
                        else{
                            completion(list,"")
                        }
                        //                        completion(list,"")
                    }
                }
                else{
                    if userIds.count > 0{
                        self.getUpcomingGuestEventVisibleToAllFirestore(userIds: userIds, userId: userId, completion: completion,list:list)
                    }
                    else{
                        completion(list,"")
                    }
                    //                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "getUpcomingGuestEventFirestore Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    typealias GetPastGuestEventsSuccess = ([EventModel],String) -> Void
    func getPastGuestEventFirestore(userIds:[String],userId:String, completion: @escaping GetPastGuestEventsSuccess){
        CommonMethods.showLog(self.TAG, "getPastGuestEventFirestore")
        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let calendar = Calendar.current
        let currentDate = Date()
        let startOfCurrentDay = calendar.startOfDay(for: currentDate)
        let startOfCurrentDayTimestamp = startOfCurrentDay.timeIntervalSince1970
        let refrence = Endpoints.eventsFirestore.whereField("dateTimestamp", isLessThan: startOfCurrentDayTimestamp).whereField("selectedMembers", arrayContains: userId)
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "getPastGuestEventFirestore Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "getPastGuestEventFirestore Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            self.getUser(eventModel.userId ?? "") { (user, error) in
                                let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
                                eventModel.hostName = name
                                list.append(eventModel)
                                dispatchGroup.leave()
                            }
                            
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        if userIds.count > 0{
                            self.getPastGuestEventVisibleToAllFirestore(userIds: userIds, userId: userId, completion: completion,list:list)
                        }
                        else{
                            completion(list,"")
                        }
                        //                        self.getPastGuestEventVisibleToAllFirestore(userIds: userIds, userId: userId, completion: completion,list:list)
                    }
                }
                else{
                    if userIds.count > 0{
                        self.getPastGuestEventVisibleToAllFirestore(userIds: userIds, userId: userId, completion: completion,list:list)
                    }
                    else{
                        completion(list,"")
                    }
                    //                    self.getPastGuestEventVisibleToAllFirestore(userIds: userIds, userId: userId, completion: completion,list:list)
                }
            } else {
                CommonMethods.showLog(self.TAG, "getPastGuestEventFirestore Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    //    typealias GetPastGuestEventsSuccess = ([EventModel],String) -> Void
    func getUpcomingGuestEventVisibleToAllFirestore(userIds:[String],userId:String, completion: @escaping GetPastGuestEventsSuccess,list:[EventModel]){
        CommonMethods.showLog(self.TAG, "UserIdsAre: \(userIds)")
        var list : [EventModel] = list
        //        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let refrence = Endpoints.eventsFirestore
        //            .whereField("dateTimestamp", isLessThan: Date().timeIntervalSince1970)
            .whereField("userId", in: userIds)
            .whereField("isVisibleToAllSelected", isEqualTo: true)
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "getUpcomingGuestEventVisibleToAllFirestore Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "getUpcomingGuestEventVisibleToAllFirestore Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            if eventModel.acceptedCoHostInvites?.count ?? 0 > 0{
                                if let acceptedCoHostInvites = eventModel.acceptedCoHostInvites,
                                   !acceptedCoHostInvites.contains(userId) {
                                    self.getUser(eventModel.userId ?? "") { (user, error) in
                                        let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
                                        eventModel.hostName = name
                                        if eventModel.dateTimestamp ?? 0.0 > Date().timeIntervalSince1970{
                                            CommonMethods.showLog(self.TAG, "List Count : \(list.count)")
                                            if list.contains(where: { $0.id == eventModel.id }){
                                                CommonMethods.showLog(self.TAG, "Already Hai List ch ")
                                            }
                                            else{
                                                list.append(eventModel)
                                            }
                                            //                                   list.append(eventModel)
                                            dispatchGroup.leave()
                                        }
                                        else{
                                            dispatchGroup.leave()
                                        }
                                    }
                                }
                                else{
                                    dispatchGroup.leave()
                                }
                            }
                            else{
                                self.getUser(eventModel.userId ?? "") { (user, error) in
                                    let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
                                    eventModel.hostName = name
                                    if eventModel.dateTimestamp ?? 0.0 > Date().timeIntervalSince1970{
                                        CommonMethods.showLog(self.TAG, "List Count : \(list.count)")
                                        if list.contains(where: { $0.id == eventModel.id }){
                                            CommonMethods.showLog(self.TAG, "Already Hai List ch ")
                                        }
                                        else{
                                            list.append(eventModel)
                                        }
                                        //                                    list.append(eventModel)
                                        dispatchGroup.leave()
                                    }
                                    else{
                                        dispatchGroup.leave()
                                    }
                                }
                            }
                            
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            dispatchGroup.leave()
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        CommonMethods.showLog(self.TAG, "List is: \(list)")
                        completion(list,"")
                    }
                }
                else{
                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "getUpcomingGuestEventVisibleToAllFirestore Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    func getPastGuestEventVisibleToAllFirestore(userIds:[String],userId:String, completion: @escaping GetPastGuestEventsSuccess,list:[EventModel]){
        CommonMethods.showLog(self.TAG, "getPastGuestEventVisibleToAllFirestore")
        var list : [EventModel] = list
        //        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let refrence = Endpoints.eventsFirestore
        //            .whereField("dateTimestamp", isLessThan: Date().timeIntervalSince1970)
            .whereField("userId", in: userIds)
            .whereField("isVisibleToAllSelected", isEqualTo: true)
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "getUpcomingGuestEventVisibleToAllFirestore Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "getUpcomingGuestEventVisibleToAllFirestore Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            if eventModel.acceptedCoHostInvites?.count ?? 0 > 0{
                                if let acceptedCoHostInvites = eventModel.acceptedCoHostInvites,
                                   !acceptedCoHostInvites.contains(userId) {
                                    self.getUser(eventModel.userId ?? "") { (user, error) in
                                        let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
                                        eventModel.hostName = name
                                        if eventModel.dateTimestamp ?? 0.0 < Date().timeIntervalSince1970{
                                            CommonMethods.showLog(self.TAG, "List Count : \(list.count)")
                                            if list.contains(where: { $0.id == eventModel.id }){
                                                CommonMethods.showLog(self.TAG, "Already Hai List ch ")
                                            }
                                            else{
                                                list.append(eventModel)
                                            }
                                            //                                   list.append(eventModel)
                                            dispatchGroup.leave()
                                        }
                                        else{
                                            dispatchGroup.leave()
                                        }
                                    }
                                }
                                else{
                                    dispatchGroup.leave()
                                }
                            }
                            else{
                                self.getUser(eventModel.userId ?? "") { (user, error) in
                                    let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
                                    eventModel.hostName = name
                                    if eventModel.dateTimestamp ?? 0.0 < Date().timeIntervalSince1970{
                                        CommonMethods.showLog(self.TAG, "List Count : \(list.count)")
                                        if list.contains(where: { $0.id == eventModel.id }){
                                            CommonMethods.showLog(self.TAG, "Already Hai List ch ")
                                        }
                                        else{
                                            list.append(eventModel)
                                        }
                                        //                                    list.append(eventModel)
                                        dispatchGroup.leave()
                                    }
                                    else{
                                        dispatchGroup.leave()
                                    }
                                }
                            }
//                            self.getUser(eventModel.userId ?? "") { (user, error) in
//                                let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
//                                eventModel.hostName = name
//                                if eventModel.dateTimestamp ?? 0.0 < Date().timeIntervalSince1970{
//                                    list.append(eventModel)
//                                    dispatchGroup.leave()
//                                }
//                                else{
//                                    dispatchGroup.leave()
//                                }
//                            }
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list,"")
                    }
                }
                else{
                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "getUpcomingGuestEventVisibleToAllFirestore Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    
    typealias GetGuestListSuccess = ([UserModel]) -> Void
    func getGuestListFirestore(userIds:[String],completion: @escaping GetGuestListSuccess){
        CommonMethods.showLog(self.TAG, "userIds are: \(userIds)")
        var list : [UserModel] = []
        let dispatchGroup = DispatchGroup()
        if userIds.count > 0{
            userIds.forEach{ id in
                dispatchGroup.enter()
                self.getUser(id) { (user, error) in
                    var isExist = false
                    if list.count > 0{
                        CommonMethods.showLog(self.TAG, "getGuestListFirestore If ")
                        list.forEach{ data in
                            if data.id == user?.id {
                                isExist = true
                            }
                        }
                        
                        if !isExist{
                            list.append(user ?? UserModel())
                            dispatchGroup.leave()
                        }
                        else{
                            dispatchGroup.leave()
                        }
                    }
                    else{
                        CommonMethods.showLog(self.TAG, "getGuestListFirestore Else")
                        list.append(user ?? UserModel())
                        dispatchGroup.leave()
                    }
                    
                }
            }
            
            dispatchGroup.notify(queue: .main) {
                CommonMethods.showLog(self.TAG, "Group Notify")
                completion(list)
            }
        }
        else{
            completion(list)
        }
    }
    
    typealias GetAllEventsSuccess = ([EventModel],String) -> Void
    func getAllEventFirestore(userId:String, completion: @escaping GetAllEventsSuccess){
        var list : [EventModel] = []
        let dispatchGroup = DispatchGroup()
        let refrence = Endpoints.eventsFirestore.whereField("dateTimestamp", isGreaterThan: Date().timeIntervalSince1970).whereField("userId", notIn: [userId])
        refrence.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                CommonMethods.showLog(self.TAG, "VALUE Document Data: \(document.documents.count)")
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        CommonMethods.showLog(self.TAG, "VALUE Document Inner Data: \(document.documentID) => \(document.data())")
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                            self.getUser(eventModel.userId ?? "") { (user, error) in
                                let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
                                eventModel.hostName = name
                                list.append(eventModel)
                                dispatchGroup.leave()
                            }
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion(list,"")
                    }
                }
                else{
                    completion(list,"")
                }
            } else {
                CommonMethods.showLog(self.TAG, "VALUE Document does not exist")
                completion(list,Constants.COMMON_ERROR_MESSAGE)
            }
        }
    }
    
    
    //MARK: - Event Memories Methods here
    
    ///Method to create an event memory and upload to firestore event inner collection
    typealias CreateEventMemoryCompletion = (Error?, EventMemoryModel) -> Void
    func createEventMemoryFirestore(eventId: String, eventMemoryModel : EventMemoryModel, completion: @escaping CreateEventMemoryCompletion) {
        let ref = Endpoints.eventsFirestore.document(eventId).collection("event_memories")
        let autoId = ref.document().documentID
        let model = eventMemoryModel
        model.id = autoId
        ref.document(autoId).setData(eventMemoryModel.createEventMemoryParameters) { error in
            if let error = error {
                print("Error adding document: \(error)")
            } else {
                print("Document added")
            }
            completion(error, model)
        }
    }
    
    ///Method to get all event memories of their respective event using the event id.
    typealias GetEventMemoriesSuccess = ([EventMemoryModel]) -> Void
    func getEventMemoriesFirestore(eventId: String, completion: @escaping GetEventMemoriesSuccess) {
        CommonMethods.showLog(TAG, "VALUE getPastGuestEvents")
        let ref = Endpoints.eventsFirestore.document(eventId).collection("event_memories")
        //start
        var list : [EventMemoryModel] = []
        let dispatchGroup = DispatchGroup()
        ref.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let model = try JSONDecoder().decode(EventMemoryModel.self, from: data)
                            list.append(model)
                            dispatchGroup.leave()
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error")
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        completion(list)
                    }
                }
                else{
                    completion(list)
                }
            } else {
                completion(list)
            }
        }
    }
    
    typealias FetchEventCompletion = (Error?, EventModel?) -> Void
    func fetchEventFirestore(eventID: String, completion: @escaping FetchEventCompletion) {
        Endpoints.eventsFirestore.document(eventID).getDocument { snapshot, error in
            if let error = error {
                print("Error fetching document: \(error)")
                completion(error, nil)
            }else if let document = snapshot, document.exists {
                do {
                    let data = try JSONSerialization.data(withJSONObject: document.data() as Any, options: .prettyPrinted)
                    let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                    completion(nil, eventModel)
                } catch {
                    CommonMethods.showLog(self.TAG, "Error")
                }
            }
        }

    }
    
    func getEventDataWithId(eventID: String, completion: @escaping FetchEventCompletion) {
        Endpoints.eventsFirestore.document(eventID).getDocument { snapshot, error in
            if let error = error {
                print("Error fetching document: \(error)")
                completion(error, nil)
            }else if let document = snapshot, document.exists {
                do {
                    let data = try JSONSerialization.data(withJSONObject: document.data() as Any, options: .prettyPrinted)
                    let eventModel = try JSONDecoder().decode(EventModel.self, from: data)
                    self.getUser(eventModel.userId ?? "") { (user, error) in
                        let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
                        eventModel.hostName = name
                        self.getEventDatePollList(eventModel:eventModel){ datePollList in
                            eventModel.datePollList = datePollList
                            self.getEventLocationPollList(eventModel:eventModel){ locationList in
                                eventModel.locationList = locationList
                                completion(nil, eventModel)
                            }
                        }
                    }
                    
                } catch {
                    CommonMethods.showLog(self.TAG, "Error")
                }
            }
        }

    }

    ///Method to get all event memories of their respective event using the event id.
    typealias GetNotificationsSuccess = ([NotificationModel]) -> Void
    
    func getNotificationsFirestore(_ userId: String, completion: @escaping GetNotificationsSuccess){
        let ref = Endpoints.notificationsFirestore.document(userId).collection("notificationsList")
        var list : [NotificationModel] = []
        let dispatchGroup = DispatchGroup()
        ref.getDocuments() { (snapshot,error) in
            if let document = snapshot {
                if document.documents.count > 0{
                    for document in document.documents {
                        dispatchGroup.enter()
                        do {
                            let data = try JSONSerialization.data(withJSONObject: document.data(), options: .prettyPrinted)
                            let model = try JSONDecoder().decode(NotificationModel.self, from: data)
                            FirebaseAPI.default.getUser(model.info?.userId ?? "") { user, error in
                                if let user = user, error == nil {
                                    CommonMethods.showLog(self.TAG, "innerCode")
                                    if let type = model.type {
                                        if type == Constants.FRIEND_REQUEST_SENT {
                                            if let lastName = user.lastName {
                                                if lastName.trimAndCheckIsEmpty() {
                                                    model.info?.message = "You have new friend request from \(user.firstName ?? "")!"
                                                }else {
                                                    model.info?.message = "You have new friend request from \(user.firstName ?? "")\(user.lastName ?? "")!"
                                                }
                                            }else {
                                                model.info?.message = "You have new friend request from \(user.firstName ?? "")!"
                                            }
//                                            model.info?.message = "You have new friend request from \(user.firstName ?? "")\(user.lastName ?? "")!"
                                            model.info?.userImage = user.imageUrl ?? ""
                                        }else if type == Constants.FRIEND_REQUEST_ACCEPTED {
                                            if let lastName = user.lastName {
                                                if lastName.trimAndCheckIsEmpty() {
                                                    model.info?.message = "\(user.firstName ?? "") has accepted your friend request!"
                                                }else {
                                                    model.info?.message = "\(user.firstName ?? "") \(user.lastName ?? "") has accepted your friend request!"
                                                }
                                            }else {
                                                model.info?.message = "\(user.firstName ?? "") has accepted your friend request!"
                                            }
//                                            model.info?.message = "\(user.firstName ?? "") \(user.lastName ?? "") has accepted your friend request!"
                                            model.info?.userImage = user.imageUrl ?? ""
                                        }else if type == Constants.EVENT_CREATED || type == Constants.EVENT_UPDATED {
                                            model.info?.userImage = user.imageUrl ?? ""
                                        }
                                        
                                    }
                                    list.append(model)
                                }
                                dispatchGroup.leave()
                            }
                            CommonMethods.showLog(self.TAG, "outerCode")
//                            list.append(model)
//                            dispatchGroup.leave()
                        } catch {
                            CommonMethods.showLog(self.TAG, "Error Fetching Notifications: \(error.localizedDescription)")
                            
                            continue
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        completion(list)
                    }
                }
                else{
                    completion(list)
                }
            } else {
                completion(list)
            }
        }
    }
    
    typealias EditNotificationSuccess = (Bool, Error?)->Void
    func EditNotification(_ userId: String, notificationId: String, info: Info? = nil, type: String = "", completion: @escaping EditNotificationSuccess){
        let ref = Endpoints.notificationsFirestore.document(userId).collection("notificationsList").document(notificationId)
        if info != nil {
            print("TYPE_IS: \(type)")
            ref.updateData([
                "status": 1,
                "info": info?.infoParameters, 
                "type": type
            ]) { error in
                if let error = error {
                    completion(false, error)
                }else {
                    completion(true, nil)
                }
            }
        }else {
            ref.updateData([
                "status": 1
            ]) { error in
                if let error = error {
                    completion(false, error)
                }else {
                    completion(true, nil)
                }
            }
        }
        
    }
    
    
    func removeFromSelectedCrowds(_ eventId: String, crowdId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["selectedCrowds": FieldValue.arrayRemove([crowdId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func removeFromSelectedMembers(_ eventId: String, memberId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["selectedMembers": FieldValue.arrayRemove([memberId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }
    
    func removeFromGoingList(_ eventId: String, memberId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["goingList": FieldValue.arrayRemove([memberId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
    }
    
    func acceptCoHostInvitation(_ eventId: String, userId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        
        ref.updateData(["acceptedCoHostInvites": FieldValue.arrayUnion([userId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                ref.updateData(["pendingCoHostInvites": FieldValue.arrayRemove([userId])]){error in
                    if let error = error {
                        completion(false, error)
                    }else {
                        ref.updateData(["selectedMembers": FieldValue.arrayRemove([userId])]){error in
                            if let error = error {
                                completion(false, error)
                            }else {
                                ref.updateData(["goingList": FieldValue.arrayRemove([userId])]){error in
                                    if let error = error {
                                        completion(false, error)
                                    }else {
                                        completion(true, nil)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    func declineCoHostInvitation(_ eventId: String, userId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId)
        ref.updateData(["pendingCoHostInvites": FieldValue.arrayRemove([userId])]){error in
            if let error = error {
                completion(false, error)
            }else {
                ref.updateData(["acceptedCoHostInvites": FieldValue.arrayRemove([userId])]){error in
                    if let error = error {
                        completion(false, error)
                    }else {
                        completion(true, nil)
                    }
                }
            }
        }
    }
    
    func removeVoteOfMembers(_ eventId: String, locationId: String, memberId: String, completion: @escaping (Bool, Error?)->Void){
        let ref = Endpoints.eventsFirestore.document(eventId).collection("locationPollList").document(locationId)
        
        ref.updateData(["userList": FieldValue.arrayRemove([memberId])]) { error in
            if let error = error {
                completion(false, error)
            }else {
                completion(true, nil)
            }
        }
        
    }

}

