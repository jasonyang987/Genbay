//
//  AdminHomeViewModel.swift
//  TruthAlibi
//
//  Created by Nap Works on 15/02/23.
//

import Foundation



final class HomeViewModel{
    let TAG = String(describing: HomeViewModel.self)
    var vc : HomeVC
    
    init(vc: HomeVC) {
        self.vc = vc
    }
    
    func getNotifications(_ userId: String, completion: @escaping ([NotificationModel])->Void){
        FirebaseAPI.default.getNotificationsFirestore(userId) {[self] notifications in
            let list = notifications.sorted{Double($0.info?.timeStamp ?? "") ?? 0 > Double($1.info?.timeStamp ?? "") ?? 0}
            completion(list)
        }
    }
    
    func readNotification(_ userId: String, notificationId: String, info: Info? = nil, type: String = "", completion: @escaping (Bool)->Void){
        self.vc.showProgressHUD()
        FirebaseAPI.default.EditNotification(userId, notificationId: notificationId, info: info, type: type) {[self] success, error in
            if success, error == nil {
                self.vc.hideProgressHUD()
                completion(true)
            }else {
                self.vc.hideProgressHUD()
                self.vc.showDialog(title: Constants.APP_NAME, message: "Some Error Occurred")
                completion(false)
            }
        }
    }
    
    func searchOrder(){
        
//        vc.showProgressHUD()
//        CommonWebServices.getAssignOrdersList(email: vc.searchText.text!) { status, message,email, data in
//            self.vc.hideProgressHUD()
//            if status == Constants.SUCCESS {
//                self.vc.tableView.isHidden = false
//                self.vc.dataList = data
//                self.vc.email = email
//                self.vc.tableView.reloadData()
//                CommonMethods.showLog(self.TAG, "Home List Count : \(data.count)")
//                //                    AppDelegate.shared.mainNavController?.popToRootViewController(animated: false)
//            }
//            else if status == Constants.SESSION_OUT{
//                self.vc.showDialog(title : Constants.APP_NAME, message: message,hideDialog:{
//                    CommonMethods.sessionOut()
//                })
//            }
//            else {
//                self.vc.showDialog(title : Constants.APP_NAME, message: message)
//            }
//        }
    }
}
