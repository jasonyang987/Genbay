//
//  MemoryImageVC.swift
//  Genbay
//
//  Created by Nap Works on 01/05/23.
//

import UIKit
import Kingfisher

protocol MemoryImageVCDelegate: AnyObject {
    func removeImageAndVC(_ index: Int?)
}

class MemoryImageVC: UIViewController {
    let TAG = String(describing: MemoryImageVC.self)
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var deleteBtnView: UIView!
    static var delegate: MemoryImageVCDelegate?
    var images: [UIImage] = []
    var imageStrings: [String] = []
    var index: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if images.count > 0 {
            deleteBtnView.isHidden = false
            imageView.contentMode = .scaleAspectFill
            CommonMethods.showLog(self.TAG, "images: \(images)")
            self.imageView.image = images[index]
        }else {
            deleteBtnView.isHidden = true
            imageView.contentMode = .scaleAspectFit
            CommonMethods.showLog(self.TAG, "imageStrings: \(imageStrings)")
            imageView.kf.setImage(with: URL(string: imageStrings[index]),placeholder: UIImage(named: "cameraPlaceholder"), options: [.cacheOriginalImage])
        }
        
    }
    
    @IBAction func deleteBtnPressed(_ sender: UIButton){
//        images.remove(at: index)
        MemoryImageVC.delegate?.removeImageAndVC(index)
    }
    
    static func getInstance(index: Int, images: [UIImage]? = nil, imageStrings: [String]? = nil) -> MemoryImageVC {
        let vc = UIStoryboard(name: "Common", bundle: nil).instantiateViewController(withIdentifier: "MemoryImageVC") as! MemoryImageVC
        vc.index = index
        if let images = images {
            vc.images = images
        }
        if let imageStrings = imageStrings {
            vc.imageStrings = imageStrings
        }
        return vc
    }
    
}
