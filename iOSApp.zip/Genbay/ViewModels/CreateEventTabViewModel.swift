//
//  CreateEventTabViewModel.swift
//  Genbay
//
//  Created by Nap Works on 10/04/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class CreateEventTabViewModel{
    let TAG = String(describing: CreateEventTabViewModel.self)
    var vc : CreateEventTabVC
    
    init(vc: CreateEventTabVC) {
        self.vc = vc
    }
    
    
    func validate() throws {
        
        if let name = vc.eventNameText.text {
            if name.trimAndCheckIsEmpty() {
                throw ValidationError.nameEmpty
            }
        } else {
            throw ValidationError.nameEmpty
        }
        
        if self.vc.selectedCrowdList.count == 0 && !(self.vc.isVisibleToAllSelected ?? false) && self.vc.selectedMembersList.count == 0 {
            throw ValidationError.crowdSelectionEmpty
        }
        
        if self.vc.startTimeTimeStamp == 0.0 {
            throw ValidationError.startTimeEmpty
        }
        
        if self.vc.dateTimestamp == 0.0 && self.vc.datePollList.count == 0{
                throw ValidationError.dateEmpty
        }
        
//        
//        if self.vc.datePollList.count > 0 && self.vc.datePollDeadlineTimestamp == 0.0{
//            throw ValidationError.pollDateEmpty
//        }
//        

        if let desc = vc.eventDescriptionText.text {
            if desc == "" || desc == "Event Description"{
                throw ValidationError.descEmpty
            }
        } else {
            throw ValidationError.descEmpty
        }
        
    }
        
        // MARK: - Enums
        enum ValidationError: Error {
            case nameEmpty
            case crowdSelectionEmpty
            case startTimeEmpty
            case dateEmpty
            case pollDateEmpty
            case descEmpty
            
            var localizedDescription: String {
                switch self {
                case .nameEmpty:
                    return "Please enter event name."
                case .crowdSelectionEmpty:
                    return "Choose crowds visible to or visible to all friends or add individual friends."
                case .startTimeEmpty:
                    return "Please choose start time."
                case .dateEmpty:
                    return "Please choose date."
                case .pollDateEmpty:
                    return "Please choose poll deadline date."
                case .descEmpty:
                    return "Please enter event description."
                }
            }
        }
    
    func getCrowds(){
        self.vc.showProgressHUD()
        FirebaseAPI.default.getCrowdsWithMembers(userId: self.vc.userData?.id ?? ""){ list in
            self.vc.hideProgressHUD()
            self.vc.mainView.isHidden = false
            self.vc.crowdList = []
            self.vc.crowdList = list ?? []
            if self.vc.calledFrom != Constants.EDIT_EVENT{
                self.resetData()
            }
            else{
                self.vc.setUI()
            }
        }
    }
    
    func createEvent(){
        self.vc.showProgressHUD()
        
        var dateTimestamp = 0.0,date = "" , isDateSelected = false,isDateConfirmed = false, isLocationSelected=false, locationText : String = "",isLocationConfirmed = false
        
        if self.vc.dateTimestamp == 0.0{
            if self.vc.datePollList.count > 0{
                date = self.vc.datePollList[0].date ?? ""
                dateTimestamp = CommonMethods.getFullDateFromString(dateString: date).timeIntervalSince1970
                isDateSelected = true
            }
        }
        else{
            isDateSelected = true
            isDateConfirmed = true
            date = self.vc.dateText.text ?? ""
            dateTimestamp = self.vc.dateTimestamp
        }
        
        if self.vc.locationText.text == ""{
            if self.vc.locationList.count > 0{
                locationText = self.vc.locationList[0].location ?? ""
                isLocationSelected = true
            }
        }
        else{
            isLocationSelected = true
            locationText = self.vc.locationText.text ?? ""
            isLocationConfirmed = true
        }
        
        if isDateSelected{
            let autoId = FirebaseAPI.Endpoints.eventsFirestore.document().documentID
            let eventModel = EventModel()
            eventModel.id = autoId
            eventModel.userId = self.vc.userData?.id ?? ""
            eventModel.name = self.vc.eventNameText.text
            eventModel.selectedCrowds = self.vc.selectedCrowdList
            eventModel.selectedMembers = self.vc.selectedMembersList
            eventModel.pendingCoHostInvites = self.vc.inviteFriends
            eventModel.createdAt = Date().timeIntervalSince1970
            eventModel.updatedAt = Date().timeIntervalSince1970
            eventModel.startTime = self.vc.startTimeText.text
            eventModel.startTimestamp = self.vc.startTimeTimeStamp
            eventModel.pollVotingDeadlineTime = self.vc.pollVotingDeadlineText.text
            eventModel.pollVotingDeadlineTimestamp = self.vc.datePollDeadlineTimestamp
            eventModel.date = date
            eventModel.dateTimestamp = dateTimestamp
            eventModel.isDateConfirmed = isDateConfirmed
            eventModel.datePollList = self.vc.datePollList
            eventModel.locationList = self.vc.locationList
            eventModel.location = locationText
            eventModel.isLocationConfirmed = isLocationConfirmed
            eventModel.isVisibleToAllSelected = self.vc.isVisibleToAllSelected
            eventModel.description = self.vc.eventDescriptionText.text
            eventModel.isDatePollCreated = self.vc.datePollList.count == 0 ? false : true
            eventModel.isLocationPollCreated = self.vc.locationList.count == 0 ? false : true
            
            CommonWebServices.createNewEventFirestore(eventModel: eventModel
//                                                      ,selectedMembers: "",selectedCrowds: "",acceptedCoHostInvites: "",goingList: "",pendingCoHostInvites: ""
            ) { status, message, model in
                self.vc.hideProgressHUD()
                if status == Constants.SUCCESS {
                    FirebaseAPI.default.createDatePollInEvent(eventModel: eventModel){error,model in
                        if error != nil{
                            if let error = error{
                                self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
                            }else{
                                self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                            }
                        }
                        else{
                            CommonMethods.showLog(self.TAG, "Event Created Succesfully")
                            self.resetData()
                            Navigations.goToEvents(navigationController: self.vc.navigationController,calledFrom: Constants.VIEW_EVENT)
                        }
                    }
                }else if status == Constants.FAILURE {
                    self.vc.showDialog(title : Constants.APP_NAME, message: message)
                }
            }
            
//            FirebaseAPI.default.createNewEventFirestore(eventModel: eventModel){error,model in
//                self.vc.hideProgressHUD()
//                if error != nil{
//                    if let error = error{
//                        self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
//                    }else{
//                        self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
//                    }
//                }
//                else{
//                    CommonMethods.showLog(self.TAG, "Event Created Succesfully")
//                    self.resetData()
//                    Navigations.goToEvents(navigationController: self.vc.navigationController,calledFrom: Constants.VIEW_EVENT)
//                    //                NotifyData.notifyCrowdVC(crowdModel: crowdModel)
//                    //                CommonMethods.dismiss(vc: self.vc,animated: true)
//                    //                Navigations.goToCrowdDetail(navigationController: self.vc.navigationController,crowdId  :crowdModel.id ?? "")
//                }
//
//            }
        }
        else{
            self.vc.showDialog(title:Constants.APP_NAME,message: "It seems like that you haven't selected date or not created any date poll list for your event.")
        }
    }
    
    func editEvent(){
        self.vc.showProgressHUD()
        
        var dateTimestamp = 0.0,date = "" , isDateSelected = false,isDateConfirmed = false, isLocationSelected=false, locationText : String = "",isLocationConfirmed = false
        
        if self.vc.dateTimestamp == 0.0{
            if self.vc.datePollList.count > 0{
                date = self.vc.datePollList[0].date ?? ""
                dateTimestamp = CommonMethods.getFullDateFromString(dateString: date).timeIntervalSince1970
                isDateSelected = true
            }
        }
        else{
            isDateSelected = true
            isDateConfirmed = true
            date = self.vc.dateText.text ?? ""
            dateTimestamp = self.vc.dateTimestamp
        }
        
        if self.vc.locationText.text == ""{
            if self.vc.locationList.count > 0{
                locationText = self.vc.locationList[0].location ?? ""
//              locationModel = self.vc.locationList[0]
                isLocationSelected = true
            }
        }
        else{
            isLocationSelected = true
            locationText = self.vc.locationText.text ?? ""
            isLocationConfirmed = true  
//          locationModel = self.vc.locationModel ?? Location()
        }
        
        if isDateSelected{
            let eventModel = self.vc.eventModel
            eventModel?.id = self.vc.eventModel?.id ?? ""
            eventModel?.userId = self.vc.eventModel?.userId ?? ""
            eventModel?.name = self.vc.eventNameText.text
            eventModel?.selectedCrowds = self.vc.selectedCrowdList
            eventModel?.selectedMembers = self.vc.selectedMembersList
            eventModel?.pendingCoHostInvites = self.vc.inviteFriends
            eventModel?.startTime = self.vc.startTimeText.text
            eventModel?.startTimestamp = self.vc.startTimeTimeStamp
            eventModel?.pollVotingDeadlineTime = self.vc.pollVotingDeadlineText.text
            eventModel?.pollVotingDeadlineTimestamp = self.vc.datePollDeadlineTimestamp
            eventModel?.date = date
            eventModel?.dateTimestamp = dateTimestamp
            eventModel?.isDateConfirmed = isDateConfirmed
            eventModel?.datePollList = self.vc.datePollList
            eventModel?.locationList = self.vc.locationList
            eventModel?.location = locationText
            eventModel?.isLocationConfirmed = isLocationConfirmed
            eventModel?.isVisibleToAllSelected = self.vc.isVisibleToAllSelected
            eventModel?.description = self.vc.eventDescriptionText.text
            
            eventModel?.isDatePollCreated = self.vc.datePollList.count == 0 ? false : true
            eventModel?.isLocationPollCreated = self.vc.locationList.count == 0 ? false : true
            
            if let eventModel = eventModel{
                CommonWebServices.editEventFirestore(eventModel: eventModel
                ) { status, message, model in
                    self.vc.hideProgressHUD()
                    if status == Constants.SUCCESS {
                        CommonMethods.showLog(self.TAG, "Event Edited Succesfully1")
                        FirebaseAPI.default.createDatePollInEvent(eventModel: eventModel){error,model in
                            if error != nil{
                                if let error = error{
                                    self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
                                }else{
                                    self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                                }
                            }
                            else{
                                CommonMethods.showLog(self.TAG, "Event Edited Succesfully")
                                NotifyData.notifyEventVC(type:Constants.UPDATE_EVENT,eventModel: eventModel)
                                CommonMethods.dismiss(vc: self.vc)
                            }
                        }
                    }else if status == Constants.FAILURE {
                        self.vc.showDialog(title : Constants.APP_NAME, message: message)
                    }
                }
            }
            
            
            
            
//            FirebaseAPI.default.editEventFirestore(eventModel: eventModel ?? EventModel()){error,model in
//                self.vc.hideProgressHUD()
//                if error != nil{
//                    if let error = error{
//                        self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
//                    }else{
//                        self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
//                    }
//                }
//                else{
//                    CommonMethods.showLog(self.TAG, "Event Edited Succesfully")
////                    self.resetData()
//                    NotifyData.notifyEventVC(type:Constants.UPDATE_EVENT,eventModel: eventModel ?? EventModel())
//                    CommonMethods.dismiss(vc: self.vc)
//                }
//            }
        }
        else{
            self.vc.showDialog(title:Constants.APP_NAME,message: "It seems like that you haven't selected date or not created any date poll list for your event.")
        }
    }
    
    func deleteEvent(){
        self.vc.showProgressHUD()
        FirebaseAPI.default.deleteEventFirestore(eventModel: self.vc.eventModel ?? EventModel()){error,model in
            self.vc.hideProgressHUD()
            if error != nil{
                if let error = error{
                    self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
                }else{
                    self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                }
            }
            else{
                CommonMethods.showLog(self.TAG, "Event Deleted Succesfully")
                NotifyData.notifyEventVC(type: Constants.DELETE_EVENT,eventModel: self.vc.eventModel ?? EventModel())
                CommonMethods.dismiss(vc: self.vc)
            }
        }
    }
    
    func resetData(){
        self.vc.eventNameText.text = ""
        self.vc.startTimeText.text = ""
        self.vc.dateText.text = ""
        self.vc.locationText.text = ""
        self.vc.eventDescriptionText.textColor = .darkGray
        self.vc.eventDescriptionText.text = "Event Description"
        self.vc.pollVotingDeadlineText.text = ""
        
        self.vc.startTimeTimeStamp = 0.0
        self.vc.datePollDeadlineTimestamp = 0.0
        self.vc.dateTimestamp = 0.0
        self.vc.locationList = []
        self.vc.datePollList = []
        self.vc.setDatePollUI()
        self.vc.setLocationPollUI()
        self.vc.setPollingDeadlineUI()
        
        self.vc.crowdList.forEach{ data in
            data.isSelected = false
        }
        
        self.vc.spinnerText.text = ""

    }
}
