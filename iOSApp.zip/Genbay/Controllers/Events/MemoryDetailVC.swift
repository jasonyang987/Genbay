//
//  MemoryDetailVC.swift
//  Genbay
//
//  Created by Nap Works on 17/04/23.
//

import UIKit
import Kingfisher

class MemoryDetailVC: BaseViewController, MemoryPVCDelegate {
    let TAG = String(describing: MemoryDetailVC.self)
    @IBOutlet weak var descriptionText: UILabel!
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var pagerView: UIView!
    @IBOutlet weak var leftBtn: UIButton!
    @IBOutlet weak var rightBtn: UIButton!
    @IBOutlet weak var placeholderImageView: UIImageView!
    @IBOutlet weak var rightBtnView: UIView!
    @IBOutlet weak var leftBtnView: UIView!
    var pageVC: MemoryPVC?
    var currentIndex: Int = 0
    var eventMemoryModel: EventMemoryModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUI()
        
        self.setupPageViewController()
        
    }
    
    //MARK: - This is a delegate method which is defined in MemoryImageVC and used to handle the conditions after deleting the image from the list of images. The main conditions are handled in MemoryPVC. here Only the current index is being handled.
    func setCurrentIndex(_ index: Int?) {
        if let index = index {
            CommonMethods.showLog(self.TAG, "index: \(index)")
            currentIndex = index
        }else {
            placeholderImageView.isHidden = false
        }
    }
    
    
    func setupPageViewController() {
        for view in self.pagerView.subviews {
            view.removeFromSuperview()
        }

        DispatchQueue.main.async {
            self.pageVC = MemoryPVC()
            self.pageVC?.indexDelegate = self
            if let images = self.eventMemoryModel?.images {
                self.pageVC?.setMemoryImages(images, direction: .forward)
            }
            let frame = self.pagerView.frame
            CommonMethods.showLog(self.TAG, "frame width : \(frame.width)")
            CommonMethods.showLog(self.TAG, "frame height : \(frame.height)")
            CommonMethods.showLog(self.TAG, "frame size : \(frame.size)")
            CommonMethods.showLog(self.TAG, "frame origin : \(frame.origin)")
            self.pageVC?.view.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.height)
            if let pageVC = self.pageVC{
                self.addChild(pageVC)
                self.pagerView.addSubview(pageVC.view)
                pageVC.didMove(toParent: self)
            }
        }
    }
    
    func setUI(){
        placeholderImageView.isHidden = true
        if let desc = eventMemoryModel?.description {
            if desc == ""{
                descriptionView.isHidden = true
            }else {
                descriptionView.isHidden = false
                CommonMethods.roundCornerFilled(uiView: descriptionView, borderColor: .black, backgroundColor: .white, cornerRadius: 0.0, borderWidth: 1.1)
                descriptionText.text = desc
            }
        }
        
        if eventMemoryModel?.images?.count ?? 0 > 1{
            leftBtnView.isHidden = false
            rightBtnView.isHidden = false
        }
        else{
            leftBtnView.isHidden = true
            rightBtnView.isHidden = true
        }
        
    }
    
    @IBAction func backBtnPressed(_ sender: UIButton){
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func leftBtnPressed(_ sender: UIButton){
        if let images = eventMemoryModel?.images {
            if currentIndex > 0 {
                currentIndex -= 1
                CommonMethods.showLog(self.TAG, "currentIndexLeft: \(currentIndex)")
                pageVC?.changePage(direction: .reverse, posiiton: currentIndex, imageStrings: images)
                if currentIndex == 0 {
                    CommonMethods.showLog(self.TAG, "zero")
                    return
                }
            } else {
                currentIndex = images.count - 1
                pageVC?.changePage(direction: .reverse, posiiton: currentIndex, imageStrings: images)
                CommonMethods.showLog(self.TAG, "can't do this")
                return
            }
        }

    }
    
    @IBAction func rightBtnPressed(_ sender: UIButton){
        if let images = eventMemoryModel?.images {
            if images.count > 1 {
                if currentIndex < images.count - 1 {
                    currentIndex+=1
                    CommonMethods.showLog(self.TAG, "currentIndex Right: \(currentIndex)")
                    pageVC?.changePage(direction: .forward, posiiton: currentIndex, imageStrings: images)
                    if currentIndex == images.count - 1 {
                        CommonMethods.showLog(self.TAG, "reached")
                        return
                    }
                } else {
                    currentIndex = 0
                    pageVC?.changePage(direction: .forward, posiiton: currentIndex, imageStrings: images)
                    return
                }
            }
        }
    }

}
