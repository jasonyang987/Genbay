//
//  GroupTabVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit
class FriendsTabVC: BaseViewController, SearchOptionPressedDelegate,UITextFieldDelegate, ShowInstructionsVCDelegate {
    
    
    let TAG = String(describing: FriendsTabVC.self)
    
    @IBOutlet weak var searchUsernameText: UITextField!
    @IBOutlet weak var searchNameText: UITextField!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchUserNameBtnView: UIView!
    @IBOutlet weak var searchNameBtnView: UIView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var noUserText: UILabel!
    @IBOutlet weak var friendsBtn: UIButton!
    @IBOutlet weak var crowdsBtn: UIButton!
    
    var usersList : [UserModel] = []
    var searchedUserList : [UserModel] = []
    var serverUsersList : [UserModel] = []
    var userData:UserModel?
    var viewModel:FriendsTabViewModel?
    @IBOutlet weak var tapToContinueLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = FriendsTabViewModel(vc: self)
        
        noUserText.isHidden = true
        userData = UserDefaultsMapper.getUser()
        searchUsernameText.delegate = self
        searchNameText.delegate = self
        searchUsernameText.autocorrectionType = .no
        searchNameText.autocorrectionType = .no
        searchNameText.autocapitalizationType = .none
        searchUsernameText.autocapitalizationType = .none
        
        setUI()
        
        CommonMethods.setPlaceholderColor(textFields: [searchUsernameText, searchNameText], color: .darkGray)
    }
    
    @objc func frienRequestAction(_ notification: NSNotification){
//        getAllUsers()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        mainView.isHidden = true
        getAllUsers()
        checkAndShowTutorial()
        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(frienRequestAction(_:)), name: Notification.Name("FRIEND_REQUEST_CANCELLED"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(frienRequestAction(_:)), name: Notification.Name("FRIEND_REQUEST_CONFIRMED"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(frienRequestAction(_:)), name: Notification.Name("frienRequestActionFromButton"), object: nil)
    }
    
    ///Method to check if user has completed the tutorial, if not, then show the tutorial
    func checkAndShowTutorial(){
        let isCompletedTutorial = UserDefaults.standard.bool(forKey: Constants.IS_COMPLETED_TUTORIAL)
        if isCompletedTutorial {
            tapToContinueLabel.isHidden = true
        }else{
            Navigations.showInstructionsVC(self, delegate: self, calledFrom: "FriendsTabVC")
            tapToContinueLabel.isHidden = false
        }
    }
    
    ///ShowInstructionsVC Delegate Method
    func navigate() {
        Navigations.goToCrowds(navigationController:navigationController)
    }
    
    func getAllUsers(){
        self.showProgressHUD()
        FirebaseAPI.default.getAllUsers(userId:userData?.id ?? "") { (list) in
            self.hideProgressHUD()
            self.mainView.isHidden = false
            self.usersList = []
            self.serverUsersList = []
            self.serverUsersList = list
            //            CommonMethods.showLog(self.TAG, "getData list : \(self.usersList.count)")
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    @IBAction func searchUsernameBtnPressed(_ sender: UIButton) {
        self.usersList = []
        if searchUsernameText.text?.trim().count == 0 {
            showDialog(title: Constants.APP_NAME, message: "Please enter username")
        }else {
            self.usersList = serverUsersList.filter({
                ($0.username ?? "").lowercased().contains(searchUsernameText.text?.trim().lowercased() ?? "")
            })
            self.checkAndShowMessage()
            self.tableView.reloadData()
        }
        
    }
    
    
    @IBAction func searchNameBtnPressed(_ sender: UIButton) {
        self.usersList = []
        if searchNameText.text?.trim().count == 0 {
            showDialog(title: Constants.APP_NAME, message: "Please enter name")
        }else {
            CommonMethods.showLog(TAG, "Search Text : \(searchNameText.text?.trim().lowercased() ?? "")")
            var text = "\(serverUsersList[0].firstName ?? "") \(serverUsersList[0].lastName ?? "")".lowercased()
            CommonMethods.showLog(TAG, "Search Text : \(text)")
            
            self.usersList = serverUsersList.filter({
                (($0.firstName ?? "") + " " + ($0.lastName ?? "")).lowercased().contains(searchNameText.text?.trim().lowercased() ?? "")
            })
            self.checkAndShowMessage()
            self.tableView.reloadData()
        }
        
        
    }
    
    @IBAction func friendsBtnPressed(_ sender: Any) {
        Navigations.goToFriends(navigationController:navigationController)
    }
    
    @IBAction func crowdsBtnPressed(_ sender: Any) {
        Navigations.goToCrowds(navigationController:navigationController)
    }
    
    
    @IBAction func searchBtnPressed(_ sender: Any) {
        //      getSearchData()
    }
    
    func getSearchData(){
        //        let searchText = searchText.text?.trimmingCharacters(in: .whitespaces) ?? ""
        //        if searchText == ""{
        //            showDialog(title:Constants.APP_NAME,message: "Enter text to search.")
        //        }
        //        else{
        //            getSearchData(searchText: searchText)
        //        }
    }
    
    func checkAndShowMessage(){
        if usersList.count == 0{
            tableView.isHidden = true
            noUserText.isHidden = false
        }
        else{
            tableView.isHidden = false
            noUserText.isHidden = true
        }
    }
    
    func onSearchOptionsPressed(pos: Int?, userModel: UserModel?) {
        CommonMethods.showLog(TAG, "Type : \(userModel?.friendStatus?.rawValue)")
        if userModel?.friendStatus == .noType{
            viewModel?.addFriend(clickedPos:pos ?? 0)
        }else if userModel?.friendStatus == .sent{
            viewModel?.cancelFriendRequest(clickedPos:pos ?? 0)
        }else if userModel?.friendStatus == .pending{
            viewModel?.confirmFriendRequest(clickedPos:pos ?? 0)
        }
    }
    
    func setUI(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .transparent
        tableView.register(UINib(nibName: "ItemsTVC", bundle: nil), forCellReuseIdentifier: "ItemsTVC")
        
        crowdsBtn.layer.cornerRadius = 20.0
        friendsBtn.layer.cornerRadius = 20.0
        
        CommonMethods.roundCornerFilled(uiView: searchUserNameBtnView, borderColor: .clear, backgroundColor: .secondaryMainColor, cornerRadius: 5.0, borderWidth: 0.0)
        CommonMethods.roundCornerFilled(uiView: searchNameBtnView, borderColor: .clear, backgroundColor: .secondaryMainColor, cornerRadius: 5.0, borderWidth: 0.0)
        
        CommonMethods.showLog(self.TAG, "count: \(usersList.count)")
        CommonMethods.showLog(self.TAG, "count: \(serverUsersList.count)")
    }
    
    
    @IBAction func addFriendsPressed(_ sender: Any) {
        Navigations.goToAddFriend(navigationController:navigationController)
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //        self.usersList = []
        if textField == searchUsernameText {
            searchNameText.text = ""
        }else {
            searchUsernameText.text = ""
        }
        self.tableView.isHidden = false
        self.noUserText.isHidden = true
        self.tableView.reloadData()
    }
    
    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        
        if textField == searchUsernameText {
            var searchText  = searchUsernameText.text! + string
            if string  == "" {
                searchText = (searchText as String).substring(to: searchText.index(before: searchText.endIndex))
            }
            
            if searchText == "" {
                //                self.usersList = []
                noUserText.isHidden = true
                tableView.reloadData()
            }
            else{
                //                getSearchData(searchText: searchText, isUsername: true)
            }
        }else {
            var searchText  = searchNameText.text! + string
            if string  == "" {
                searchText = (searchText as String).substring(to: searchText.index(before: searchText.endIndex))
            }
            
            if searchText == "" {
                //                self.usersList = []
                noUserText.isHidden = true
                tableView.reloadData()
            }
            else{
                //                getSearchData(searchText: searchText, isUsername: false)
            }
        }
        
        
        return true
    }
    
    
    func getSearchData(searchText:String, isUsername: Bool){
        self.usersList = []
        
        if isUsername {
            self.usersList = serverUsersList.filter({
                ($0.username ?? "").lowercased().contains(searchText.lowercased())
            })
        }else {
            self.usersList = serverUsersList.filter({
                (($0.firstName ?? "") + " " + ($0.lastName ?? "")).lowercased().contains(searchText.lowercased())
            })
        }
        
        CommonMethods.showLog(TAG, "userList outside loop: \(usersList)")
        self.checkAndShowMessage()
        self.tableView.reloadData()
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        self.usersList = []
        //        self.usersList = serverUsersList
        noUserText.isHidden = true
        tableView.reloadData()
        return true
    }
    
    
}

extension FriendsTabVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemsTVC", for: indexPath) as! ItemsTVC
        cell.selectionStyle = .none
        cell.configure(data:usersList[indexPath.row],delegate:self,pos: indexPath.row)
        //        cell.configure(data: dataList[indexPath.row],type: Constants.ADMIN_HOME)
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
}
