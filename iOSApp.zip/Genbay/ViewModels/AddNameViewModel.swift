//
//  AddNameViewModel.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class AddNameViewModel{
    let TAG = String(describing: AddNameViewModel.self)
    var vc : AddNameVC
    
    init(vc: AddNameVC) {
        self.vc = vc
    }
    
    func validate() throws {
        
        if let firstName = vc.firstNameText.text {
            if firstName.trimAndCheckIsEmpty() {
                throw ValidationError.firstNameEmpty
            }
        } else {
            throw ValidationError.firstNameEmpty
        }
        
//        if let lastName = vc.lastNameText.text {
//            if lastName.trimAndCheckIsEmpty() {
//                throw ValidationError.lastNameEmpty
//            }
//        } else {
//            throw ValidationError.lastNameEmpty
//        }
    }
        
        // MARK: - Enums
        enum ValidationError: Error {
            case firstNameEmpty
            case lastNameEmpty
            
            var localizedDescription: String {
                switch self {
                case .firstNameEmpty:
                    return "Please enter your first name"
                case .lastNameEmpty:
                    return "Please enter your last name"
                }
            }
        }
    
    func updateData(){
        if let user = vc.userModel{
            vc.showProgressHUD()
            FirebaseAPI.default.saveUser(user,Constants.NAME) { (success, error, user) in
                self.vc.hideProgressHUD()
                if success{
                    if let user = user {
                        do{
                            CommonMethods.showLog(self.vc.TAG, "First : \(user.firstName).")
                            CommonMethods.showLog(self.vc.TAG, "Last : \(user.lastName).")
                            try UserDefaultsMapper.saveUser(user)
                            
                            if self.vc.calledFrom == Constants.PROFILE{
                                self.vc.showDialog(title: Constants.APP_NAME, message: "Profile updated successfully") {
                                    NotifyData.notifyProfileNotification(updateType: Constants.NAME)
                                    CommonMethods.dismiss(vc: self.vc)
                                }
                            }
                            else{
                                Navigations.goToAddUsernameVC()
                            }
                            
                            
                        }catch{
                            CommonMethods.showLog(self.TAG, "saveUser error : \(error.localizedDescription)")
                            self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                        }
                        
                    }
                }else{
                    if let error = error{
                        self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
                    }else{
                        self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                    }
                }
            }
        }
        else{
            CommonMethods.showLog(TAG, "Model is null")
        }
    }
}
