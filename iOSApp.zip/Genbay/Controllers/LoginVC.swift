//
//  AdminLoginVC.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import UIKit

class LoginVC: BaseViewController, UITextFieldDelegate {
    
    let TAG = String(describing: LoginVC.self)

    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var loginBtn: UIButton!
    
    @IBOutlet weak var passwordView: UIView!
    @IBOutlet weak var emailView: UIView!
    
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var emailText: UITextField!
    
    @IBOutlet weak var signInBtn: UIButton!
    @IBOutlet weak var forgotPasswordBtn: UIButton!
    
    var viewModel : LoginViewModel?
    
    var calledFrom = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = LoginViewModel(vc:self)
        setUI()
        
    }
    
    func setUI(){

        if Constants.FILL_STATIC_FORM{
//            emailText.text = "jasonyang987@gmail.com"
//            passwordText.text = "stanford12345"
//            emailText.text = "manvir@napworks.in"
            emailText.text = "pankaj@napworks.in"
            passwordText.text = "Qwerty@123"
        }
        forgotPasswordBtn.underlineButton( text: "Forgot Password?")
        signInBtn.underlineButton( text: "New? Create Account  ")
        
        [emailView,passwordView].forEach{view in
            CommonMethods.roundCornerFilled(uiView: view, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)}

        CommonMethods.setPlaceholderColor(textFields: [emailText,passwordText], color: .darkGray)


        CommonMethods.roundCornerFilled(uiView: loginBtn, borderColor: .secondaryMainColor, backgroundColor: .secondaryMainColor, cornerRadius: 25.0, borderWidth: 0.0)
        
        emailText.delegate = self
        passwordText.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
              if textField == emailText {
                  passwordText.becomeFirstResponder()
              }else if textField == passwordText{
                  textField.resignFirstResponder()
              }
              return true
     }
    
    @IBAction func loginClicked(_ sender: Any) {
        CommonMethods.showLog(TAG, "loginClicked")
        do{
            try viewModel?.validate()
            viewModel?.login()
        }
        catch let error as LoginViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }
    
    @IBAction func signUpClicked(_ sender: Any) {
        CommonMethods.showLog(TAG, "signUpClicked")
        Navigations.goToSignup()
    }
    
    @IBAction func backButtonPressed(_ sender: Any) {
        CommonMethods.dismiss(vc: self)
    }
    
    
    @IBAction func forgetPasswordClicked(_ sender: Any) {
        Navigations.goToForgotPassword(accountType:calledFrom)
    }
    
    
}
