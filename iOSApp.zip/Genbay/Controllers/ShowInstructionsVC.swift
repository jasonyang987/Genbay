//
//  showInstructionsVC.swift
//  Genbay
//
//  Created by Nap Works on 18/05/23.
//

import UIKit
import EasyTipView

protocol ShowInstructionsVCDelegate: AnyObject {
    func navigate()
}

class ShowInstructionsVC: UIViewController, EasyTipViewDelegate {
  
    let TAG = String(describing: ShowInstructionsVC.self)

    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view4: UIView!
    @IBOutlet weak var view5: UIView!
    @IBOutlet weak var view6: UIView!
    @IBOutlet weak var mainView: UIView!
    weak var delegate: ShowInstructionsVCDelegate?
    var calledFrom: String = ""
    var tip = EasyTipView(text: "")
    var tip1 = EasyTipView(text: "")
    var tip2 = EasyTipView(text: "")
    var tip3 = EasyTipView(text: "")
    var tip4 = EasyTipView(text: "")
    var tip5 = EasyTipView(text: "")
    var isTipDismissed: Bool = false
    var showNext : String = "Start"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view?.backgroundColor = .black.withAlphaComponent(0.2)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didTapContinue))
        view.addGestureRecognizer(tapGesture)
        view.isUserInteractionEnabled = true
        
        showTip()
    }
    
    ///Method to show the instructions on various conditions and related view controllers
    func showTip(){
        if calledFrom == "HomeTabVC" {
            showHomeTabTip()
        }else if calledFrom == "FriendsTabVC"{
            showFriendsTabTip()
        }else if calledFrom == "CrowdsVC" {
            showCrowdsVCTip()
        }else if calledFrom == "CreateEventTabVC"{
            showCreateEventTabTip()
        }
    }
    
    ///This method will be called when user taps on anywhere in entire view
    @objc func didTapContinue(){
        dismissTip()
    }
    
    ///Method to dismiss instructions tip view on various conditions
    func dismissTip(){
        if calledFrom == "HomeTabVC" {
            tip.dismiss {
                self.isTipDismissed = true
            }
        }else if calledFrom == "FriendsTabVC"{
            tip.dismiss{
                self.isTipDismissed = true
            }
        }else if calledFrom == "CrowdsVC" {
            
            if showNext == "Start"{
                tip1.dismiss{
                    self.showNext = "Tip2"
                }
                    
            }
            else if showNext == "ShowTip2"{
                self.tip2.dismiss{
                    self.showNext = "Tip3"
                }
            }
            else if showNext == "Tip2"{
                self.tip2.dismiss{
                    self.showNext = "Tip3"
                }
            }
            
            else if showNext == "Tip3"{
                self.tip3.dismiss{
                    self.showNext = "End"
                    self.isTipDismissed = true
                }
            }
        }else if calledFrom == "CreateEventTabVC"{
            if showNext == "Start"{
                tip4.dismiss{
                    self.showNext = "Tip5"
                }
                    
            }
            else if showNext == "Tip5"{
                self.tip5.dismiss{
                    self.showNext = "End"
                    self.isTipDismissed = true
                }
            }
            
            
//            tip4.dismiss{
//                self.tip5.dismiss{
//                    self.isTipDismissed = true
//                }
//            }
           
        }
    }
    
    /// Method to dismiss the current view controller and trigger the delegate method
    func closeVC(){
        CommonMethods.showLog(self.TAG, "closeVC")
        self.dismiss(animated: false) {
            CommonMethods.showLog(self.TAG, "closeVCInner")
            self.delegate?.navigate()
        }
        
    }
    
    ///Method to show instructions for homeTabVC
    func showHomeTabTip(){
        tip = EasyTipView(text: "This is your homepage where you can see all the events your friends have posted and RSVP for them.", delegate: self)
        tip.show(forView: view1, withinSuperview: mainView)
    }
    
    ///Method to show instructions for friendsTabVC
    func showFriendsTabTip(){
        tip = EasyTipView(text: "Use this page to add friends, edit your friends list, or create crowds.", delegate: self)
        tip.show(forView: view1, withinSuperview: mainView)
    }
    
    ///Method to show instructions for crowdsVC
    func showCrowdsVCTip(){
        tip1 = EasyTipView(text: "A crowd is a way for you to organize your friends into groups. No one can see these except for you!", delegate: self)
//        tip2 = EasyTipView(text: "Having a watch party just for roommates or a dinner just for family? You control who gets to see and RSVP to your events.", delegate: self)
//        tip3 = EasyTipView(text: "How you build your crowd is up to you, there are no limitations. You can always edit them afterwards!", delegate: self)
        tip1.show(forView: view3, withinSuperview: mainView)
//        tip2.show(forView: view4, withinSuperview: mainView)
//        tip3.show(forView: view5, withinSuperview: mainView)
    }
    
    ///Method to show instructions for createEventTabVC
    func showCreateEventTabTip(){
        tip4 = EasyTipView(text: "When you create an event (by clicking the plus icon in the bottom bar), you can select which crowds your event will be visible to.", delegate: self)
//        tip5 = EasyTipView(text: "As an event host, you are also optionally able to  create polls to ask your friends on which date or location they prefer for an event.", delegate: self)
        tip4.show(forView: view2, withinSuperview: mainView)
//        tip5.show(forView: view6, withinSuperview: mainView)
    }
    
    ///EasyTipView Delegate Methods
    func easyTipViewDidTap(_ tipView: EasyTipView) {
        CommonMethods.showLog(self.TAG, "easyTipViewDidTap")
        dismissTip()

    }
    
    func easyTipViewDidDismiss(_ tipView: EasyTipView) {
        CommonMethods.showLog(self.TAG, "isTipDismissed: \(isTipDismissed)")
        if isTipDismissed {
            closeVC()
        }
        else if calledFrom == "CrowdsVC"{
            CommonMethods.showLog(TAG, "Show Next : \(showNext)")
            if showNext == "Tip2" {
                showNext = "ShowTip2"
                self.tip2 = EasyTipView(text: "Having a watch party just for roommates or a dinner just for family? You control who gets to see and RSVP to your events.", delegate: self)
                self.tip2.show(forView: self.view4, withinSuperview: self.mainView)
                
            }
            else if showNext == "Tip3"{
                tip3 = EasyTipView(text: "How you build your crowd is up to you, there are no limitations. You can always edit them afterwards!", delegate: self)
                tip3.show(forView: view5, withinSuperview: mainView)
            }
        }else if calledFrom == "CreateEventTabVC"{
            if showNext == "Tip5" {
                tip5 = EasyTipView(text: "As an event host, you are also optionally able to  create polls to ask your friends on which date or location they prefer for an event.", delegate: self)
                tip5.show(forView: view6, withinSuperview: mainView)
                
            }
        }
    }
    
 
}
