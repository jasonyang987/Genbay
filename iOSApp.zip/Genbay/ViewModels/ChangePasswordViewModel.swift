//
//  ChangePasswordViewModel.swift
//  TruthAlibi
//
//  Created by Nap Works on 21/02/23.
//

import Foundation



final class ChangePasswordViewModel{
    let TAG = String(describing: ChangePasswordViewModel.self)
    var vc : ChangePasswordVC
    
    init(vc: ChangePasswordVC) {
        self.vc = vc
    }
    
    func validate() throws {
        
        if let currentPassword = vc.currentPasswordText.text {
            if currentPassword.trimAndCheckIsEmpty() {
                throw ValidationError.currentPasswordEmpty
            }
        } else {
            throw ValidationError.currentPasswordEmpty
        }
        
        if let newPassword = vc.newPasswordText.text {
            if newPassword.trimAndCheckIsEmpty() {
                throw ValidationError.newPasswordEmpty
            }else if newPassword.trim().count < 8{
                throw ValidationError.newPasswordShortLength
            }
        } else {
            throw ValidationError.newPasswordEmpty
        }
        
        if let confirmNewPassword = vc.confirmNewPasswordText.text {
            if confirmNewPassword.trimAndCheckIsEmpty() {
                throw ValidationError.confirmNewPasswordEmpty
            }else if confirmNewPassword.trim().count < 8{
                throw ValidationError.confirmNewPasswordShortLength
            }
        } else {
            throw ValidationError.confirmNewPasswordEmpty
        }
        
        if vc.newPasswordText.text?.trimmingCharacters(in: .whitespaces) != vc.confirmNewPasswordText.text?.trimmingCharacters(in: .whitespaces){
            throw ValidationError.passwordNotMatched
        }
    }
        
        // MARK: - Enums
    enum ValidationError: Error {
        case currentPasswordEmpty
        case newPasswordEmpty
        case newPasswordShortLength
        case confirmNewPasswordEmpty
        case confirmNewPasswordShortLength
        case passwordNotMatched
        
        var localizedDescription: String {
            switch self {
            case .currentPasswordEmpty:
                return "Please enter your current password"
            case .newPasswordEmpty:
                return "Please enter your new password"
            case .newPasswordShortLength:
                return "New Password must have 8 characters"
            case .confirmNewPasswordEmpty:
                return "Please enter your confirm new password"
            case .confirmNewPasswordShortLength:
                return "Confirm New Password must have 8 characters"
            case .passwordNotMatched:
                return "Passwords doesn't matched"
            }
        }
    }
    
    func changePassword(){
        vc.showProgressHUD()
        FirebaseAPI.default.login(email: vc.userModel?.email ?? "", password: vc.currentPasswordText.text?.trimmingCharacters(in: .whitespaces) ?? "") { user, error in
            if let error = error{
                CommonMethods.showLog(self.TAG, "ERROR changePassword : \(error) ")
                self.vc.hideProgressHUD()
                self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
            }else{
                FirebaseAPI.default.changePassword(password: self.vc.newPasswordText.text?.trimmingCharacters(in: .whitespaces) ?? "") { success, message in
                    if success{
                        self.vc.hideProgressHUD()
                        self.vc.showDialog(title: Constants.APP_NAME, message: "You have successfully changed your password.") {
                            CommonMethods.dismiss(vc: self.vc)
                        }
                    }else{
                        self.vc.hideProgressHUD()
                        self.vc.showDialog(title:Constants.APP_NAME,message: message)
                    }
                }
            }
        }
    }

}
