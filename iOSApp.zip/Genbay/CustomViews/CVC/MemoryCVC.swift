//
//  MemoryCVC.swift
//  Genbay
//
//  Created by Nap Works on 05/04/23.
//

import UIKit
import Kingfisher

class MemoryCVC: UICollectionViewCell {

    @IBOutlet weak var memoryImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configure(with model: EventMemoryModel){
        if let images = model.images {
            if images.count > 0 {
                memoryImageView.kf.setImage(with: URL(string: images[0]),placeholder: UIImage(named: "cameraPlaceholder"), options: [.cacheOriginalImage])
            }
        }
     
    }

}
