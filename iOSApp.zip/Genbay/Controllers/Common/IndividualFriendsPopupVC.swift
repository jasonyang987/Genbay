//
//  IndividualFriendsPopupVC.swift
//  Genbay
//
//  Created by Nap Works on 28/08/23.
//

import UIKit

protocol IndividualFriendsPopupVCDelegate: AnyObject {
    func onFriendsSelection(_ friends: [String], isCellSelected: Bool)
    func onCoHostsSelection(_ coHosts: [UserModel], isCellSelected: Bool)
}
class IndividualFriendsPopupVC: UIViewController {

    let TAG = String(describing: IndividualFriendsPopupVC.self)
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableViewHeightConstraint: NSLayoutConstraint!
    var friendsList: [UserModel] = []
    var selectedFriends: [String] = []
    var delegate: IndividualFriendsPopupVCDelegate?
    var calledFrom: IndividualFriendPopupType = .addIndividualFriends
    var selectedCoHosts: [UserModel] = []
    var isCellSelected: Bool = false
    var isCellDeSelected: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()

        setUI()
    }
    
    override func viewWillLayoutSubviews() {
        super.updateViewConstraints()
        self.tableViewHeightConstraint.constant = self.tableView.contentSize.height
    }

    func setUI(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .transparent
        tableView.register(UINib(nibName: "ChooseCrowdsTVC", bundle: nil), forCellReuseIdentifier: "ChooseCrowdsTVC")
        friendsList = AppDelegate.shared.friendList.filter{ $0.id != nil}
        friendsList.forEach { model in
            CommonMethods.showLog(self.TAG, "FRIENDUSERID: \(model.id) NAME: \(model.firstName) \(model.lastName)")
        }
        let filteredFriends = friendsList.filter {
            selectedFriends.contains($0.id ?? "")
        }
        
        for index in friendsList.indices {
            if filteredFriends.contains(where: { $0.id == friendsList[index].id }) {
                AppDelegate.shared.friendList[index].isSelected = true
            } else {
                AppDelegate.shared.friendList[index].isSelected = false
            }
        }
        
        view.backgroundColor = .black.withAlphaComponent(0.5)
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        mainView.clipsToBounds = true
        CommonMethods.roundCornerFilled(uiView: backBtn, borderColor: .blue, backgroundColor: .secondaryMainColor, cornerRadius: 20.0, borderWidth: 1.0)
        
    }
    
    @IBAction func closeMainBtnPressed(_ sender: UIButton){
        self.dismiss(animated: true)
    }
    
    @IBAction func closeBtnPressed(_ sender: UIButton){
        self.dismiss(animated: true)
    }
    
    
    @IBAction func backBtnPressed(_ sender: UIButton){
        delegate?.onFriendsSelection(selectedFriends, isCellSelected: isCellSelected)
        delegate?.onCoHostsSelection(selectedCoHosts, isCellSelected: isCellSelected)
        self.dismiss(animated: true)
    }
}

extension IndividualFriendsPopupVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return friendsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChooseCrowdsTVC", for: indexPath) as! ChooseCrowdsTVC
        cell.selectionStyle = .none
        cell.configure(data: friendsList[indexPath.row],position: indexPath.row, count: friendsList.count)
//        tableViewHeightConstraint.constant = tableViewHeightConstraint.constant + cell.frame.height
        CommonMethods.showLog(TAG, "Height After Section1 : \(tableViewHeightConstraint.constant)")
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        isCellSelected = true
        callUnitFuncationality(indexPath.row)
    }
    
    func callUnitFuncationality(_ clickedPos: Int){
        friendsList[clickedPos].isSelected = !(friendsList[clickedPos].isSelected)
        for (index, _) in friendsList.enumerated() {
            if index != clickedPos{
                self.tableView.reloadData()
            }
            else{
                if selectedFriends.contains(where:{ $0 == friendsList[index].id ?? "" }){
                    selectedFriends = selectedFriends.filter({$0 != friendsList[index].id ?? ""})
                }else{
                    selectedFriends.append(friendsList[index].id ?? "")
                }
                CommonMethods.showLog(TAG, "Selected Friends = \(selectedFriends)")
            }
        }
        for (index, _) in friendsList.enumerated() {
            if index != clickedPos{
                self.tableView.reloadData()
            }
            else{
                if selectedCoHosts.contains(where:{ $0.id == friendsList[index].id ?? "" }){
                    selectedCoHosts = selectedCoHosts.filter({$0.id != friendsList[index].id ?? ""})
                }else{
                    selectedCoHosts.append(friendsList[index])
                }
            }
        }
        self.tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        self.viewWillLayoutSubviews()
    }
    
    
}
