//
//  CommonDelegate.swift
//  TruthAlibi
//
//  Created by Nap Works on 15/02/23.
//

import Foundation
import SwiftUI

protocol DateSelectionDelegate{
    func onDateSelected(calledFrom:String,date:Date)
}

protocol LocationSelectionDelegate{
    func onLocationSelected(location:Location)
}

protocol PollSelectionDelegate{
    func onPollDateSelected(dates: [DatePollModel]?)
    func onPollLocationSelected(list:[Location]?)
//    func sendLocationList(locations: [Location]?)
}

protocol ButtonPressedDelegate{
    func onButtonPressed(type:String,pos : Int)
}

protocol ViewPagerDelegate{
    func onPageChanged(type:String)
}

protocol SlideButtonDelegate{
    func onButtonSlide()
}

protocol FriendsOptionPressedDelegate{
    func onFriendOptionsPressed(pos : Int?,userModel:UserModel?,contentView:UIView?)
    func onCrowdOptionsPressed(pos : Int?, contentView:UIView?)
}

protocol SearchOptionPressedDelegate{
    func onSearchOptionsPressed(pos : Int?,userModel:UserModel?)
}

protocol UpdateMembersDelegate{
    func onMembersUpdated(crowdModel:CrowdModel?)
}

protocol ChooseCrowdForEventDelegate{
    func onCrowdsSelected(type:String,selectedCrowdList:[String]?,selectedMembersList:[String]?,selectedTitle:String,
                          crowdList:[CrowdModel],isVisibleToAllSelected:Bool)
}
