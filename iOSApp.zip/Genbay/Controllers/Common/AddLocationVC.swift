//
//  AddLocationVC.swift
//  Genbay
//
//  Created by Nap Works on 12/04/23.
//

import UIKit

class AddLocationVC: UIViewController {

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var locationTitleLabel: UILabel!
    @IBOutlet weak var addLocationTextView: UIView!
    @IBOutlet weak var addLocationText: UITextField!
    var delegate: LocationSelectionDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
//        mainView.backgroundColor = .red
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        CommonMethods.roundCornerFilled(uiView: addLocationTextView, borderColor: .darkGray, backgroundColor: .white, cornerRadius: 10, borderWidth: 0.5)
        // Do any additional setup after loading the view.
        
        CommonMethods.setPlaceholderColor(textFields: [addLocationText], color: .darkGray)
        addBtn.layer.cornerRadius = 20.0
        addBtn.layer.borderWidth = 1
        addBtn.layer.borderColor = UIColor.black.cgColor
        view.backgroundColor = .black.withAlphaComponent(0.3)
    }
    
    
    @IBAction func addBtnPressed(_ sender: UIButton) {
        if let locationText = self.addLocationText.text?.trimmingCharacters(in: .whitespaces), !locationText.isEmpty {
            self.dismiss(animated: true) {
                var location = Location()
                location.location = locationText
                location.vote = 0
                self.delegate?.onLocationSelected(location: location)
            }
        }else {
            showDialog(title: Constants.APP_NAME, message: "Please enter location!")
        }
      
    }
    
    @IBAction func closeBtnPressed(_ sender: UIButton){
        self.dismiss(animated: true)
    }
}
