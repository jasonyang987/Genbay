//
//  DropdownCell.swift
//  SuggestMe
//
//  Created by Nap Works on 24/02/23.
//

import UIKit
import DropDown

class MyCell: DropDownCell {
   @IBOutlet weak var logoImageView: UIImageView!
}
