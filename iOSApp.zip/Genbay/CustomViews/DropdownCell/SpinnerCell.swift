//
//  SpinnerCell.swift
//  TruthAlibi
//
//  Created by Nap Works on 15/02/23.
//

import Foundation
import UIKit
import DropDown

class SpinnerCell: DropDownCell {
    
    let TAG = String(describing: SpinnerCell.self)
    
    @IBOutlet weak var guestImage: UIImageView!
    @IBOutlet weak var guestNames: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setDetail( ){
        CommonMethods.showLog(TAG, "Set Detail")
//        selectView.isHidden = true
        
    }
    
    
}
