//
//  UIColor.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//
import Foundation
import UIKit

extension UIColor{
    
    static var transparent : UIColor {
        return UIColor(white: 1.0, alpha: 0.0)
    }
    
    static var mainColor:UIColor{
        return UIColor(named: "ColorPrimary") ?? UIColor.lightGray
    }
    
    static var secondaryMainColor:UIColor{
        return UIColor(named: "SecondaryColorPrimary") ?? UIColor.lightGray
    }
    
    static var editTextBackground:UIColor{
        return UIColor(named: "EditTextBackground") ?? UIColor.lightGray
    }
    
    static var lightBackground:UIColor{
        return UIColor(named: "LightBackground") ?? UIColor.lightGray
    }
    
    static var orderAssigned:UIColor{
        return UIColor(named: "OrderAssigned") ?? UIColor.lightGray
    }
    static var orderCompleted:UIColor{
        return UIColor(named: "OrderCompleted") ?? UIColor.lightGray
    }
    static var orderPickedUp:UIColor{
        return UIColor(named: "OrderPickedUp") ?? UIColor.lightGray
    }
    
    static var calendarCellSecondaryColor: UIColor {
          return UIColor(named: "CalendarCellSecondary") ?? UIColor.lightGray
      }
      static var calendarCellBorderColor: UIColor {
          return UIColor(named: "CalendarCellBorderColor") ?? UIColor.lightGray
      }
      
    
    static func random() -> UIColor {
            let red = CGFloat.random(in: 0...1)
            let green = CGFloat.random(in: 0...1)
            let blue = CGFloat.random(in: 0...1)
            return UIColor(red: red, green: green, blue: blue, alpha: 1)
        }
}

extension UIColor {
    func image(_ size: CGSize = CGSize(width: 1, height: 1)) -> UIImage {
        return UIGraphicsImageRenderer(size: size).image { rendererContext in
            self.setFill()
            rendererContext.fill(CGRect(origin: .zero, size: size))
        }
    }
    
    func roundedImage(_ size: CGSize = CGSize(width: 1, height: 1), radius: CGFloat = 0) -> UIImage {
        return UIGraphicsImageRenderer(size: size).image { rendererContext in
            self.setFill()
            let path = UIBezierPath(roundedRect: CGRect(origin: .zero, size: size), cornerRadius: radius)
            path.fill()
        }
    }
}

