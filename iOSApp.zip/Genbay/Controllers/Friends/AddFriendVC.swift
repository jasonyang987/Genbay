//
//  AddFriendVC.swift
//  Genbay
//
//  Created by Nap Works on 03/04/23.
//

import UIKit

class AddFriendVC: BaseViewController, ButtonPressedDelegate {
    func onButtonPressed(type: String, pos: Int) {
        
    }
    
    let TAG = String(describing: AddFriendVC.self)
    
    @IBOutlet weak var searchText: UITextField!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var mainView: UIView!
    var usersList : [UserModel] = []
    
    var userData:UserModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        userData = UserDefaultsMapper.getUser()
        setUI()
        mainView.isHidden = true
        
        getAllUsers()
    }
    
    func getAllUsers(){
        self.showProgressHUD()
        FirebaseAPI.default.getAllUsers(userId:userData?.id ?? "") { (list) in
            self.hideProgressHUD()
            self.mainView.isHidden = false
            self.usersList = []
            self.usersList = list
            CommonMethods.showLog(self.TAG, "getData list : \(self.usersList.count)")
            self.tableView.reloadData()
        }
    }
    
    func setUI(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .transparent
        tableView.register(UINib(nibName: "ItemsTVC", bundle: nil), forCellReuseIdentifier: "ItemsTVC")
        
        CommonMethods.roundCornerFilled(uiView: searchView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
    }
    
    @IBAction func backPressed(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
extension AddFriendVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemsTVC", for: indexPath) as! ItemsTVC
        cell.selectionStyle = .none
//        cell.configure(data:usersList[indexPath.row],delegate: self,pos: indexPath.row)
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        Navigations.goToAdminAssignOrder(salesId:dataList[indexPath.row].salesId ?? "",email:email)
    }
    
}
