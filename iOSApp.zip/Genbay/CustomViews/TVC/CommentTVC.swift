//
//  CommentTVC.swift
//  Genbay
//
//  Created by Nap Works on 05/04/23.
//

import UIKit

class CommentTVC: UITableViewCell {

    let TAG = String(describing: CommentTVC.self)
    @IBOutlet weak var guestImageView: UIView!
    @IBOutlet weak var guestImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var commentLabel: UILabel!
    
    var dataInCell : CommentModel?
    var guestList : [UserModel] = []
    var usernames: [String] = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(data:CommentModel,guestList:[UserModel]){
        self.dataInCell = data
        self.guestList = guestList
        self.usernames = extractUsernames(from: data.comment ?? "")
        boldTaggedUsers(data.comment ?? "")
        nameLabel.text = "\(dataInCell?.userModel?.firstName ?? "") \(dataInCell?.userModel?.lastName ?? "")"
        let image = dataInCell?.userModel?.imageUrl ?? ""
        if image != ""{
            guestImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
        
        guestImageView.layer.cornerRadius = guestImageView.frame.width / 2.0
    }
    
    func boldTaggedUsers(_ text: String) {
        let attributedText = NSMutableAttributedString(string: text)
        let boldAttributes: [NSAttributedString.Key: Any] = [ .font: UIFont.boldSystemFont(ofSize: 14)]
        if let regex = try? NSRegularExpression(pattern: "@\\w+", options: []) {
            let matches = regex.matches(in: text, options: [], range: NSRange(location: 0, length: text.utf16.count))
            for match in matches {
                attributedText.addAttributes(boldAttributes, range: match.range)
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
                commentLabel.isUserInteractionEnabled = true
                commentLabel.addGestureRecognizer(tapGesture)
                commentLabel.tag = match.range.location // Store the location as a tag for later identification
            }
        }
        commentLabel.attributedText = attributedText
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
       
    }
    
    func extractUsernames(from text: String) -> [String] {
        let usernameRegex = try! NSRegularExpression(pattern: "@[a-zA-Z0-9_]+")
        let matches = usernameRegex.matches(in: text, options: [], range: NSRange(location: 0, length: text.utf16.count))
        
        let usernames = matches.map { match in
            let matchRange = Range(match.range, in: text)!
            return String(text[matchRange])
        }
        
        return usernames
    }
    
    @objc func handleTap(_ gesture: UITapGestureRecognizer) {
     
    }
    
    
    func setName(){
        if guestList.count > 0 {
            var isExistInComment = false
            var existPos = 0
            var existUsername = ""
            var comment = dataInCell?.comment ?? ""
            
            for (i, data) in guestList.enumerated() {
//                CommonMethods.showLog(TAG, "Item \(index): \(data)")
                let guestModel = guestList[i]
                let username = guestModel.username ?? ""
                if comment.contains("@\(username)"){
                    existUsername = username
                    isExistInComment = true
                    existPos = i
                    break
                }
            }
//            for i in 0...guestList.count{
//                let guestModel = guestList[i]
//                let username = guestModel.username ?? ""
//                if comment.contains("@\(username)"){
//                    existUsername = username
//                    isExistInComment = true
//                    existPos = i
//                    break
//                }
//            }
            
            commentLabel.isUserInteractionEnabled = true
            commentLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleTapOnLabel(_:))))
            
            if isExistInComment{
                commentLabel.attributedText = attributedText(withString: dataInCell?.comment ?? "", boldString: "@\(existUsername)", font: UIFont.systemFont(ofSize: 15))
               
            }
            else{
                
                if comment.contains("@guests"){
                    commentLabel.attributedText = attributedText(withString: dataInCell?.comment ?? "", boldString: "@guests", font: UIFont.systemFont(ofSize: 15))
                }
                else{
                    commentLabel.text = dataInCell?.comment
                }
            }
        }
        else{
            commentLabel.text = dataInCell?.comment
        }
        
    }
    
    @objc func handleTapOnLabel(_ recognizer: UITapGestureRecognizer) {
        guard let text = commentLabel.attributedText?.string else {
            return
        }

        if let range = text.range(of: "@guests"),
            recognizer.didTapAttributedTextInLabel(label: commentLabel, inRange: NSRange(range, in: text)) {
            CommonMethods.showLog("TAG", "Guests Tapped")
//            goToTermsAndConditions()
        } else if let range = text.range(of: NSLocalizedString("_onboarding_privacy", comment: "privacy")),
            recognizer.didTapAttributedTextInLabel(label: commentLabel, inRange: NSRange(range, in: text)) {
//            goToPrivacyPolicy()
        }
    }
    
    func attributedText(withString string: String, boldString: String, font: UIFont) -> NSAttributedString {
        let attributedString = NSMutableAttributedString(string: string,
                                                     attributes: [NSAttributedString.Key.font: font])
        let boldFontAttribute: [NSAttributedString.Key: Any] = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: font.pointSize)]
        let range = (string as NSString).range(of: boldString)
        CommonMethods.showLog("TAG", "string : \(string)")
        CommonMethods.showLog("TAG", "boldString : \(boldString)")
        CommonMethods.showLog("TAG", "Range : \(range)")
        
//        attributedString.addAttribute(.link, value: boldString, range: (attributedString.string as NSString).range(of: boldString))
        attributedString.addAttributes(boldFontAttribute, range: range)
        return attributedString
    }
}

extension UITapGestureRecognizer {
    func didTapAttributedTextInLabel(label: UILabel, inRange targetRange: NSRange) -> Bool {
        guard let attrString = label.attributedText else {
            return false
        }

        let layoutManager = NSLayoutManager()
        let textContainer = NSTextContainer(size: .zero)
        let textStorage = NSTextStorage(attributedString: attrString)

        layoutManager.addTextContainer(textContainer)
        textStorage.addLayoutManager(layoutManager)

        textContainer.lineFragmentPadding = 0
        textContainer.lineBreakMode = label.lineBreakMode
        textContainer.maximumNumberOfLines = label.numberOfLines
        let labelSize = label.bounds.size
        textContainer.size = labelSize

        let locationOfTouchInLabel = self.location(in: label)
        let textBoundingBox = layoutManager.usedRect(for: textContainer)
        let textContainerOffset = CGPoint(x: (labelSize.width - textBoundingBox.size.width) * 0.5 - textBoundingBox.origin.x, y: (labelSize.height - textBoundingBox.size.height) * 0.5 - textBoundingBox.origin.y)
        let locationOfTouchInTextContainer = CGPoint(x: locationOfTouchInLabel.x - textContainerOffset.x, y: locationOfTouchInLabel.y - textContainerOffset.y)
        let indexOfCharacter = layoutManager.characterIndex(for: locationOfTouchInTextContainer, in: textContainer, fractionOfDistanceBetweenInsertionPoints: nil)
        return NSLocationInRange(indexOfCharacter, targetRange)
    }
}
