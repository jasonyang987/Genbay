//
//  VerificationViewModel.swift
//  TruthAlibi
//
//  Created by Nap Works on 18/02/23.
//

import Foundation

final class VerificationViewModel{
    let TAG = String(describing: VerificationViewModel.self)
    var vc : VerificationVC
    
    var code = ""
    
    init(vc: VerificationVC) {
        self.vc = vc
    }
    
    func validate() throws {
        code = "\(vc.firstTextField.text ?? "")\(vc.secondTextField.text ?? "")\(vc.thirdTextField.text ?? "")\(vc.fourthTextField.text ?? "")\(vc.fifthTextField.text ?? "")\(vc.sixthTextField.text ?? "")"
        
        if code.count < 6{
            throw ValidationError.notValidCode
        }
    }
        
        // MARK: - Enums
        enum ValidationError: Error {
            case notValidCode
            
            var localizedDescription: String {
                switch self {
                case .notValidCode:
                    return "Enter Valid Verification Code"
                }
            }
        }
    
    func verifyOtpLogin(){
        CommonMethods.showLog(TAG, "Code : \(code)")
        vc.showProgressHUD()
        
        if self.vc.calledFrom == Constants.FORGOT_PASSWORD{
            //
            //            CommonWebServices.verifyForgotPasswordOtp(email: vc.email,otp: code,accountType:vc.accountType) { status, message, data in
            //                self.vc.hideProgressHUD()
            //                if status == Constants.SUCCESS {
            //                    self.vc.showDialog(title : Constants.APP_NAME, message: message,hideDialog:{
//                                    Navigations.goToChangePassword(calledFrom: self.vc.calledFrom,userId: "")
            //                    })
            //                }
            //                else {
            //                    self.vc.showDialog(title : Constants.APP_NAME, message: message)
            //                }
            //            }
            

        }
        else{
            //            CommonWebServices.verifyOtp(email: vc.email,otp: code) { status, message, data in
            //                self.vc.hideProgressHUD()
            //                if status == Constants.SUCCESS {
            //                    CommonWebServices.updatefcmToken()
                                AppDelegate.shared.mainNavController?.popToRootViewController(animated: false)
            //                }
            //                else {
            //                    self.vc.showDialog(title : Constants.APP_NAME, message: message)
            //                }
            //            }
        }
        
    }
    
    func resendOtp(){
//        vc.showProgressHUD()
//        CommonWebServices.forgotPassword(email: vc.email,accountType: self.vc.accountType) { status, message, data in
//            self.vc.hideProgressHUD()
//            if status == Constants.SUCCESS {
//                self.vc.showDialog(title : Constants.APP_NAME, message: "Otp resent to email")
//            }
//            else {
//                self.vc.showDialog(title : Constants.APP_NAME, message: message)
//            }
//        }
////        if self.vc.calledFrom == Constants.FORGOT_PASSWORD{
////            CommonWebServices.forgotPassword(email: vc.email,accountType: self.vc.accountType) { status, message, data in
////                self.vc.hideProgressHUD()
////                if status == Constants.SUCCESS {
////                    self.vc.showDialog(title : Constants.APP_NAME, message: "Otp resent to email")
////                }
////                else {
////                    self.vc.showDialog(title : Constants.APP_NAME, message: message)
////                }
////            }
////        }
////        else{
////            CommonWebServices.forgotPassword(email: vc.email,accountType: self.vc.accountType) { status, message, data in
////                self.vc.hideProgressHUD()
////                if status == Constants.SUCCESS {
////                    self.vc.showDialog(title : Constants.APP_NAME, message: "Otp resent to email")
////                }
////                else {
////                    self.vc.showDialog(title : Constants.APP_NAME, message: message)
////                }
////            }
////        }
    }
}
