//
//  FriendsModel.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import Foundation
import UIKit
import Firebase

class FriendModel: Codable{
    
    // MARK: - Properties
    
    var id: String?
//    var userId: String?
    var pendingList: [String]?
    var acceptedList: [String]?
    var sentList: [String]?
    
    enum CodingKeys: String, CodingKey {
        case id
//        case userId
        case pendingList
        case acceptedList
        case sentList
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(String.self, forKey: .id)
//        userId = try container.decodeIfPresent(String.self, forKey: .userId)
        pendingList = try container.decodeIfPresent([String].self, forKey: .pendingList)
        acceptedList = try container.decodeIfPresent([String].self, forKey: .acceptedList)
        sentList = try container.decodeIfPresent([String].self, forKey: .sentList)
    }
    
    init()
    {
        
    }
    
    var updateDataParameters: [String: Any] {
        return [
            "id":id ?? "",
            "pendingList": pendingList ?? [],
            "acceptedList": acceptedList ?? [],
            "sentList": sentList ?? []
            
        ]
    }
}

