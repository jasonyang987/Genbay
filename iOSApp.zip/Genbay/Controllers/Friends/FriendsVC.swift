//
//  FriendsVC.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import UIKit
import DropDown


protocol FriendsVCDelegate: AnyObject {
    func sendUpdatedGuestListToGuestListVC(_ guestList: [UserModel])
}

class FriendsVC: BaseViewController, FriendsOptionPressedDelegate {
 
    let TAG = String(describing: FriendsVC.self)
    var delegate: FriendsVCDelegate?
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noDataText: UILabel!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchTF: UITextField!
    
    var friendsList : [UserModel] = []
    var pendingList : [UserModel] = []
    var refreshControl = UIRefreshControl()
    var userData:UserModel?
    var viewModel: FriendsViewModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        noDataText.isHidden = true
        userData = UserDefaultsMapper.getUser()
        viewModel = FriendsViewModel(vc: self)
        setUI()
        
        //        friendsList = AppDelegate.shared.friendList
        //        pendingList = AppDelegate.shared.pendingList
        //        tableView.reloadData()
        //        checkAndShowMessage()
        getFriendList(true)
        let name = "\(userData?.firstName ?? "") \(userData?.lastName ?? "")"
//        FirebaseAPI.default.getAllHostEventFirestore(name: name, userId: userData?.id ?? "") { eventList, error in
//            if eventList.count > 0{
//                CommonMethods.showLog(self.TAG, "eventList: \(eventList)")
//            }
//        }
    }

    func getFriendList(_ isShowLoading:Bool){
        if isShowLoading{
            self.showProgressHUD()
        }
        FirebaseAPI.default.getFriends(userId: userData?.id ?? ""){ acceptedList , pendingList in
            self.hideProgressHUD()
            self.refreshControl.endRefreshing()
            self.friendsList = []
            self.pendingList = []
            self.friendsList = acceptedList?.filter { $0.id != nil} ?? []
            self.pendingList = pendingList?.filter { $0.id != nil} ?? []
            self.checkAndShowMessage()
            CommonMethods.showLog(self.TAG, "FriendList count : \(self.friendsList.count)")
            CommonMethods.showLog(self.TAG, "PendingList count : \(self.pendingList.count)")
            self.tableView.reloadData()
        }
    }
    
    func checkAndShowMessage(){
        if pendingList.count == 0 && friendsList.count == 0{
            noDataText.isHidden = false
        }
        else{
            noDataText.isHidden = true
        }
    }
    
    func setUI(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .transparent
        refreshControl.tintColor = .secondaryMainColor
        if #available(iOS 10.0, *) {
            tableView.refreshControl = refreshControl
        } else {
            tableView.addSubview(refreshControl)
        }
        refreshControl.addTarget(self, action: #selector(onRefresh(_:)), for: .valueChanged)
        
        tableView.register(UINib(nibName: "LabelTVC", bundle: nil), forCellReuseIdentifier: "LabelTVC")
        tableView.register(UINib(nibName: "LineTVC", bundle: nil), forCellReuseIdentifier: "LineTVC")
        tableView.register(UINib(nibName: "FriendsTVC", bundle: nil), forCellReuseIdentifier: "FriendsTVC")
        CommonMethods.roundCornerFilled(uiView: searchView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        searchTF.delegate = self
        searchTF.returnKeyType = .done
        CommonMethods.setPlaceholderColor(textFields: [searchTF], color: .black)
    }
    
    @objc func onRefresh(_ sender : Any) {
        CommonMethods.showLog(TAG, "onRefresh")
        getFriendList(false)
    }
    
    @IBAction func backPressed(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func onFriendOptionsPressed(pos: Int?, userModel: UserModel?,contentView:UIView?) {
        CommonMethods.showLog(TAG, "onFriendOptionsPressed")
        showDialog(clickedUserModel:userModel,contentView:contentView)
    }
    
    ///it is not required here
    func onCrowdOptionsPressed(pos: Int?, contentView: UIView?) {
        
    }

    func showDialog(clickedUserModel:UserModel?,contentView:UIView?){
        let name = "\(clickedUserModel?.firstName ?? "") \(clickedUserModel?.lastName ?? "")"
        let dropDownList = clickedUserModel?.friendStatus?.dropDownList(name:name) ?? []
        
        let dropDown = DropDown()
        dropDown.textColor = UIColor.black
        dropDown.selectedTextColor = .black
        dropDown.textFont = UIFont.systemFont(ofSize: 15)
        dropDown.backgroundColor = UIColor.white
        dropDown.selectionBackgroundColor = .white
        dropDown.cellHeight = 35
        
        dropDown.anchorView = contentView
        dropDown.dataSource = dropDownList
        //        let images = ["delete", "delete", "delete"]
        let width = self.view.frame.width / 1.6
        let xWidth = (contentView?.frame.width ?? 0) - width
        let yWidth = (contentView?.frame.height ?? 0) / 1.5
        CommonMethods.showLog(TAG, "width : \(width)")
        CommonMethods.showLog(TAG, "contentViewWidth : \(contentView?.frame.width)")
        CommonMethods.showLog(TAG, "contentViewHeight : \(contentView?.frame.height)")
        CommonMethods.showLog(TAG, "xWidth : \(xWidth)")
        dropDown.width = width
        dropDown.bottomOffset = CGPoint(x: xWidth , y: yWidth)
        dropDown.cellNib = UINib(nibName: "MyCell", bundle: nil)
        
        //        dropDown.customCellConfiguration = { (index: Index, item: String, cell: DropDownCell) -> Void in
        //            guard let cell = cell as? MyCell else { return }
        //            cell.logoImageView.image = UIImage(named: images[index])
        //        }
        
        dropDown.show()
        
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            if item == "Confirm Request"{
                self.showProgressHUD()
                CommonWebServices.confirmFriendRequest(userId: self.userData?.id ?? "", receiverId: clickedUserModel?.id ?? "") { status, message, model in
                    self.hideProgressHUD()
                    if status == Constants.SUCCESS {
                        clickedUserModel?.friendStatus = .accepted
                        for (index, model) in self.pendingList.enumerated(){
                            if model.id == clickedUserModel?.id{
                                self.pendingList.remove(at: index)
                                break
                            }
                        }
                        let userInfo: [AnyHashable: Any] = ["userId": clickedUserModel?.id ?? ""]
                        NotificationCenter.default.post(name: Notification.Name("FRIEND_REQUEST_CONFIRMED"), object: nil, userInfo: userInfo)
                        self.tableView.reloadData()
                    }else if status == Constants.FAILURE {
                        self.showDialog(title : Constants.APP_NAME, message: message)
                    }
                }
//                FirebaseAPI.default.confirmFriendRequest(clickedUserId: clickedUserModel?.id ?? "", userId: self.userData?.id ?? ""){ success,message in
//                    self.hideProgressHUD()
//                    if success{
//                        clickedUserModel?.friendStatus = .accepted
//                        //                        self.friendsList.append(clickedUserModel ?? UserModel())
//                        for (index, model) in self.pendingList.enumerated(){
//                            if model.id == clickedUserModel?.id{
//                                self.pendingList.remove(at: index)
//                                break
//                            }
//                        }
//
//                        self.tableView.reloadData()
//                    }
//                    else{
//                        self.showDialog(title: Constants.APP_NAME,message: message)
//                    }
//
//                }
            }else if item == "Cancel Request"{
                self.showProgressHUD()
                FirebaseAPI.default.cancelFriendRequest(clickedUserId: clickedUserModel?.id ?? "", userId: self.userData?.id ?? ""){ success,message in
                    self.hideProgressHUD()
                    if success{
                        for (index, model) in self.pendingList.enumerated(){
                            if model.id == clickedUserModel?.id{
                                self.pendingList.remove(at: index)
                                break
                            }
                        }
                        self.checkAndShowMessage()
                        let userInfo: [AnyHashable: Any] = ["userId": clickedUserModel?.id ?? ""]
                        NotificationCenter.default.post(name: Notification.Name("FRIEND_REQUEST_CANCELLED"), object: nil, userInfo: userInfo)
                        self.tableView.reloadData()
                    }
                    else{
                        self.showDialog(title: Constants.APP_NAME,message: message)
                    }
                    
                }
            }
            else if item == "Unfriend \(name)"{
                self.showProgressHUD()
                FirebaseAPI.default.unfriendRequest(clickedUserId: clickedUserModel?.id ?? "", userId: self.userData?.id ?? ""){ success,message in
                    if success{
                        for (index, model) in self.friendsList.enumerated(){
                            if model.id == clickedUserModel?.id{
                                self.friendsList.remove(at: index)
                                break
                            }
                        }
                        self.viewModel?.handleUserId(id1: self.userData?.id ?? "", id2: clickedUserModel?.id ?? "")
//                        self.viewModel?.handleUserId(id1: clickedUserModel?.id ?? "", id2: self.userData?.id ?? "")
                        self.checkAndShowMessage()
                        self.tableView.reloadData()
                    }
                    else{
                        self.showDialog(title: Constants.APP_NAME,message: message){
                            self.hideProgressHUD()
                        }
                    }
                }
            }
            else{
                
            }
        }
        
    }

}
extension FriendsVC : UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if pendingList.count > 0{
            if section == 1{
                return pendingList.count
            }
            else if section == 3{
                return friendsList.count
            }
            else{
                return 1
            }
        }
        else{
            return friendsList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if pendingList.count>0{
            if indexPath.section == 0{
                let cell = tableView.dequeueReusableCell(withIdentifier: "LabelTVC", for: indexPath) as! LabelTVC
                //                cell.selectionStyle = .none
                cell.configure(title:"Pending Requests")
                return cell
            }
            else if indexPath.section == 1{
                let cell = tableView.dequeueReusableCell(withIdentifier: "FriendsTVC", for: indexPath) as! FriendsTVC
                cell.selectionStyle = .none
                cell.configure(data:pendingList[indexPath.row],position: indexPath.row,delegate: self)
                return cell
            }
            else if indexPath.section == 2{
                let cell = tableView.dequeueReusableCell(withIdentifier: "LineTVC", for: indexPath) as! LineTVC
                //                cell.selectionStyle = .none
                //                cell.configure(data:pendingList[indexPath.row])
                return cell
            }
            else{
                let cell = tableView.dequeueReusableCell(withIdentifier: "FriendsTVC", for: indexPath) as! FriendsTVC
                cell.selectionStyle = .none
                cell.configure(data:friendsList[indexPath.row],position: indexPath.row,delegate: self)
                return cell
            }
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "FriendsTVC", for: indexPath) as! FriendsTVC
            cell.selectionStyle = .none
            cell.configure(data:friendsList[indexPath.row],position: indexPath.row,delegate: self)
            return cell
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if pendingList.count > 0{
            return 4
        }
        else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     
    }
    
    func textFieldDidChangeSelection(_ textField: UITextField) {
        self.friendsList = AppDelegate.shared.friendList
        if textField.text == "" {
            self.friendsList = AppDelegate.shared.friendList
        }else {
            self.friendsList = self.friendsList.filter({
                (($0.firstName ?? "") + " " + ($0.lastName ?? "")).lowercased().contains(searchTF.text?.trim().lowercased() ?? "")
            })
            
        }
        self.checkAndShowMessage()
        self.tableView.reloadData()
        CommonMethods.showLog(self.TAG, "self.friendsList: \(self.friendsList)")
        CommonMethods.showLog(self.TAG, "self.friendsList count: \(self.friendsList.count)")
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

}

