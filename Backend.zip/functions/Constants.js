class Constants {
    static IS_LOCAL_FUNCTION = false;
    static EVENT_CREATED = "eventCreated";
    static EVENT_UPDATED = "eventUpdated";
    static CO_HOST_INVITE = "coHostInvite";
    static EVENT_COMMENT_ADDED = "eventCommentAdded";
    static USER_MENTIONED = "userMentioned";
    static EVENT_MEMORY_ADDED = "eventMemoryAdded";
    static GOING_TO_EVENT = "goingToEvent";
    static FRIEND_REQUEST_SENT = "friendRequestSent";
    static FRIEND_REQUEST_ACCEPTED= "friendRequestAccepted";

    static PENDING_LIST = "pendingList";
    static ACCEPTED_LIST = "acceptedList";
    static SENT_LIST = "sentList";
    static GOING = "going"
    static NOT_GOING = "not_going"

}
module.exports = Constants;
