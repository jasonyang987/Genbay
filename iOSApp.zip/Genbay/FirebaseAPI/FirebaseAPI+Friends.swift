//
//  FirebaseAPI+Friends.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import Foundation
import Firebase
import FirebaseFirestore

extension FirebaseAPI {
    
    typealias AddFriendCompletion = (Bool,String, FriendModel) -> Void
    func addFriend(clickedUserId:String,userId:String, completion: @escaping AddFriendCompletion) {
//        let clickedUserId = friendModel.userId ?? ""
        CommonMethods.showLog(TAG, "addFriend clickedUserId : \(clickedUserId)")
        CommonMethods.showLog(TAG, "addFriend userID : \(userId)")
        getDataFromFriends(userId){isExists,model in
            var currentUserFriendModel = model
            if isExists{
                CommonMethods.showLog(self.TAG, "Current User Data Exists")
                let acceptedList = currentUserFriendModel.acceptedList ?? []
                var sentList = currentUserFriendModel.sentList ?? []
                let pendingList = currentUserFriendModel.pendingList ?? []
                let isExistInAccepted = self.checkIfExistInList(acceptedList,clickedUserId)
                let isExistInSent = self.checkIfExistInList(sentList,clickedUserId)
                let isExistInPending = self.checkIfExistInList(pendingList,clickedUserId)
                
                if !isExistInAccepted{
                    if !isExistInPending{
                        if !isExistInSent{
                            sentList.append(clickedUserId)
                            currentUserFriendModel.sentList = sentList
                        }
                        else{
                            CommonMethods.showLog(self.TAG, "Id Sent Vich Hai")
                            completion(false,"You have already sent an friend request to this user.", model)
                            return
                        }
                    }
                    else{
                        CommonMethods.showLog(self.TAG, "Id Pending Vich Hai")
                        completion(false,"You have already got request from this user.Check pending requests", model)
                        return
                    }
                }
                else{
                    CommonMethods.showLog(self.TAG, "Id Accepted Vich Hai")
                    completion(false,"You have already added to friends.", model)
                    return
                }
                
                 
            }
            else{
                CommonMethods.showLog(self.TAG, "Current User Data Not Exists")
                currentUserFriendModel = FriendModel()
                currentUserFriendModel.id = userId
                currentUserFriendModel.sentList = [clickedUserId]
                currentUserFriendModel.pendingList = []
                currentUserFriendModel.acceptedList = []
            }
            
            self.uploadDataToFriendsTable(currentUserFriendModel){ success,message in
                CommonMethods.showLog(self.TAG, "CurrentUser Data Upload : \(success)")
                if message != ""{
                    completion(false,message,currentUserFriendModel)
                }
                
                /// Clicked User Start
                
                self.getDataFromFriends(clickedUserId){isExists,model in
                    
                    var clickedUserFriendModel = model
                    if isExists{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Exists")
                        let acceptedList = clickedUserFriendModel.acceptedList ?? []
                        var pendingList = clickedUserFriendModel.pendingList ?? []
                        let sentList = clickedUserFriendModel.sentList ?? []
                        let isExistInAccepted = self.checkIfExistInList(acceptedList,userId)
                        let isExistInPending = self.checkIfExistInList(pendingList,userId)
                        let isExistInSent = self.checkIfExistInList(sentList,userId)
                        
                        if !isExistInAccepted{
                            if !isExistInSent{
                                if !isExistInPending{
                                    pendingList.append(userId)
                                    clickedUserFriendModel.pendingList = pendingList
                                }
                                else{
                                    CommonMethods.showLog(self.TAG, "ClickedUser Id Pending Vich Hai")
                                    completion(false,"You have already sent an friend request to this user.", model)
                                    return
                                }
                            }
                            else{
                                CommonMethods.showLog(self.TAG, "ClickedUser Id Sent Vich Hai")
                                completion(false,"You have already sent an friend request to this user.", model)
                                return
                            }
                            
                        }
                        else{
                            CommonMethods.showLog(self.TAG, "ClickedUser Id Accepted Vich Hai")
                            completion(false,"You have already added to friends.", model)
                            return
                        }
                        
                         
                    }
                    else{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Not Exists")
                        clickedUserFriendModel = FriendModel()
                        clickedUserFriendModel.id = clickedUserId
                        clickedUserFriendModel.pendingList = [userId]
                        clickedUserFriendModel.sentList = []
                        clickedUserFriendModel.acceptedList = []
                        
                    }
                    
                    self.uploadDataToFriendsTable(clickedUserFriendModel){success,message in
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Upload : \(success)")
                        if message != ""{
                            completion(false,message,clickedUserFriendModel)
                        }
                        else{
                            completion(true,"",clickedUserFriendModel)
                        }
                        
                    }
                }
            }
        }
    }
    
    func getDataFromFriends(_ id:String, completion : @escaping(Bool,FriendModel)->()){
        CommonMethods.showLog(self.TAG, "checkDataExists userId : \(id)")
        let ref = Endpoints.friends.child(id)
        ref.observeSingleEvent(of: .value, with: { snapshot in
            guard let dict = snapshot.value as? [String: Any] else {
                completion(false,FriendModel())
                return
            }
            if dict.count > 0{
                do {
                    let data = try JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted)
                    let detail = try JSONDecoder().decode(FriendModel.self, from: data)
                    completion(true,detail)
                } catch {
                    completion(false,FriendModel())
                }
            } else{
                completion(false,FriendModel())
            }
        })
    }
    
    typealias UploadDataCompletion = (Bool,String) -> Void
    func uploadDataToFriendsTable(_ friendModel:FriendModel,completion: @escaping UploadDataCompletion){
        Endpoints.friends.child(friendModel.id ?? "").updateChildValues(friendModel.updateDataParameters) { error,dbRef in
            if error != nil{
                completion(false,error?.localizedDescription ?? Constants.COMMON_ERROR_MESSAGE)
            }
            else{
                completion(true,"")
            }
        }
    }
    
    
    func checkIfExistInList(_ list:[String],_ clickedUserId:String) -> Bool{
        var isExist = false
        if list.count > 0{
            if list.contains(clickedUserId){
                CommonMethods.showLog(TAG, "clickedUserId hegi aa")
                isExist = true
            }
        }
        return isExist
    }
    
    typealias SearchCompletion = ([SearchedUserModel]?) -> Void
    func getSearchData(searchText: String,userId:String, completion: @escaping SearchCompletion) {
        Endpoints.users.queryOrdered(byChild: "username")
            .queryStarting(atValue: searchText)
            .queryEnding(atValue: "\(searchText)\\uf8ff")
            .observeSingleEvent(of: .value, with: { snapshot in
            CommonMethods.showLog(self.TAG, "snapshot : \(snapshot)")
                self.handleSearchedUserSnapshot(snapshot: snapshot,userId: userId,completion: completion)
            }, withCancel: { error in
                completion([])
            })
    }
    
    func handleSearchedUserSnapshot(snapshot : DataSnapshot,userId:String, completion : @escaping SearchCompletion){
        
        guard let dict = snapshot.value as? [String: Any] else {
            CommonMethods.showLog(TAG, "handleSearchedUserSnapshot Error \(snapshot)")
            completion([])
            return
        }
        var list: [SearchedUserModel] = []
        CommonMethods.showLog(TAG, "SnapDict Count : \(dict.count)")
        let dispatchGroup = DispatchGroup()
        for snapDict in dict {
            guard let value = snapDict.value as? [String: Any] else { continue }
            do {
                let data = try JSONSerialization.data(withJSONObject: value, options: .prettyPrinted)
                let detail = try JSONDecoder().decode(SearchedUserModel.self, from: data)
                
                if detail.id != userId && detail.username != nil && detail.username != ""
                {
                    dispatchGroup.enter()
                    let id = detail.id ?? ""
                    self.getDataFromFriends(id){isExists,model in
                        
                        let searchedUserFriendModel = model
                        if isExists{
                            CommonMethods.showLog(self.TAG, "searchedUserFriendModel Data Exists")
                            let acceptedList = searchedUserFriendModel.acceptedList ?? []
                            let pendingList = searchedUserFriendModel.pendingList ?? []
                            let sentList = searchedUserFriendModel.sentList ?? []
                            
                            let isExistInAccepted = self.checkIfExistInList(acceptedList,userId)
                            let isExistInPending = self.checkIfExistInList(pendingList,userId)
                            let isExistInSent = self.checkIfExistInList(sentList,userId)
                            
                            if !isExistInAccepted{
                                if !isExistInSent{
                                    if !isExistInPending{
                                        CommonMethods.showLog(self.TAG, "searchedUserFriendModel Id Kise Vich ni Hai")
                                        detail.friendStatus = .noType
                                        list.append(detail)
                                        dispatchGroup.leave()
                                    }
                                    else{
                                        CommonMethods.showLog(self.TAG, "searchedUserFriendModel Id Pending Vich Hai")
                                        detail.friendStatus = .sent
                                        list.append(detail)
                                        dispatchGroup.leave()
                                    }
                                }
                                else{
                                    CommonMethods.showLog(self.TAG, "searchedUserFriendModel Id Sent Vich Hai")
                                    detail.friendStatus = .pending
                                    list.append(detail)
                                    dispatchGroup.leave()
                                }
                                
                            }
                            else{
                                CommonMethods.showLog(self.TAG, "searchedUserFriendModel Id Accepted Vich Hai")
                                detail.friendStatus = .accepted
                                list.append(detail)
                                dispatchGroup.leave()
                            }
                            
                            
                            
                        }
                        else{
                            CommonMethods.showLog(self.TAG, "searchedUserFriendModel Data Not Exists")
                            detail.friendStatus = .noType
                            list.append(detail)
                            dispatchGroup.leave()
                        }
                    }
                }
                else{
                    CommonMethods.showLog(TAG, "Same ID")
                    continue
                }
            } catch {
                CommonMethods.showLog(self.TAG, "handleUserSnapshot Error: \(snapDict.key):\(error.localizedDescription)")
                continue
            }
            

        }
        
        dispatchGroup.notify(queue: .main) {
            CommonMethods.showLog(self.TAG, "Group Notify")
            completion(list)
        }
        
    }
    
    func checkAlreadyExists(ref : DatabaseReference, completion : @escaping(Bool,FriendModel)->()){
        let userModel = UserDefaultsMapper.getUser()
        let userId = userModel?.id ?? ""
        CommonMethods.showLog(self.TAG, "checkAlreadyExists userId : \(userId)")
        CommonMethods.showLog(self.TAG, "checkAlreadyExists ref : \(ref)")
        ref.queryOrdered(byChild: "userId")
            .queryEqual(toValue: userId)
            .observeSingleEvent(of: .value, with: { snapshot in
                guard let dict = snapshot.value as? [String: Any] else {
                    completion(false,FriendModel())
                    return
                }
                if dict.count > 0{
                    for snapDict in dict {
                        guard let value = snapDict.value as? [String: Any] else { continue }
                        do {
                            let data = try JSONSerialization.data(withJSONObject: value, options: .prettyPrinted)
                            let detail = try JSONDecoder().decode(FriendModel.self, from: data)
                            completion(true,detail)
                        } catch {
                            completion(true,FriendModel())
                        }
                    }

                } else{
                    completion(false,FriendModel())
                }
            })
    }

    
    
    typealias GetFriendsCompletion = ([UserModel]?,[UserModel]?) -> Void
    func getFriends(userId:String, completion: @escaping GetFriendsCompletion) {
        Endpoints.friends
            .child(userId)
            .observe(.value, with: { snapshot in
                CommonMethods.showLog(self.TAG, "snapshot : \(snapshot)")
                self.handleFriendsSnapshot(snapshot: snapshot,userId: userId,completion: completion)
            }, withCancel: { error in
                completion([],[])
            })
    }
    
    func handleFriendsSnapshot(snapshot : DataSnapshot,userId:String, completion : @escaping GetFriendsCompletion){
        
        guard let dict = snapshot.value as? [String: Any] else {
            CommonMethods.showLog(TAG, "handleSearchedUserSnapshot Error \(snapshot)")
            completion([],[])
            return
        }
        var list: [UserModel] = []
        var pendingFinalList: [UserModel] = []
        CommonMethods.showLog(TAG, "SnapDict Count : \(dict.count)")
        do {
            let data = try JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted)
            let detail = try JSONDecoder().decode(FriendModel.self, from: data)
            let acceptedList = detail.acceptedList ?? []
            let pendingList = detail.pendingList ?? []
             
            CommonMethods.showLog(self.TAG, "acceptedList Count : \(acceptedList.count)")
            CommonMethods.showLog(self.TAG, "pendingList Count : \(pendingList.count)")
            if acceptedList.count > 0{
                let dispatchGroup = DispatchGroup()
                for (index, id) in acceptedList.enumerated() {
                    dispatchGroup.enter()
                    CommonMethods.showLog(TAG, "Item \(index): \(id)")
                    self.getUser(id) { (user, error) in
                        user?.friendStatus = .accepted
                        list.append(user ?? UserModel())
                        dispatchGroup.leave()
                    }
                }
                
                // Fetch Pending List
                CommonMethods.showLog(self.TAG, "Fetch Pending List")
                if pendingList.count > 0{
                    let dispatchGroup = DispatchGroup()
                    for (index, id) in pendingList.enumerated() {
                        CommonMethods.showLog(self.TAG, "Item \(index): \(id)")
                        dispatchGroup.enter()
                        self.getUser(id) { (user, error) in
                            user?.friendStatus = .pending
                            pendingFinalList.append(user ?? UserModel())
                            dispatchGroup.leave()
                        }
                    }
                    dispatchGroup.notify(queue: .main) {
                        completion(list,pendingFinalList)
                    }
                }
                else{
                    dispatchGroup.notify(queue: .main) {
                        completion(list,[])
                    }
                }
            }
            else{
                // Fetch Pending List
                CommonMethods.showLog(self.TAG, "Fetch Pending List")
                if pendingList.count > 0{
                    let dispatchGroup = DispatchGroup()
                    for (index, id) in pendingList.enumerated() {
                        CommonMethods.showLog(self.TAG, "Item \(index): \(id)")
                        dispatchGroup.enter()
                        self.getUser(id) { (user, error) in
                            CommonMethods.showLog(self.TAG, "Data Fetch")
                            user?.friendStatus = .pending
                            pendingFinalList.append(user ?? UserModel())
                            dispatchGroup.leave()
                        }
                        
                    }
                    dispatchGroup.notify(queue: .main) {
                        CommonMethods.showLog(self.TAG, "Group Notify")
                        completion([],pendingFinalList)
                    }
                }
                else{
                    completion([],[])
                }
                
            }
            
        } catch {
            CommonMethods.showLog(self.TAG, "handleFriendsSnapshot Error: \(error.localizedDescription)")
        }
        
        
        
//        for snapDict in dict {
//            guard let value = snapDict.value as? [String: Any] else {
//                CommonMethods.showLog(self.TAG, "Error")
//                continue }
//            do {
//                let data = try JSONSerialization.data(withJSONObject: value, options: .prettyPrinted)
//                let detail = try JSONDecoder().decode(FriendModel.self, from: data)
//                let acceptedList = detail.acceptedList ?? []
//                let pendingList = detail.pendingList ?? []
//                CommonMethods.showLog(self.TAG, "acceptedList Count : \(acceptedList.count)")
//                CommonMethods.showLog(self.TAG, "pendingList Count : \(pendingList.count)")
//                if acceptedList.count > 0{
//                    for (index, id) in acceptedList.enumerated() {
//                        CommonMethods.showLog(TAG, "Item \(index): \(id)")
//                        self.getUser(id) { (user, error) in
//                            list.append(user ?? UserModel())
//                            if index == acceptedList.count - 1{
//                                CommonMethods.showLog(self.TAG, "Last Index")
//                                // Pending List
//                                if pendingList.count > 0{
//                                    for (index, id) in pendingList.enumerated() {
//                                        CommonMethods.showLog(self.TAG, "Item \(index): \(id)")
//                                        self.getUser(id) { (user, error) in
//                                            pendingFinalList.append(user ?? UserModel())
//                                            if index == pendingList.count - 1{
//                                                CommonMethods.showLog(self.TAG, "Last Index")
//                                                completion(list,pendingFinalList)
//                                            }
//                                        }
//                                    }
//                                }
//                                else{
//                                    completion(list,[])
//                                }
//                            }
//                        }
//                    }
//                }
//                else{
//                    // Fetch Pending List
//
//                    CommonMethods.showLog(self.TAG, "Fetch Pending List")
//                    if pendingList.count > 0{
//                        for (index, id) in pendingList.enumerated() {
//                            CommonMethods.showLog(self.TAG, "Item \(index): \(id)")
//                            self.getUser(id) { (user, error) in
//                                pendingFinalList.append(user ?? UserModel())
//                                if index == pendingList.count - 1{
//                                    CommonMethods.showLog(self.TAG, "Last Index")
//                                    completion(list,pendingFinalList)
//                                }
//                            }
//                        }
//                    }
//                    else{
//                        completion([],[])
//                    }
//
//                }
//
//            } catch {
//                CommonMethods.showLog(self.TAG, "handleFriendsSnapshot Error: \(snapDict.key):\(error.localizedDescription)")
//                continue
//            }
//        }
        
    }
    
    typealias ConfirmFriendRequestCompletion = (Bool,String) -> Void
    func confirmFriendRequest(clickedUserId:String,userId:String, completion: @escaping ConfirmFriendRequestCompletion){
        getDataFromFriends(userId){isExists,model in
            let currentUserFriendModel = model
            if isExists{
                CommonMethods.showLog(self.TAG, "Current User Data Exists")
                var acceptedList = currentUserFriendModel.acceptedList ?? []
                var pendingList = currentUserFriendModel.pendingList ?? []
                let isExistInPending = self.checkIfExistInList(pendingList,clickedUserId)
                
                CommonMethods.showLog(self.TAG, "isExistInPending : \(isExistInPending)")
                    if isExistInPending{
                        acceptedList.append(clickedUserId)
                        if let index = pendingList.firstIndex(of: clickedUserId) {
                            pendingList.remove(at: index)
                        }
                        currentUserFriendModel.acceptedList = acceptedList
                        currentUserFriendModel.pendingList = pendingList
                    }
                else{
                    completion(false,Constants.COMMON_ERROR_MESSAGE)
                    return
                }
            }
            else{
                CommonMethods.showLog(self.TAG, "Current User Data Not Exists")
                completion(false,Constants.COMMON_ERROR_MESSAGE)
                return
            }
            
            self.uploadDataToFriendsTable(currentUserFriendModel){ success,message in
                CommonMethods.showLog(self.TAG, "CurrentUser Data Upload : \(success)")
                if message != ""{
                    completion(false,message)
                }

                /// Clicked User Start

                self.getDataFromFriends(clickedUserId){isExists,model in

                    let clickedUserFriendModel = model
                    if isExists{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Exists")
                        var acceptedList = clickedUserFriendModel.acceptedList ?? []
                        var sentList = clickedUserFriendModel.sentList ?? []
                        
                        let isExistInAccepted = self.checkIfExistInList(acceptedList,userId)
                        let isExistInSent = self.checkIfExistInList(sentList,userId)
                        
                        CommonMethods.showLog(self.TAG, "ClickedUser isExistInAccepted : \(isExistInAccepted)")
                        CommonMethods.showLog(self.TAG, "ClickedUser isExistInSent : \(isExistInSent)")
                        
                        if isExistInSent{
                            acceptedList.append(userId)
                            if let index = sentList.firstIndex(of: userId) {
                                sentList.remove(at: index)
                            }
                            clickedUserFriendModel.acceptedList = acceptedList
                            clickedUserFriendModel.sentList = sentList
                            
                        }
                        else{
                            completion(false,Constants.COMMON_ERROR_MESSAGE)
                            return
                        }
                    }
                    else{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Not Exists")
                        completion(false,Constants.COMMON_ERROR_MESSAGE)
                        return
                    }

                    self.uploadDataToFriendsTable(clickedUserFriendModel){success,message in
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Upload : \(success)")
                        if message != ""{
                            completion(false,message)
                        }
                        else{
                            completion(true,"")
                        }

                    }
                }
            }
        }
    }
    
    typealias CancelFriendRequestCompletion = (Bool,String) -> Void
    func cancelFriendRequest(clickedUserId:String,userId:String, completion: @escaping ConfirmFriendRequestCompletion){
        getDataFromFriends(userId){isExists,model in
            let currentUserFriendModel = model
            if isExists{
                CommonMethods.showLog(self.TAG, "Current User Data Exists")
                var pendingList = currentUserFriendModel.pendingList ?? []
                
                let isExistInSent = self.checkIfExistInList(pendingList,clickedUserId)
                
                CommonMethods.showLog(self.TAG, "isExistInSent : \(isExistInSent)")
                    if isExistInSent{
                        if let index = pendingList.firstIndex(of: clickedUserId) {
                            pendingList.remove(at: index)
                        }
                        currentUserFriendModel.pendingList = pendingList
                    }
                else{
                    completion(false,Constants.COMMON_ERROR_MESSAGE)
                    return
                }
            }
            else{
                CommonMethods.showLog(self.TAG, "Current User Data Not Exists")
                completion(false,Constants.COMMON_ERROR_MESSAGE)
                return
            }
            
            self.uploadDataToFriendsTable(currentUserFriendModel){ success,message in
                CommonMethods.showLog(self.TAG, "CurrentUser Data Upload : \(success)")
                if message != ""{
                    completion(false,message)
                }

                /// Clicked User Start

                self.getDataFromFriends(clickedUserId){isExists,model in

                    let clickedUserFriendModel = model
                    if isExists{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Exists")
                        var sentList = clickedUserFriendModel.sentList ?? []
                        
                        let isExistInPending = self.checkIfExistInList(sentList,userId)
                        
                        CommonMethods.showLog(self.TAG, "ClickedUser isExistInPending : \(isExistInPending)")
                        
                        if isExistInPending{
                            if let index = sentList.firstIndex(of: userId) {
                                sentList.remove(at: index)
                            }
                            clickedUserFriendModel.sentList = sentList
                            
                        }
                        else{
                            completion(false,Constants.COMMON_ERROR_MESSAGE)
                            return
                        }
                    }
                    else{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Not Exists")
                        completion(false,Constants.COMMON_ERROR_MESSAGE)
                        return
                    }

                    self.uploadDataToFriendsTable(clickedUserFriendModel){success,message in
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Upload : \(success)")
                        if message != ""{
                            completion(false,message)
                        }
                        else{
                            completion(true,"")
                        }

                    }
                }
            }
        }
    }
    
    func cancelFriendRequestFromSearch(clickedUserId:String,userId:String, completion: @escaping ConfirmFriendRequestCompletion){
        getDataFromFriends(userId){isExists,model in
            let currentUserFriendModel = model
            if isExists{
                CommonMethods.showLog(self.TAG, "Current User Data Exists")
                var sentList = currentUserFriendModel.sentList ?? []
                
                let isExistInSent = self.checkIfExistInList(sentList,clickedUserId)
                
                CommonMethods.showLog(self.TAG, "isExistInSent : \(isExistInSent)")
                    if isExistInSent{
                        if let index = sentList.firstIndex(of: clickedUserId) {
                            sentList.remove(at: index)
                        }
                        currentUserFriendModel.sentList = sentList
                    }
                else{
                    completion(false,Constants.COMMON_ERROR_MESSAGE)
                    return
                }
            }
            else{
                CommonMethods.showLog(self.TAG, "Current User Data Not Exists")
                completion(false,Constants.COMMON_ERROR_MESSAGE)
                return
            }
            
            self.uploadDataToFriendsTable(currentUserFriendModel){ success,message in
                CommonMethods.showLog(self.TAG, "CurrentUser Data Upload : \(success)")
                if message != ""{
                    completion(false,message)
                }

                /// Clicked User Start

                self.getDataFromFriends(clickedUserId){isExists,model in

                    let clickedUserFriendModel = model
                    if isExists{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Exists")
                        var pendingList = clickedUserFriendModel.pendingList ?? []
                        
                        let isExistInPending = self.checkIfExistInList(pendingList,userId)
                        
                        CommonMethods.showLog(self.TAG, "ClickedUser isExistInPending : \(isExistInPending)")
                        
                        if isExistInPending{
                            if let index = pendingList.firstIndex(of: userId) {
                                pendingList.remove(at: index)
                            }
                            clickedUserFriendModel.pendingList = pendingList
                            
                        }
                        else{
                            completion(false,Constants.COMMON_ERROR_MESSAGE)
                            return
                        }
                    }
                    else{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Not Exists")
                        completion(false,Constants.COMMON_ERROR_MESSAGE)
                        return
                    }

                    self.uploadDataToFriendsTable(clickedUserFriendModel){success,message in
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Upload : \(success)")
                        if message != ""{
                            completion(false,message)
                        }
                        else{
                            completion(true,"")
                        }

                    }
                }
            }
        }
    }
    
    typealias UnfriendCompletion = (Bool,String) -> Void
    func unfriendRequest(clickedUserId:String,userId:String, completion: @escaping UnfriendCompletion){
        getDataFromFriends(userId){isExists,model in
            let currentUserFriendModel = model
            if isExists{
                CommonMethods.showLog(self.TAG, "Current User Data Exists")
                var acceptedList = currentUserFriendModel.acceptedList ?? []
                
                let isExistInAccepted = self.checkIfExistInList(acceptedList,clickedUserId)
                
                CommonMethods.showLog(self.TAG, "isExistInSent : \(isExistInAccepted)")
                    if isExistInAccepted{
                        if let index = acceptedList.firstIndex(of: clickedUserId) {
                            acceptedList.remove(at: index)
                        }
                        currentUserFriendModel.acceptedList = acceptedList
                    }
                else{
                    completion(false,Constants.COMMON_ERROR_MESSAGE)
                    return
                }
            }
            else{
                CommonMethods.showLog(self.TAG, "Current User Data Not Exists")
                completion(false,Constants.COMMON_ERROR_MESSAGE)
                return
            }
            
            self.uploadDataToFriendsTable(currentUserFriendModel){ success,message in
                CommonMethods.showLog(self.TAG, "CurrentUser Data Upload : \(success)")
                if message != ""{
                    completion(false,message)
                }

                /// Clicked User Start

                self.getDataFromFriends(clickedUserId){isExists,model in

                    let clickedUserFriendModel = model
                    if isExists{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Exists")
                        var acceptedList = clickedUserFriendModel.acceptedList ?? []
                        
                        let isExistInAccepted = self.checkIfExistInList(acceptedList,userId)
                        
                        CommonMethods.showLog(self.TAG, "ClickedUser isExistInPending : \(isExistInAccepted)")
                        
                        if isExistInAccepted{
                            if let index = acceptedList.firstIndex(of: userId) {
                                acceptedList.remove(at: index)
                            }
                            clickedUserFriendModel.acceptedList = acceptedList
                            
                        }
                        else{
                            completion(false,Constants.COMMON_ERROR_MESSAGE)
                            return
                        }
                    }
                    else{
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Not Exists")
                        completion(false,Constants.COMMON_ERROR_MESSAGE)
                        return
                    }

                    self.uploadDataToFriendsTable(clickedUserFriendModel){success,message in
                        CommonMethods.showLog(self.TAG, "ClickedUser Data Upload : \(success)")
                        if message != ""{
                            completion(false,message)
                        }
                        else{
                            completion(true,"")
                        }

                    }
                }
            }
        }
    }
    
}
