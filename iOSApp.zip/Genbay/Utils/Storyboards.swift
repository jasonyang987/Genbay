//
//  Storyboard.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import Foundation
import UIKit

internal enum StoryboardScene {
    
    internal enum LaunchScreen: StoryboardType {
        internal static let storyboardName = "LaunchScreen"
        
        internal static let initialScene = InitialSceneType<UIKit.UIViewController>(storyboard: LaunchScreen.self)
    }
    
    internal enum Authentication: StoryboardType {
        internal static let storyboardName = "Authentication"
        
        internal static let initialScene = InitialSceneType<SplashVC>(storyboard: Authentication.self)
        
        internal static let splashVC = SceneType<SplashVC>(storyboard: Authentication.self, identifier: "SplashVC")
        
        internal static let loginVC = SceneType<LoginVC>(storyboard: Authentication.self, identifier: "LoginVC")
        
        internal static let signupVC = SceneType<SignupVC>(storyboard: Authentication.self, identifier: "SignupVC")
       
        internal static let addNameVC = SceneType<AddNameVC>(storyboard: Authentication.self, identifier: "AddNameVC")
        
        internal static let addUsernameVC = SceneType<AddUsernameVC>(storyboard: Authentication.self, identifier: "AddUsernameVC")
        
        internal static let addImageVC = SceneType<AddImageVC>(storyboard: Authentication.self, identifier: "AddImageVC")
        
        internal static let changePasswordVC = SceneType<ChangePasswordVC>(storyboard: Authentication.self, identifier: "ChangePasswordVC")
       
        internal static let forgotPasswordVC = SceneType<ForgotPasswordVC>(storyboard: Authentication.self, identifier: "ForgotPasswordVC")
        internal static let verificationVC = SceneType<VerificationVC>(storyboard: Authentication.self, identifier: "VerificationVC")
        
    }
    
    internal enum Main: StoryboardType {
        internal static let storyboardName = "Main"
        
        internal static let quickTourVC = SceneType<QuickTourVC>(storyboard: Main.self, identifier: "QuickTourVC")
        
        internal static let homeVC = SceneType<HomeVC>(storyboard: Main.self, identifier: "HomeVC")
        
        internal static let addFriendVC = SceneType<AddFriendVC>(storyboard: Main.self, identifier: "AddFriendVC")
        
        internal static let friendsVC = SceneType<FriendsVC>(storyboard: Main.self, identifier: "FriendsVC")

        internal static let eventVC = SceneType<EventsVC>(storyboard: Main.self, identifier: "EventsVC")

        internal static let createEventVC = SceneType<CreateEventTabVC>(storyboard: Main.self, identifier: "CreateEventTabVC")

        internal static let crowdsVC = SceneType<CrowdsVC>(storyboard: Main.self, identifier: "CrowdsVC")

        internal static let createCrowdVC = SceneType<CreateCrowdVC>(storyboard: Main.self, identifier: "CreateCrowdVC")

        internal static let crowdDetailVC = SceneType<CrowdDetailVC>(storyboard: Main.self, identifier: "CrowdDetailVC")

        internal static let addMembersVC = SceneType<AddMembersVC>(storyboard: Main.self, identifier: "AddMembersVC")

//        internal static let webVC = SceneType<WebVC>(storyboard: Main.self, identifier: "WebVC")
//
//        internal static let adminAssignOrderVC = SceneType<AdminAssignOrderVC>(storyboard: Admin.self, identifier: "AdminAssignOrderVC")
//
//        internal static let manageDriverVC = SceneType<ManageDriversVC>(storyboard: Admin.self, identifier: "ManageDriversVC")
//
//        internal static let addDriverVC = SceneType<AddDriverVC>(storyboard: Admin.self, identifier: "AddDriverVC")
//
//        internal static let ordersVC = SceneType<OrdersVC>(storyboard: Admin.self, identifier: "OrdersVC")
//
//        internal static let orderDetailVC = SceneType<OrderDetailVC>(storyboard: Admin.self, identifier: "OrderDetailVC")


    }
//
//    internal enum Driver: StoryboardType {
//        internal static let storyboardName = "Driver"
//
//
//        internal static let driverHomeVC = SceneType<DriverHomeVC>(storyboard: Driver.self, identifier: "DriverHomeVC")
//
//        internal static let driverOrderDetailVC = SceneType<DriverOrderDetailVC>(storyboard: Driver.self, identifier: "DriverOrderDetailVC")
//
//    }
//
//
//    internal enum Customer: StoryboardType {
//        internal static let storyboardName = "Customer"
//
//        internal static let customerLoginVC = SceneType<CustomerLoginVC>(storyboard: Customer.self, identifier: "CustomerLoginVC")
//
//        internal static let verificationVC = SceneType<VerificationVC>(storyboard: Customer.self, identifier: "VerificationVC")
//
//        internal static let customerHomeVC = SceneType<CustomerHomeVC>(storyboard: Customer.self, identifier: "CustomerHomeVC")
//
//        internal static let customerOrdersVC = SceneType<CustomerOrdersVC>(storyboard: Customer.self, identifier: "CustomerOrdersVC")
//
//        internal static let webViewVC = SceneType<WebViewVC>(storyboard: Customer.self, identifier: "WebViewVC")
//
//    }
    
    
    
//    internal enum Main: StoryboardType {
//        internal static let storyboardName = "Main"
//
//        internal static let initialScene = InitialSceneType<HomeTabVC>(storyboard: Main.self)
//
//        internal static let homeTabVC = SceneType<HomeTabVC>(storyboard: Main.self, identifier: "HomeTabVC")
//
//
//    }
    
  
}
// swiftlint:enable explicit_type_interface identifier_name line_length type_body_length type_name

// MARK: - Implementation Details

internal protocol StoryboardType {
    static var storyboardName: String { get }
}

internal extension StoryboardType {
    static var storyboard: UIStoryboard {
        let name = self.storyboardName
        return UIStoryboard(name: name, bundle: BundleToken.bundle)
    }
}

internal struct SceneType<T: UIViewController> {
    internal let storyboard: StoryboardType.Type
    internal let identifier: String
    
    internal func instantiate() -> T {
        let identifier = self.identifier
        guard let controller = storyboard.storyboard.instantiateViewController(withIdentifier: identifier) as? T else {
            fatalError("ViewController '\(identifier)' is not of the expected class \(T.self).")
        }
        return controller
    }
    
    @available(iOS 13.0, tvOS 13.0, *)
    internal func instantiate(creator block: @escaping (NSCoder) -> T?) -> T {
        return storyboard.storyboard.instantiateViewController(identifier: identifier, creator: block)
    }
}

internal struct InitialSceneType<T: UIViewController> {
    internal let storyboard: StoryboardType.Type
    
    internal func instantiate() -> T {
        guard let controller = storyboard.storyboard.instantiateInitialViewController() as? T else {
            fatalError("ViewController is not of the expected class \(T.self).")
        }
        return controller
    }
    
    @available(iOS 13.0, tvOS 13.0, *)
    internal func instantiate(creator block: @escaping (NSCoder) -> T?) -> T {
        guard let controller = storyboard.storyboard.instantiateInitialViewController(creator: block) else {
            fatalError("Storyboard \(storyboard.storyboardName) does not have an initial scene.")
        }
        return controller
    }
}

// swiftlint:disable convenience_type
private final class BundleToken {
    static let bundle: Bundle = {
#if SWIFT_PACKAGE
        return Bundle.module
#else
        return Bundle(for: BundleToken.self)
#endif
    }()
}
// swiftlint:enable convenience_type
