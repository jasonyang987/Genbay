//
//  FirebaseAPI+Storage.swift
//  SoulSync
//
//  Created by Nap Works on 23/01/23.
//

import Foundation
import Firebase
import Photos

extension FirebaseAPI {
    
    // MARK: - Enums

    enum StorageRefenrenceType {
        case userPicture
        case crowdPicture
        case eventMemoryPicture
//        case timelinePicture
//        case momentPicture
//        case momentVideo
//        case testingData

        var path: StorageReference {
            switch self {
            case .userPicture:
                return Endpoints.userPictures
            case .crowdPicture:
                return Endpoints.crowdPictures
            case .eventMemoryPicture:
                return Endpoints.eventMemoryPictures
//            case .timelinePicture:
//                return Endpoints.timelinePictures
//            case .momentPicture:
//                return Endpoints.momentPictures
//            case .momentVideo:
//                return Endpoints.momentVideo
//            case .testingData:
//                return Endpoints.testingData
            }
        }
    }
    
    func upload(name : String, image: UIImage, reference: StorageRefenrenceType, completion: @escaping StorageCompletion) {
        let storageRef = reference.path.child(name)
        let metaData = StorageMetadata()
        metaData.contentType = "image/jpg"
       
        guard let data = image.jpegData(compressionQuality: 1) else {
            completion(nil, nil)
            return
        }

        storageRef.putData(data, metadata: metaData, completion: { (_, error) in
            if error != nil {
                completion(error, nil)
            } else {
                storageRef.downloadURL(completion: { (url, error) in
                    completion(error, url?.absoluteString)
                })
            }
        })
    }
    
    func uploadEventMemoryImage(name : String, image: UIImage, eventId: String, reference: StorageRefenrenceType, completion: @escaping StorageCompletion) {
        let storageRef = reference.path.child("\(eventId)/\(name)")
        let metaData = StorageMetadata()
        metaData.contentType = "image/jpg"
       
        guard let data = image.jpegData(compressionQuality: 1) else {
            completion(nil, nil)
            return
        }

        storageRef.putData(data, metadata: metaData, completion: { (_, error) in
            if error != nil {
                completion(error, nil)
            } else {
                storageRef.downloadURL(completion: { (url, error) in
                    completion(error, url?.absoluteString)
                })
            }
        })
    }
    
    typealias StorageCompletion = (Error?, String?) -> Void
    func upload(image: UIImage, reference: StorageRefenrenceType, completion: @escaping StorageCompletion) {
        let storageRef = reference.path.child("\(uid).jpg")
        let metaData = StorageMetadata()
        metaData.contentType = "image/jpg"

        guard let data = image.jpegData(compressionQuality: 1) else {
            completion(nil, nil)
            return
        }

        storageRef.putData(data, metadata: metaData, completion: { (_, error) in
            if error != nil {
                completion(error, nil)
            } else {
                storageRef.downloadURL(completion: { (url, error) in
                    completion(error, url?.absoluteString)
                })
            }
        })
    }
    
    
    func deleteEventMemoryImages(eventId: String, reference: StorageRefenrenceType, completion: @escaping StorageCompletion) {
        let storageRef = reference.path.child(eventId)

        // Delete all images inside the folder
        storageRef.listAll { (result, error) in
            if let error = error {
                completion(error, nil)
                return
            }
            let imagesRefs = result?.items
            if ((imagesRefs?.isEmpty) != nil) {
                // No images inside the folder, delete the folder
                storageRef.delete { error in
                    completion(error, nil)
                }
            } else {
                // Delete each image inside the folder
                let group = DispatchGroup()
                imagesRefs?.forEach({ imageRef in
                    group.enter()
                    imageRef.delete { error in
                        group.leave()
                    }
                })
                
                group.notify(queue: .main) {
                    // All images are deleted, delete the folder
                    storageRef.delete { error in
                        completion(error, nil)
                    }
                }
            }
        }
    }

    
}
