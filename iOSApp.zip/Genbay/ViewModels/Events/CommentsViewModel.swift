//
//  CommentsViewModel.swift
//  Genbay
//
//  Created by Nap Works on 15/04/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class CommentsViewModel{
    let TAG = String(describing: CommentsViewModel.self)
    var vc : CommentsVC
    
    
    
    init(vc: CommentsVC) {
        self.vc = vc
    }
    
    
    func getCommentList(){
        self.vc.showProgressHUD()
        FirebaseAPI.default.getEventComments(self.vc.eventModel?.id ?? ""){ list,error in
            self.vc.hideProgressHUD()
            self.vc.commentList = list.sorted(by: { ($0.createdAt ?? 0) > ($1.createdAt ?? 0)})
            CommonMethods.showLog(self.vc.TAG, "getCommentList Count : \(list.count)")
            self.checkAndShowMessage()
            self.vc.commentsTableView.reloadData()
        }
    }
    
    func getGuestList(){
        CommonMethods.showLog(TAG, "getGuestList")
        self.vc.showProgressHUD()
        FirebaseAPI.default.getGuestListFirestore(userIds:self.vc.eventModel?.selectedMembers ?? []){ list in
            self.vc.hideProgressHUD()
            self.vc.guestList = list
            self.vc.allGuestList = list
            self.vc.getAllGuestNames()
            self.checkAndShowMessage()
            self.vc.commentsTableView.reloadData()
        }
    }
    
    func checkAndShowMessage(){
        if self.vc.commentList.count == 0{
            self.vc.noCommentsView.isHidden = false
        }
        else{
            self.vc.noCommentsView.isHidden = true
        }
    }
}
