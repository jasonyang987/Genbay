//
//  CommonEnums.swift
//  Genbay
//
//  Created by Nap Works on 06/04/23.
//

import Foundation
import UIKit

enum FriendRequestType:String,Encodable,Decodable{
    case pending
    case sent
    case accepted
    case noType

    var image: UIImage? {
        switch self {
        case .pending:
            return UIImage(named: "accept_request")
        case .sent:
            return UIImage(named: "cancel_friend")
        case .accepted:
            return UIImage(named: "already_friend")
        case .noType:
            return UIImage(named: "add_friend")
        }
    }
    
    func dropDownList(name :String) -> [String]{
        switch self {
        case .pending:
            return ["Confirm Request","Cancel Request"]
        case .sent:
            return []
        case .accepted:
            return [
//                "Message \(name)","Add \(name) To Crowd",
                "Unfriend \(name)"]
        case .noType:
            return []
        }
    }
    
}

enum NotificationSettingType {
    case muteAllNotification
    case friendRequests
    case inviteToEvents
    case eventAttendanceUpdates
    case newEventMemories
    case discussionComments
    case mentions
}

enum CrowdVCType {
    case createCrowd
    case editCrowd
}

enum IndividualFriendPopupType {
    case addIndividualFriends
    case inviteFriendsAsCoHost
}
