//
//  Notifications.swift
//  TruthAlibi
//
//  Created by Nap Works on 22/02/23.
//

import Foundation

extension Notification.Name {
    
//    static let userUpdate = Notification.Name("userUpdate")
    static let adminHomeNotificationVC = Notification.Name("adminHomeNotificationVC")
    static let profileNotificationVC = Notification.Name("profileNotificationVC")
    static let homeNotificationVC = Notification.Name("homeNotificationVC")
    static let crowdVC = Notification.Name("crowdVC")
    static let eventVC = Notification.Name("eventVC")
    static let crowdDetailVC = Notification.Name("crowdDetailVC")
    static let driverHomeNotificationVC = Notification.Name("driverHomeNotificationVC")
    static let driverOrderDetailVC = Notification.Name("driverOrderDetailVC")
    static let updatedGuestList = Notification.Name("updatedGuestList")
    static let updatedGuestListFromCrowd = Notification.Name("updatedGuestListFromCrowd")
    static let updatedEventsList = Notification.Name("updatedEventsList")
    static let updatedNotificationsCount = Notification.Name("updatedNotificationsCount")
    static let handleCloudNotification = Notification.Name("handleCloudNotification")
    static let friendRequestNotification = Notification.Name("friendRequestNotification")
    
}

