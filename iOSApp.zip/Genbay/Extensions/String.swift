//
//  String.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import Foundation


extension String{
    func trimAndCheckIsEmpty() -> Bool{
        return trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    func trim() -> String{
        return trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    func trimSpace() -> String{
        return trimmingCharacters(in: .whitespaces)
    }
    
    func slice(from: String, to: String) -> String? {
        return (range(of: from)?.upperBound).flatMap { substringFrom in
            (range(of: to, range: substringFrom..<endIndex)?.lowerBound).map { substringTo in
                String(self[substringFrom..<substringTo])
            }
        }
    }
    
    var initials: String {
        return self.components(separatedBy: " ")
            .reduce("") {
                ($0.isEmpty ? "" : "\($0.first?.uppercased() ?? "")") +
                ($1.isEmpty ? "" : "\($1.first?.uppercased() ?? "")")
            }
    }
    
    var formattedDateString : String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a EEEE MM/dd/yyyy"
        let date = dateFormatter.date(from: self) ?? Date()
        dateFormatter.dateFormat = "MM/dd"
        let formattedDate = dateFormatter.string(from: date)
        return formattedDate
    }
    
    var formattedDateStringWithoutYear : String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let date = dateFormatter.date(from: self) ?? Date()
        dateFormatter.dateFormat = "MM/dd"
        let formattedDate = dateFormatter.string(from: date)
        return formattedDate
    }
}


extension NSMutableAttributedString {
//    var fontSize:CGFloat { return 14 }
//    var boldFont:UIFont { return UIFont.boldSystemFont(ofSize: fontSize) }
////    var boldFont:UIFont { return UIFont(name: "AvenirNext-Bold", size: fontSize) ?? UIFont.boldSystemFont(ofSize: fontSize) }
//    var normalFont:UIFont { return UIFont.systemFont(ofSize: fontSize)}
//    
//    func bold(_ value:String) -> NSMutableAttributedString {
//
//        let attributes:[NSAttributedString.Key : Any] = [
//            .font : boldFont
//        ]
//
//        self.append(NSAttributedString(string: value, attributes:attributes))
//        return self
//    }
//
//    func normal(_ value:String) -> NSMutableAttributedString {
//
//        let attributes:[NSAttributedString.Key : Any] = [
//            .font : normalFont,
//        ]
//
//        self.append(NSAttributedString(string: value, attributes:attributes))
//        return self
//    }
//    /* Other styling methods */
//    func greyHighlight(_ value:String) -> NSMutableAttributedString {
//
//        let attributes:[NSAttributedString.Key : Any] = [
//            .font :  normalFont,
//            .foregroundColor : UIColor.lightTextColor
//        ]
//
//        self.append(NSAttributedString(string: value, attributes:attributes))
//        return self
//    }
//
//    func blackHighlight(_ value:String) -> NSMutableAttributedString {
//
//        let attributes:[NSAttributedString.Key : Any] = [
//            .font :  normalFont,
//            .foregroundColor : UIColor.white,
//            .backgroundColor : UIColor.black
//
//        ]
//
//        self.append(NSAttributedString(string: value, attributes:attributes))
//        return self
//    }
//
//    func underlined(_ value:String) -> NSMutableAttributedString {
//
//        let attributes:[NSAttributedString.Key : Any] = [
//            .font :  normalFont,
//            .underlineStyle : NSUnderlineStyle.single.rawValue
//
//        ]
//
//        self.append(NSAttributedString(string: value, attributes:attributes))
//        return self
//    }
}
