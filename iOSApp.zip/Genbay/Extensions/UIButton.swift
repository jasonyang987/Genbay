//
//  UIButton.swift
//  Genbay
//
//  Created by Nap Works on 29/03/23.
//

import Foundation
import UIKit

extension UIButton {
    
    func underlineButton(text: String, color: UIColor = .white){
           let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 14),
                .foregroundColor: color,
                .underlineStyle: NSUnderlineStyle.single.rawValue
            ]
        
           let attributeString = NSMutableAttributedString(
                   string: text,
                   attributes: attributes
                )
           setAttributedTitle(attributeString, for: .normal)
       }
}
