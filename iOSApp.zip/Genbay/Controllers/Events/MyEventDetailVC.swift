//
//  MyEventDetailVC.swift
//  Genbay
//
//  Created by Nap Works on 11/04/23.
//

import UIKit

protocol MyEventDetailVCDelegate: AnyObject {
    func fetchEventsAfterConfirm()
}
class MyEventDetailVC: BaseViewController, VotingPopupVCDelegate {

    let TAG = String(describing: MyEventDetailVC.self)
    var delegate: MyEventDetailVCDelegate?
    @IBOutlet weak var viewCommentsBtn: UIButton!
    @IBOutlet weak var viewOtherGuestListBtn: UIButton!
    @IBOutlet weak var viewGuestCommentsView: UIView!
    @IBOutlet weak var viewEventMemoriesView: UIView!
    @IBOutlet weak var viewGuestListView: UIView!
    @IBOutlet weak var editViewPollView: UIView!
    @IBOutlet weak var eventView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var hostNameLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var viewPollResultsBtn: UIButton!
    @IBOutlet weak var descriptionLabel: UITextView!
    @IBOutlet weak var editBtn: UIButton!
    @IBOutlet weak var guestListBtn: UIButton!
    @IBOutlet weak var eventMemoriesBtn: UIButton!
    @IBOutlet weak var addressView: UIView!
    @IBOutlet weak var dateLocationAlertView: UIView!
    @IBOutlet weak var dateLocationPollAlertLabel: UILabel!
    @IBOutlet weak var pollDeadlineMessageView: UIView!
    @IBOutlet weak var pollDeadlineMessageLabel: UILabel!
    @IBOutlet weak var voteBtnView: UIView!
    @IBOutlet weak var voteBtn: UIButton!
    @IBOutlet weak var notGoingBtnView: UIView!
    @IBOutlet weak var notGoingBtn: UIButton!
    @IBOutlet weak var goingBtnView: UIView!
    @IBOutlet weak var goingBtn: UIButton!
    @IBOutlet weak var goingNotGoingView: UIView!
    let regularFont = UIFont.systemFont(ofSize: 14, weight: .regular)
    let boldFont = UIFont.systemFont(ofSize: 14, weight: .bold)
    var isHost : Bool?
    var isUpcoming: Bool?
    var isVoted: Bool?
    var isConfirmed: Bool = false
    var isAlreadySelectedGoing: Bool = false
    var isDateVoted: Bool = false
    var isLocationVoted: Bool = false
    var navVc : UINavigationController?
    var eventModel : EventModel?
    var eventId : String?
    var userModel: UserModel?
    var viewModel: MyEventDetailViewModel?
    var datePollList: [DatePollModel] = []
    var locationList: [Location] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        viewModel = MyEventDetailViewModel(vc: self)
        view.backgroundColor = .black.withAlphaComponent(0.4)
        self.eventView.isHidden = true
        showProgressHUD()
        FirebaseAPI.default.getEventDataWithId(eventID: eventId ?? "") { error, model in
            self.eventView.isHidden = false
            if let model = model, error == nil {
                self.eventModel = model
                self.setUI()
               
            }else {
                self.hideProgressHUD()
                self.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "")
            }
        }
        
//        self.setUI()
    }
    
    func setUI(){
        

        DispatchQueue.main.async {
            if let model = self.eventModel,
               let eventId = model.id{
                self.viewModel?.checkIfUserAlreadySelectedGoing(eventId, inViewDidLoad: true)
            }
        }
        CommonMethods.roundCornerFilled(uiView: eventView,
                                        borderColor: .white,
                                        backgroundColor: .white,
                                        cornerRadius: 20,
                                        borderWidth: 0.0)
        CommonMethods.roundCornerFilled(uiView: editBtn,
                                        borderColor: .black,
                                        backgroundColor: .secondaryMainColor,
                                        cornerRadius: 20,
                                        borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: viewPollResultsBtn,
                                        borderColor: .black,
                                        backgroundColor: .secondaryMainColor,
                                        cornerRadius: 20,
                                        borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: voteBtn,
                                        borderColor: .black,
                                        backgroundColor: .secondaryMainColor,
                                        cornerRadius: 20,
                                        borderWidth: 1)
        
        defaultBtnBackgroundAndLabel(view1: notGoingBtnView, view2: goingBtnView, btn1: notGoingBtn, btn2: goingBtn)
        
        ///Modify button's title with underline attributed text
        guestListBtn.underlineButton(text: "View Guest List", color: .black)
        eventMemoriesBtn.underlineButton(text: "See Event Memories!", color: .black)
        viewOtherGuestListBtn.underlineButton(text: "View Guest List", color: .black)
        viewCommentsBtn.underlineButton(text: "View Discussion", color: .black)
        
        
        if let model = eventModel {
            viewModel?.setModelData(model)
            
            if let acceptedCoHostInvites = model.acceptedCoHostInvites {
                self.isHost = acceptedCoHostInvites.contains(userModel?.id ?? "") || model.userId == userModel?.id
            }else {
                self.isHost = model.userId == userModel?.id
            }
            
            if let isHost = isHost {
                viewModel?.setUIByCheckIfHostOrNot(isHost, model: model)
            }
        }
        
        if let isUpcoming = isUpcoming {
            if !isUpcoming {
                dateLocationAlertView.isHidden = true
                pollDeadlineMessageView.isHidden = true
                goingNotGoingView.isHidden = true
                voteBtnView.isHidden = true
            }
        }
    }

     func changeButtonTitle(_ voted: Bool){
        if voted {
            voteBtn.setTitle("Edit Vote", for: .normal)
        }else {
            voteBtn.setTitle("Vote", for: .normal)
        }
    }
    
    
    //MARK: - Method to change background of button and font weight of Going and not going button based on user action.
    func changeBtnBackgroundAndLabel(view1: UIView, view2: UIView, btn1: UIButton, btn2: UIButton){
        CommonMethods.roundCornerFilled(uiView: view1, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: view2, borderColor: .black, backgroundColor: .white, cornerRadius: 0, borderWidth: 1)
        btn1.titleLabel?.font = boldFont
        btn2.titleLabel?.font = regularFont
    }
    
    //MARK: - Method to set default background of button and font weight when initially view loads
    private func defaultBtnBackgroundAndLabel(view1: UIView, view2: UIView, btn1: UIButton, btn2: UIButton){
        CommonMethods.roundCornerFilled(uiView: view1, borderColor: .black, backgroundColor: .white, cornerRadius: 0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: view2, borderColor: .black, backgroundColor: .white, cornerRadius: 0, borderWidth: 1)
        btn1.titleLabel?.font = regularFont
        btn2.titleLabel?.font = regularFont
    }
    
    @IBAction func voteBtnPressed(_ sender: UIButton) {
        showVotingPopup(false)
    }
    
    @IBAction func goingBtnPressed(_ sender: UIButton){
            if let model = eventModel,
               let eventId = model.id,
               let userId = userModel?.id {
                showProgressHUD()
                CommonWebServices.goingList(userId: userId, eventId: eventId, type: Constants.GOING) { status, message, model in
                    self.hideProgressHUD()
                    CommonMethods.showLog(self.TAG, "status : \(status)")
                    CommonMethods.showLog(self.TAG, "message : \(message)")
                    if status == Constants.SUCCESS {
                        self.isAlreadySelectedGoing = true
                        self.changeBtnBackgroundAndLabel(view1: self.goingBtnView, view2: self.notGoingBtnView, btn1: self.goingBtn, btn2: self.notGoingBtn)
                        self.showDialog(title: Constants.APP_NAME, message: "Vote Updated Successfully!")

                    }else if status == Constants.FAILURE {
                        self.showDialog(title : Constants.APP_NAME, message: message)
                    }
                }
            }
        
    }
    
   
    
    @IBAction func notGoingBtnPressed(_ sender: UIButton){
            if let model = eventModel,
               let eventId = model.id,
               let userId = userModel?.id {
                showProgressHUD()
                CommonWebServices.goingList(userId: userId, eventId: eventId, type: Constants.NOT_GOING) { status, message, model in
                    self.hideProgressHUD()
                    if status == Constants.SUCCESS {
                        self.isAlreadySelectedGoing = false
                        self.changeBtnBackgroundAndLabel(view1: self.notGoingBtnView, view2: self.goingBtnView, btn1: self.notGoingBtn, btn2: self.goingBtn)
                        self.showDialog(title: Constants.APP_NAME, message: "Removed from going list!"){
//                            self.checkIfUserAlreadySelectedGoing(model.id ?? "", inViewDidLoad: false)
                        }

                    }else if status == Constants.FAILURE {
                        self.showDialog(title : Constants.APP_NAME, message: message)
                    }
                }
//                viewModel?.checkIfUserAlreadySelectedGoing(eventId, inViewDidLoad: false, completion: { success in
//                    if success {
//                        self.viewModel?.removeFromGoingList(eventId, userId: userId)
//                    }else {
//                        self.showDialog(title: Constants.APP_NAME, message: "You have not selected to go in event.!")
//                    }
//                })
            }
    

    }

    private func showVotingPopup(_ isHostHere: Bool){
            if let model = self.eventModel,
               let isDatePollCreated = model.isDatePollCreated,
               let isLocationPollCreated = model.isLocationPollCreated{
                if isDatePollCreated && !isLocationPollCreated {
                    Navigations.showVotingPopup(viewController: self, model: model, isDateList: true, delegate: self, isHost: isHostHere)
                }else if !isDatePollCreated && isLocationPollCreated {
                    Navigations.showVotingPopup(viewController: self, model: model, isDateList: false, delegate: self, isHost: isHostHere)
                }else if isDatePollCreated && isLocationPollCreated{
                        let alert = UIAlertController(title: Constants.APP_NAME, message: "Please choose voting popup", preferredStyle: .actionSheet)
                        
                        if self.isDateVoted {
                            alert.addAction(UIAlertAction(title: "Edit Date Vote", style: .default, handler: { _ in
                                Navigations.showVotingPopup(viewController: self, model: model, isDateList: true, delegate: self, isHost: isHostHere)
                            }))
                        } else {
                            alert.addAction(UIAlertAction(title: "Date Poll", style: .default, handler: { _ in
                                Navigations.showVotingPopup(viewController: self, model: model, isDateList: true, delegate: self, isHost: isHostHere)
                            }))
                        }
                        
                        if self.isLocationVoted {
                            alert.addAction(UIAlertAction(title: "Edit Location Vote", style: .default, handler: { _ in
                                Navigations.showVotingPopup(viewController: self, model: model, isDateList: false, delegate: self, isHost: isHostHere)
                            }))
                        } else {
                            alert.addAction(UIAlertAction(title: "Location Poll", style: .default, handler: { _ in
                                Navigations.showVotingPopup(viewController: self, model: model, isDateList: false, delegate: self, isHost: isHostHere)
                            }))
                        }
                        
                        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
                        
                        self.present(alert, animated: true)
                }else {
                    showDialog(title: Constants.APP_NAME, message: "You have not created any poll for this event!")
                }
            }
        }
    
    func voteAdded(_ voteAdded: Bool) {
        if voteAdded{
            viewModel?.checkIfUserAlreadySelectedGoing(eventModel?.id ?? "", inViewDidLoad: true, completion: {[self] success in
                CommonMethods.showLog(self.TAG, "Success: \(success)")
                if success {
                    showDialog(title: Constants.APP_NAME, message: "Vote Updated Successfully!")
                }else {
                    if let model = eventModel,
                       let eventId = model.id,
                       let userId = userModel?.id {
                        showProgressHUD()
                        CommonWebServices.goingList(userId: userId, eventId: eventId, type: Constants.GOING) { status, message, model in
                            self.hideProgressHUD()
                            CommonMethods.showLog(self.TAG, "status : \(status)")
                            CommonMethods.showLog(self.TAG, "message : \(message)")
                            if status == Constants.SUCCESS {
                                self.isAlreadySelectedGoing = true
                                self.changeBtnBackgroundAndLabel(view1: self.goingBtnView, view2: self.notGoingBtnView, btn1: self.goingBtn, btn2: self.notGoingBtn)
                                self.showDialog(title: Constants.APP_NAME, message: "Vote Updated Successfully!")

                            }else if status == Constants.FAILURE {
                                self.showDialog(title : Constants.APP_NAME, message: message)
                            }
                        }
                    }
                }
            })
        }else {
            showDialog(title: Constants.APP_NAME, message: "Vote has not been added!")

        }
    }
    
    func setEditedModel(_ model: EventModel, isConfirmed: Bool) {
        viewModel?.setModelData(model)
        if let isHost = isHost {
            viewModel?.setUIByCheckIfHostOrNot(isHost, model: model)
        }
        self.isConfirmed = isConfirmed
//        if let pollDeadlineTimestamp = model.pollVotingDeadlineTimestamp {
//            let date = Date(timeIntervalSince1970: TimeInterval(pollDeadlineTimestamp))
//            pollDeadlineMessageLabel.text = "Poll opens until \(date.formattedMonthYearString)"
//        }
//
//        var dateString = ""
//        if model.isDateConfirmed ?? false{
//            let date = Date(timeIntervalSince1970: model.dateTimestamp ?? 0.0)
//            dateString = date.formattedDateString
//        }
//        else{
//            dateString = "DATE TBD"
//        }
//
//        titleLabel.text = "\(model.name ?? "") | \(model.startTime ?? "") \(dateString)"
//        hostNameLabel.text = "Host: \(model.hostName ?? "")"
//
//        let location = model.location
//        if location != nil && location != "" {
//            addressView.isHidden = false
//            if model.isLocationConfirmed ?? false{
//                addressLabel.text = location
//            }
//            else{
//                addressLabel.text = "TBD"
//            }
//        }else {
//            addressView.isHidden = true
//        }
//        self.isConfirmed = isConfirmed
//
//        if let isDatePollCreated = model.isDatePollCreated,
//           let isLocationPollCreated = model.isLocationPollCreated{
//            if !isDatePollCreated, !isLocationPollCreated  {
//                dateLocationAlertView.isHidden = true
//                pollDeadlineMessageView.isHidden = true
////                rsvpBtn.setTitle("RSVP", for: .normal)
//            }else {
//                dateLocationAlertView.isHidden = false
//                pollDeadlineMessageView.isHidden = false
////                rsvpBtn.setTitle("Vote and RSVP", for: .normal)
//
//                if isDatePollCreated && !isLocationPollCreated {
//                    dateLocationPollAlertLabel.text = "Host has opened: Date Poll"
//                }else if !isDatePollCreated && isLocationPollCreated {
//                    dateLocationPollAlertLabel.text = "Host has opened: Location Poll"
//                }else if isDatePollCreated && isLocationPollCreated {
//                    dateLocationPollAlertLabel.text = "Host has opened: Date Poll and Location Poll"
//                }
//            }
//            if let polldeadlineTimestamp = model.pollVotingDeadlineTimestamp {
//                let currentTimeStamp = Date().timeIntervalSince1970
//                if currentTimeStamp >= polldeadlineTimestamp {
//                    dateLocationAlertView.isHidden = true
//                    pollDeadlineMessageView.isHidden = true
////                    rsvpBtn.setTitle("RSVP", for: .normal)
//                } else {
//                    let timeRemainingInSeconds = Int(polldeadlineTimestamp - currentTimeStamp)
//                    let hours = timeRemainingInSeconds / 3600
//                    let minutes = (timeRemainingInSeconds % 3600) / 60
//                    CommonMethods.showLog(self.TAG, "Poll deadline not reached. \(hours) hours and \(minutes) minutes remaining.")
//                }
//            }
//        }
//        else{
//            CommonMethods.showLog(TAG, "Else guard")
//        }

    }
    
    
    @IBAction func viewPollBtnPressed(_ sender: Any) {
        showVotingPopup(true)
    }
    
    @IBAction func editBtnPressed(_ sender: Any) {
        Navigations.goToCreateEvent(navigationController: navVc, eventModel: eventModel ?? EventModel(), type: Constants.EDIT_EVENT)
        dismiss(animated: true)
    }

    
    @IBAction func viewGuestListBtnPressed(_ sender: UIButton){
        pushToGuestListVC(vc: self, eventModel: self.eventModel)
//        delegate?.pushToGuestListVC(vc: self, eventTitle: self.name, eventDate: self.date)
    }
    
    
    @IBAction func viewCommentsPressed(_ sender: Any) {
        var dateString = ""
        if eventModel?.isDateConfirmed ?? false{
            let date = Date(timeIntervalSince1970: eventModel?.dateTimestamp ?? 0.0)
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            dateString = dateFormatter.string(from: date)
        }
        else{
            dateString = "DATE TBD"
        }
        Navigations.goToViewComments(navigationController: navVc, eventId: eventModel?.id ?? "", eventTitle: eventModel?.name ?? "", eventDate: dateString, calledFromDetail: true)
//        Navigations.goToViewComments(navigationController: navVc, eventModel: eventModel ?? EventModel())
        dismiss(animated: true)
    }
    
    @IBAction func viewMemoriesBtnPressed(_ sender: UIButton){
//        delegate?.pushToMemoriesVC(vc: self, eventTitle: self.name, eventDate: self.date)
        var dateString = ""
        if eventModel?.isDateConfirmed ?? false{
            let date = Date(timeIntervalSince1970: eventModel?.dateTimestamp ?? 0.0)
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            dateString = dateFormatter.string(from: date)
        }
        else{
            dateString = "DATE TBD"
        }
        Navigations.goToEventMemories(eventId: eventModel?.id ?? "", navigationController: navVc, eventTitle: eventModel?.name ?? "", eventDate: dateString, calledFromDetail: true)
        dismiss(animated: true)
    }
    
    
    @IBAction func crossBtnPressed(_ sender: UIButton){
        if isConfirmed {
            self.delegate?.fetchEventsAfterConfirm()
            self.dismiss(animated: true)
        }else {
            self.dismiss(animated: true)

        }
    }
    
    @IBAction func closeBtnPressed(_ sender: UIButton){
        if isConfirmed {
            self.delegate?.fetchEventsAfterConfirm()
            self.dismiss(animated: true)
        }else {
            self.dismiss(animated: true)

        }    }
    
    func pushToGuestListVC(vc: UIViewController, eventModel: EventModel?) {
        guard let guestListVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "GuestListVC") as? GuestListVC else {
            return
        }
        guestListVC.eventModel = eventModel
        guestListVC.isCalledFromDetail = true
        navVc?.pushViewController(guestListVC, animated: true)
        vc.dismiss(animated: true)
    }

}
