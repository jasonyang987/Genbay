//
//  NotificationTabViewModel.swift
//  Genbay
//
//  Created by Nap Works on 11/05/23.
//

import Foundation

final class NotificationTabViewModel {
    let TAG = String(describing: NotificationTabViewModel.self)
    let vc: NotificationTabVC
    
    init(vc: NotificationTabVC) {
        self.vc = vc
    }
    
    //MARK: - Method to fetch notifications of a user using userId
    ///This method will use the id of logged in user to fetch their respective notification to be read to do something...
    func getNotifications(_ userId: String, showLoading: Bool){
        if showLoading {
            self.vc.showProgressHUD()
        }
        FirebaseAPI.default.getNotificationsFirestore(userId) {[self] notifications in
            CommonMethods.showLog(self.TAG, "notifications are: \(notifications)")
            self.vc.hideProgressHUD()
            self.vc.notifications = notifications.sorted{Double($0.info?.timeStamp ?? "") ?? 0 > Double($1.info?.timeStamp ?? "") ?? 0}
            if self.vc.notifications.count == 0 {
                self.vc.noNotificationsView.isHidden = false
            }else {
                self.vc.noNotificationsView.isHidden = true
            }
            self.vc.refreshControl.endRefreshing()
            NotificationCenter.default.post(name: .updatedNotificationsCount, object: notifications)
            DispatchQueue.main.async {
                self.vc.tableView.reloadData()
            }
        }
    }
    
    //MARK: - Method to read notification
    ///This method will be called when a user clicks on the notification cell to read the notification...
    func readNotification(_ userId: String, notificationId: String, completion: @escaping (Bool)->Void){
        self.vc.showProgressHUD()
        FirebaseAPI.default.EditNotification(userId, notificationId: notificationId) {[self] success, error in
            if success, error == nil {
                self.vc.hideProgressHUD()
                self.getNotifications(userId, showLoading: true)
                completion(true)
            }else {
                self.vc.hideProgressHUD()
                self.vc.showDialog(title: Constants.APP_NAME, message: "Some Error Occurred")
                completion(false)
            }
        }
    }
    
    func readNotification(_ userId: String, notificationId: String, info: Info? = nil, type: String = "", completion: @escaping (Bool)->Void){
        self.vc.showProgressHUD()
        FirebaseAPI.default.EditNotification(userId, notificationId: notificationId, info: info, type: type) {[self] success, error in
            if success, error == nil {
                self.vc.hideProgressHUD()
                self.getNotifications(userId, showLoading: true)
                completion(true)
            }else {
                self.vc.hideProgressHUD()
                self.vc.showDialog(title: Constants.APP_NAME, message: "Some Error Occurred")
                completion(false)
            }
        }
    }
    
}
