//
//  CreateCrowdVC.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import UIKit
import Kingfisher

protocol CreateCrowdVCDelegate: AnyObject {
    func onCrowdUpdation()
}

class CreateCrowdVC: BaseViewController, UITextViewDelegate {
    let TAG = String(describing: CreateCrowdVC.self)
    
    @IBOutlet weak var crowdDescView: UIView!
    @IBOutlet weak var crowdNameText: UITextField!
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var crowdNameView: UIView!
    @IBOutlet weak var cameraView: UIView!
    @IBOutlet weak var descriptionText: UITextView!
    @IBOutlet weak var createBtn: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    var delegate: CreateCrowdVCDelegate?
    var userModel:UserModel?
    var isImageSelected = false
    var viewModel : CreateCrowdViewModel?
    var calledFrom: CrowdVCType = .createCrowd
    var model: CrowdModel?
    
    private lazy var cameraPickerController: UIImagePickerController = {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .camera
        pickerController.cameraDevice = .front
        pickerController.allowsEditing = true
        return pickerController
    }()
    private lazy var photoLibraryPickerController: UIImagePickerController = {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .photoLibrary
        pickerController.allowsEditing = true
        return pickerController
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        viewModel = CreateCrowdViewModel(vc: self)
        
        setUI()
        
    }
    
    func setUI(){
        
        descriptionText.delegate = self
        descriptionText.textColor = .darkGray
        
        userImageView.layer.cornerRadius = userImageView.frame.width / 2.0
        cameraView.layer.cornerRadius = cameraView.frame.height / 2.0
        createBtn.layer.cornerRadius = 20.0
        
        [crowdNameView,crowdDescView].forEach{view in
            CommonMethods.roundCornerFilled(uiView: view, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)}
        
        CommonMethods.setPlaceholderColor(textFields: [crowdNameText], color: .darkGray)
        
        if calledFrom == .editCrowd {
            createBtn.setTitle("Edit", for: .normal)
            crowdNameText.text = model?.name ?? ""
            descriptionText.text = model?.description ?? ""
            titleLabel.text = "Edit Crowd"
            if let image = model?.imageUrl {
                if image != ""{
                    userImageView.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
                }
                isImageSelected = true
            }
        }
    }


    @IBAction func cameraButtonPressed(_ sender: Any) {
        presentCameraPhotoLibraryAlert(camera: { [unowned self] _ in
            guard UIImagePickerController.isSourceTypeAvailable(.camera) else { return }
            self.present(self.cameraPickerController, animated: true, completion: nil)
        }, library: { [unowned self] _ in
            guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else { return }
            self.present(self.photoLibraryPickerController, animated: true, completion: nil)
            }, sender: userImageView)
    }
    
    @IBAction func backPressed(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func createBtuttonPressed(_ sender: Any) {
        
        do{
            try viewModel?.validate()
            if calledFrom == .createCrowd {
                viewModel?.checkAndCreateCrowd()
            }else {
                viewModel?.checkAndUpdateCrowd()
            }
            
        }
        catch let error as CreateCrowdViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }

    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == .darkGray {
                textView.text = nil
            textView.textColor = .black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            CommonMethods.showLog(TAG, "textViewDidEndEditing")
            textView.text = "Enter Crowd Description"
            textView.textColor = .darkGray
            
        }
    }
    
}
extension CreateCrowdVC : UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.editedImage] as? UIImage
            ?? info[.originalImage] as? UIImage else { return }
        isImageSelected = true
        userImageView.image = image
        userImageView.layer.cornerRadius = userImageView.frame.width / 2
        dismiss(animated: true, completion: nil)
    }
}
