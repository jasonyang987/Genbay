//
//  NotificationTabVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit

class NotificationTabVC: BaseViewController, MyEventDetailVCDelegate {
    
    
    let TAG = String(describing: NotificationTabVC.self)
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noNotificationsView: UIView!
    @IBOutlet weak var noNotificationsLabel: UILabel!
    var userModel: UserModel?
    var notifications: [NotificationModel] = []
    var viewModel: NotificationTabViewModel?
    var refreshControl = UIRefreshControl()
    var isFirstTime = true
    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        viewModel = NotificationTabViewModel(vc: self)

        setUI()
        noNotificationsView.isHidden = true
        DispatchQueue.main.async {
            self.notifications = AppDelegate.shared.notificationList
            CommonMethods.showLog(self.TAG, "notifications: \(self.notifications)")
            if self.notifications.count == 0 {
                self.noNotificationsView.isHidden = false
            }else{
                self.notifications.forEach{ data in
                    CommonMethods.showLog(self.TAG, "notifications Data Type : \(data.type)")
                }
                self.noNotificationsView.isHidden = true
                
            }
            self.isFirstTime = false
            self.tableView.reloadData()
        }
       
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if let userId = userModel?.id {
            if !isFirstTime{
                viewModel?.getNotifications(userId, showLoading: false)
            }
        }
    }

    
    private func setUI(){
        let nib = UINib(nibName: "NotificationTVC", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "NotificationTVC")
        tableView.delegate = self
        tableView.dataSource = self
        refreshControl.tintColor = .secondaryMainColor
        if #available(iOS 10.0, *) {
            tableView.refreshControl = refreshControl
        } else {
            tableView.addSubview(refreshControl)
        }
        refreshControl.addTarget(self, action: #selector(onRefresh(_:)), for: .valueChanged)
    }
    
    @objc func onRefresh(_ sender : Any) {
        if let userId = userModel?.id {
            viewModel?.getNotifications(userId, showLoading: false)
        }
    }
    
    
}

extension NotificationTabVC: UITableViewDelegate, UITableViewDataSource, NotificationTVCDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notifications.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationTVC", for: indexPath) as! NotificationTVC
        cell.viewController = self
        cell.delegate = self
        cell.configure(with: notifications[indexPath.row], index: indexPath.row)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let type = notifications[indexPath.row].type {
            if type == Constants.CO_HOST_INVITE{
                if notifications[indexPath.row].status == 1 {
                    if let message = notifications[indexPath.row].info?.message {
                        if message.contains("accepted"){
                            Navigations.goToEvents(navigationController: navigationController, calledFrom: Constants.VIEW_EVENT)
                        }else {
                            return
                        }
                    }
                }
            }else if type == Constants.FRIEND_REQUEST_SENT{
                return
            }else {
                if notifications[indexPath.row].status == 1 {
                    navigateAccordingToType(notifications[indexPath.row].type,indexPath.row)
                }else{
                    viewModel?.readNotification(userModel?.id ?? "", notificationId: notifications[indexPath.row].id ?? "", completion: {[self] success in
                        if success {
                            navigateAccordingToType(notifications[indexPath.row].type,indexPath.row)
                        }
                    })
                }
            }
        }
    }
    
    func onButtonPressed(_ index: Int, isAccepted: Bool, type: AcceptActionType) {
        
        if notifications[index].status == 1 {
            if type == .coHostInvite {
                let currentMessage = notifications[index].info?.message ?? ""
                let modifiedCurrentMessage = currentMessage.replacingOccurrences(of: " has invited you to be a co-host for ", with: "'s ")
                CommonMethods.showLog(self.TAG, "Modified_Message: \(modifiedCurrentMessage)")
                var newMessage: String = ""
                if isAccepted {
                    newMessage = "You have accepted co-host invitation for \(modifiedCurrentMessage)"
                }else {
                    newMessage = "You have declined co-host invitation for \(modifiedCurrentMessage)"
                }
                CommonMethods.showLog(self.TAG, "New_Message: \(newMessage)")

                
                notifications[index].info?.message = newMessage
                viewModel?.readNotification(userModel?.id ?? "", notificationId: notifications[index].id ?? "", info: notifications[index].info, type: isAccepted ? "coHostInviteAccepted" : "coHostInviteDeclined", completion: { success in
                    if success {
                        Navigations.goToEvents(navigationController: self.navigationController, calledFrom: Constants.VIEW_EVENT)
                    }
                })
            }
            else{
                navigateAccordingToType(notifications[index].type, index)
            }
        }
        else{
            if type == .coHostInvite {
                let currentMessage = notifications[index].info?.message ?? ""
                let modifiedCurrentMessage = currentMessage.replacingOccurrences(of: " has invited you to be a co-host for ", with: "'s ")
                var newMessage: String = ""
                if isAccepted {
                    newMessage = "You have accepted co-host invitation for \(modifiedCurrentMessage)"
                }else {
                    newMessage = "You have declined co-host invitation for \(modifiedCurrentMessage)"
                }
                notifications[index].info?.message = newMessage
//                notifications[index].info?.timeStamp = "\(Date().timeIntervalSince1970)"
                viewModel?.readNotification(userModel?.id ?? "", notificationId: notifications[index].id ?? "", info: notifications[index].info, type: isAccepted ? "coHostInviteAccepted" : "coHostInviteDeclined", completion: { success in
                    if success {
                        Navigations.goToEvents(navigationController: self.navigationController, calledFrom: Constants.VIEW_EVENT)
                    }
                })
            }
            else if type == .friendRequest {
                let currentMessage = notifications[index].info?.message ?? ""
                let modifiedCurrentMessage = currentMessage.replacingOccurrences(of: "You have new friend request from ", with: "")
                var newMessage: String = ""
                if isAccepted {
                    newMessage = "You have accepted friend request of \(modifiedCurrentMessage)"
                }else {
                    newMessage = "You have declined friend request of \(modifiedCurrentMessage)"
                }
                notifications[index].info?.message = newMessage
//                notifications[index].info?.timeStamp = "\(Date().timeIntervalSince1970)"
                viewModel?.readNotification(userModel?.id ?? "", notificationId: notifications[index].id ?? "", info: notifications[index].info, type: isAccepted ? "friendRequestAcceptedByUser" : "friendRequestDeclinedByUser", completion: { success in
                    if success {
                        NotificationCenter.default.post(name: Notification.Name("frienRequestActionFromButton"), object: nil)
                        Navigations.goToFriends(navigationController: self.navigationController)
                    }
                })
            }
            else {
                viewModel?.readNotification(userModel?.id ?? "", notificationId: notifications[index].id ?? "", info: notifications[index].info, completion: { success in
                    if success {
                        self.navigateAccordingToType(self.notifications[index].type ?? "", index)
                    }
                })
            }
          
        }
    }
    
    func navigateAccordingToType(_ type: String?,_ pos : Int?){
        if let type = type {
            switch type{
            case Constants.FRIEND_REQUEST_SENT, Constants.FRIEND_REQUEST_ACCEPTED:
                NotifyData.notifyFriendRequests()
                break
            case Constants.EVENT_CREATED, Constants.EVENT_UPDATED,Constants.GOING_TO_EVENT:
                if let eventId = notifications[pos ?? 0].info?.eventId ,
                   eventId != ""{
                    Navigations.showMyEventDetailPopup(navVc:self.navigationController,viewController: self,eventId:eventId,isHost:false, delegate: self, isUpcoming: true)
                }
                else{
                    Navigations.goToEvents(navigationController: navigationController, calledFrom: Constants.VIEW_EVENT)
                }
//                if let eventData = notifications[pos ?? 0].info?.eventData ,
//                eventData != ""{
//                    let jsonData = Data(eventData.utf8)
//                    do {
//                        let eventModel = try JSONDecoder().decode(EventModel.self, from: jsonData)
//                        CommonMethods.showLog(TAG, "Event Id  : \(eventModel.id)")
//                        Navigations.showMyEventDetailPopup(navVc:self.navigationController,viewController: self,eventId:eventModel.id ?? "",isHost:false, delegate: self, isUpcoming: true)
//                    } catch {
//                        CommonMethods.showLog(TAG, "JSONDecoder error : \(error.localizedDescription)")
//                    }
//                }
//                else{
//                    Navigations.goToEvents(navigationController: navigationController, calledFrom: Constants.VIEW_EVENT)
//                }
                break
            case Constants.USERS_MENTIONED, Constants.EVENT_COMMENT_ADDED:
                if let eventId = notifications[pos ?? 0].info?.eventId ,
                   eventId != ""{
                    Navigations.goToViewComments(navigationController: self.navigationController, eventId: eventId)
                }
                else{
                    Navigations.goToEvents(navigationController: navigationController, calledFrom: Constants.VIEW_EVENT)
                }
                break
            case Constants.GOING_TO_EVENT:
                if let eventId = notifications[pos ?? 0].info?.eventId ,
                   eventId != ""{
                    Navigations.goToGuestListVC(navigationController:self.navigationController, eventId: eventId)
                }
                else{
                    Navigations.goToEvents(navigationController: navigationController, calledFrom: Constants.VIEW_EVENT)
                }
                break
            
            case Constants.EVENT_MEMORY_ADDED:
                if let eventId = notifications[pos ?? 0].info?.eventId ,
                   eventId != ""{
                    Navigations.goToEventMemories(eventId: eventId, navigationController: self.navigationController)
                }
                else{
                    Navigations.goToEvents(navigationController: navigationController, calledFrom: Constants.VIEW_EVENT)
                }
            case Constants.FRIEND_REQEUEST_ACCEPTED_BY_USER, Constants.FRIEND_REQEUEST_DECLINED_BY_USER, Constants.FRIEND_REQEUEST_CANCELLED_BY_USER:
                Navigations.goToFriends(navigationController: self.navigationController)
            case Constants.CO_HOST_INVITE_ACCEPTED, Constants.CO_HOST_INVITE_DECLINED:
                Navigations.goToEvents(navigationController: navigationController, calledFrom: Constants.VIEW_EVENT)
//                if let eventData = notifications[pos ?? 0].info?.eventData ,
//                eventData != ""{
//                    let jsonData = Data(eventData.utf8)
//                    do {
//                        let eventModel = try JSONDecoder().decode(EventModel.self, from: jsonData)
//                        CommonMethods.showLog(TAG, "Event Id  : \(eventModel.id)")
//                        Navigations.goToEventMemories(model: eventModel, navigationController: self.navigationController)
//                    } catch {
//                        CommonMethods.showLog(TAG, "JSONDecoder error : \(error.localizedDescription)")
//                    }
//                }
//                else{
//                    Navigations.goToEvents(navigationController: navigationController, calledFrom: Constants.VIEW_EVENT)
//                }
                break
            default:
                break
            }
        }
    }
    
    func fetchEventsAfterConfirm() {
        
    }
    
    
}
