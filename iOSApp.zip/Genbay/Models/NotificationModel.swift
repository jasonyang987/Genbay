//
//  NotificationModel.swift
//  Genbay
//
//  Created by Nap Works on 10/05/23.
//

import Foundation

class NotificationModel: Codable {
    var id: String?
    var info: Info?
    var status: Int?
    var type: String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case info
        case status
        case type
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(String.self, forKey: .id)
        info = try container.decodeIfPresent(Info.self, forKey: .info)
        status = try container.decodeIfPresent(Int.self, forKey: .status)
        type = try container.decodeIfPresent(String.self, forKey: .type)
    }
    
    init(){
        
    }
    
    var notificationParameters: [String: Any] {
        return [
            "id":id ?? "",
            "info": info ?? "",
            "status": status ?? "",
            "type": type ?? ""
        ]
    }
    
}

struct Info: Codable {
    var message: String?
    var timeStamp: String?
    var userId: String?
    var eventId: String?
    var userImage: String?
    var visibleTo: String?
    var eventData : String?
    
    enum CodingKeys: String, CodingKey {
        case message
        case timeStamp
        case userId
        case userImage
        case visibleTo
        case eventData
        case eventId
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        message = try container.decodeIfPresent(String.self, forKey: .message)
        timeStamp = try container.decodeIfPresent(String.self, forKey: .timeStamp)
        userId = try container.decodeIfPresent(String.self, forKey: .userId)
        eventId = try container.decodeIfPresent(String.self, forKey: .eventId)
        userImage = try container.decodeIfPresent(String.self, forKey: .userImage)
        visibleTo = try container.decodeIfPresent(String.self, forKey: .visibleTo)
        eventData = try container.decodeIfPresent(String.self, forKey: .eventData)
    }
    
    init(){
        
    }
    
    var infoParameters: [String: Any] {
        return [
            "eventData": eventData ?? "",
            "message":message ?? "",
            "timeStamp": timeStamp ?? "",
            "userId": userId ?? "",
            "userImage": userImage ?? "",
            "visibleTo": visibleTo ?? "",
            "eventId":eventId ?? ""
        ]
    }
}

enum NotificationType: String {
    case friendRequestSent
    case friendRequestAccepted
    case invitedAsCoHost
    case invitedToEvent
    case goingSelected
    case addedToEventMemory
    case commentedInDiscussion
    case mentionedInDiscussion
}


struct NotificationSampleModel {
    let message: String
    let type: NotificationType
}


