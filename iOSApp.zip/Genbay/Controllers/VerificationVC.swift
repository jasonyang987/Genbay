//
//  VerificationVC.swift
//  TruthAlibi
//
//  Created by Nap Works on 18/02/23.
//

import UIKit

class VerificationVC: BaseViewController,UITextFieldDelegate {
    
    let TAG = String(describing: VerificationVC.self)
    
    var email = "",calledFrom=""
    
    @IBOutlet weak var verifyView: UIView!
    @IBOutlet weak var verifyButton: UIButton!
    @IBOutlet weak var verificationTitle: UILabel!
    @IBOutlet weak var resendButton: UIButton!
    
    @IBOutlet weak var firstTextField: UITextField!
    @IBOutlet weak var secondTextField: UITextField!
    @IBOutlet weak var thirdTextField: UITextField!
    @IBOutlet weak var fourthTextField: UITextField!
    @IBOutlet weak var fifthTextField: UITextField!
    @IBOutlet weak var sixthTextField: UITextField!
    
    @IBOutlet weak var firstView: UIView!
    @IBOutlet weak var secondView: UIView!
    @IBOutlet weak var thirdView: UIView!
    @IBOutlet weak var fourthView: UIView!
    @IBOutlet weak var fifthView: UIView!
    @IBOutlet weak var sixthView: UIView!
    
    var viewModel : VerificationViewModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = VerificationViewModel(vc: self)
        setUI()
    }
    
    func setUI() {
        
        CommonMethods.setPlaceholderColor(textFields: [firstTextField,secondTextField,thirdTextField,fourthTextField,fifthTextField,sixthTextField], color: .darkGray)
        
        if Constants.FILL_STATIC_FORM{
            firstTextField.text = "1"
            secondTextField.text = "2"
            thirdTextField.text = "3"
            fourthTextField.text = "4"
            fifthTextField.text = "5"
            sixthTextField.text = "6"
        }
        
        verificationTitle.text="Enter your email verification code below "
        
        firstTextField.delegate = self
        secondTextField.delegate = self
        thirdTextField.delegate = self
        fourthTextField.delegate = self
        fifthTextField.delegate = self
        sixthTextField.delegate = self
        
        CommonMethods.roundParticularCornerFilled(uiView: verifyView, borderColor: .white, backgroundColor: .white, cornerRadius: 30.0, borderWidth: 0.0, corners: [.layerMaxXMinYCorner,.layerMinXMinYCorner])
        
        CommonMethods.roundCornerFilled(uiView: verifyButton, borderColor: .mainColor, backgroundColor: .mainColor, cornerRadius: 25.0, borderWidth: 0.0)
        
        
        CommonMethods.roundCornerStroke(uiview: firstView, borderWidth: 1.0, borderColor: .mainColor, cornerRadius: firstView.frame.size.width / 2)
        CommonMethods.roundCornerStroke(uiview: secondView, borderWidth: 1.0, borderColor: .mainColor, cornerRadius: secondView.frame.size.width / 2)
        CommonMethods.roundCornerStroke(uiview: thirdView, borderWidth: 1.0, borderColor: .mainColor, cornerRadius: thirdView.frame.size.width / 2)
        CommonMethods.roundCornerStroke(uiview: fourthView, borderWidth: 1.0, borderColor: .mainColor, cornerRadius: fourthView.frame.size.width / 2)
        CommonMethods.roundCornerStroke(uiview: fifthView, borderWidth: 1.0, borderColor: .mainColor, cornerRadius: fifthView.frame.size.width / 2)
        CommonMethods.roundCornerStroke(uiview: sixthView, borderWidth: 1.0, borderColor: .mainColor, cornerRadius: sixthView.frame.size.width / 2)
        setTextChangeTarget(textField: firstTextField)
        setTextChangeTarget(textField: secondTextField)
        setTextChangeTarget(textField: thirdTextField)
        setTextChangeTarget(textField: fourthTextField)
        setTextChangeTarget(textField: fifthTextField)
        setTextChangeTarget(textField: sixthTextField)
        
        //        updateUI()
    }
    
    func setTextChangeTarget(textField : UITextField) {
        textField.addTarget(self, action: #selector(onChangeTextField(_:)), for: .editingChanged)
    }
    
    @objc private func onChangeTextField(_ textField: UITextField) {
        CommonMethods.showLog(TAG, "onChangeTextField")
        switch textField {
        case firstTextField:
            changeTextFieldFocus(previousTextField: firstTextField, currentTextField: firstTextField, nextTextField: secondTextField)
            break
        case secondTextField:
            changeTextFieldFocus(previousTextField: firstTextField, currentTextField: secondTextField, nextTextField: thirdTextField)
            break
        case thirdTextField:
            changeTextFieldFocus(previousTextField: secondTextField, currentTextField: thirdTextField, nextTextField: fourthTextField)
            break
        case fourthTextField:
            changeTextFieldFocus(previousTextField: thirdTextField, currentTextField: fourthTextField, nextTextField: fifthTextField)
            break
        case fifthTextField:
            changeTextFieldFocus(previousTextField: fourthTextField, currentTextField: fifthTextField, nextTextField: sixthTextField)
            break
        case sixthTextField:
            changeTextFieldFocus(previousTextField: fifthTextField, currentTextField: sixthTextField, nextTextField: sixthTextField)
            break
        default:
            break
        }
        //        updateUI()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let maxLength = 1
        let currentString: NSString = textField.text! as NSString
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
    }
    
    func changeTextFieldFocus(previousTextField : UITextField, currentTextField : UITextField, nextTextField : UITextField) {
        currentTextField.resignFirstResponder()
        if let text = currentTextField.text{
            if text.count == 0{
                previousTextField.becomeFirstResponder()
            }else{
                nextTextField.becomeFirstResponder()
            }
        }else{
            previousTextField.becomeFirstResponder()
        }
    }
    
    
    @IBAction func backButtonPressed(_ sender: Any) {
        CommonMethods.dismiss(vc: self)
    }
    
    
    @IBAction func resendButtonPressed(_ sender: Any) {
        viewModel?.resendOtp()
    }
    
    @IBAction func verifyButtonPressed(_ sender: Any) {
        CommonMethods.showLog(TAG, "verifyButtonPressed")
        do{
            try viewModel?.validate()
            viewModel?.verifyOtpLogin()
        }
        catch let error as VerificationViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }
}
