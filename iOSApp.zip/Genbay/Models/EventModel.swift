//
//  EventModel.swift
//  Genbay
//
//  Created by Nap Works on 30/03/23.
//

import Foundation


class EventModel: Codable {
    var id: String?
    var name: String?
    var visibleTo: [String]?
    var selectedCrowds: [String]?
    var selectedMembers: [String]?
    var goingList: [String]?
    var date: String?
    var dateTimestamp: Double?
    var startTime: String?
    var startTimestamp: Double?
    var pollVotingDeadlineTime : String?
    var pollVotingDeadlineTimestamp: Double?
    var datePollList: [DatePollModel]?
    var locationList: [Location]?
    var location:String?
    var description: String?
    var userId: String?
    var createdAt: Double?
    var updatedAt: Double?
    var isDateConfirmed: Bool?
    var isLocationConfirmed: Bool?
    var isDatePollCreated: Bool?
    var isLocationPollCreated: Bool?
    var isVisibleToAllSelected: Bool?
    var hostName: String?
    var commentList : [CommentModel]?
    var pendingCoHostInvites: [String]?
    var acceptedCoHostInvites: [String]?
    
    enum CodingKeys: CodingKey {
        case id
        case name
        case visibleTo
        case selectedCrowds
        case selectedMembers
        case goingList
        case date
        case dateTimestamp
        case startTime
        case startTimestamp
        case pollVotingDeadlineTime
        case pollVotingDeadlineTimestamp
        case datePollList
        case locationList
        case location
        case description
        case userId
        case createdAt
        case updatedAt
        case isDateConfirmed
        case isLocationConfirmed
        case isDatePollCreated
        case isLocationPollCreated
        case isVisibleToAllSelected
        case commentList
        case pendingCoHostInvites
        case acceptedCoHostInvites
        case hostName
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(String.self, forKey: .id)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        visibleTo = try container.decodeIfPresent([String].self, forKey: .visibleTo)
        selectedCrowds = try container.decodeIfPresent([String].self, forKey: .selectedCrowds)
        selectedMembers = try container.decodeIfPresent([String].self, forKey: .selectedMembers)
        goingList = try container.decodeIfPresent([String].self, forKey: .goingList)
        date = try container.decodeIfPresent(String.self, forKey: .date)
        dateTimestamp = try container.decodeIfPresent(Double.self, forKey: .dateTimestamp)
        startTime = try container.decodeIfPresent(String.self, forKey: .startTime)
        startTimestamp = try container.decodeIfPresent(Double.self, forKey: .startTimestamp)
        pollVotingDeadlineTime = try container.decodeIfPresent(String.self, forKey: .pollVotingDeadlineTime)
        pollVotingDeadlineTimestamp = try container.decodeIfPresent(Double.self, forKey: .pollVotingDeadlineTimestamp)
        datePollList = try container.decodeIfPresent([DatePollModel].self, forKey: .datePollList)
        locationList = try container.decodeIfPresent([Location].self, forKey: .locationList)
        location = try container.decodeIfPresent(String.self, forKey: .location)
        description = try container.decodeIfPresent(String.self, forKey: .description)
        userId = try container.decodeIfPresent(String.self, forKey: .userId)
        hostName = try container.decodeIfPresent(String.self, forKey: .hostName)
        createdAt = try container.decodeIfPresent(Double.self, forKey: .createdAt)
        updatedAt = try container.decodeIfPresent(Double.self, forKey: .updatedAt)
        isDateConfirmed = try container.decodeIfPresent(Bool.self, forKey: .isDateConfirmed)
        isLocationConfirmed = try container.decodeIfPresent(Bool.self, forKey: .isLocationConfirmed)
        isDatePollCreated = try container.decodeIfPresent(Bool.self, forKey: .isDatePollCreated)
        isLocationPollCreated = try container.decodeIfPresent(Bool.self, forKey: .isLocationPollCreated)
        isVisibleToAllSelected = try container.decodeIfPresent(Bool.self, forKey: .isVisibleToAllSelected)
        commentList = try container.decodeIfPresent([CommentModel].self, forKey: .commentList)
        pendingCoHostInvites = try container.decodeIfPresent([String].self, forKey: .pendingCoHostInvites)
        acceptedCoHostInvites = try container.decodeIfPresent([String].self, forKey: .acceptedCoHostInvites)
    }
    
    init(){
        
    }
    
    var commentParameters: [String: Any] {
        var commentsArray: [[String: Any]] = []
        
        if let commentList = commentList {
            for commentModel in commentList {
                commentsArray.append(commentModel.commentParameters)
            }
        }
        
        return [
            "commentList": commentsArray
        ]
    }
    
    var createEventParameters: [String: Any] {
        var locationArray: [[String: Any]] = []
        
        if let locationList = locationList {
            for location in locationList {
                locationArray.append(location.firebaseLocationParameters)
            }
        }
        
        var dateArray: [[String: Any]] = []
        
        if let dateList = datePollList {
            for date in dateList {
                dateArray.append(date.firebaseDateParameters)
            }
        }
        
        
        return [
            "id": id ?? "",
            "name": name ?? "",
            "selectedCrowds": selectedCrowds ?? [],
            "selectedMembers": selectedMembers ?? [],
            "pendingCoHostInvites": pendingCoHostInvites ?? [],
            "acceptedCoHostInvites": acceptedCoHostInvites ?? [],
            "goingList": goingList ?? [],
            "date": date ?? "0",
            "dateTimestamp": Int(dateTimestamp ?? 0),
            "startTime": startTime ?? "",
            "startTimestamp": Int(startTimestamp ?? 0),
            "pollVotingDeadlineTime": pollVotingDeadlineTime ?? "",
            "pollVotingDeadlineTimestamp": Int(pollVotingDeadlineTimestamp ?? 0),
//            "datePollList": dateArray,
//            "locationList": locationArray,
            "location": location ?? "",
            "description": description ?? "",
            "userId": userId ?? "",
            "createdAt": Int(createdAt ?? Date().timeIntervalSince1970),
            "updatedAt": Int(updatedAt ?? Date().timeIntervalSince1970),
            "isDateConfirmed":isDateConfirmed ?? false,
            "isLocationConfirmed":isLocationConfirmed ?? false,
            "isVisibleToAllSelected":isVisibleToAllSelected ?? false,
            "isDatePollCreated":isDatePollCreated ?? false,
            "isLocationPollCreated":isLocationPollCreated ?? false
        ]
    }
    
    var createDatePollParameters: [String: Any] {
        var dateArray: [[String: Any]] = []
        
        if let dateList = datePollList {
            for date in dateList {
                dateArray.append(date.firebaseDateParameters)
            }
        }
        
        
        return [
            "datePollList": dateArray,
        ]
    }
    
    var createLocationPollParameters: [String: Any] {
        var locationArray: [[String: Any]] = []
        
        if let locationList = locationList {
            for location in locationList {
                locationArray.append(location.firebaseLocationParameters)
            }
        }
        
        
        return [
            "locationPollList": locationArray,
        ]
    }


}


struct Location: Codable {
    var id: String?
    var location:String?
    var vote : Int?
    var userList : [String]?
    
//    var fullAddress: String?
//    var latitude: Double?
//    var longitude: Double?
    
    enum CodingKeys: CodingKey {
        case id
        case location
        case vote
        case userList
//        case fullAddress
//        case latitude
//        case longitude
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(String.self, forKey: .id)
        location = try container.decodeIfPresent(String.self, forKey: .location)
        vote = try container.decodeIfPresent(Int.self, forKey: .vote)
        userList = try container.decodeIfPresent([String].self, forKey: .userList)
//        fullAddress = try container.decodeIfPresent(String.self, forKey: .fullAddress)
//        latitude = try container.decodeIfPresent(Double.self, forKey: .latitude)
//        longitude = try container.decodeIfPresent(Double.self, forKey: .longitude)
    }
    
    init(){
        
    }
    
    var firebaseLocationParameters: [String: Any] {
        return [
             "id": id ?? "",
             "location": location ?? "",
             "vote": vote ?? 0,
             "userList":userList ?? []
//             "fullAddress": fullAddress ?? "",
//             "latitude": Double(latitude ?? 0.0),
//             "longitude": Double(longitude ?? 0.0)
        ]
    }
}

struct DatePollModel: Codable {
    var id: String?
    var date: String?
    var dateTimestamp: Double?
    var vote: Int?
    var userList:[String]?
    
    enum CodingKeys: CodingKey {
        case id
        case date
        case dateTimestamp
        case vote
        case userList
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(String.self, forKey: .id)
        date = try container.decodeIfPresent(String.self, forKey: .date)
        dateTimestamp = try container.decodeIfPresent(Double.self, forKey: .dateTimestamp)
        vote = try container.decodeIfPresent(Int.self, forKey: .vote)
        userList = try container.decodeIfPresent([String].self, forKey: .userList)
    }
    
    init(){
        
    }
    
    init(date:String,dateTimestamp:Double,vote:Int,userList:[String]){
        self.date = date
        self.dateTimestamp = dateTimestamp
        self.vote = vote
        self.userList = userList
    }
    
    var firebaseDateParameters: [String: Any] {
        return [
             "id": id ?? "",
             "date": date ?? "",
             "dateTimestamp": dateTimestamp ?? 0.0,
             "vote": Int(vote ?? 0),
             "userList":userList ?? []
        ]
    }
}

struct CommentModel: Codable {
    
    // MARK: - Properties
    
    var comment:String?
    var createdAt:Double?
    var userId:String?
    var commentId:String?
    var userModel:UserModel?
    var mentions: [String]?
    
    enum CodingKeys: String, CodingKey {

        case comment
        case createdAt
        case userId
        case commentId
        case userModel
        case mentions
    }
    
    init(){
        
    }
    
    init(comment: String, createdAt: Double, userId : String,userModel:UserModel, mentions: [String]){
    
        self.comment = comment
        self.createdAt = createdAt
        self.userId = userId
        self.userModel = userModel
        self.mentions = mentions
       
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        commentId = try container.decodeIfPresent(String.self, forKey: .commentId)
        comment = try container.decodeIfPresent(String.self, forKey: .comment)
        createdAt = try container.decodeIfPresent(Double.self, forKey: .createdAt)
        userId = try container.decodeIfPresent(String.self, forKey: .userId)
        userModel = try container.decodeIfPresent(UserModel.self, forKey: .userModel)
        mentions = try container.decodeIfPresent([String].self, forKey: .mentions)
    }
    
    var commentParameters: [String: Any] {
        return [
             "commentId": commentId ?? "",
             "comment": comment ?? "",
             "userId":userId ?? "",
             "createdAt": createdAt ?? 0.0,
             "mentions": mentions ?? []
        ]
    }

}
