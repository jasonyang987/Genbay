//
//  FriendsViewModel.swift
//  Genbay
//
//  Created by Nap Works on 04/05/23.
//

import Foundation

final class FriendsViewModel {
    let TAG = String(describing: FriendsViewModel.self)
    let vc: FriendsVC
    init(vc: FriendsVC){
        self.vc = vc
    }
    
    
    //MARK: - Method to remove unfriend user from selected members of the events of host.
    func getHostEventsAndRemoveUnfriendUserFromSelectedMembersAndGoingList(unFriendUserId: String, userId id: String, completion: @escaping (Bool, Error?) -> Void){
        let name = "\(self.vc.userData?.firstName ?? "") \(self.vc.userData?.lastName ?? "")"
        FirebaseAPI.default.getUpcomingHostEventFirestore(name:name, userId: id){list,error in
            if list.count == 0 {
                self.vc.hideProgressHUD()
            }else {
                list.forEach { eventModel in
                    eventModel.selectedMembers?.forEach({ id in
                        if id == unFriendUserId {
                            self.removeUnfriendUserFromEventSelectedMember(eventModel.id ?? "", clickedUserId: unFriendUserId) { success, error in
                                if success, error == nil {
                                    if let goingList = eventModel.goingList {
                                        if goingList.count > 0 {
                                            goingList.forEach({ id in
                                                if id == unFriendUserId {
                                                    self.removeUnfriendUserFromEventGoingList(eventModel.id ?? "", unfriendId: unFriendUserId) { success, error in
                                                        if success, error == nil {
                                                            self.removeUnfriendUserFromDateVotingOrLocationVoting(eventModel, unfriendUserId: unFriendUserId) { success, error in
                                                                if success, error == nil {
                                                                    self.vc.showDialog(title: Constants.APP_NAME, message: "Votes of user also removed!"){
                                                                        self.vc.hideProgressHUD()
                                                                    }
                                                                }else {
                                                                    self.vc.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "Some error occurred"){
                                                                        self.vc.hideProgressHUD()
                                                                    }
                                                                }
                                                            }
                                                        }else {
                                                            self.vc.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "Some error occurred"){
                                                                self.vc.hideProgressHUD()
                                                            }
                                                        }
                                                    }
                                                }else{
                                                    self.vc.hideProgressHUD()
                                                }
                                            })
                                        }else {
                                            self.vc.hideProgressHUD()
                                        }
                                    }else{
                                        self.vc.hideProgressHUD()
                                    }
                                    
                                }else {
                                    self.vc.showDialog(title: Constants.APP_NAME, message: "some error occurred")
                                }
                            }
                        }else {
                            self.vc.hideProgressHUD()
                        }
                    })
                }
            }
        }
    }
    
    func removeUnfriendUserFromEventSelectedMember(_ eventId: String, clickedUserId: String, completion: @escaping (Bool, Error?) -> Void){
        FirebaseAPI.default.removeUnfriendUserFromEventSelectedMembers(eventId, clickedUserId: clickedUserId) { success, error in
            if success, error == nil {
                completion(true, nil)
            }else {
                completion(false, error)
            }
        }
    }
    
    func removeUnfriendUserFromEventGoingList(_ eventId: String, unfriendId: String, completion: @escaping (Bool, Error?) -> Void){
        FirebaseAPI.default.removeUnfriendUserFromEventGoingList(eventId, clickedUserId: unfriendId) { success, error in
            if success, error == nil {
                completion(true, nil)
            }else {
                self.vc.hideProgressHUD()
                completion(false, error)
            }
        }
    }
    
    //MARK: - Single method to use methods of removing date vote and location vote of unfriend user on basis of creation of datepoll and location poll...
    func removeUnfriendUserFromDateVotingOrLocationVoting(_ eventModel: EventModel, unfriendUserId: String, completion: @escaping (Bool, Error?) -> Void){
        if let isDatePollCreated = eventModel.isDatePollCreated , let isLocationPollCreated = eventModel.isLocationPollCreated {
            ///if only date poll is created and location poll is not created, then this method will be triggered
            if isDatePollCreated && !isLocationPollCreated {
                self.removeUnfriendUserFromDateVoting(eventModel, unfriendUserId: unfriendUserId) { success, error in
                    if success, error == nil {
                        completion(true, nil)
                    }else{
                        completion(false, error)
                    }
                }
                ///if only location poll is created and date poll is not created, then this method will be triggered
            }else if !isDatePollCreated && isLocationPollCreated {
                self.removeUnfriendUserFromLocationVoting(eventModel, unfriendUserId: unfriendUserId) { success, error in
                    if success, error == nil {
                        completion(true, nil)
                    }else {
                       completion(false, error)
                    }
                }
                /// if both date poll and location poll is created, then both methods will be triggered, first removing date vote will be triggered, then after success of it, remove location vote will be triggered
            }else if isDatePollCreated && isLocationPollCreated {
                self.removeUnfriendUserFromDateVoting(eventModel, unfriendUserId: unfriendUserId) { success, error in
                    if success, error == nil {
                        self.removeUnfriendUserFromLocationVoting(eventModel, unfriendUserId: unfriendUserId) { success, error in
                            if success, error == nil {
                                completion(true, nil)
                            }else {
                                completion(false, error)
                            }
                        }
                    }else {
                        completion(false, error)
                    }
                }
            }else {
                self.vc.hideProgressHUD()
            }
        }else{
            self.vc.hideProgressHUD()
        }
    }
    
    //MARK: - Method to remove vote of unfriend user from date voting of host event...
    func removeUnfriendUserFromDateVoting(_ eventModel: EventModel, unfriendUserId: String, completion: @escaping (Bool, Error?) -> Void){
        FirebaseAPI.default.fetchDatePollList(eventModel.id ?? "") { datePollList in
            if let datePollList = datePollList {
                datePollList.forEach { datePollModel in
                    datePollModel.userList?.forEach({ id in
                        if id == unfriendUserId {
                            FirebaseAPI.default.removeVoteFromDatePollUserList(eventModel.id ?? "", dateId: datePollModel.id ?? "", userId: id) { success, error in
                                if success, error == nil {
                                    completion(true, nil)
                                }else {
                                    completion(false, error)
                                }
                            }
                        }else {
                            self.vc.hideProgressHUD()
                        }
                    })
                }
            }
        }
    }
    
    //MARK: - Method to remove vote of unfriend user from location voting of host event...
    func removeUnfriendUserFromLocationVoting(_ eventModel: EventModel, unfriendUserId: String, completion: @escaping (Bool, Error?) -> Void){
        FirebaseAPI.default.fetchLocationPollList(eventModel.id ?? "") { locationList in
            if let locationList = locationList {
                locationList.forEach { locationModel in
                    locationModel.userList?.forEach({ id in
                        if id == unfriendUserId {
                            FirebaseAPI.default.removeVoteFromLocationPollUserList(eventModel.id ?? "", locationId: locationModel.id ?? "", userId: id) { success, error in
                                if success, error == nil {
                                    completion(true, nil)
                                }else {
                                    completion(false, error)
                                }
                            }
                        }else {
                            self.vc.hideProgressHUD()
                        }
                    })
                }
            }
        }
    }
    
    func getCrowdsWithMembersOfUserAndRemoveUnfriendUser(_ clickedUserId: String){
        self.vc.showProgressHUD()
        FirebaseAPI.default.getCrowdsWithMembers(userId: self.vc.userData?.id ?? "") { crowdList in
            if let crowdList = crowdList {
                self.vc.hideProgressHUD()
                crowdList.forEach { crowdModel in
                    crowdModel.membersList?.forEach({ id in
                        if id == clickedUserId {
                            CommonMethods.showLog(self.TAG, "match id: \(id) with \(clickedUserId)")
                            crowdModel.membersList = crowdModel.membersList?.filter({$0 != id})
                            self.vc.showProgressHUD()
                            FirebaseAPI.default.updateMembersToCrowd(crowdId: crowdModel.id ?? "", membersList: crowdModel.membersList ?? []) { success, message in
                                if success {
                                    self.vc.hideProgressHUD()
                                    self.vc.showDialog(title: Constants.APP_NAME, message: "Friend also removed from the crowd you have created!"){
                                        self.getHostEventsAndRemoveUnfriendUserFromSelectedMembersAndGoingList(unFriendUserId: id, userId: self.vc.userData?.id ?? "") { success, error in
                                            if success, error == nil {
                                                self.vc.showDialog(title: Constants.APP_NAME, message: "Friend also removed from the event' selected members you have created!"){
                                                    FirebaseAPI.default.getGuestListFirestore(userIds: crowdModel.membersList?.filter({$0 != id}) ?? []) { guestList in
                                                        let updatedGuestList = guestList
                                                        NotificationCenter.default.post(name: .updatedGuestList, object: updatedGuestList)
                                                        
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }else {
                                    self.vc.showDialog(title: Constants.APP_NAME, message: message)
                                }
                            }
                        }
                    })
                }
            }
        }
    }
    
    func getCrowdsWithMembersOfUnfriendUserAndRemoveUser(_ clickedUserId: String){
        self.vc.showProgressHUD()
        FirebaseAPI.default.getCrowdsWithMembers(userId: clickedUserId) { crowdList in
            self.vc.hideProgressHUD()
            if let crowdList = crowdList {
                crowdList.forEach { crowdModel in
                    crowdModel.membersList?.forEach({ id in
                        if id == self.vc.userData?.id ?? ""{
                            crowdModel.membersList = crowdModel.membersList?.filter({$0 != id})
                            self.vc.showProgressHUD()
                            FirebaseAPI.default.updateMembersToCrowd(crowdId: crowdModel.id ?? "", membersList: crowdModel.membersList ?? []) { success, message in
                                if success {
                                    self.vc.hideProgressHUD()
                                    self.vc.showDialog(title: Constants.APP_NAME, message: "You have removed from the crowd that user created!"){
                                        self.getHostEventsAndRemoveUnfriendUserFromSelectedMembersAndGoingList(unFriendUserId: id, userId: clickedUserId) { success, error in
                                            if success, error == nil {
                                                self.vc.showDialog(title: Constants.APP_NAME, message: "You have also removed from the event' selected members that user has created!")
                                            }
                                        }
                                    }
                                }else {
                                    self.vc.showDialog(title: Constants.APP_NAME, message: message)
                                }
                            }
                        }
                    })
                }
            }
        }
    }
    
    func handleUserId(id1: String, id2: String){
//            self.vc.showProgressHUD()
            FirebaseAPI.default.getCrowdsWithMembers(userId: id1) { crowdList in
                if let crowdList = crowdList {
                    if crowdList.count > 0 {
                        crowdList.forEach { crowdModel in
                            crowdModel.membersList?.forEach({ id in
                                if id == id2{
                                    crowdModel.membersList = crowdModel.membersList?.filter({$0 != id})
                                    self.updateCrowdMembersAfterRemoveId(crowdModel.id ?? "",
                                                                    membersList: crowdModel.membersList ?? []) { success in
                                        if success {
                                            self.getHostEventsAndRemoveUnfriendUserFromSelectedMembersAndGoingList(unFriendUserId: id2, userId: id1) { success, error in
                                                if success, error == nil {
                                                    self.vc.showDialog(title: Constants.APP_NAME, message: "You have also removed from the event' selected members that user has created!"){
                                                        self.vc.hideProgressHUD()
                                                    }
                                                }
                                            }

                                        }else{
                                            self.vc.showDialog(title: Constants.APP_NAME, message: "Some Error occurred!"){
                                                self.vc.hideProgressHUD()
                                            }
                                        }
                                    }
                                }else {
                                    self.vc.hideProgressHUD()
                                }
                            })
                        }

                    }else {
                        self.vc.hideProgressHUD()
                    }
                }else {
                    self.vc.hideProgressHUD()
                }
            }
    }
    
    func updateCrowdMembersAfterRemoveId(_ crowdId: String, membersList: [String], completion: @escaping (Bool)->Void){
        FirebaseAPI.default.updateMembersToCrowd(crowdId: crowdId, membersList: membersList) { success, message in
            if success {
                    self.vc.showDialog(title: Constants.APP_NAME, message: "You have removed from the crowd that user created!"){
                        completion(true)
                    }
            }else {
                self.vc.showDialog(title: Constants.APP_NAME, message: message){
                    completion(false)
                }
              
            }
        }
    }
}
