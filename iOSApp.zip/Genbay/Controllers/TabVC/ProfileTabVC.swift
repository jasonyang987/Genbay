//
//  ProfileVC.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit
import Kingfisher
import MessageUI

class ProfileTabVC: BaseViewController, UINavigationControllerDelegate {
    let TAG = String(describing: ProfileTabVC.self)
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var cameraView: UIView!
    @IBOutlet weak var editNameButton: UIButton!
    @IBOutlet weak var changePasswordButton: UIButton!
    @IBOutlet weak var editNotificationSettingsButton: UIButton!
    @IBOutlet weak var feedBackButton: UIButton!
    
    @IBOutlet weak var logoutBtn: UIButton!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var name: UILabel!
    
    var userModel:UserModel?
       
    override func viewDidLoad() {
        super.viewDidLoad()
        userModel = UserDefaultsMapper.getUser()
        
        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(handleNotification(notification:)), name: .profileNotificationVC, object: nil)
        
        setUI()
        
    }
    
    func setUI(){
        userImageView.layer.cornerRadius = userImageView.frame.width / 2.0
        cameraView.layer.cornerRadius = cameraView.frame.height / 2.0
        
        editNameButton.underlineButton( text: "Edit Name")
        logoutBtn.underlineButton( text: "  Logout  ")
        changePasswordButton.underlineButton( text: "Change Password")
        editNotificationSettingsButton.underlineButton( text: "Edit Notification Settings")
        feedBackButton.underlineButton( text: "Give Feedback to Help Improve Genbay")
        
        let image = userModel?.imageUrl ?? ""
        if image != ""{
            userImageView.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.forceRefresh])
        }
        userName.text = userModel?.username ?? ""
        name.text = "\(userModel?.firstName ?? "") \(userModel?.lastName ?? "")"
        
    }
   
    @IBAction func editNameBtnPressed(_ sender: UIButton){
        CommonMethods.showLog(self.TAG, "editNameBtnPressed")
        Navigations.goToAddNameVC(calledFrom:Constants.PROFILE)
    }
    
    @IBAction func editNotificationSettingsBtnPressed(_ sender: UIButton){
        CommonMethods.showLog(self.TAG, "editNameBtnPressed")
        Navigations.goToNotificationSettingsVC(navigationController ?? UINavigationController())
    }
    
    @IBAction func logoutPressed(_ sender: Any) {
        self.showLogoutAlert(title: Constants.APP_NAME, message: "Are you sure you want to logout?") { alert in
            if self.userModel != nil{
                let tokens = self.userModel?.tokens ?? []
                if tokens.count > 0{
                    let currentToken = UserDefaultsMapper.getObject(key: .fcmToken) as? String ?? ""
                    self.userModel?.tokens = tokens.filter { $0 != currentToken}
                    if let userModel = self.userModel{
                        self.showProgressHUD()
                        FirebaseAPI.default.updateFCMToken(calledToAddToken: false) { success, error in
                            self.hideProgressHUD()
                            CommonMethods.logout(true)
                        }
                    }else{
                        CommonMethods.logout(true)
                    }
                }else{
                    CommonMethods.logout(true)
                }
            }else{
                CommonMethods.logout(true)
            }
        }
    }
    
    
    @IBAction func changePasswordBtnPressed(_ sender: UIButton){
        CommonMethods.showLog(self.TAG, "changePasswordBtnPressed")
        Navigations.goToChangePassword()
    }
    
    @IBAction func giveFeedbackBtnPressed(_ sender: UIButton){
        CommonMethods.showLog(self.TAG, "giveFeedbackBtnPressed")
        if let url = URL(string: Constants.FEEDBACK_URL) {
                if #available(iOS 10, *){
                    UIApplication.shared.open(url)
                }else{
                    UIApplication.shared.openURL(url)
                }

            }
//        sendEmail()
    }
     
    @IBAction func cameraBtnPressed(_ sender: UIButton) {
        CommonMethods.showLog(self.TAG, "cameraBtnPressed")
        Navigations.goToAddImageVC(calledFrom: Constants.PROFILE)
        
    }
    
    func sendEmail() {
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.delegate = self
            mail.setToRecipients(["contact@napworks.in"])
            present(mail, animated: true)
        }
        else {
            CommonMethods.showLog(TAG, "Error in Sending mail")
            showDialog(title:Constants.APP_NAME,message: "Mail services are not available")
        }
    }
    
    func handleNotificationData(_ updateType:String){
        CommonMethods.showLog(TAG, "handleNotificationData")
        userModel = UserDefaultsMapper.getUser()
        if updateType == Constants.IMAGE{
            let image = userModel?.imageUrl ?? ""
            if image != ""{
                userImageView.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
            }
        }
        userName.text = userModel?.username ?? ""
        name.text = "\(userModel?.firstName ?? "") \(userModel?.lastName ?? "")"
    }
    
}

extension ProfileTabVC{
    
    @objc func handleNotification(notification: NSNotification) {
        if let value = notification.userInfo as? [String : Any]{
            CommonMethods.showLog(TAG, "handleNotification value : \(value)")
            if let type = value["type"] as? String{
                if type == Constants.UPDATE_HOME{
                    if let updateType = value["updateType"] as? String{
                        handleNotificationData(updateType)
                    }
                    
                }
            }
        }
    }
    
}
