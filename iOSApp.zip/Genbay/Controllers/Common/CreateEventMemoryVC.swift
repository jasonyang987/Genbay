//
//  UploadMemoryVC.swift
//  Genbay
//
//  Created by Nap Works on 15/04/23.
//

import UIKit
import PhotosUI

protocol CreateEventMemoryVCDelegate: AnyObject {
    func getEventMemories()
}

class CreateEventMemoryVC: BaseViewController, UITextViewDelegate, MemoryPVCDelegate, UploadPopupVCDelegate {
    

    let TAG = String(describing: CreateEventMemoryVC.self)
    @IBOutlet weak var eventDescription: UITextView!
    @IBOutlet weak var uploadBtn: UIButton!
    @IBOutlet weak var pagerView: UIView!
    @IBOutlet weak var chooseBtn: UIButton!
    @IBOutlet weak var leftBtn: UIButton!
    @IBOutlet weak var rightBtn: UIButton!
    @IBOutlet weak var placeholderImageView: UIImageView!
    
    var image : UIImage?
    var calledFrom = ""
    
    private lazy var photoLibraryPickerController: UIImagePickerController = {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .photoLibrary
        pickerController.allowsEditing = true
        return pickerController
    }()
    
    private lazy var cameraPickerController: UIImagePickerController = {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .camera
        pickerController.cameraDevice = .front
        pickerController.allowsEditing = true
        return pickerController
    }()
    
    var pageVC: MemoryPVC?
    var currentIndex: Int = 0
    let placeholderText = "Write something about event memory (Optional)..."
    var viewModel:CreateEventMemoryViewModel?
    var eventModel: EventModel?
    var delegate: CreateEventMemoryVCDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        CommonMethods.roundCornerFilled(uiView: uploadBtn, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 20, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: chooseBtn, borderColor: .black, backgroundColor: .secondaryMainColor, cornerRadius: 20, borderWidth: 1)
        eventDescription.delegate = self
        eventDescription.returnKeyType = .done
        eventDescription.textColor = .darkGray
        eventDescription.text = placeholderText
        viewModel = CreateEventMemoryViewModel(vc: self)
        
        self.setupPageViewController()
        CommonMethods.showLog(TAG, "Camera : \(image)")
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if calledFrom == Constants.CAMERA{
            calledFrom = ""
            self.present(self.cameraPickerController, animated: true, completion: nil)
            
//            CommonMethods.showLog(TAG, "Camera : \(image)")
//            var imageList : [UIImage] = []
//            imageList.append(image ?? UIImage())
//            CommonMethods.showLog(TAG, "imageList : \(imageList.count)")
//            self.pageVC?.images = imageList
//
////            self.pageVC?.images = []
////            self.pageVC?.images?.append(image!)
//            CommonMethods.showLog(self.TAG, "images count: \(self.pageVC?.images?.count)")
//            if let images = self.pageVC?.images {
//                self.pageVC?.updateImages(self.pageVC?.images ?? [], direction: .forward, index: images.count - 1)
//                self.currentIndex = images.count - 1
//                self.pageVC?.changePage(direction: .forward, posiiton: self.currentIndex)
//                CommonMethods.showLog(self.TAG, "images count: \(images.count - 1)")
//            }
////            self.pageVC?.changePage(direction: .forward, posiiton: self.currentIndex)
//            if self.pageVC?.images?.count ?? 0 > 0 {
//                self.placeholderImageView.isHidden = true
//            }
        }
        CommonMethods.showLog(self.TAG, "viewWillAppear called")
    }
    
    //MARK: - This is a delegate method which is defined in MemoryImageVC and used to handle the conditions after deleting the image from the list of images. The main conditions are handled in MemoryPVC. here Only the current index is being handled.
    func setCurrentIndex(_ index: Int?) {
        if let index = index {
            CommonMethods.showLog(self.TAG, "index: \(index)")
            currentIndex = index
        }else {
            placeholderImageView.isHidden = false
        }
    }
    
    
    func setupPageViewController() {
        for view in self.pagerView.subviews {
            view.removeFromSuperview()
        }

        DispatchQueue.main.async {
            self.pageVC = MemoryPVC()
            self.pageVC?.indexDelegate = self
            let frame = self.pagerView.frame
            CommonMethods.showLog(self.TAG, "frame width : \(frame.width)")
            CommonMethods.showLog(self.TAG, "frame height : \(frame.height)")
            CommonMethods.showLog(self.TAG, "frame size : \(frame.size)")
            CommonMethods.showLog(self.TAG, "frame origin : \(frame.origin)")
            self.pageVC?.view.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.height)
            if let pageVC = self.pageVC{
                self.addChild(pageVC)
                self.pagerView.addSubview(pageVC.view)
                pageVC.didMove(toParent: self)
            }
        }
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == .darkGray {
            textView.text = nil
            textView.textColor = .black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = placeholderText
            textView.textColor = .darkGray
            
        }
    }
    
    func textViewDidChange(_ textView: UITextView) {
            if textView.text.isEmpty {
                invalidateTextView()
            } else {
                textView.textColor = UIColor.black
            }
        }
    
    
    @IBAction func backBtnPressed(_ sender: UIButton){
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func uploadBtnPressed(_ sender: UIButton){
     
        do{
            try viewModel?.validate()
            viewModel?.createEventMemory()
        }
        catch let error as CreateEventMemoryViewModel.ValidationError{
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
        catch {
            CommonMethods.showLog(TAG, "\(error.localizedDescription)")
            showDialog(title:Constants.APP_NAME,message:error.localizedDescription)
        }
    }
    
    @IBAction func chooseBtnPressed(_ sender: UIButton){
        
        Navigations.showUploadPopupVC(viewController: self, delegate: self)
        
//        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else { return }
//        self.present(self.photoLibraryPickerController, animated: true, completion: nil)
    }
    
    func pushToUploadMemoryVC(vc: UIViewController, image: UIImage, calledFrom: String) {
        vc.dismiss(animated: true) {
            self.pageVC?.images?.append(image)
            if let images = self.pageVC?.images {
                self.pageVC?.updateImages(self.pageVC?.images ?? [], direction: .forward, index: images.count - 1)
                self.currentIndex = images.count - 1
                self.pageVC?.changePage(direction: .forward, posiiton: self.currentIndex)
                CommonMethods.showLog(self.TAG, "images count: \(images.count - 1)")
            }
    //            self.pageVC?.changePage(direction: .forward, posiiton: self.currentIndex)
            if self.pageVC?.images?.count ?? 0 > 0 {
                self.placeholderImageView.isHidden = true
            }
        }
        
    }
    
    
    @IBAction func leftBtnPressed(_ sender: UIButton){
        if let images = pageVC?.images {
            if currentIndex > 0 {
                currentIndex -= 1
                CommonMethods.showLog(self.TAG, "currentIndexLeft: \(currentIndex)")
                pageVC?.changePage(direction: .reverse, posiiton: currentIndex)
                if currentIndex == 0 {
                    CommonMethods.showLog(self.TAG, "zero")
                    return
                }
            } else {
                currentIndex = images.count - 1
                pageVC?.changePage(direction: .reverse, posiiton: currentIndex)
                CommonMethods.showLog(self.TAG, "can't do this")
                return
            }
        }

    }
    
    @IBAction func rightBtnPressed(_ sender: UIButton){
        if let images = pageVC?.images {
            if images.count > 1 {
                if currentIndex < images.count - 1 {
                    currentIndex+=1
                    CommonMethods.showLog(self.TAG, "currentIndex Right: \(currentIndex)")
                    pageVC?.changePage(direction: .forward, posiiton: currentIndex)
                    if currentIndex == images.count - 1 {
                        CommonMethods.showLog(self.TAG, "reached")
                        return
                    }
                } else {
                    currentIndex = 0
                    pageVC?.changePage(direction: .forward, posiiton: currentIndex)
                    return
                }
            }
        }
        
     
    }
    
     func invalidateTextView(){
        self.eventDescription.text = self.placeholderText
        self.eventDescription.resignFirstResponder()
        self.eventDescription.textColor = .darkGray
    }
    
}

        
extension CreateEventMemoryVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        CommonMethods.showLog(self.TAG, "Image Captured")
        guard let image = info[.editedImage] as? UIImage
            ?? info[.originalImage] as? UIImage else { return }
        dismiss(animated: true) {
            CommonMethods.showLog(self.TAG, "images count gallery : \(self.pageVC?.images?.count)")
            self.pageVC?.images?.append(image)
            if let images = self.pageVC?.images {
                self.pageVC?.updateImages(self.pageVC?.images ?? [], direction: .forward, index: images.count - 1)
                self.currentIndex = images.count - 1
                self.pageVC?.changePage(direction: .forward, posiiton: self.currentIndex)
                CommonMethods.showLog(self.TAG, "images count: \(images.count - 1)")
            }
//            self.pageVC?.changePage(direction: .forward, posiiton: self.currentIndex)
            if self.pageVC?.images?.count ?? 0 > 0 {
                self.placeholderImageView.isHidden = true
            }
        }
    }}
