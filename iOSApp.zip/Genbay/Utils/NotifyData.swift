//
//  NotifyData.swift
//  TruthAlibi
//
//  Created by Nap Works on 22/02/23.
//

import Foundation

class NotifyData{
    static func notifyProfileNotification(updateType:String){
        let nc = NotificationCenter.default
        let data : [String: Any] = ["type": Constants.UPDATE_HOME,"updateType":updateType]
        nc.post(name: .profileNotificationVC, object: nil, userInfo: data)
    }
    
    static func notifyHomeFromAppDelegate(){
        let nc = NotificationCenter.default
        let data : [String: Any] = ["type": Constants.UPDATE_HOME_FROM_APP_DELEGATE]
        nc.post(name: .homeNotificationVC, object: nil, userInfo: data)
    }
    
    static func notifyHomeFromNotification(){
        let nc = NotificationCenter.default
        let data : [String: Any] = ["type": Constants.HANDLE_NOTIFICATION]
        nc.post(name: .handleCloudNotification, object: nil, userInfo: data)
    }
    
    static func notifyCrowdVC(crowdModel:CrowdModel){
        let nc = NotificationCenter.default
        let data : [String: Any] = ["type": Constants.UPDATE_CROWD,"crowdModel":crowdModel]
        nc.post(name: .crowdVC, object: nil, userInfo: data)
    }
    
    static func notifyEventVC(type:String,eventModel:EventModel){
        let nc = NotificationCenter.default
        let data : [String: Any] = ["type": type,"eventModel":eventModel]
        nc.post(name: .eventVC, object: nil, userInfo: data)
    }
    
    static func notifyCrowdDetailVC(actionType:String,selectedUsersList:[UserModel]){
        let nc = NotificationCenter.default
        let data : [String: Any] = ["type": Constants.UPDATE_CROWD_MEMBERS,
                                    "actionType":actionType,
                                    "selectedUsersList":selectedUsersList]
        nc.post(name: .crowdDetailVC, object: nil, userInfo: data)
    }
    
    static func notifyDriverHomeNotification(type:String){
        let nc = NotificationCenter.default
        let data : [String: Any] = ["type": type]
        nc.post(name: .driverHomeNotificationVC, object: nil, userInfo: data)
    }
    
    static func notifyDriverOrderDetailNotification(){
        let nc = NotificationCenter.default
        let data : [String: Any] = ["type": Constants.UPDATE_LOCATION]
        nc.post(name: .driverOrderDetailVC, object: nil, userInfo: data)
    }
    
    static func notifyFriendRequests(){
        let nc = NotificationCenter.default
        nc.post(name: .friendRequestNotification, object: nil)
    }
    
//    static func notifyAdminHomeNotification(type:String,driverModel:DriverModel?,salesId:String){
//        print("notifyAdminHomeNotification")
//        let nc = NotificationCenter.default
//        let data : [String: Any] = ["type": type,"driverData": driverModel ?? DriverModel(),"salesId":salesId]
//        nc.post(name: .adminHomeNotificationVC, object: nil, userInfo: data)
//    }
}
