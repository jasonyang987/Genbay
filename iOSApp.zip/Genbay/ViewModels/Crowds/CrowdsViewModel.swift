//
//  CrowdsViewModel.swift
//  Genbay
//
//  Created by Nap Works on 28/08/23.
//

import Foundation

final class CrowdsViewModel {
    let TAG = String(describing: CrowdsViewModel.self)
    var vc: CrowdsVC
    init(vc: CrowdsVC) {
        self.vc = vc
    }
    
    //there are some steps have to follow while deleting a crowd
    ///1. Delete crowd from the realtime database crowds collection
    ///2. Delete that crowd from the events selected crowds
    ///3. Delete all the members of the deleted crowd from the events selected members
    ///4. Delete all the votes in date poll list and location list given by the selected members of the deleted crowd
    ///5. Delete all the selected members from the going list of the event who was in the crowd that is deleted..
    func deleteCrowdFromDatabase(_ model: CrowdModel){
        vc.showProgressHUD()
        FirebaseAPI.default.deleteCrowd(crowdId: model.id ?? "") { error in
            if let error = error {
                self.vc.hideProgressHUD()
                self.vc.showDialog(title: Constants.APP_NAME, message: error.localizedDescription)
            }else {
                self.removeDeletedCrowdFromEventSelectedCrowd(model.id ?? "", crowdModel: model)
            }
        }
    }
    
    func removeDeletedCrowdFromEventSelectedCrowd(_ id: String, crowdModel: CrowdModel){
        let user = UserDefaultsMapper.getUser()
        let name = "\(user?.firstName ?? "") \(user?.lastName ?? "")"
        FirebaseAPI.default.getAllHostEventFirestore(name: name, userId: user?.id ?? "") { list, error in
            if list.count > 0 {
                list.forEach { model in
                    if let selectedCrowds = model.selectedCrowds, selectedCrowds.count > 0 {
                        if selectedCrowds.contains(id){
                            FirebaseAPI.default.removeFromSelectedCrowds(model.id ?? "", crowdId: id) { success, error in
                                if let error = error {
                                    self.vc.hideProgressHUD()
                                    self.vc.showDialog(title: Constants.APP_NAME, message: error.localizedDescription)
                                }else {
                                    self.removeMembersFromSelectedMember(of: model, crowdModel: crowdModel) { success in
                                        if success {
                                            self.vc.hideProgressHUD()
//                                            self.removeMembersFromGoingList(of: model, crowdModel: crowdModel) { success in
//                                                if success {
//                                                    self.removeMembersFromDatePollList(of: model, crowdModel: crowdModel) { success in
//                                                        if success {
//                                                            self.removeMembersFromLocationPollList(of: model, crowdModel: crowdModel) { success in
//                                                                if success {
//                                                                    self.vc.hideProgressHUD()
////                                                                    self.showMessageAndFilterCrowds(id: id)
//                                                                }
//                                                            }
//                                                        }
//                                                    }
//                                                }
//                                            }
                                        }
                                    }
                                }
                            }
                        }else {
                            self.vc.hideProgressHUD()
                        }
                       
                    }else {
                        self.vc.hideProgressHUD()
//                        self.showMessageAndFilterCrowds(id: id)
                    }
                }
            }
            else {
                self.vc.hideProgressHUD()
//                self.showMessageAndFilterCrowds(id: id)
            }
            
            self.vc.hideProgressHUD()
            self.showMessageAndFilterCrowds(id: id)
        }
    }

    func removeMembersFromSelectedMember(of model: EventModel, crowdModel: CrowdModel, completion: @escaping (Bool) -> Void) {
        if let selectedMembers = model.selectedMembers, selectedMembers.count > 0 {
            var membersToRemove: [String] = []

            for memberId in selectedMembers {
                if !isMemberPresentInOtherCrowds(memberId: memberId, crowds: vc.crowdList, excluding: crowdModel) {
                    membersToRemove.append(memberId)
                }
            }

            for memberId in membersToRemove {
                FirebaseAPI.default.removeFromSelectedMembers(model.id ?? "", memberId: memberId) { success, error in
                    if let error = error {
                        completion(false)
                    } else {
                        completion(true)
                    }
                }
            }
        }
    }
    
    func removeMembersFromGoingList(of model: EventModel, crowdModel: CrowdModel, completion: @escaping (Bool) -> Void){
        if let goingList = model.goingList, goingList.count > 0 {
            var membersToRemove: [String] = []
            for memberId in crowdModel.membersList ?? [] {
                if goingList.contains(memberId),
                   !isMemberPresentInOtherCrowds(memberId: memberId, crowds: vc.crowdList, excluding: crowdModel) {
                    membersToRemove.append(memberId)
                }
            }
            for memberId in membersToRemove {
                FirebaseAPI.default.removeFromGoingList(model.id ?? "", memberId: memberId) { success, error in
                    if let error = error {
                        completion(false)
                    }else {
                        completion(true)
                    }
                }
            }
        }
    }
    
    func removeMembersFromDatePollList(of model: EventModel, crowdModel: CrowdModel, completion: @escaping (Bool) -> Void){
        if let datePollList = model.datePollList, datePollList.count > 0 {
            var membersToRemove: [String] = []
            for memberId in crowdModel.membersList ?? [] {
                for datePollModel in datePollList {
                    if let users = datePollModel.userList, users.contains(memberId),
                       !isMemberPresentInOtherCrowds(memberId: memberId, crowds: vc.crowdList, excluding: crowdModel) {
                        membersToRemove.append(memberId)
                    }
                }
            }
            for memberId in membersToRemove {
                datePollList.forEach { datePollModel in
                    if let users = datePollModel.userList, users.count > 0 {
                        if users.contains(memberId){
                            FirebaseAPI.default.removeVoteFromDatePollUserList(model.id ?? "", dateId: datePollModel.id ?? "", userId: memberId) { success, error in
                                if let error = error {
                                   completion(false)
                                }else {
                                  completion(true)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    func removeMembersFromLocationPollList(of model: EventModel, crowdModel: CrowdModel, completion: @escaping (Bool) -> Void){
        if let locationPollList = model.locationList, locationPollList.count > 0 {
            var membersToRemove: [String] = []

            for memberId in crowdModel.membersList ?? [] {
                for locationPollModel in locationPollList {
                    if let users = locationPollModel.userList, users.contains(memberId),
                       !isMemberPresentInOtherCrowds(memberId: memberId, crowds: vc.crowdList, excluding: crowdModel) {
                        membersToRemove.append(memberId)
                    }
                }
            }
            
            for memberId in membersToRemove {
                locationPollList.forEach { locationPollModel in
                    if let users = locationPollModel.userList, users.count > 0 {
                        if users.contains(memberId){
                            FirebaseAPI.default.removeVoteFromLocationPollUserList(model.id ?? "", locationId: locationPollModel.id ?? "", userId: memberId) { success, error in
                                if let error = error {
                                   completion(false)
                                }else {
                                  completion(true)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    func isMemberPresentInOtherCrowds(memberId: String, crowds: [CrowdModel], excluding crowdToExclude: CrowdModel) -> Bool {
        for crowd in crowds {
            if crowd !== crowdToExclude, let members = crowd.membersList, members.contains(memberId) {
                return true
            }
        }
        return false
    }
    
    func showMessageAndFilterCrowds(id deletedCrowdId: String){
        self.vc.showDialog(title: Constants.APP_NAME, message: "Crowd Deleted Successfully!") {
            self.vc.crowdList = self.vc.crowdList.filter({$0.id ?? "" != deletedCrowdId})
            self.vc.tableView.reloadData()
        }
    }

}
