//
//  Date.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import Foundation

extension Date {
    var formattedDateString: String {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "EEEE MM/dd/yyyy"
            return dateFormatter.string(from: self)
        }
    
    var formattedString: String {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "h:mm a EEEE MM/dd/yyyy"
            return dateFormatter.string(from: self)
        }
    
    var formattedTimeString: String {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "h:mm a"
            return dateFormatter.string(from: self)
        }
    
    var formattedMonthYearString: String {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            return dateFormatter.string(from: self)
        
    }
    
    var defaultFormattedString: String {
          let dateFormatter = DateFormatter()
          dateFormatter.dateFormat = "yyyy-MM-dd"
          return dateFormatter.string(from: self)
      }

}
