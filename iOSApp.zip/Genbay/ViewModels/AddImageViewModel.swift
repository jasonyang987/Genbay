//
//  AddImageViewModel.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class AddImageViewModel{
    let TAG = String(describing: AddImageViewModel.self)
    var vc : AddImageVC
    
    
    
    init(vc: AddImageVC) {
        self.vc = vc
    }
    
   
    func checkAndUploadData(){
        if self.vc.isImageSelected{
            self.vc.showProgressHUD()
            if let image = vc.userImage.image {
                let ref = FirebaseAPI.StorageRefenrenceType.userPicture
                CommonMethods.showLog(TAG, "REF : \(ref)")
                FirebaseAPI.default.upload(image: image, reference: ref) { (error, imageURLString) in
                    if let error = error {
                        CommonMethods.showLog(self.TAG, "Error : \(error)")
                        self.vc.hideProgressHUD()
                        self.vc.showDialog(title: Constants.APP_NAME,message: error.localizedDescription)
                    } else {
                        self.vc.userModel?.imageUrl = imageURLString
                        self.updateData(imageURLString ?? "")
                    }
                }
            }
        }
        else{
            var message = ""
            if self.vc.calledFrom == Constants.PROFILE{
                message = "Please choose picture to update profile picture."
            }
            else{
                message = "Please choose profile picture."
            }
            self.vc.showDialog(title: Constants.APP_NAME,message: message)
        }
    }
    
    func updateData(_ imageUrl:String){
        CommonMethods.showLog(TAG, "Image : \(imageUrl)")
        if let user = vc.userModel{
            FirebaseAPI.default.saveUser(user,Constants.IMAGE) { (success, error, user) in
                self.vc.hideProgressHUD()
                if success{
                    if let user = user {
                        do{
                            let notificationSettings = NotificationSettingsModel()
                            notificationSettings.muteAllPushNotifications = false
                            notificationSettings.friendRequests = true
                            notificationSettings.inviteToEvents = true
                            notificationSettings.eventAttendanceUpdates = true
                            notificationSettings.newEventMemories = true
                            notificationSettings.discussionComments = true
                            notificationSettings.mentions = true
                            user.notificationSettings = notificationSettings
                            var tokens : [String] = []
                            if let token = UserDefaultsMapper.getObject(key: .fcmToken) as? String{
                                tokens.append(token)
                            }
                            user.tokens = tokens
                            FirebaseAPI.default.saveUser(user, Constants.NOTIFICATION_SETTINGS) { success, error, userModel in
                                if let error = error {
                                    self.vc.showDialog(title: Constants.APP_NAME, message: error.localizedDescription)
                                }
                            }
                            try UserDefaultsMapper.saveUser(user)
                            self.vc.showDialog(title: Constants.APP_NAME, message: "You have successfully completed your profile") {
                                if self.vc.calledFrom == Constants.PROFILE{
                                    NotifyData.notifyProfileNotification(updateType: Constants.IMAGE)
                                    CommonMethods.dismiss(vc: self.vc)
                                }
                                else{
                                    Navigations.goToHome()
                                }
                            }
                            
                        }catch{
                            CommonMethods.showLog(self.TAG, "saveUser error : \(error.localizedDescription)")
                        }
                        
                    }
                }else{
                    if let error = error{
                        self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
                    }else{
                        self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                    }
                }
            }
        }
        else{
            CommonMethods.showLog(TAG, "Model is null")
        }
    }
}
