//
//  AppDelegate.swift
//  Genbay
//
//  Created by Nap Works on 28/03/23.
//

import UIKit
import IQKeyboardManager
import Firebase
import FirebaseMessaging
import EasyTipView
@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    let TAG = String(describing : AppDelegate.self)
    static var shared : AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    var window : UIWindow?
    var application : UIApplication?
    var mainNavController : UINavigationController?
    var secondaryNavController : UINavigationController?
    var friendList:[UserModel] = []
    var pendingList:[UserModel] = []
    var notificationList: [NotificationModel] = []
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        // Override point for customization after application launch.
        self.application = application
        FirebaseApp.configure()
        //        GMSServices.provideAPIKey(Constants.GOOGLE_MAP_API_KEY)
        //        GMSPlacesClient.provideAPIKey(Constants.GOOGLE_MAP_API_KEY)
        IQKeyboardManager.shared().isEnabled = true
        IQKeyboardManager.shared().toolbarTintColor = UIColor.mainColor
        
        
        CommonMethods.showLog(self.TAG, "didFinishLaunchingWithOptions Called")
        setupFirebase()
        
        let token = UserDefaultsMapper.getObject(key: .fcmToken)
        CommonMethods.showLog(self.TAG, "token is: \(token)")
        getFriends()
        getNotifications()
        
        //MARK: - setup preferences of easytipview
        var preferences = EasyTipView.Preferences()
        preferences.drawing.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        preferences.drawing.foregroundColor = UIColor.black
        preferences.drawing.backgroundColor = UIColor.white
        preferences.drawing.borderWidth = 1
        preferences.drawing.borderColor = UIColor.black
        preferences.drawing.arrowWidth = 0
        preferences.drawing.arrowHeight = 0
        preferences.animating.dismissDuration = 0
        EasyTipView.globalPreferences = preferences
        
        
        return true
    }
    
    func getFriends(){
        let userData = UserDefaultsMapper.getUser()
        if let userData = userData{
            
//            updateNotificationSettings(userData:userData)
            
            self.friendList = []
            self.pendingList = []
            FirebaseAPI.default.getFriends(userId: userData.id ?? ""){ acceptedList , pendingList in
                if let acceptedList = acceptedList,
                   let pendingList = pendingList {
                    self.friendList = acceptedList
                    self.pendingList = pendingList
                    self.friendList.forEach { item in
                        CommonMethods.showLog(self.TAG, "Friend Id : \(item.id)")
                    }
                    CommonMethods.showLog(self.TAG, "FriendList count : \(self.friendList.count)")
                    CommonMethods.showLog(self.TAG, "PendingList count : \(self.pendingList.count)")
                    NotifyData.notifyHomeFromAppDelegate()
                }
            }
        }
    }
    
//    func updateNotificationSettings(userData:UserModel){
//        if userData.notificationSettings == nil {
//            let notificationSettings = NotificationSettingsModel()
//            notificationSettings.muteAllPushNotifications = false
//            notificationSettings.friendRequests = true
//            notificationSettings.inviteToEvents = true
//            notificationSettings.eventAttendanceUpdates = true
//            notificationSettings.newEventMemories = true
//            notificationSettings.discussionComments = true
//            notificationSettings.mentions = true
//            userData.notificationSettings = notificationSettings
//            FirebaseAPI.default.saveUser(userData, Constants.NOTIFICATION_SETTINGS) { success, error, userModel in
//
//            }
//        }
//    }
//
    func getNotifications(){
        CommonMethods.showLog(self.TAG, "CallinggetNotifications")
        let userData = UserDefaultsMapper.getUser()
        CommonMethods.showLog(self.TAG, "UserData: \(userData)")
        if let userData = userData{
            self.notificationList = []
            FirebaseAPI.default.getNotificationsFirestore(userData.id ?? "") { notificationList in
                CommonMethods.showLog(self.TAG, "notifications: \(notificationList.count)")
                self.notificationList = notificationList.sorted{Double($0.info?.timeStamp ?? "") ?? 0 > Double($1.info?.timeStamp ?? "") ?? 0}
                NotificationCenter.default.post(name: .updatedNotificationsCount, object: notificationList)
            }
        }
    }
    
    func signoutUser(_ completion: ((Bool, String) -> Void)?) {
        CommonMethods.showLog(TAG, "signoutUser")
        UserDefaultsMapper.removeCurrentUserData()
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
            completion?(true, "")
        } catch let signOutError as NSError {
            CommonMethods.showLog(TAG, "Error signing out: \(signOutError)")
            completion?(false, signOutError.localizedDescription)
        }
    }
    
    // MARK: UISceneSession Lifecycle
    
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    
}

extension AppDelegate : UNUserNotificationCenterDelegate, MessagingDelegate{
    
    func setupFirebase(){
        if #available(iOS 10.0, *) {
            // For iOS 10 display notification (sent via APNS)
            UNUserNotificationCenter.current().delegate = self
            
            let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
            UNUserNotificationCenter.current().requestAuthorization(
                options: authOptions,
                completionHandler: {_, _ in })
        } else {
            let settings: UIUserNotificationSettings =
            UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application?.registerUserNotificationSettings(settings)
        }
        application?.registerForRemoteNotifications()
        Messaging.messaging().delegate = self
    }
    
    func refreshFCMToken(){
        Messaging.messaging().token { token, error in
            if let error = error {
                CommonMethods.showLog(self.TAG, "Error fetching FCM registration token: \(error)")
            } else if let token = token {
                CommonMethods.showLog(self.TAG, "FCM registration token: \(token)")
                self.handleFcmToken(token: token)
            }
        }
    }
    
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        CommonMethods.showLog(TAG, "didReceiveRegistrationToken token: \(String(describing: fcmToken))")
        if let fcmToken = fcmToken{
            handleFcmToken(token: fcmToken)
        }
    }
    
    func handleFcmToken(token : String){
        let lastToken = UserDefaultsMapper.getObject(key: .fcmToken) as? String ?? ""
        let isTokenUpdated = UserDefaultsMapper.getObject(key: .isTokenUpdated) as? Bool ?? false
        CommonMethods.showLog(TAG, "didReceiveRegistrationToken lastToken : \(lastToken)")
        CommonMethods.showLog(TAG, "didReceiveRegistrationToken isTokenUpdated : \(isTokenUpdated)")
        UserDefaultsMapper.save(token, forKey: .fcmToken)
        if lastToken != token{
            sendToServer()
        }else{
            CommonMethods.showLog(self.TAG, "updateFCMToken lastToken is same")
            if isTokenUpdated{
                CommonMethods.showLog(self.TAG, "updateFCMToken lastToken already updated")
            }else{
                sendToServer()
            }
        }
    }
    
    func sendToServer(){
        if UserDefaultsMapper.getUser() != nil {
            FirebaseAPI.default.updateFCMToken(calledToAddToken: true) { success, error in
                CommonMethods.showLog(self.TAG, "updateFCMToken success : \(success) error : \(error?.localizedDescription ?? "")")
                if success{
                    UserDefaultsMapper.save(true, forKey: .isTokenUpdated)
                }
            }
        }else{
            CommonMethods.showLog(self.TAG, "updateFCMToken getUser nil")
        }
    }
    
    // Receive displayed notifications for iOS 10 devices.
    // FOREGROUND NOTIFICATION
    
    //    func userNotificationCenter(_ center: UNUserNotificationCenter,
    //                                didReceive response: UNNotificationResponse,
    //                                withCompletionHandler completionHandler: @escaping () -> Void) {
    //        let userInfo = response.notification.request.content.userInfo,
    //        let userModel = UserDefaultsMapper.getUser()
    //        CommonMethods.showLog(TAG, "NOTIFICATION TAP : \(userInfo)")
    //
    //        completionHandler()
    //    }
    //
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions)
                                -> Void) {
        let userInfo = notification.request.content.userInfo
        CommonMethods.showLog(TAG, "FOREGROUND MESSAGE : \(userInfo)")
        UserDefaults.standard.setValue(false, forKey: "notifyTabTapped")
        let type = userInfo["type"] as? String
//        if type == Constants.EVENT_COMMENT_ADDED {
//            if let currentVC = UIApplication.topViewController() as? CommentsVC {
//                if let eventId = userInfo["eventId"] as? String{
//                    let userId = userInfo["userId"] as? String
//                     
//                    let model = CommentModel(comment: <#T##String#>, createdAt: <#T##Double#>, userId: <#T##String#>, userModel: <#T##UserModel#>, mentions: <#T##[String]#>)
//                }else{
//                    completionHandler([.alert, .badge, .sound])
//                }
//            }else{
//                completionHandler([.alert, .badge, .sound])
//            }
//        }
        getNotifications()
        completionHandler([.alert, .badge, .sound])
    }
    
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        
        CommonMethods.showLog(self.TAG, "userInfo: \(userInfo)")
        completionHandler(.newData)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        let userModel = UserDefaultsMapper.getUser()
        CommonMethods.showLog(TAG, "NOTIFICATION TAP : \(userInfo)")
        if let jsonString = CommonMethods.convertJsonToString(dic: userInfo){
            UserDefaultsMapper.save(jsonString, forKey: .notificationData)
            NotifyData.notifyHomeFromNotification()
        }
        completionHandler()
    }
    
    
    
    
}

extension UIApplication {
    class func topViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return topViewController(base: nav.visibleViewController)
        }
        if let tab = base as? UITabBarController {
            if let selected = tab.selectedViewController {
                return topViewController(base: selected)
            }
        }
        if let presented = base?.presentedViewController {
            return topViewController(base: presented)
        }
        return base
    }
}
