//
//  Label TVC.swift
//  Genbay
//
//  Created by Nap Works on 05/04/23.
//

import UIKit

class LabelTVC: UITableViewCell {

    @IBOutlet weak var titleText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(title:String){
        titleText.text = title
    }
    
}

