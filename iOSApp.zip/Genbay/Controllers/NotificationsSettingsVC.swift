//
//  NotificationsSettingsVC.swift
//  Genbay
//
//  Created by Nap Works on 22/08/23.
//

import UIKit

class NotificationsSettingsVC: BaseViewController {

    let TAG = String(describing: NotificationsSettingsVC.self)
    @IBOutlet weak var muteAllSwitch: UISwitch!
    @IBOutlet weak var friendRequestSwitch: UISwitch!
    @IBOutlet weak var inviteToEventsSwitch: UISwitch!
    @IBOutlet weak var eventAttendanceSwitch: UISwitch!
    @IBOutlet weak var newEventMemoriesSwitch: UISwitch!
    @IBOutlet weak var discussionSwitch: UISwitch!
    @IBOutlet weak var mentionsSwitch: UISwitch!
 
    override func viewDidLoad() {
        super.viewDidLoad()

        setUI()
    }
    
    func setUI(){
        
        [muteAllSwitch, friendRequestSwitch, inviteToEventsSwitch, eventAttendanceSwitch, newEventMemoriesSwitch, discussionSwitch, mentionsSwitch].forEach { customSwitch in
            if let mySwitch = customSwitch {
                CommonMethods.roundCornerStroke(uiview: mySwitch, borderWidth: 1.0, borderColor: .black, cornerRadius: 16)
            }
        }
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let user = UserDefaultsMapper.getUser()
        let notificationSettings = user?.notificationSettings
        let muteAllNotificationState = notificationSettings?.muteAllPushNotifications ?? false
        let friendRequestNotificationState = notificationSettings?.friendRequests ?? true
        let inviteToEventsNotificationState = notificationSettings?.inviteToEvents ?? true
        let eventAttendanceNotificationState = notificationSettings?.eventAttendanceUpdates ?? true
        let newEventMemoriesNotificationState = notificationSettings?.newEventMemories ?? true
        let discussionNotificationState = notificationSettings?.discussionComments ?? true
        let mentionsNotificationState = notificationSettings?.mentions ?? true
        
        muteAllSwitch.setOn(muteAllNotificationState, animated: true)
        friendRequestSwitch.setOn(friendRequestNotificationState, animated: true)
        inviteToEventsSwitch.setOn(inviteToEventsNotificationState, animated: true)
        eventAttendanceSwitch.setOn(eventAttendanceNotificationState, animated: true)
        newEventMemoriesSwitch.setOn(newEventMemoriesNotificationState, animated: true)
        discussionSwitch.setOn(discussionNotificationState, animated: true)
        mentionsSwitch.setOn(mentionsNotificationState, animated: true)
        
//        if muteAllNotificationState == true && friendRequestNotificationState == true &&
        
    }
    
    
    @IBAction func muteAllPressed(_ sender: UISwitch) {
        
        if let user = UserDefaultsMapper.getUser() {
            user.notificationSettings?.muteAllPushNotifications?.toggle()
//            let notMute = !(user.notificationSettings?.muteAllPushNotifications)!
            user.notificationSettings?.friendRequests = false
            user.notificationSettings?.inviteToEvents = false
            user.notificationSettings?.eventAttendanceUpdates = false
            user.notificationSettings?.newEventMemories = false
            user.notificationSettings?.discussionComments = false
            user.notificationSettings?.mentions = false
            friendRequestSwitch.setOn(false, animated: true)
            inviteToEventsSwitch.setOn(false, animated: true)
            eventAttendanceSwitch.setOn(false, animated: true)
            newEventMemoriesSwitch.setOn(false, animated: true)
            discussionSwitch.setOn(false, animated: true)
            mentionsSwitch.setOn(false, animated: true)
            saveUpdatedSettings(user)
        }
 
    }
    
    @IBAction func friendRequestsPressed(_ sender: UISwitch) {
        if let user = UserDefaultsMapper.getUser() {
            user.notificationSettings?.muteAllPushNotifications = false
            muteAllSwitch.setOn(false, animated: true)
            user.notificationSettings?.friendRequests?.toggle()
            saveUpdatedSettings(user)
        }
    }
    
    @IBAction func inviteToEventsPressed(_ sender: UISwitch) {
        if let user = UserDefaultsMapper.getUser() {
            user.notificationSettings?.muteAllPushNotifications = false
            muteAllSwitch.setOn(false, animated: true)
            user.notificationSettings?.inviteToEvents?.toggle()
            saveUpdatedSettings(user)
        }
    }
    
    @IBAction func eventAttendancePressed(_ sender: UISwitch) {
        if let user = UserDefaultsMapper.getUser() {
            user.notificationSettings?.muteAllPushNotifications = false
            muteAllSwitch.setOn(false, animated: true)
            user.notificationSettings?.eventAttendanceUpdates?.toggle()
            saveUpdatedSettings(user)
        }
    }
    
    @IBAction func newEventMemoriesPressed(_ sender: UISwitch) {
        if let user = UserDefaultsMapper.getUser() {
            user.notificationSettings?.muteAllPushNotifications = false
            muteAllSwitch.setOn(false, animated: true)
            user.notificationSettings?.newEventMemories?.toggle()
            saveUpdatedSettings(user)
        }
    }
    
    @IBAction func discussionPressed(_ sender: UISwitch) {
        if let user = UserDefaultsMapper.getUser() {
            user.notificationSettings?.muteAllPushNotifications = false
            muteAllSwitch.setOn(false, animated: true)
            user.notificationSettings?.discussionComments?.toggle()
            saveUpdatedSettings(user)
        }
    }
    
    @IBAction func mentionPressed(_ sender: UISwitch) {
        if let user = UserDefaultsMapper.getUser() {
            user.notificationSettings?.muteAllPushNotifications = false
            muteAllSwitch.setOn(false, animated: true)
            user.notificationSettings?.mentions?.toggle()
            saveUpdatedSettings(user)
        }
    }
    
    @IBAction func backBtnPressed(_ sender: UIButton){
        navigationController?.popViewController(animated: true)
    }
    
    func saveUpdatedSettings(_ user: UserModel){
        showProgressHUD()
        FirebaseAPI.default.saveUser(user, Constants.NOTIFICATION_SETTINGS) { success, error, model in
            self.hideProgressHUD()
            if success, error == nil {
                do {
                    try UserDefaultsMapper.saveUser(user)
                }catch {
                    self.showDialog(title: Constants.APP_NAME, message: error.localizedDescription)
                }
            }else {
                self.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "Some error occurred")
            }
        }
    }
}

