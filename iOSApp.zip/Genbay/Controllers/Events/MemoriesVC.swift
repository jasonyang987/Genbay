//
//  MemoriesVC.swift
//  Genbay
//
//  Created by Nap Works on 05/04/23.
//

import UIKit

class MemoriesVC: BaseViewController, UploadPopupVCDelegate, CreateEventMemoryVCDelegate {
 
    let TAG = String(describing: MemoriesVC.self)
    @IBOutlet weak var eventTitleLabel: UILabel!
    @IBOutlet weak var memoriesCollectionView: UICollectionView!
    @IBOutlet weak var uploadMemoryBtnView: UIView!
    @IBOutlet weak var uploadMemoryBtn: UIButton!
    @IBOutlet weak var noMemoriesView: UIView!
    var eventTitle: String = ""
    var eventDate: String = ""
    var calledFromDetail: Bool = false
    var eventModel: EventModel?
    var eventId : String?
    var eventMemoriesList: [EventMemoryModel] = []
    var viewModel: MemoryViewModel?
    var imagesList: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        if calledFromDetail {
            eventTitleLabel.text = "\(eventTitle) | \(eventDate)"
        }else {
            eventTitleLabel.isHidden = true
        }
        CommonMethods.roundCornerFilled(uiView: uploadMemoryBtnView,
                                        borderColor: .black,
                                        backgroundColor: .secondaryMainColor,
                                        cornerRadius: 20,
                                        borderWidth: 1)
        noMemoriesView.isHidden = true
        self.showProgressHUD()
        FirebaseAPI.default.getEventDataWithId(eventID: eventId ?? "") { error, model in
//            self.eventView.isHidden = false
            self.hideProgressHUD()
            if let model = model, error == nil {
                self.eventModel = model
                self.setUI()
               
            }else {
                self.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "")
            }
        }
      
    }
    
    private func setUI(){
       
        noMemoriesView.isHidden = true
        let nib = UINib(nibName: "MemoryCVC", bundle: nil)
        memoriesCollectionView.register(nib, forCellWithReuseIdentifier: "MemoryCVC")
        memoriesCollectionView.delegate = self
        memoriesCollectionView.dataSource = self
        
        var dateString = ""
        if eventModel?.isDateConfirmed ?? false{
            let date = Date(timeIntervalSince1970: eventModel?.dateTimestamp ?? 0.0)
    //        let date = Date(timeIntervalSince1970: TimeInterval(date) ?? TimeInterval())
             dateString = date.formattedMonthYearString
        }
        else{
            dateString = "DATE TBD"
        }
        eventTitleLabel.isHidden = false
        eventTitleLabel.text = "\(eventModel?.name ?? "") | \(dateString)"
       
        noMemoriesView.isHidden = true
        viewModel = MemoryViewModel(vc: self)
        viewModel?.getEventMemories()

    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//    }
    
    @IBAction func backBtnPressed(_ sender: UIButton){
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func uploadMemoryBtnPressed(_ sender: UIButton){
        Navigations.goToCreateEventMemory( model: self.eventModel, navigationController: self.navigationController, delegate: self,image:UIImage(),calledFrom:"")
//        Navigations.showUploadPopupVC(viewController: self, delegate: self)
    }
    
    func pushToUploadMemoryVC(vc: UIViewController,image:UIImage,calledFrom:String) {
        vc.dismiss(animated: true) {
            Navigations.goToCreateEventMemory( model: self.eventModel, navigationController: self.navigationController, delegate: self,image:image,calledFrom:calledFrom)
        }
    }
    
    func getEventMemories() {
        viewModel?.getEventMemories()
    }
    
}

extension MemoriesVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        Navigations.goToEventMemoryDetail(eventModel: eventMemoriesList[indexPath.row], navigationController: navigationController, index: indexPath.row)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return eventMemoriesList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MemoryCVC", for: indexPath) as? MemoryCVC else {
            return UICollectionViewCell()
        }
        
        cell.configure(with: eventMemoriesList[indexPath.row])
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width/3 - 10 - 15, height: (collectionView.frame.width/3 - 10 - 15) * 1.067)
    }
}
