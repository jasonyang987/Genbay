//
//  ForgotPasswordViewModel.swift
//  TruthAlibi
//
//  Created by Nap Works on 21/02/23.
//

import Foundation

final class ForgotPasswordViewModel{
    let TAG = String(describing: ForgotPasswordViewModel.self)
    var vc : ForgotPasswordVC
    
    init(vc: ForgotPasswordVC) {
        self.vc = vc
    }
    
    func validate() throws {
        if let email = vc.emailText.text {
            if email.trimAndCheckIsEmpty() {
                throw ValidationError.emailEmpty
            }
        } else {
            throw ValidationError.emailEmpty
        }
    }
        
    enum ValidationError: Error {
        case emailEmpty
        
        var localizedDescription: String {
            switch self {
            case .emailEmpty:
                return "Please enter email address"
            }
        }
    }
    
    
    func resetPassword(){
            vc.showProgressHUD()
            let email = vc.emailText.text?.trim() ?? ""
            FirebaseAPI.default.resetPassword(email: email) { success, error in
                self.vc.hideProgressHUD()
                if success{
                    self.vc.showDialog(title: Constants.APP_NAME, message: "Password reset link has been sent to \(email). Please follow instruction in the email to reset your password.", confirmation: {
                        CommonMethods.dismiss(vc: self.vc)
                    }, completion: nil)
//                    self.vc.showDialog(title : Constants.APP_NAME, message: "Password reset link has been sent to \(email). Please follow instruction in the email to reset your password.") {
//                        AppDelegate.shared.mainNavController?.popToRootViewController(animated: false)
//                    }
                }else{
                    if let error = error{
                        self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
                    }else{
                        self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                    }
                }
            }
        }

}

