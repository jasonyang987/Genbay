//
//  AddMembersTVC.swift
//  Genbay
//
//  Created by Nap Works on 07/04/23.
//

import UIKit

class AddMembersTVC: UITableViewCell {
    let TAG = String(describing: AddMembersTVC.self)

    @IBOutlet weak var selectedImageView: UIImageView!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var name: UILabel!
    
    var dataInCell : UserModel?
    var clickedPos : Int?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        userImage.layer.cornerRadius = userImage.frame.width/2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func configure(calledFrom:String,data : UserModel?,position:Int){
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        dataInCell = data
        clickedPos = position
//        self.delegate = delegate
        name.text = "\(dataInCell?.firstName ?? "") \(dataInCell?.lastName ?? "")"
        let image = dataInCell?.imageUrl ?? ""
        if image != ""{
            userImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
        
        
        
        if calledFrom == Constants.CROWD_DETAIL{
            selectedImageView.isHidden = true
        }
        else{
            if dataInCell?.isSelected ?? false{
                selectedImageView.image = UIImage(named: "friend_selected")
            }
            else{
                selectedImageView.image = UIImage(named: "friend_unselected")
            }
        }
        
        
    }
    
}
