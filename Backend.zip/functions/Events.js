var admin = require("firebase-admin");
const User = require("./User")
const Constants = require("./Constants");
const CommonMethods = require("./CommonMethods");
const FriendRequest = require("./FriendRequest");
const { user } = require("firebase-functions/v1/auth");
const notifications = admin.firestore().collection("notifications");

class Events {

  static getEventData(eventId, callback) {
    console.log("getEventData");
    const docRef = admin.firestore().collection("events").doc(eventId)
    docRef.get().then((doc) => {
      console.log("Data Aa gya");
      if (doc.exists) {
        let data = doc.data();
        console.log("Document data:", data);
        callback(true, data);
      } else {
        console.log("No such document!");
        callback(false, null);
      }
    }).catch((error) => {
      console.log("Error getting document:", error);
      callback(false, null);
    });
  }


  static getListOfEvents(userId, callback) {
    const userEventsRef = admin.firestore().collection("events")
      .where("dateTimestamp", ">", Date.now() / 1000).where("userId", "==", userId);

    userEventsRef.get()
      .then((querySnapshot) => {
        callback(true, querySnapshot);
      })
      .catch((error) => {
        console.error('Error getting documents: ', error);
        callback(false, null);
      });
  }


  static goingList(request, response, callback) {
    let eventId = request.body.eventId
    let userId = request.body.userId
    let type = request.body.type

    Events.getEventData(eventId, function (eventDataSuccess, eventData) {
      console.log("goingList eventDataSuccess : ", eventDataSuccess);
      if (eventDataSuccess) {
        console.log("goingList eventData is: ", eventData);
        let goingList = eventData.goingList || []

        if (!Array.isArray(goingList)) {
          goingList = [goingList]; // Convert to an array if it's not already one
        }

        FriendRequest.checkIfExistInList(goingList, userId, function (isExistInGoing) {
          console.log("ISExistInGoing : " + isExistInGoing)
          if (!isExistInGoing) {
            if (type == Constants.GOING) {
              goingList.push(userId)
              eventData.goingList = goingList
              const ref = admin.firestore().collection("events").doc(eventId);
              ref.set(eventData)

              let hosts = eventData.acceptedCoHostInvites || []

              if (!Array.isArray(hosts)) {
                hosts = [hosts]; // Convert to an array if it's not already one
              }

              let finalHost = [...hosts]

              // let hosts = eventData.acceptedCoHostInvites
              if (finalHost.includes(eventData.userId)) {
              }
              else {
                finalHost.push(eventData.userId)
              }

              console.log("hosts Count : ", finalHost.length);
              //earlier only the host was getting the notification of going members, but now all the co-hosts will get the notification
              finalHost.forEach((hostId) => {
                User.getUserData('users', hostId, function (hostSuccess, hostDetail) {
                  console.log("hostSuccess : ", hostSuccess);
                  if (hostSuccess) {
                    User.getUserData('users', userId, function (goingUserSuccess, goingUserDetail) {
                      console.log("goingUserSuccess : ", goingUserSuccess);
                      if (goingUserSuccess) {
                        let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
                        // let body = `${goingUserDetail.firstName} ${goingUserDetail.lastName} is going to ${eventData.name} | ${eventData.startTime} ${dateString}`
                        let body;
                        if (goingUserDetail.lastName !== "") {
                          body = `${goingUserDetail.firstName} ${goingUserDetail.lastName} is going to ${eventData.name} | ${eventData.startTime} ${dateString}`
                        }
                        else {
                          body = `${goingUserDetail.firstName} is going to ${eventData.name} | ${eventData.startTime} ${dateString}`
                        }
                        Events.sendNotificationFromServer(hostId, body, goingUserDetail, eventData, hostDetail, Constants.GOING_TO_EVENT, eventData.userId)
                        callback(1, "Updated Successfully")
                      } else {
                        console.log("Error While Getting Member Data");
                        callback(0, "Some Error Occurred")
                      }
                    });
                  } else {
                    console.log("Error While Getting Host Data");
                    callback(0, "Some Error Occurred")
                  }
                });
              });
            }
            else if (type == Constants.NOT_GOING) {
              callback(0, "You have not selected to go in event.!")
            }
          }
          else {
            if (type == Constants.GOING) {
              callback(0, "You have already selected to go in event.")
            }
            else {

              const index = goingList.indexOf(userId);
              if (index !== -1) {
                goingList.splice(index, 1);
              }
              eventData.goingList = goingList
              const ref = admin.firestore().collection("events").doc(eventId);
              ref.set(eventData)
              callback(1, "Updated Successfully")
            }
          }

        })

      } else {
        console.log("goingList Error While Getting Event Data");
        callback(0, "Invalid Data.")
      }
    });
  }


  static addMemory(request, response, callback) {
    let eventId = request.body.eventId
    let createdAt = request.body.createdAt
    let userId = request.body.userId
    let description = request.body.description
    let imagesList = JSON.parse(request.body.imagesList)

    const memoryData = {
      eventId: eventId,
      userId: userId,
      images: imagesList,
      createdAt: createdAt,
      description: description
    }


    const ref = admin.firestore().collection("events").doc(eventId).collection("event_memories");
    let autoId = ref.doc().id;
    ref.doc(autoId).set(memoryData);

    Events.getEventData(eventId, function (eventDataSuccess, eventData) {
      console.log("addMemoryToEvent eventDataSuccess : ", eventDataSuccess);
      if (eventDataSuccess) {
        console.log("addMemoryToEvent eventData is: ", eventData);
        console.log("addMemoryToEvent memoryData is: ", memoryData);
        User.getUserData('users', memoryData.userId, function (userSuccess, userDetail) {
          console.log("userSuccess : ", userSuccess);
          console.log("userDetail : ", userDetail);
          if (userSuccess) {
            let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
            // let body = `${userDetail.firstName} ${userDetail.lastName} has added a memory to ${eventData.name} | ${eventData.startTime} ${dateString}`
            let body;
            if (userDetail.lastName !== "") {
              body = `${userDetail.firstName} ${userDetail.lastName} has added a memory to ${eventData.name} | ${eventData.startTime} ${dateString}`
            }
            else {
              body = `${userDetail.firstName} has added a memory to ${eventData.name} | ${eventData.startTime} ${dateString}`
            }
            let coHosts = eventData.acceptedCoHostInvites
            if (eventData.isVisibleToAllSelected == true) {
              User.getUserFriends('friends', eventData.userId, function (friendsSuccess, friendList) {
                console.log("Friends success : ", friendsSuccess);
                if (friendsSuccess) {
                  if (friendList.length == 0) {
                    friendList = []
                  }
                  let members = friendList.concat(coHosts)
                  let allMembers = [...members]
                  if (memoryData.userId != eventData.userId) {
                    allMembers.push(eventData.userId)
                    allMembers = allMembers.filter(memberId => memberId !== memoryData.userId);
                  }

                  if (allMembers.length > 0) {
                    allMembers.forEach((memberId) => {
                      User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                        console.log("Member success : ", memberSuccess + " " + memberId);
                        if (memberSuccess) {
                          Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_MEMORY_ADDED, userDetail.id)
                          callback(1, "Memory Added Successfully")
                        } else {
                          console.log("Error While Getting Member Data");
                          callback(0, "Invalid Data.")
                        }
                      });
                    })
                  }
                } else {
                  console.log("Error While Getting Friend List");
                  callback(0, "Invalid Data.")
                }
              });
            }
            else {
              let selectedMembers = eventData.selectedMembers
              let allMembers = selectedMembers.concat(coHosts)
              if (memoryData.userId != eventData.userId) {
                allMembers.push(eventData.userId)
                allMembers = allMembers.filter(memberId => memberId !== memoryData.userId);
              }
              console.log("selectedMembers are: ", allMembers);
              if (allMembers.length > 0) {
                allMembers.forEach((memberId) => {
                  User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                    console.log("Member success : ", memberSuccess);
                    if (memberSuccess) {
                      console.log("MemberId : " + memberId)
                      Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_MEMORY_ADDED, userDetail.id)
                      callback(1, "Memory Added Successfully")
                    } else {
                      console.log("Error While Getting Member Data");
                      callback(0, "Invalid Data")
                    }
                  });
                })
              }
            }

          } else {
            console.log("Error While Getting User Data");
            callback(0, "Invalid Data.")
          }
        });
      } else {
        console.log("addMemoryToEvent Error While Getting Event Data");
        callback(0, "Invalid Data.")
      }
    });
  }

  static updateEvent(request, response, callback) {
    let eventId = request.body.eventId
    let userId = request.body.userId

    const eventData = {
      id: eventId,
      userId: userId,
      title: request.body.title,
      date: request.body.date,
      startTime: request.body.startTime,
      startTimestamp: parseFloat(request.body.startTimestamp),
      dateTimestamp: parseFloat(request.body.dateTimestamp),
      createdAt: parseFloat(request.body.createdAt),
      updatedAt: parseFloat(request.body.updatedAt),
      description: request.body.description,
      isDateConfirmed: Boolean(request.body.isDateConfirmed),
      isDatePollCreated: Boolean(request.body.isDatePollCreated),
      isLocationConfirmed: Boolean(request.body.isLocationConfirmed),
      isLocationPollCreated: Boolean(request.body.isLocationPollCreated),
      isVisibleToAllSelected: Boolean(request.body.isVisibleToAllSelected),
      location: request.body.location,
      name: request.body.name,
      pollVotingDeadlineTime: request.body.pollVotingDeadlineTime,
      pollVotingDeadlineTimestamp: parseFloat(request.body.pollVotingDeadlineTimestamp),
      selectedMembers: JSON.parse(request.body.selectedMembers),
      selectedCrowds: JSON.parse(request.body.selectedCrowds),
      acceptedCoHostInvites: JSON.parse(request.body.acceptedCoHostInvites),
      goingList: JSON.parse(request.body.goingList),
      pendingCoHostInvites: JSON.parse(request.body.pendingCoHostInvites)
    }

    const ref = admin.firestore().collection("events").doc(eventId);
    ref.set(eventData);



    Events.getEventData(eventId, function (eventDataSuccess, beforeEventData) {
      console.log("updateEvent eventDataSuccess : ", eventDataSuccess);
      if (eventDataSuccess) {
        console.log("updateEvent eventData is: ", eventData);

        User.getUserData('users', eventData.userId, function (userSuccess, userDetail) {
          if (userSuccess) {
            let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
            if (eventData.pendingCoHostInvites.length > 0) {
              var newCoHostList = eventData.pendingCoHostInvites.filter(
                (member) => {
                  return !beforeEventData.pendingCoHostInvites.includes(member);
                }
              );
              console.log("newCoHostList are: ", newCoHostList);
              const newCoHostInvites = newCoHostList.filter(
                (member) => {
                  return !eventData.acceptedCoHostInvites.includes(member);
                }
              );
              // const newCoHostInvites = eventData.acceptedCoHostInvites.filter(
              //   (member) => {
              //     return !newCoHostList.includes(member);
              //   }
              // );
              console.log("New co-host invites are: ", newCoHostInvites);
              eventData.pendingCoHostInvites = newCoHostInvites
              ref.set(eventData);
              if (newCoHostInvites.length > 0) {
                // let body = `${userDetail.firstName} ${userDetail.lastName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`
                let body;
                if (userDetail.lastName !== "") {
                  body = `${userDetail.firstName} ${userDetail.lastName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`
                }
                else {
                  body = `${userDetail.firstName} has invited you to be a co-host for ${eventData.name} | ${eventData.startTime} ${dateString}`
                }
                newCoHostInvites.forEach((memberId) => {
                  User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                    console.log("Member success : ", memberSuccess);
                    if (memberSuccess) {
                      Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.CO_HOST_INVITE, eventData.userId)
                    } else {
                      console.log("Error While Getting Member Data");
                      callback(0, "Invalid Data.")
                    }
                  });
                })
              }
              else {
                console.log("No new co-host invites.");
              }
            } else {
              console.log("Pending Co-Host Empty");
            }

            if (eventData.isVisibleToAllSelected == true) {
              if (beforeEventData.isVisibleToAllSelected == true && eventData.isVisibleToAllSelected == true) {
                // Same Data 
                console.log("Before and now data are same (VISIBLE TO ALL)");
              }
              else {
                console.log("Before and now data are not same (VISIBLE TO ALL)");
                User.getUserFriends('friends', userDetail.id, function (friendsSuccess, friendList) {
                  console.log("Friends success : ", friendsSuccess);
                  if (friendsSuccess) {
                    if (friendList.length > 0) {
                      friendList.forEach((memberId) => {
                        User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                          console.log("Member success : ", memberSuccess + " " + memberId);
                          if (memberSuccess) {
                            // let body = `${userDetail.firstName} ${userDetail.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
                            let body;
                            if (userDetail.lastName !== "") {
                              body = `${userDetail.firstName} ${userDetail.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
                            }
                            else {
                              body = `${userDetail.firstName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
                            }
                            Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
                          } else {
                            console.log("Error While Getting Member Data");

                            callback(0, "Invalid Data.")
                          }
                        });
                      })
                    }
                  } else {
                    console.log("Error While Getting Friend List");
                    callback(0, "Invalid Data.")
                  }
                });
              }
            }
            else {
              // if (
              //     eventData.selectedMembers.length >
              //     beforeEventData.selectedMembers.length
              // ) {
              const newSelectedMembers = eventData.selectedMembers.filter(
                (member) => {
                  return !beforeEventData.selectedMembers.includes(member);
                }
              );
              console.log("New selected members are: ", newSelectedMembers);
              if (newSelectedMembers.length > 0) {
                // let body = `${userDetail.firstName} ${userDetail.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
                let body;
                if (userDetail.lastName !== "") {
                  body = `${userDetail.firstName} ${userDetail.lastName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
                }
                else {
                  body = `${userDetail.firstName} invited you to ${eventData.name} | ${eventData.startTime} ${dateString}`
                }
                newSelectedMembers.forEach((memberId) => {
                  User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                    console.log("Member success : ", memberSuccess);
                    if (memberSuccess) {
                      Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
                    } else {
                      console.log("Error While Getting Member Data");
                      callback(0, "Invalid Data.")
                    }
                  });
                })
              }
              else {
                console.log("No new Member Selected.");
              }
              // } else {
              // console.log("No new member added in the event.");
              // }
            }

            if (beforeEventData.dateTimestamp != eventData.dateTimestamp ||
              beforeEventData.description != eventData.description ||
              beforeEventData.location != eventData.location ||
              beforeEventData.name != eventData.name ||
              beforeEventData.startTimestamp != eventData.startTimestamp) {
              if (eventData.isVisibleToAllSelected == true) {
                User.getUserFriends('friends', userDetail.id, function (friendsSuccess, friendList) {
                  console.log("Friends success : ", friendsSuccess);
                  if (friendsSuccess) {
                    if (friendList.length > 0) {
                      friendList.forEach((memberId) => {
                        User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                          console.log("Member success : ", memberSuccess + " " + memberId);
                          if (memberSuccess) {
                            let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
                            // let body = `${userDetail.firstName} ${userDetail.lastName} updated ${eventData.name} | ${eventData.startTime} ${dateString}`
                            let body;
                            if (userDetail.lastName !== "") {
                              body = `${userDetail.firstName} ${userDetail.lastName} updated ${eventData.name} | ${eventData.startTime} ${dateString}`
                            }
                            else {
                              body = `${userDetail.firstName} updated ${eventData.name} | ${eventData.startTime} ${dateString}`
                            }
                            Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
                            callback(1, "Event Updated Successfully.")
                          } else {
                            console.log("Error While Getting Member Data");
                            callback(0, "Invalid Data.")
                          }
                        });
                      })
                    }
                  } else {
                    console.log("Error While Getting Friend List");
                    callback(0, "Invalid Data.")
                  }
                });
              }
              else {
                const selectedMembers = eventData.selectedMembers;
                if (selectedMembers.length > 0) {
                  selectedMembers.forEach((memberId) => {
                    User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                      console.log("Member success : ", memberSuccess);
                      if (memberSuccess) {
                        console.log("MemberId : " + memberId)
                        let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
                        // let body = `${userDetail.firstName} ${userDetail.lastName} updated ${eventData.name} | ${eventData.startTime} ${dateString}`
                        let body;
                        if (userDetail.lastName !== "") {
                          body = `${userDetail.firstName} ${userDetail.lastName} updated ${eventData.name} | ${eventData.startTime} ${dateString}`
                        }
                        else {
                          body = `${userDetail.firstName} updated ${eventData.name} | ${eventData.startTime} ${dateString}`
                        }

                        Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_UPDATED, eventData.userId)
                        callback(1, "Event Updated Successfully.")
                      } else {
                        console.log("Error While Getting Member Data");
                        callback(0, "Invalid Data.")
                      }
                    });
                  })
                }
              }
            }
            else {
              console.log("Before and now data are same");
              callback(1, "Event Updated Successfully.")
            }
          }
          else {
            callback(0, "Invalid Data.")
          }
        })
      } else {
        console.log("updateEvent Error While Getting Event Data");
        callback(0, "Invalid Data.")
      }
    });
  }

  static addCommentInEventDiscussion(request, response, callback) {
    let eventId = request.body.eventId
    let createdAt = request.body.createdAt
    let userId = request.body.userId
    let comment = request.body.comment

    const ref = admin.firestore().collection("events").doc(eventId).collection("event_comments");
    let autoId = ref.doc().id;
    const commentData = {
      commentId: autoId,
      userId: userId,
      comment: comment,
      createdAt: createdAt,
      mentions: []

    }
    ref.doc(autoId).set(commentData);

    Events.getEventData(eventId, function (eventDataSuccess, eventData) {
      console.log("eventDataSuccess : ", eventDataSuccess);
      if (eventDataSuccess) {
        console.log("eventData is: ", eventData);
        console.log("commentData is: ", commentData);
        User.getUserData('users', commentData.userId, function (userSuccess, userDetail) {
          console.log("userSuccess : ", userSuccess);
          console.log("userDetail : ", userDetail);
          if (userSuccess) {
            let dateString = CommonMethods.prepareDateString(eventData.isDateConfirmed, eventData.dateTimestamp)
            // let body = `${userDetail.firstName} ${userDetail.lastName} commented in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
            let body;
            if (userDetail.lastName !== "") {
              body = `${userDetail.firstName} ${userDetail.lastName} commented in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
            }
            else {
              body = `${userDetail.firstName} commented in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
            }

            let coHosts = eventData.acceptedCoHostInvites
            let selectedMembers = eventData.goingList

            console.log("MEMBERS DATA : ", selectedMembers.length);
            var members = selectedMembers.concat(coHosts)
            var finalMembers = [...members]
            console.log("MEMBERS DATA AFTER");
            console.log("Commented User Id : " + commentData.userId)
            console.log("Event User Id : " + eventData.userId)
            if (commentData.userId != eventData.userId) {
              finalMembers.push(eventData.userId)
              finalMembers = finalMembers.filter(memberId => memberId !== commentData.userId);
              console.log("selectedMembers are: ", finalMembers);
            }
            console.log("MEMBERS COUNT : ", finalMembers.length);
            if (finalMembers.length > 0) {
              finalMembers.forEach((memberId) => {
                User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                  console.log("Member success : ", memberSuccess);
                  if (memberSuccess) {
                    console.log("MemberId : " + memberId)
                    Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.EVENT_COMMENT_ADDED, userDetail.id)
                  } else {
                    console.log("Error While Getting Member Data");
                    callback(0, "Invalid Data")
                  }
                });
              })
            }
            //notify the mentioned users
            let comment = commentData.comment
            const regex = /@(\w+)/g;
            if (comment.match(regex)) {
              let mentionedUsers = comment.match(regex).map((user) => user.slice(1));
              if (mentionedUsers.length > 0) {
                if (mentionedUsers.includes('guests')) {
                  if (eventData.isVisibleToAllSelected == true) {
                    //// If Else Lgana id kdni ode base te 
                    User.getUserFriends('friends', eventData.userId, function (friendsSuccess, friendList) {
                      console.log("Friends success : ", friendsSuccess);
                      if (friendsSuccess) {
                        if (friendList.length == 0) {
                          friendList = []
                        }
                        let allMembers = friendList.concat(coHosts)
                        if (commentData.userId != eventData.userId) {
                          allMembers.push(eventData.userId)
                          allMembers = allMembers.filter(memberId => memberId !== commentData.userId);
                        }

                        if (allMembers.length > 0) {
                          allMembers.forEach((memberId) => {
                            User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                              console.log("Member success : ", memberSuccess + " " + memberId);
                              if (memberSuccess) {
                                // Notification send krni mention Vali
                                // let body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
                                let body;
                                if (userDetail.lastName !== "") {
                                  body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
                                }
                                else {
                                  body = `${userDetail.firstName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
                                }
                                Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.USER_MENTIONED, userDetail.id)
                                callback(1, "Event Updated Successfully.")
                              } else {
                                console.log("Error While Getting Member Data");
                                callback(0, "Invalid Data")
                              }
                            });
                          })
                        }
                      } else {
                        console.log("Error While Getting Friend List");
                        callback(0, "Invalid Data")
                      }
                    });
                  }
                  else {
                    let selectedMembers = eventData.selectedMembers
                    let allMembers = selectedMembers.concat(coHosts)
                    if (commentData.userId != eventData.userId) {
                      allMembers.push(eventData.userId)
                      allMembers = allMembers.filter(memberId => memberId !== commentData.userId);
                    }
                    console.log("selectedMembers are: ", allMembers);
                    if (allMembers.length > 0) {
                      allMembers.forEach((memberId) => {
                        User.getUserData('users', memberId, function (memberSuccess, memberDetail) {
                          console.log("Member success : ", memberSuccess);
                          if (memberSuccess) {
                            console.log("MemberId : " + memberId)
                            // let body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
                            let body;
                            if (userDetail.lastName !== "") {
                              body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
                            }
                            else {
                              body = `${userDetail.firstName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
                            }
                            Events.sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, Constants.USER_MENTIONED, userDetail.id)
                            callback(1, "Event Updated Successfully.")
                          } else {
                            console.log("Error While Getting Member Data");
                            callback(0, "Invalid Data")
                          }
                        });
                      })
                    }
                  }
                } else {
                  console.log("mentionedUsers are: ", mentionedUsers);
                  mentionedUsers.forEach((mentionedId) => {
                    User.getUserDataFromUsername(mentionedId, function (mentionUserSuccess, mentionedUserId) {
                      console.log("mentionUserSuccess : ", mentionUserSuccess);
                      // console.log("mentionedUserDetail : ", mentionedUserDetail.notificationSettings.mentions)
                      if (mentionUserSuccess) {
                        const userId = Object.keys(mentionedUserId)[0];
                        console.log("mentionedUserId : ", userId)
                        User.getUserData('users', userId, function (mentionedUserInnerSuccess, mentionedUserInnerDetail) {
                          console.log("Member success : ", mentionedUserInnerSuccess);
                          if (mentionedUserInnerSuccess) {
                            // let body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
                            let body;
                            if (userDetail.lastName !== "") {
                              body = `${userDetail.firstName} ${userDetail.lastName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
                            }
                            else {
                              body = `${userDetail.firstName} mentioned you in the discussion for ${eventData.name} | ${eventData.startTime} ${dateString}`
                            }
                            Events.sendNotificationFromServer(userId, body, userDetail, eventData, mentionedUserInnerDetail, Constants.USER_MENTIONED, userDetail.id)
                            callback(1, "Event Updated Successfully.")
                          } else {
                            console.log("Error While Getting Member Data");
                            callback(0, "Invalid Data")
                          }
                        });
                        // sendNotificationFromServer(mentionedId, body, userDetail, eventData, mentionedUserDetail, Constants.USER_MENTIONED, userDetail.id)
                      } else {
                        console.log("Error While Getting mentionUser Data");
                        callback(0, "Invalid Data")
                      }
                    });
                  })
                }
              }
              else {
                console.log("No Mention Inside in comment");
                callback(1, "Event Updated Successfully.")
              }
            }
            else {
              console.log("No Mention in comment");
              callback(1, "Event Updated Successfully.")
            }
          } else {
            console.log("Error While Getting User Data");
            callback(0, "Invalid Data")
          }
        });
      } else {
        console.log("Error While Getting Event Data");
        callback(0, "Invalid Data")
      }
    });


  }


  static sendNotificationFromServer(memberId, body, userDetail, eventData, memberDetail, type, userId) {
    let notificationSettings = memberDetail.notificationSettings
    const notificationRef = notifications.doc(memberId).collection("notificationsList");
    let autoId = notificationRef.doc().id;
    eventData.hostName = `${userDetail.firstName} ${userDetail.lastName}`

    const data = {
      type: type,
      message: body,
      userImage: userDetail.imageUrl,
      visibleTo: memberId,
      userId: userId,
      // eventData: JSON.stringify(eventData),
      eventId: eventData.id,
      timeStamp: String(Date.now()),
      notificationId: autoId
    };

    const newNotification = {
      type: type,
      info: data,
      id: autoId,
      status: 0,
    };
    notificationRef.doc(autoId).set(newNotification);
    const notificationObj = { notificationSettings: 'someValue' };

    if (type == Constants.CO_HOST_INVITE) {
      if (notificationSettings != undefined) {
        if (notificationSettings.muteAllPushNotifications == true) {
          console.log("User has turned off event invite notifications.");
        } else {
          console.log("Settings exist");
          CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
      } else {
        console.log("muteAllPushNotifications Settings not exist");
        CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
      }

    }
    else if (type == Constants.EVENT_CREATED || type == Constants.EVENT_UPDATED) {
      if (notificationSettings != undefined) {
        if (notificationSettings.inviteToEvents == false || notificationSettings.muteAllPushNotifications == true) {
          console.log("User has turned off event invite notifications.");
        } else {
          console.log("EVENT_CREATED Notification Send Hon Lgi");
          CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
      } else {
        console.log("inviteToEvents Settings not exist");
        CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
      }

    }
    else if (type == Constants.EVENT_COMMENT_ADDED) {
      console.log("Notification Settings Of User Are: ", notificationSettings);
      if (notificationSettings != undefined) {
        if (notificationSettings.discussionComments == false || notificationSettings.muteAllPushNotifications == true) {
          console.log("User has turned off discussion comments notifications.");
          // return null;
        } else {
          console.log("EVENT_COMMENT_ADDED Notification Send Hon Lgi");
          CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
      } else {
        console.log("discussionComments Settings not exist");
        CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
      }
    }
    else if (type == Constants.USER_MENTIONED) {
      if (notificationSettings != undefined) {
        if (notificationSettings.mentions == false || notificationSettings.muteAllPushNotifications == true) {
          console.log("User has turned off mention notifications.");
          // return null;
        } else {
          console.log("USER_MENTIONED Notification Send Hon Lgi");
          CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
      } else {
        console.log("mentions Settings not exist");
        CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
      }
    }
    else if (type == Constants.EVENT_MEMORY_ADDED) {
      if (notificationSettings != undefined) {
        if (notificationSettings.newEventMemories == false || notificationSettings.muteAllPushNotifications == true) {
          console.log("User has turned off event memories notifications.");
          // return null;
        }
        else {
          CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
      } else {
        console.log("newEventMemories Settings not exist");
        CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
      }
    }
    else if (type == Constants.GOING_TO_EVENT) {
      if (notificationSettings != undefined) {
        if (notificationSettings.eventAttendanceUpdates == false || notificationSettings.muteAllPushNotifications == true) {
          console.log("User has turned off event attendance updates notifications.");
          // return null;
        } else {
          CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
        }
      } else {
        console.log("eventAttendanceUpdates Settings not exist");
        CommonMethods.sendNotification(eventData.name, body, data, memberDetail.tokens, type);
      }
    }



  }

}
module.exports = Events