//
//  UploadPopupVC.swift
//  Genbay
//
//  Created by Nap Works on 15/04/23.
//

import UIKit

protocol UploadPopupVCDelegate: AnyObject {
    func pushToUploadMemoryVC(vc: UIViewController,image:UIImage,calledFrom:String)
}

class UploadPopupVC: UIViewController {
    let TAG = String(describing: UploadPopupVC.self)
    var delegate: UploadPopupVCDelegate?
    @IBOutlet weak var popupView: UIView!
    private lazy var photoLibraryPickerController: UIImagePickerController = {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .photoLibrary
        pickerController.allowsEditing = true
        return pickerController
    }()
    
    private lazy var cameraPickerController: UIImagePickerController = {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .camera
        pickerController.cameraDevice = .front
        pickerController.allowsEditing = true
        return pickerController
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
         setUI()
        // Do any additional setup after loading the view.
    }
    
    func setUI(){
        CommonMethods.roundCornerFilled(uiView: popupView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0)
        view.backgroundColor = .black.withAlphaComponent(0.3)
    }
   
 
    @IBAction func takeNewBtnPressed(_ sender: UIButton){
//        self.delegate?.pushToUploadMemoryVC(vc: self,image: UIImage(),calledFrom: Constants.CAMERA)
        self.present(self.cameraPickerController, animated: true, completion: nil)
    }
    
    @IBAction func uploadBtnPressed(_ sender: UIButton){
//        self.delegate?.pushToUploadMemoryVC(vc: self,image: UIImage(),calledFrom: Constants.GALLERY)
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else { return }
        self.present(self.photoLibraryPickerController, animated: true, completion: nil)
    }
    
    @IBAction func closeBtnPressed(_ sender: UIButton){
        self.dismiss(animated: true)
    }
}

extension UploadPopupVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.editedImage] as? UIImage
            ?? info[.originalImage] as? UIImage else { return }
        CommonMethods.showLog(TAG, "Image : \(image)")
        
        dismiss(animated: true) {
            self.delegate?.pushToUploadMemoryVC(vc: self,image: image,calledFrom: Constants.CAMERA)
//            self.delegate?.pushToUploadMemoryVC(vc: self, image: image)
        }
    }}
