//
//  MyEventDetailViewModel.swift
//  Genbay
//
//  Created by Nap Works on 04/05/23.
//

import Foundation

final class MyEventDetailViewModel {
    let TAG = String(describing: MyEventDetailViewModel.self)
    let vc: MyEventDetailVC
    
    init(vc: MyEventDetailVC) {
        self.vc = vc
    }
    
    //MARK: - Method to fetch date poll list from firebase to check if user already voted in date poll list or not..
    func fetchDatePollListAndCheckIfUserAlreadyVoted(_ eventId: String, completion: @escaping (Bool) -> Void){
        self.vc.showProgressHUD()
        FirebaseAPI.default.fetchDatePollList(eventId) { datePollList in
            if let datePollList = datePollList {
                self.checkIfUserAlreadyVotedForDate(datePollList) { success in
                    if success {
                        self.vc.datePollList = datePollList
                        self.vc.hideProgressHUD()
                        completion(success)
                    }else {
                        completion(false)
                    }
                    
                }
            }else {
                self.vc.hideProgressHUD()
                self.vc.showDialog(title: Constants.APP_NAME, message: "some error occurred")
            }
        }
    }
    
    //MARK: - Method to fetch location list from firebase to check if user already voted in location list or not...
    func fetchLocationListAndCheckIfUserAlreadyVoted(_ eventId: String, completion: @escaping (Bool) -> Void){
        self.vc.showProgressHUD()
        FirebaseAPI.default.fetchLocationPollList(eventId) { locationList in
            if let locationList = locationList {
                self.checkIfUserAlreadyVotedForLocation(locationList) { success in
                    if success {
                        self.vc.locationList = locationList
                        self.vc.hideProgressHUD()
                        completion(success)
                    }else {
                        completion(false)
                    }
                }
            }else {
                self.vc.hideProgressHUD()
                self.vc.showDialog(title: Constants.APP_NAME, message: "some error occurred")
            }
        }
    }
    
    //MARK: - Method to check if user already voted in date poll
    func checkIfUserAlreadyVotedForDate(_ datePollList: [DatePollModel], completion: @escaping (Bool) -> Void){
        for i in 0..<datePollList.count {
            let dateModel = datePollList[i]
            if let userList = dateModel.userList, userList.count > 0 {
                if let userId = self.vc.userModel?.id {
                    if userList.contains(userId){
                        CommonMethods.showLog(self.TAG, "matched with id: \(userId)")
                        self.vc.isDateVoted = true
                        completion(true)
                        break // exit the inner for loop
                    }
                }
            }
            if self.vc.isDateVoted {
                break // exit the outer for loop if a vote is found
            }
        }
    }
    
    //MARK: - Method to check if user already voted in location poll
    func checkIfUserAlreadyVotedForLocation(_ locationList: [Location], completion: @escaping (Bool) -> Void){
        for i in 0..<locationList.count {
            let locationModel = locationList[i]
            if let userList = locationModel.userList, userList.count > 0 {
                if let userId = self.vc.userModel?.id {
                    if userList.contains(userId){
                        CommonMethods.showLog(self.TAG, "matched with id: \(userId)")
                        self.vc.isLocationVoted = true
                        completion(true)
                        break // exit the inner for loop
                    }
                }
            }
            if self.vc.isLocationVoted {
                break // exit the outer for loop if a vote is found
            }
        }
    }
    
    //MARK: - Method to add user in going list of an event...
    func addToGoingList(_ eventId: String, userId: String){
        self.vc.showProgressHUD()
        FirebaseAPI.default.fetchEventFirestore(eventID: eventId) { error, model in
            if let model = model, error == nil {
                FirebaseAPI.default.addisGoingInGoingList(model.id ?? "", userId: userId) { success, error in
                    if success, error == nil {
                        self.vc.isAlreadySelectedGoing = true
                        self.vc.hideProgressHUD()
                        self.vc.changeBtnBackgroundAndLabel(view1: self.vc.goingBtnView, view2: self.vc.notGoingBtnView, btn1: self.vc.goingBtn, btn2: self.vc.notGoingBtn)
                        self.vc.showDialog(title: Constants.APP_NAME, message: "Vote Updated Successfully!"){
                            self.checkIfUserAlreadySelectedGoing(model.id ?? "", inViewDidLoad: false)
                        }
                    }else {
                        self.vc.hideProgressHUD()
                        self.vc.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "")
                    }
                }
            }else {
                self.vc.hideProgressHUD()
                self.vc.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "")
            }
        }
    }
    
    //MARK: - Method to remove user from going list...
    func removeFromGoingList(_ eventId: String, userId: String){
        self.vc.showProgressHUD()
        FirebaseAPI.default.fetchEventFirestore(eventID: eventId) { error, model in
            if let model = model, error == nil {
                FirebaseAPI.default.removeFromGoingList(model.id ?? "", userId: userId) { success, error in
                    if success, error == nil {
                        self.vc.isAlreadySelectedGoing = false
                        self.vc.hideProgressHUD()
                        self.vc.changeBtnBackgroundAndLabel(view1: self.vc.notGoingBtnView, view2: self.vc.goingBtnView, btn1: self.vc.notGoingBtn, btn2: self.vc.goingBtn)
                        self.vc.showDialog(title: Constants.APP_NAME, message: "Removed from going list!"){
                            self.checkIfUserAlreadySelectedGoing(model.id ?? "", inViewDidLoad: false)
                        }
                    }else {
                        self.vc.hideProgressHUD()
                        self.vc.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "")
                    }
                }
            }else {
                self.vc.hideProgressHUD()
                self.vc.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "")
            }
        }
    }
    
    func checkIfUserAlreadySelectedGoing(_ eventId: String, inViewDidLoad: Bool, completion: ( ((Bool)) -> Void)? = nil){
        if inViewDidLoad {
            self.vc.showProgressHUD()
        }
        FirebaseAPI.default.fetchEventFirestore(eventID: eventId) { error, model in
            if let model = model, error == nil {
                if inViewDidLoad {
                    self.vc.hideProgressHUD()
                }
                
                self.vc.eventModel = model
                if let goingList = model.goingList {
                    for i in 0..<goingList.count {
                        let goingUserId = goingList[i]
                        if let userId = self.vc.userModel?.id {
                            if goingUserId == userId{
                                self.vc.isAlreadySelectedGoing = true
                                break // exit the inner for loop
                            }
                        }
                        if self.vc.isAlreadySelectedGoing {
                            if inViewDidLoad {
                                self.vc.hideProgressHUD()
                            }
                            break // exit the outer for loop if a vote is found
                        }
                    }
                }
                
                DispatchQueue.main.async {
                    completion?(self.vc.isAlreadySelectedGoing)
                    if inViewDidLoad {
                        self.vc.hideProgressHUD()
                    }
                    if self.vc.isAlreadySelectedGoing {
                        self.vc.changeBtnBackgroundAndLabel(view1: self.vc.goingBtnView, view2: self.vc.notGoingBtnView, btn1: self.vc.goingBtn, btn2: self.vc.notGoingBtn)
                    } else {
                        self.vc.changeBtnBackgroundAndLabel(view1: self.vc.notGoingBtnView, view2: self.vc.goingBtnView, btn1: self.vc.notGoingBtn, btn2: self.vc.goingBtn)
                    }
                }
            }else {
                DispatchQueue.main.async {
                    self.vc.hideProgressHUD()
                    self.vc.showDialog(title: Constants.APP_NAME, message: error?.localizedDescription ?? "Some Error occurred while fetching going list")
                }
            }
        }
    }
    
    func setModelData(_ model: EventModel){
        if let pollDeadlineTimestamp = model.pollVotingDeadlineTimestamp {
            let date = Date(timeIntervalSince1970: TimeInterval(pollDeadlineTimestamp))
            self.vc.pollDeadlineMessageLabel.text = "Poll opens until \(date.formattedMonthYearString)"
        }
        var dateString = ""
        if model.isDateConfirmed ?? false{
            let date = Date(timeIntervalSince1970: model.dateTimestamp ?? 0.0)
            dateString = date.formattedDateString
        }
        else{
            dateString = "DATE TBD"
        }
        
        self.vc.titleLabel.text = "\(model.name ?? "") | \(model.startTime ?? "") \(dateString)"
        self.vc.hostNameLabel.text = "Host: \(model.hostName ?? "")"
        self.vc.descriptionLabel.text = model.description ?? ""
        CommonMethods.showLog(TAG, "DESCRIPTION : \(model.description)")
        
        let location = model.location
        if location != nil && location != "" {
            self.vc.addressView.isHidden = false
            if model.isLocationConfirmed ?? false{
                self.vc.addressLabel.text = location
            }
            else{
                self.vc.addressLabel.text = "TBD"
            }
        }else {
            self.vc.addressView.isHidden = true
            
        }
    }
    
    func hideVotingUI(){
        self.vc.dateLocationAlertView.isHidden = true
        self.vc.pollDeadlineMessageView.isHidden = true
        self.vc.voteBtnView.isHidden = true
    }
    
    func showVotingUI(){
        self.vc.dateLocationAlertView.isHidden = false
        self.vc.pollDeadlineMessageView.isHidden = false
        self.vc.voteBtnView.isHidden = false
    }
    
    func checkPollVotingDeadline(_ model: EventModel){ 
        if let polldeadlineTimestamp = model.pollVotingDeadlineTimestamp {
            let currentTimeStamp = Date().timeIntervalSince1970
            if currentTimeStamp >= polldeadlineTimestamp {
                self.vc.dateLocationAlertView.isHidden = true
                self.vc.pollDeadlineMessageView.isHidden = true
            } else {
                let timeRemainingInSeconds = Int(polldeadlineTimestamp - currentTimeStamp)
                let hours = timeRemainingInSeconds / 3600
                let minutes = (timeRemainingInSeconds % 3600) / 60
                CommonMethods.showLog(self.TAG, "Poll deadline not reached. \(hours) hours and \(minutes) minutes remaining.")
            }
        }
    }
    
    func setUIByCheckIfHostOrNot(_ isHost: Bool, model: EventModel){
        if isHost{
            self.vc.editViewPollView.isHidden = false
            self.vc.viewGuestListView.isHidden = true
            self.hideVotingUI()
            self.vc.goingNotGoingView.isHidden = true
        }
        else{
            self.vc.editViewPollView.isHidden = true
            self.vc.viewGuestListView.isHidden = true
            self.vc.voteBtnView.isHidden = false
            self.vc.goingNotGoingView.isHidden = false
            if let isDatePollCreated = model.isDatePollCreated,
               let isLocationPollCreated = model.isLocationPollCreated{
                if !isDatePollCreated, !isLocationPollCreated  {
                    self.hideVotingUI()
                }else {
                    self.showVotingUI()
                    if isDatePollCreated && !isLocationPollCreated {
                        self.vc.dateLocationPollAlertLabel.text = "Host has opened: Date Poll"
                        self.fetchDatePollListAndCheckIfUserAlreadyVoted(model.id ?? "") { success in
                            if success {
                                self.vc.changeButtonTitle(true)
                            }else {
                                self.vc.changeButtonTitle(false)
                            }
                        }
                    }else if !isDatePollCreated && isLocationPollCreated {
                        self.vc.dateLocationPollAlertLabel.text = "Host has opened: Location Poll"
                        self.fetchLocationListAndCheckIfUserAlreadyVoted(model.id ?? "") { success in
                            if success {
                                self.vc.changeButtonTitle(true)
                            }else {
                                self.vc.changeButtonTitle(false)
                            }
                        }
                    }else if isDatePollCreated && isLocationPollCreated {
                        self.vc.dateLocationPollAlertLabel.text = "Host has opened: Date Poll and Location Poll"
                        self.fetchDatePollListAndCheckIfUserAlreadyVoted(model.id ?? "") { success in
                            if success {
                                self.vc.isDateVoted = true
                            }else {
                                self.vc.isDateVoted = false
                            }
                        }
                        
                        self.fetchLocationListAndCheckIfUserAlreadyVoted(model.id ?? "") { success in
                            if success {
                                self.vc.isLocationVoted = true
                            }else {
                                self.vc.isLocationVoted = false
                            }
                        }
                    }
                }
                
                self.checkPollVotingDeadline(model)
            }
            else{
                CommonMethods.showLog(TAG, "Else guard")
            }
        }
    }
}
