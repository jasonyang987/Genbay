//
//  ChooseCrowdsToEventVC.swift
//  Genbay
//
//  Created by Nap Works on 10/04/23.
//

import UIKit

class ChooseCrowdsToEventVC: BaseViewController {
    let TAG = String(describing: ChooseCrowdsToEventVC.self)
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var confirmBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var addIndividualBtn: UIButton!
    var userData:UserModel?
    var viewModel:ChooseCrowdToEventsViewModel?
    var delegate : ChooseCrowdForEventDelegate?
    
    var isVisibleToAllSelected = false
    
    var crowdList:[CrowdModel] = []
    var selectedFriends: [String] = []
    var selectedCrowdMembers: [String] = []
    var finalSelectedFriends: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        userData = UserDefaultsMapper.getUser()
        viewModel = ChooseCrowdToEventsViewModel(vc: self)
        cancelBtn.isHidden = true
        
        setUI()
    }
    
    override func viewWillLayoutSubviews() {
        super.updateViewConstraints()
        self.tableViewHeightConstraint.constant = self.tableView.contentSize.height
    }
    
    func setUI(){
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .transparent
        tableView.register(UINib(nibName: "ChooseCrowdsTVC", bundle: nil), forCellReuseIdentifier: "ChooseCrowdsTVC")
        tableView.register(UINib(nibName: "VisibleToAllTVC", bundle: nil), forCellReuseIdentifier: "VisibleToAllTVC")
        
        view.backgroundColor = .black.withAlphaComponent(0.5)
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        CommonMethods.roundCornerStroke(uiview: addIndividualBtn, borderWidth: 1.0, borderColor: .black, cornerRadius: 0)
        cancelBtn.layer.cornerRadius = 20
        confirmBtn.layer.cornerRadius = 20
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

    }

    
    @IBAction func cancelButtonPressed(_ sender: Any) {

    }
    
    @IBAction func confirmButtonPressed(_ sender: Any) {
        CommonMethods.showLog(TAG, "confirmButtonPressed")
        var selectedCrowdList : [String] = []
        var selectedMembersList : [String] = []
        var selectedTitle = ""
        
        if isVisibleToAllSelected{
            selectedTitle = "Visible To All Friends"
        }
        else{
            crowdList.forEach{ data in
                if data.isSelected {
                    selectedCrowdList.append(data.id ?? "")
                    if selectedTitle == ""{
                        selectedTitle = data.name ?? ""
                    }
                    else{
                        selectedTitle = "\(selectedTitle), \(data.name ?? "")"
                    }
                    if data.membersList?.count ?? 0 > 0{
                        data.membersList?.forEach{ memberId in
                            selectedMembersList.append(memberId)
                        }
                    }
                }
            }
        }
        
        if selectedCrowdList.count == 0 && !isVisibleToAllSelected && selectedFriends.count == 0 {
                showDialog(title: Constants.APP_NAME, message: "Choose Visible to all friends or select at least one crowd or add individual friends!")
        }
        else{
            if selectedCrowdList.count == 0 && selectedFriends.count != 0 && !isVisibleToAllSelected {
                selectedTitle = "Visible to Individual Friends"
            }
            let finalSelectedMembersList = Array(Set(selectedMembersList + selectedFriends))
            CommonMethods.showLog(self.TAG, "Final SelectedMember: \(finalSelectedMembersList.count)")
            delegate?.onCrowdsSelected(type:"Success",selectedCrowdList: selectedCrowdList, selectedMembersList: finalSelectedMembersList,selectedTitle:selectedTitle,crowdList:crowdList,isVisibleToAllSelected:isVisibleToAllSelected)
            self.dismiss(animated: true)
        }
    }
    
    @IBAction func closeBtnPressed(_ sender: UIButton){
        self.dismiss(animated: true)
    }
    
    @IBAction func closeMainBtnPressed(_ sender: UIButton){
        self.dismiss(animated: true)
    }
    
    @IBAction func addIndividualFriendBtnPressed(_ sender: UIButton){
        var selectedMembersList : [String] = []
        crowdList.forEach{ data in
            if data.isSelected {
                if data.membersList?.count ?? 0 > 0{
                    data.membersList?.forEach{ memberId in
                        selectedMembersList.append(memberId)
                    }
                }
            }
        }
        
        finalSelectedFriends = selectedMembersList + selectedFriends
        Navigations.showIndividualFriendsPopup(viewController: self, delegate: self, selectedFriends: finalSelectedFriends)
    
    }
    
}

extension ChooseCrowdsToEventVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return 1
        }
        else{
            return crowdList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "VisibleToAllTVC", for: indexPath) as! VisibleToAllTVC
            cell.selectionStyle = .none
            cell.configure(isSelected:isVisibleToAllSelected, count: crowdList.count)
//            tableViewHeightConstraint.constant = 0
//            tableViewHeightConstraint.constant =  cell.frame.height
            CommonMethods.showLog(TAG, "Height After Section0 : \(cell.frame.height)")
            CommonMethods.showLog(TAG, "Height After Section0 : \(tableViewHeightConstraint.constant)")
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChooseCrowdsTVC", for: indexPath) as! ChooseCrowdsTVC
            cell.selectionStyle = .none
            cell.configure(data:crowdList[indexPath.row],position: indexPath.row, count: crowdList.count)
//            tableViewHeightConstraint.constant = tableViewHeightConstraint.constant + cell.frame.height
            CommonMethods.showLog(TAG, "Height After Section1 : \(tableViewHeightConstraint.constant)")
            return cell
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 1{
            isVisibleToAllSelected = false
            selectedFriends = []
            selectedCrowdMembers = []
            crowdList[indexPath.row].isSelected = !(crowdList[indexPath.row].isSelected)
            crowdList.forEach { model in
                if !model.isSelected {
                    selectedFriends = selectedFriends.filter({!(model.membersList?.contains($0))!})
                }
                if model.isSelected {
                    if model.membersList?.count ?? 0 > 0{
                        model.membersList?.forEach{ memberId in
                            selectedCrowdMembers.append(memberId)
                        }
                    }
                }
            }
            self.tableView.reloadData()
        }
        else{
            self.finalSelectedFriends = []
            isVisibleToAllSelected.toggle()
            crowdList.forEach{ data in
                data.isSelected = false
            }
            if isVisibleToAllSelected {
                self.selectedFriends = AppDelegate.shared.friendList.map({$0.id ?? ""})
            }else {
                self.selectedFriends = []
            }
            self.tableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        self.viewWillLayoutSubviews()
    }
    
}

extension ChooseCrowdsToEventVC: IndividualFriendsPopupVCDelegate{
    
    func onFriendsSelection(_ friends: [String], isCellSelected: Bool) {
        self.selectedFriends = friends
        CommonMethods.showLog(self.TAG, "selected Friends: \(Set(friends))")
        CommonMethods.showLog(self.TAG, "selected Crowd Members: \(selectedCrowdMembers)")
        
        if isCellSelected {
            isVisibleToAllSelected = false
        }
        
        if !(Set(friends).count == Set(selectedCrowdMembers).count && Set(friends) == Set(selectedCrowdMembers)) {
            crowdList.forEach{ data in
                data.isSelected = false
            }
        }
        self.tableView.reloadData()
    }
    
    func onCoHostsSelection(_ coHosts: [UserModel], isCellSelected: Bool) {
        
    }
}
