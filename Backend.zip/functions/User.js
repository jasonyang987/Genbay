var admin = require("firebase-admin");
class User {

    static getUserData(type, id, callback) {
        admin.database().ref('users/' + id).once('value', (snapshot) => {
            var data = snapshot.val();
            if (data != null) {
                callback(true, data);
            } else {
                callback(false, null);
            }
        });
    }

    static getUserDataFromUsername(username, callback) {
        admin.database().ref('/users').orderByChild("username").equalTo(username).once('value', (snapshot) => {
            var data = snapshot.val();
            if (data != null) {
                callback(true, data);
            } else {
                callback(false, null);
            }
        });
    }

    static getAllUserData(callback) {
        admin.database().ref('users/').once('value', (snapshot) => {
            var data = snapshot.val();
            if (data != null) {
                callback(true, data);
            } else {
                callback(false, null);
            }
        });
    }

    static getUserFriends(type, id, callback) {
        admin.database().ref(type + '/' + id + '/acceptedList').once('value', (snapshot) => {
            var friends = snapshot.val();
            if (friends != null) {
                callback(true, friends);
            } else {
                callback(false, null);
            }
        });
    }

    static getPendingFriendList(type, id, callback) {
        admin.database().ref(type + '/' + id + '/pendingList').once('value', (snapshot) => {
            var friends = snapshot.val();
            if (friends != null) {
                callback(true, friends);
            } else {
                callback(false, null);
            }
        });
    }

    static getList(type,userId,callback){
         admin.database().ref(`/friends/${userId}/${type}`).once('value', (snapshot) => {
            var pendingList = snapshot.val();
            if (pendingList != null) {
                callback(true, pendingList);
            } else {
                callback(false, null);
            }
        });
    }

    static checkAlreadyExistOrNot(type,id,callback)
    {
        admin.database().ref(`/friends/${id}/${type}`).once('value', (snapshot) => {
            var fetchedList = snapshot.val();
            if (fetchedList != null) {
                if (fetchedList.length == 0) {
                   callback = false
                }
                else{
                    if (fetchedList.includes(id)) {
                        console.log(id+" exists in the"+type);
                        callback(true);
                    } else {
                        console.log(id+"does not exists in the"+type);
                        callback(false);
                    }
                }
            } else {
                callback(false);
            }
        });
    }
}
module.exports = User