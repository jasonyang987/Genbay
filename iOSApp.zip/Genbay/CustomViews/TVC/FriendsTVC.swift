//
//  FriendsTVC.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import UIKit

class FriendsTVC: UITableViewCell {
    let TAG = String(describing: FriendsTVC.self)

    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var optionButton: UIButton!
    var dataInCell : UserModel?
    var clickedPos : Int?
    var delegate : FriendsOptionPressedDelegate?
    var isCalledFromCrowd: Bool = false
    override func awakeFromNib() {
        super.awakeFromNib()
        userImage.layer.cornerRadius = userImage.frame.width/2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(data : UserModel?,position:Int,delegate:FriendsOptionPressedDelegate?){
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        dataInCell = data
        clickedPos = position
        self.delegate = delegate
        name.text = "\(dataInCell?.firstName ?? "") \(dataInCell?.lastName ?? "")"
        let image = dataInCell?.imageUrl ?? ""
        if image != ""{
            userImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
    }
    
    func configure(data : CrowdModel?, position:Int){
        CommonMethods.showLog("TAG", "Name : \(data?.name)")
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        name.text = data?.name ?? ""
        clickedPos = position
        let image = data?.imageUrl ?? ""
        if image != ""{
            userImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
        else{
            userImage.image = UIImage(named: "camera_icon")
        }
    }
    
    
    @IBAction func optionButtonPressed(_ sender: Any) {
        if isCalledFromCrowd {
            delegate?.onCrowdOptionsPressed(pos: clickedPos, contentView: contentView)
        }else{
            delegate?.onFriendOptionsPressed(pos: clickedPos, userModel: dataInCell,contentView: contentView)
        }
    }
    
}
