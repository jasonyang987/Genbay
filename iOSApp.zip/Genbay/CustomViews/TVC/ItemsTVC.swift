//
//  ItemsTVC.swift
//  TruthAlibi
//
//  Created by Nap Works on 15/02/23.
//

import UIKit

class ItemsTVC: UITableViewCell {
    let TAG = String(describing: ItemsTVC.self)

    @IBOutlet weak var addImage: UIImageView!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var name: UILabel!
    
    var dataInCell : UserModel?
    var clickedPos : Int = 0
    var delegate:SearchOptionPressedDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        userImage.layer.cornerRadius = userImage.frame.width/2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(data : UserModel?,delegate:SearchOptionPressedDelegate?,pos:Int){
        self.delegate = delegate
        self.clickedPos = pos
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
        dataInCell = data
        name.text = "\(data?.firstName ?? "") \(data?.lastName ?? "")"
        let image = data?.imageUrl ?? ""
        if image != ""{
            userImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
        
        addImage.image = dataInCell?.friendStatus?.image
    }
    
    func configure(data : SearchedUserModel?,delegate:SearchOptionPressedDelegate?,pos:Int){
        self.delegate = delegate
        self.clickedPos = pos
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .white, backgroundColor: .white, cornerRadius: 20.0, borderWidth: 0.0)
//        dataInCell = data
        name.text = "\(dataInCell?.firstName ?? "") \(dataInCell?.lastName ?? "")"
        let image = dataInCell?.imageUrl ?? ""
        if image != ""{
            userImage.kf.setImage(with: URL(string: image),placeholder: UIImage(named: "camera_icon"), options: [.cacheOriginalImage])
        }
        
        addImage.image = dataInCell?.friendStatus?.image
//        if friendStatus == "pending"{
//            addImage.image = UIImage(named: "back")
//        }
//        else if friendStatus == "accepted"{
//            addImage.image = UIImage(named: "homeIcon")
//        }
//        else if friendStatus == "sent"{
//            addImage.image = UIImage(named: "delete")
//        }
//        else{
//            addImage.image = UIImage(named: "add")
//        }
    }
    
    @IBAction func addFriendsPressed(_ sender: Any) {
//        if dataInCell?.friendStatus == .noType{
            delegate?.onSearchOptionsPressed(pos: clickedPos, userModel: dataInCell)
//        }
    }
}
