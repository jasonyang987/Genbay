//
//  VoteTVC.swift
//  Genbay
//
//  Created by Nap Works on 18/04/23.
//

import UIKit

protocol VoteTVCDelegate: AnyObject {
    func isCellSelected(_ isSelected: Bool)
}

class VoteTVC: UITableViewCell {
    var delegate: VoteTVCDelegate?
    let TAG = String(describing: VoteTVC.self)
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var checkMarkView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var voteNumberLabel: UILabel!
    
    @IBOutlet weak var progressView: UIView!
    @IBOutlet weak var progress: UIProgressView!
    var totalVotes = 0
    var userModel: UserModel?
    var isCellSelected: Bool = false
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func configure(with datePollList: [DatePollModel], index: Int){
        totalVotes = 0
        for date in datePollList {
            totalVotes += date.userList?.count ?? 0
        }
        let voteCount = datePollList[index].userList?.count ?? 0
        if voteCount == 0 {
            progress.progress = 0
        }else {
            progress.progress = Float(Double(voteCount) / Double(totalVotes))
        }
        if voteCount < 2 {
            voteNumberLabel.text = "\(voteCount) Vote"
        }else {
            voteNumberLabel.text = "\(voteCount) Votes"
        }
        
        let dateModel = datePollList[index]
        if let userList = dateModel.userList, userList.count > 0 {
            if let userId = userModel?.id {
                if userList.contains(userId){
                    checkMarkView.backgroundColor = .mainColor
                    isCellSelected = true
                }else {
                    checkMarkView.backgroundColor = .white
                    isCellSelected = false
                }
            }
        }

        titleLabel.text = datePollList[index].date?.formattedDateStringWithoutYear
    }
    
    func configure(with locationPollList: [Location], index: Int){
        totalVotes = 0
        for location in locationPollList {
            totalVotes += location.userList?.count ?? 0
        }
        
        let voteCount = locationPollList[index].userList?.count ?? 0
        if voteCount == 0 {
            progress.progress = 0
        }else {
            progress.progress = Float(Double(voteCount) / Double(totalVotes))
        }
        if voteCount < 2 {
            voteNumberLabel.text = "\(voteCount) Vote"
        }else {
            voteNumberLabel.text = "\(voteCount) Votes"
        }
        
        
        let locationModel = locationPollList[index]
        if let userList = locationModel.userList, userList.count > 0 {
            if let userId = userModel?.id {
                if userList.contains(userId){
                    checkMarkView.backgroundColor = .mainColor
                    isCellSelected = true
                }else {
                    checkMarkView.backgroundColor = .white
                    isCellSelected = false
                }
            }
        }
        
        titleLabel.text = locationPollList[index].location
        
    }
    
    func configure(){
        userModel = UserDefaultsMapper.getUser()
        CommonMethods.roundCornerFilled(uiView: mainView, borderColor: .black, backgroundColor: .white, cornerRadius: 0.0, borderWidth: 1)
        CommonMethods.roundCornerFilled(uiView: checkMarkView, borderColor: .black, backgroundColor: .white, cornerRadius: checkMarkView.frame.width / 2.0, borderWidth: 1.0)
        progress.layer.borderColor = UIColor.black.cgColor
        progress.layer.borderWidth = 1
        progress.layer.cornerRadius = 6.0
        progress.clipsToBounds = true
        
        if checkMarkView.backgroundColor == .white {
            isCellSelected = false
        }else {
            isCellSelected = true
        }
     
    }
    
    func configureCheckMark(){
        checkMarkView.backgroundColor = (checkMarkView.backgroundColor == .white) ? .mainColor : .white
        isCellSelected = !isCellSelected
        delegate?.isCellSelected(isCellSelected)
    }
    
    func configureCheckMark(isSelected: Bool) {
        self.isCellSelected = isSelected
        if isSelected {
            self.checkMarkView.backgroundColor = .mainColor
        } else {
            self.checkMarkView.backgroundColor = .white
        }
    }

}
