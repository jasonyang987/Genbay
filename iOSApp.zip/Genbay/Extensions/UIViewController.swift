//
//  UIViewController.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import Foundation
import UIKit

extension UIViewController {
    
    func presentCameraPhotoLibraryAlert(camera: @escaping(UIAlertAction) -> Void,
                                        library: @escaping(UIAlertAction) -> Void,
                                        cancel: ((UIAlertAction) -> Void)? = nil,
                                        sender: AnyObject) {
        
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: camera))
        alert.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: library))
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: cancel))
        
        if let presenter = alert.popoverPresentationController,
           let button = sender as? UIView {
            presenter.sourceView = button
            presenter.sourceRect = button.bounds
        }
        
        present(alert, animated: true, completion: nil)
    }
    
    func showNoOrYesAlert(title: String? = nil,
                          message: String,
                          yesHandler: @escaping (() -> Void),
                          noHandler: (() -> Void)? = nil,
                          completion: (() -> Void)? = nil) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { _ in
            noHandler?()
        }))
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { _ in
            yesHandler()
        }))
        
        self.present(alert, animated: true, completion: completion)
    }
    
    func showDialog(title: String? = nil, message: String, hideDialog: (() -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        self.present(alert, animated: true, completion: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            alert.dismiss(animated: true) {
                hideDialog?()
            }
        }
    }
    
    func showDialog(title: String? = nil,
                    message: String,
                    confirmation: (() -> Void)? = nil,
                    completion: (() -> Void)? = nil) {
        
        let okAlert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        okAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            confirmation?()
        }))
        
        self.present(okAlert, animated: true, completion: completion)
    }
    
    func openActionSheet(titleAction: String,
                         action: @escaping(UIAlertAction) -> Void,
                         cancel: ((UIAlertAction) -> Void)? = nil,
                         sender: AnyObject? = nil) {
        
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: titleAction, style: .default, handler: action))
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: cancel))
        if let presenter = alert.popoverPresentationController,
           let button = sender as? UIView {
            presenter.sourceView = button
            presenter.sourceRect = button.bounds
        }
        
        present(alert, animated: true, completion: nil)
    }
    
    func showAlertOption(title: String, message:String, completion: ((UIAlertAction) -> ())? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: completion)
        let cancel = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alert.addAction(action)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    func showLogoutAlert(title: String, message:String, completion: ((UIAlertAction) -> ())? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Logout", style: .default, handler: completion)
        let cancel = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alert.addAction(action)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    func showLocationAlert(title: String, message:String, completion: ((UIAlertAction) -> ())? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Open Settings", style: .default, handler: completion)
        let cancel = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alert.addAction(action)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    
   
    
    func showConfirmationAlert(title: String,
                               message: String,
                               yesMessage : String,
                               yesHandler: @escaping (() -> Void),
                               noMessage : String,
                               noHandler: (() -> Void)? = nil,
                               completion: (() -> Void)? = nil) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: noMessage, style: .cancel, handler: { _ in
            noHandler?()
        }))
        alert.addAction(UIAlertAction(title: yesMessage, style: .default, handler: { _ in
            yesHandler()
        }))
        
        self.present(alert, animated: true, completion: completion)
    }
    
}

