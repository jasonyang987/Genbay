//
//  FriendsTabViewModel.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class FriendsTabViewModel{
    let TAG = String(describing: FriendsTabViewModel.self)
    var vc : FriendsTabVC
    
    
    
    init(vc: FriendsTabVC) {
        self.vc = vc
    }
    
    
    func addFriend(clickedPos:Int?){
        CommonMethods.showLog(self.TAG, "userlist1: \(self.vc.usersList)")
        guard let clickedPosition = clickedPos else {
              self.vc.showDialog(title: Constants.APP_NAME, message: "Some error occurred, please search again!")
              return
          }
        
        if self.vc.usersList.isEmpty {
            self.vc.showDialog(title: Constants.APP_NAME, message: "Some error occurred, please search again!")
        }else {
            CommonMethods.showLog(self.TAG, "userlist2: \(self.vc.usersList)")

            if clickedPosition >= 0 && clickedPosition < self.vc.usersList.count {
                CommonMethods.showLog(self.TAG, "clicked index: \(clickedPosition)")
                let clickedUserData = self.vc.usersList[clickedPosition]
                CommonMethods.showLog(TAG, "clicked Name : \(clickedUserData.firstName ?? "")")
                
                self.vc.showProgressHUD()
                CommonWebServices.sendFriendRequest(userId: vc.userData?.id ?? "", receiverId: clickedUserData.id ?? "") { status, message, model in
                    self.vc.hideProgressHUD()
                    if status == Constants.SUCCESS {
                        self.vc.showDialog(title: Constants.APP_NAME, message: message) {[self] in
                                CommonMethods.showLog(self.TAG, "userlist: \(self.vc.usersList)")
                                CommonMethods.showLog(self.TAG, "clikedPos: \(clickedPosition)")
                                CommonMethods.showLog(self.TAG, "friendStatus: \(self.vc.usersList[clickedPosition].friendStatus)")
                                self.vc.usersList[clickedPosition].friendStatus = .sent
                                self.vc.tableView.reloadData()
                        }
                    }else if status == Constants.FAILURE {
                        self.vc.showDialog(title : Constants.APP_NAME, message: message)
                    }
                }
                
                
//                FirebaseAPI.default.addFriend(clickedUserId:clickedUserData.id ?? "",userId: self.vc.userData?.id ?? "") { (success, message, user) in
//                    self.vc.hideProgressHUD()
//                    if success{
//                        self.vc.showDialog(title : Constants.APP_NAME, message: "Friend request sent")
//                        CommonMethods.showLog(self.TAG, "userlist: \(self.vc.usersList)")
//                        CommonMethods.showLog(self.TAG, "clikedPos: \(clickedPosition)")
//                        CommonMethods.showLog(self.TAG, "friendStatus: \(self.vc.usersList[clickedPosition].friendStatus)")
//                        self.vc.usersList[clickedPosition].friendStatus = .sent
//                        self.vc.tableView.reloadData()
//                    }else{
//                        self.vc.showDialog(title : Constants.APP_NAME, message: message)
//                    }
//                }
            }else {
                self.vc.showDialog(title: Constants.APP_NAME, message: "Some error occurred, please search again!")
            }
        }
        
   
    }
    
    func cancelFriendRequest(clickedPos:Int?){
        guard let clickedPosition = clickedPos else {
              self.vc.showDialog(title: Constants.APP_NAME, message: "Some error occurred, please search again!")
              return
          }
        if self.vc.usersList.isEmpty {
            self.vc.showDialog(title: Constants.APP_NAME, message: "Some error occurred, please search again!")
        }else {
            if clickedPosition >= 0 && clickedPosition < self.vc.usersList.count {
                let clickedUserData = self.vc.usersList[clickedPosition]
                CommonMethods.showLog(TAG, "Clicked Name : \(clickedUserData.firstName ?? "")")
                self.vc.showProgressHUD()
                FirebaseAPI.default.cancelFriendRequestFromSearch(clickedUserId: clickedUserData.id ?? "", userId: self.vc.userData?.id ?? ""){ success,message in
                    self.vc.hideProgressHUD()
                    if success{
                        for (index, model) in self.vc.usersList.enumerated(){
                            if model.id == clickedUserData.id{
                                self.vc.usersList[index].friendStatus = .noType
                                break
                            }
                        }
                        let userInfo: [AnyHashable: Any] = ["userId": clickedUserData.id ?? ""]

                        NotificationCenter.default.post(name: Notification.Name("FRIEND_REQUEST_CANCELLED_BY_USER"), object: nil, userInfo: userInfo)
                        self.vc.tableView.reloadData()
                    }
                    else{
                        self.vc.showDialog(title: Constants.APP_NAME,message: message)
                    }
                    
                }
            }else {
                self.vc.showDialog(title: Constants.APP_NAME, message: "Some error occurred, please search again!")
            }
        }

    }
    
    func confirmFriendRequest(clickedPos:Int){
        let clickedUserData = self.vc.usersList[clickedPos]
        CommonMethods.showLog(TAG, "Clicked Name : \(clickedUserData.firstName ?? "")")
        self.vc.showProgressHUD()
        CommonWebServices.confirmFriendRequest(userId: vc.userData?.id ?? "", receiverId: clickedUserData.id ?? "") { status, message, model in
            self.vc.hideProgressHUD()
            if status == Constants.SUCCESS {
                self.vc.showDialog(title: Constants.APP_NAME, message: message) {[self] in
                    
                    for (index, model) in self.vc.usersList.enumerated(){
                        if model.id == clickedUserData.id{
                            self.vc.usersList[index].friendStatus = .accepted
                            break
                        }
                    }
                    self.vc.tableView.reloadData()
                }
            }else if status == Constants.FAILURE {
                self.vc.showDialog(title : Constants.APP_NAME, message: message)
            }
        }
//        FirebaseAPI.default.confirmFriendRequest(clickedUserId: clickedUserData.id ?? "", userId: self.vc.userData?.id ?? ""){ success,message in
//            self.vc.hideProgressHUD()
//            if success{
//                for (index, model) in self.vc.usersList.enumerated(){
//                    if model.id == clickedUserData.id{
//                        self.vc.usersList[index].friendStatus = .accepted
//                        break
//                    }
//                }
//                self.vc.tableView.reloadData()
//            }
//            else{
//                self.vc.showDialog(title: Constants.APP_NAME,message: message)
//            }
//
//        }
    }
}
