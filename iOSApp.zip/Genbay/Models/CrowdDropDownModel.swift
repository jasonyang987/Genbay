//
//  CrowdDropDownModel.swift
//  Genbay
//
//  Created by Nap Works on 31/03/23.
//

import Foundation


class CrowdDropDownModel : Codable {
    var id : String?
    var title : String?
    var type : String?
    var imageUrl : String?
    var isSelected : Bool?

    enum CodingKeys: String, CodingKey {

        case id,title,type,imageUrl,isSelected
    }

    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decodeIfPresent(String.self, forKey: .id)
        self.title = try container.decodeIfPresent(String.self, forKey: .title)
        self.type = try container.decodeIfPresent(String.self, forKey: .type)
        self.imageUrl = try container.decodeIfPresent(String.self, forKey: .imageUrl)
        self.isSelected = try container.decodeIfPresent(Bool.self, forKey: .isSelected)
    }
    
    init(id:String,title:String,type:String,imageUrl:String,isSelected:Bool){
        self.id = id
        self.title = title
        self.type = type
        self.imageUrl = imageUrl
        self.isSelected = isSelected
    }
    
    init(){
        
    }

}
