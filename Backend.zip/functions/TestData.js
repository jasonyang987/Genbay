var admin = require("firebase-admin");
class TestData {

    static addTestEventInDatabase(request, response) {
        console.log("UserId " + request.body.userId);
        let userId = request.body.userId;
        const ref = admin.firestore().collection("events");
        // let autoId = ref.doc().id;
        const data = {
            id: request.body.id,
            userId: userId,
            title: request.body.title,
            date: request.body.date,
            startTime: request.body.startTime,
            startTimestamp: parseFloat(request.body.startTimestamp),
            dateTimestamp: parseFloat(request.body.dateTimestamp),
            createdAt: parseFloat(request.body.createdAt),
            updatedAt: parseFloat(request.body.updatedAt),
            description: request.body.description,
            isDateConfirmed: Boolean(request.body.isDateConfirmed),
            isDatePollCreated: Boolean(request.body.isDatePollCreated),
            isLocationConfirmed: Boolean(request.body.isLocationConfirmed),
            isLocationPollCreated: Boolean(request.body.isLocationPollCreated),
            isVisibleToAllSelected: Boolean(request.body.isVisibleToAllSelected),
            location: request.body.location,
            name: request.body.name,
            pollVotingDeadlineTime: request.body.pollVotingDeadlineTime,
            pollVotingDeadlineTimestamp: parseFloat(request.body.pollVotingDeadlineTimestamp),
            selectedMembers: JSON.parse(request.body.selectedMembers),
            selectedCrowds: JSON.parse(request.body.selectedCrowds),
            acceptedCoHostInvites: JSON.parse(request.body.acceptedCoHostInvites),
            goingList: JSON.parse(request.body.goingList),
            pendingCoHostInvites: JSON.parse(request.body.pendingCoHostInvites)
        }

        ref.doc(request.body.id).set(data);
        console.log("data", data);
        return data
    }

    static addTestCommentEventInDatabase(userId, comment) {
        console.log("UserId " + userId);
        const ref = admin.firestore().collection("events").doc("0JqBZAcHEp8sPv3eTA1S").collection("event_comments");
        let autoId = ref.doc().id;
        const data = {
            commentId: autoId,
            userId: userId,
            comment: "@msmanvir nice",
            createdAt: 1698211270,
            mentions: []

        }
        ref.doc(autoId).set(data);
        console.log("data", data);
        return data
    }

    
}
module.exports = TestData