//
//  SplashVC.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import UIKit

class SplashVC: UIViewController {
    
    let TAG = String(describing : SplashVC.self)
    
    @IBOutlet weak var logoImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        AppDelegate.shared.mainNavController = self.navigationController
        AppDelegate.shared.secondaryNavController = self.navigationController
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        CommonMethods.showLog(self.TAG, "navigation : \(AppDelegate.shared.mainNavController)")

        AppDelegate.shared.mainNavController = self.navigationController
        AppDelegate.shared.secondaryNavController = self.navigationController
        CommonMethods.showLog(self.TAG, "navigation : \(AppDelegate.shared.mainNavController)")

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        navigationController?.navigationBar.isHidden = true
        launchInstructor()
    }
    
    private func animate() {
        let initialYPosition = logoImageView.frame.origin.y
        logoImageView.frame.origin.y = initialYPosition - 50
        logoImageView.alpha = 0
        
        UIView.animate(withDuration: 1.0, animations: {
            self.logoImageView.alpha = 1
            self.logoImageView.frame.origin.y = initialYPosition
        }, completion: { _ in
            Navigations.goToLogin()
        })
    }
    
    private func launchInstructor() {
        
        let userData = UserDefaultsMapper.getUser()
        CommonMethods.showLog(TAG, "userData name : \(userData?.firstName ?? "")")
        CommonMethods.showLog(TAG, "userData email : \(userData?.email ?? "")")
        CommonMethods.showLog(TAG, "userData id : \(userData?.id ?? "")")
        CommonMethods.showLog(TAG, "userData isLoggedIn : \(userData?.isLoggedIn ?? false)")
        let email = userData?.email ?? ""
        if email == ""{
            AppDelegate.shared.refreshFCMToken()
            animate()
        }
        else{
            let firstName = userData?.firstName ?? ""
            let username = userData?.username ?? ""
            let userImage = userData?.imageUrl ?? ""
            if firstName == "" {
                Navigations.goToAddNameVC(calledFrom: Constants.SPLASH)
            }
            else if username == ""{
                Navigations.goToAddUsernameVC()
            }else if userImage == ""{
                Navigations.goToAddImageVC(calledFrom: Constants.SPLASH)
            }
            else{
                Navigations.goToHome()
            }
        }
    }
}
