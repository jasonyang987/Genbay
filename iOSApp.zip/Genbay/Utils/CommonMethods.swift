//
//  CommonMethods.swift
//  TruthAlibi
//
//  Created by Nap Works on 13/02/23.
//

import Foundation
import UIKit

class CommonMethods{
    
    static let LOCAL_TAG = String(describing : CommonMethods.self)
    
    static func showLog(_ tag: String,_ message : String){
//        print("TEST", tag, message)
    }
    
//    static func mainBackgroundStyle(uiView : UIView){
//        uiView.backgroundColor = UIColor(patternImage: UIImage(named: "main_background")!)
//    }
    
    static func getFormattedDate(timeStamp : Double, format : String)-> String {
        let date = Date(timeIntervalSince1970: timeStamp)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: date)
    }
    
    static func getFullDateFromString(dateString : String)-> Date {
        let dateValue = dateString
//        if dateString.isEmpty{
//            dateValue = CommonMethods.getDBFormattedDate(timeStamp: Date().timeIntervalSince1970)
//        } 
        
        let fullDateString = "\(dateValue)"
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = NSTimeZone.local
        dateFormatter.locale = NSLocale.current
        dateFormatter.dateFormat = "MM/dd/yyyy"
        return dateFormatter.date(from:fullDateString)!
    }
    
    
    
    static func roundCornerFilled(uiView : UIView, borderColor : UIColor, backgroundColor : UIColor, cornerRadius : CGFloat, borderWidth : CGFloat){
        uiView.layer.borderWidth = borderWidth
        uiView.layer.cornerRadius = cornerRadius
        uiView.layer.borderColor = borderColor.cgColor
        uiView.layer.backgroundColor =  backgroundColor.cgColor
    }
    
    static func buttonShadowAndCornerRadius(view: UIView){
        view.layer.shadowColor = UIColor.mainColor.cgColor
        view.layer.shadowRadius = 10
        view.layer.shadowOpacity = 0.1
        view.layer.shadowOffset = .zero
        view.layer.cornerRadius = 25
    }
    
    /*
     CACornerMask    Corner
     layerMinXMinYCorner    top left corner
     layerMaxXMinYCorner    top right corner
     layerMinXMaxYCorner    bottom left corner
     layerMaxXMaxYCorner    bottom right corner
     */
    static func roundParticularCornerFilled(uiView : UIView, borderColor : UIColor, backgroundColor : UIColor, cornerRadius : CGFloat, borderWidth : CGFloat, corners : CACornerMask){
        uiView.layer.borderWidth = borderWidth
        uiView.layer.cornerRadius = cornerRadius
        uiView.layer.borderColor = borderColor.cgColor
        uiView.layer.backgroundColor =  backgroundColor.cgColor
        uiView.layer.maskedCorners = corners
    }
    
    static func roundParticularCornerFilled(uiView : UIImageView, borderColor : UIColor, backgroundColor : UIColor, cornerRadius : CGFloat, borderWidth : CGFloat, corners : CACornerMask){
        uiView.layer.borderWidth = borderWidth
        uiView.layer.cornerRadius = cornerRadius
        uiView.layer.borderColor = borderColor.cgColor
        uiView.layer.backgroundColor =  backgroundColor.cgColor
        uiView.layer.maskedCorners = corners
    }
    
    static func roundCornerStroke(uiview : UIView, borderWidth : CGFloat, borderColor : UIColor?, cornerRadius : CGFloat){
        uiview.layer.borderWidth = borderWidth
        uiview.layer.cornerRadius = cornerRadius
        uiview.layer.borderColor = borderColor?.cgColor
        //        var whiteColor = UIColor.white.cgColor
        //        whiteColor = whiteColor.copy(alpha: 0.0) ?? whiteColor
        uiview.layer.backgroundColor = UIColor.transparent.cgColor
    }
    
    static func dismiss(vc : UIViewController?, animated : Bool = true){
        vc?.navigationController?.popViewController(animated: animated)
        vc?.navigationController?.dismiss(animated: animated, completion: nil)
    }

    static func logout() {
        showLog(LOCAL_TAG, "logout")
        UserDefaultsMapper.removeCurrentUserData()
        AppDelegate.shared.mainNavController?.popToRootViewController(animated: true)
    }
    
    static func logout(_ goToInitView : Bool) {
        showLog(LOCAL_TAG, "logout")
        AppDelegate.shared.signoutUser { success, errorString in
            showLog(LOCAL_TAG, "logout success : \(success)")
            showLog(LOCAL_TAG, "navigation : \(AppDelegate.shared.mainNavController)")
            showLog(LOCAL_TAG, "logout errorString : \(errorString)")
            if goToInitView{
                AppDelegate.shared.refreshFCMToken()
                AppDelegate.shared.secondaryNavController?.popToRootViewController(animated: true)
            }
        }
    }
    
    static func sessionOut() {
        showLog(LOCAL_TAG, "sessionOut")
        UserDefaultsMapper.removeCurrentUserData()
        AppDelegate.shared.secondaryNavController?.popToRootViewController(animated: true)
    }
//    static func prepareNavigationList() -> [SideNavigationModel]{
//        var list : [SideNavigationModel] = []
//        list.append(SideNavigationModel(leadingIcon: UIImage(named: "account_details")!, title: "Account Details", trailingIcon: UIImage(named: "right_arrow")!,type:Constants.ACCOUNT_DETAILS))
//        list.append(SideNavigationModel(leadingIcon: UIImage(named: "change_password")!, title: "Change Password", trailingIcon: UIImage(named: "right_arrow")!,type:Constants.CHANGE_PASSWORD))
//        list.append(SideNavigationModel(leadingIcon: UIImage(named: "about_us")!, title: "About us", trailingIcon: UIImage(named: "right_arrow")!, type: Constants.ABOUT_US))
//        list.append(SideNavigationModel(leadingIcon: UIImage(named: "privacy_policy")!, title: "Privacy policy", trailingIcon: UIImage(named: "right_arrow")!, type: Constants.PRIVACY_POLICY))
//        list.append(SideNavigationModel(leadingIcon: UIImage(named: "terms")!, title: "Terms and Condition", trailingIcon: UIImage(named: "right_arrow")!, type: Constants.TERMS_AND_CONDITIONS))
//        list.append(SideNavigationModel(leadingIcon: UIImage(named: "logout")!, title: "Logout", trailingIcon: UIImage(named: "right_arrow")!,type:Constants.LOGOUT))
//
//
//        return list
//    }
    
    static func getDateString(timeStamp : Double)-> String {
        let date = Date(timeIntervalSince1970: timeStamp)
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = NSTimeZone.local
        dateFormatter.locale = NSLocale.current
        dateFormatter.dateFormat = "dd MMM yyyy, HH:mm a"
        return dateFormatter.string(from: date)
    }

    
    static func setPlaceholderColor(textFields : [UITextField], color : UIColor){
        textFields.forEach { (textField) in
            textField.attributedPlaceholder = NSAttributedString(string: textField.placeholder ?? "", attributes: [NSAttributedString.Key.foregroundColor: color])
        }
    }
    
//    static func setupAndShowSideMenu(view : UIView) -> SideMenuNavigationController? {
//        if let navigationDrawerViewController = UIStoryboard(name: "NavigationDrawer", bundle: nil).instantiateViewController(withIdentifier: "NavigationDrawer") as? SideMenuNavigationController {
//            let width = view.frame.width
//            showLog("CommonMethods", "Width : \(width)")
//            let menuWidth = width - ( (width * 30) / 100 )
//            showLog("CommonMethods", "menuWidth : \(menuWidth)")
//            navigationDrawerViewController.menuWidth = menuWidth
////            let customSideMenuManager = SideMenuManager.default
////            customSideMenuManager.menuPresentMode = .menuSlideIn
////            customSideMenuManager.menuFadeStatusBar = false
//            return navigationDrawerViewController
//        }else{
//            return nil
//        }
//    }
    
    static func convertStringToJson(jsonString : String)-> [String:AnyObject]?{
        if let data = jsonString.data(using: .utf8, allowLossyConversion: false){
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String:AnyObject]
            } catch let error as NSError {
                CommonMethods.showLog(LOCAL_TAG, "convertStringToJson error : \(error.localizedDescription)")
                return nil
            }
        }
        return nil
    }
    
    static func prepareJson(from object:Any) -> String? {
        guard let data = try? JSONSerialization.data(withJSONObject: object, options: []) else {
            return nil
        }
        return String(data: data, encoding: String.Encoding.utf8)
    }
    
    static func convertJsonToString(dic : [AnyHashable:Any])->String?{
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: dic, options: .prettyPrinted)
            if let jsonString = String(data: jsonData, encoding: String.Encoding.utf8){
                CommonMethods.showLog(LOCAL_TAG, "jsonString : \(jsonString)")
                return jsonString
            }else{
                return ""
            }
        } catch {
            CommonMethods.showLog(LOCAL_TAG, "convertJsonToString error : \(error.localizedDescription)")
            return nil
        }
    }

    
    typealias GetLatLngCompletion = (String, Double,Double) -> Void
    static func getLatLongFromAddress(address:String, completion: @escaping GetLatLngCompletion){
        CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress address : \(address)")
//        let geocoder = CLGeocoder()
//        geocoder.geocodeAddressString(address) { placemarks, error in
//            if error != nil{
//                CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress Error no Location : \(error?.localizedDescription)")
//                completion(error?.localizedDescription ?? Constants.COMMON_ERROR_MESSAGE ,0.0,0.0)
//                return
//            }
//            let placemark = placemarks?.first
//
//            let deliveredLatitude = placemark?.location?.coordinate.latitude ?? 0.0
//            let deliveredLongitude = placemark?.location?.coordinate.longitude ?? 0.0
//            CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress Lat: \(deliveredLatitude), Lon: \(deliveredLongitude)")
//            completion("",deliveredLatitude,deliveredLongitude)
//        }
    }
    
//    static func getLatLongFromAddress(){
//        let shippingAddress = orderModel?.orderData?.customer?.shippingAddress
//        let address = "\(shippingAddress?.streetAddress1 ?? "") \(shippingAddress?.streetAddress2 ?? ""), \(shippingAddress?.stateCode ?? ""), \(shippingAddress?.locality ?? ""), \(shippingAddress?.countryCode ?? "") \(shippingAddress?.postalCode ?? "")"
//        CommonMethods.showLog(self.TAG, "getLatLongFromAddress address : \(address)")
//        let geocoder = CLGeocoder()
//        geocoder.geocodeAddressString(address) { placemarks, error in
//            if error != nil{
//                CommonMethods.showLog(self.TAG, "getLatLongFromAddress Error no Location : \(error?.localizedDescription)")
//                return
//            }
//            let placemark = placemarks?.first
//            self.deliveredLatitude = placemark?.location?.coordinate.latitude ?? 0.0
//            self.deliveredLongitude = placemark?.location?.coordinate.longitude ?? 0.0
//            CommonMethods.showLog(self.TAG, "getLatLongFromAddress Lat: \(self.deliveredLatitude), Lon: \(self.deliveredLongitude)")
//        }
//    }
    
//    typealias GetLatLngCompletion = (String, Double,Double) -> Void
//    static func getLatLongFromAddress(orderModel:GetOrderDetailModel?, completion: @escaping GetLatLngCompletion){
//            let shippingAddress = orderModel?.orderData?.customer?.shippingAddress
//            let address = "\(shippingAddress?.streetAddress1 ?? "") \(shippingAddress?.streetAddress2 ?? ""), \(shippingAddress?.stateCode ?? ""), \(shippingAddress?.locality ?? ""), \(shippingAddress?.countryCode ?? "") \(shippingAddress?.postalCode ?? "")"
//            CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress address : \(address)")
//            let geocoder = CLGeocoder()
//            geocoder.geocodeAddressString(address) { placemarks, error in
//                if error != nil{
//                    CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress Error no Location : \(error?.localizedDescription)")
//                    completion(error?.localizedDescription ?? Constants.COMMON_ERROR_MESSAGE ,0.0,0.0)
//                    return
//                }
//                let placemark = placemarks?.first
//
//                let deliveredLatitude = placemark?.location?.coordinate.latitude ?? 0.0
//                let deliveredLongitude = placemark?.location?.coordinate.longitude ?? 0.0
//                CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress Lat: \(deliveredLatitude), Lon: \(deliveredLongitude)")
//                completion("",deliveredLatitude,deliveredLongitude)
//            }
//        }
    
   
//    static func getLatitudeFromAddress(address:String,completion:@escaping(Double,String) -> Void){
//        CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress address : \(address)")
//        var deliveredLatitude = 0.0
//        let geocoder = CLGeocoder()
//        geocoder.geocodeAddressString(address) { placemarks, error in
//            if error != nil{
//                CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress Error no Location : \(error?.localizedDescription)")
//                deliveredLatitude = 0.0
//                completion(deliveredLatitude,error?.localizedDescription ?? Constants.COMMON_ERROR_MESSAGE)
//            }
//            let placemark = placemarks?.first
//
//            deliveredLatitude = placemark?.location?.coordinate.latitude ?? 0.0
//            CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress Lat123: \(deliveredLatitude)")
//            completion(deliveredLatitude,"")
//        }
//
//    }
//
//    static func getLongitudeFromAddress(address:String,completion:@escaping(Double,String) -> Void){
//        CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress address : \(address)")
//        var deliveredLongitude = 0.0
//        let geocoder = CLGeocoder()
//        geocoder.geocodeAddressString(address) { placemarks, error in
//            if error != nil{
//                CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress Error no Location : \(error?.localizedDescription)")
//                deliveredLongitude = 0.0
//                completion(deliveredLongitude,error?.localizedDescription ?? Constants.COMMON_ERROR_MESSAGE)
//            }
//            let placemark = placemarks?.first
//
//            deliveredLongitude = placemark?.location?.coordinate.longitude ?? 0.0
//            completion(deliveredLongitude,"")
//        }
//
//    }
//
////    static func getLongitudeFromAddress(address:String) -> Double{
////        CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress address : \(address)")
////        var deliveredLongitude = 0.0
////        let geocoder = CLGeocoder()
////        geocoder.geocodeAddressString(address) { placemarks, error in
////            if error != nil{
////                CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress Error no Location : \(error?.localizedDescription)")
////                deliveredLongitude = 0.0
////            }
////            let placemark = placemarks?.first
////
////            deliveredLongitude = placemark?.location?.coordinate.longitude ?? 0.0
////        }
////        CommonMethods.showLog(self.LOCAL_TAG, "getLatLongFromAddress Lat: \(deliveredLongitude)")
////        return deliveredLongitude
////    }
    
}



