//
//  CreateCrowdViewModel.swift
//  Genbay
//
//  Created by Nap Works on 04/04/23.
//

import Foundation
import UIKit
import FirebaseStorage



final class CreateCrowdViewModel{
    let TAG = String(describing: CreateCrowdViewModel.self)
    var vc : CreateCrowdVC
    
    
    
    init(vc: CreateCrowdVC) {
        self.vc = vc
    }
    
    func validate() throws {
        
        if !vc.isImageSelected{
            throw ValidationError.chooseImage
        }
        
        if let name = vc.crowdNameText.text {
            if name.trimAndCheckIsEmpty() {
                throw ValidationError.nameEmpty
            }
        } else {
            throw ValidationError.nameEmpty
        }
        
        if let desc = vc.descriptionText.text {
            if desc.trimAndCheckIsEmpty() {
                throw ValidationError.descEmpty
            }
            else if desc == "Enter Crowd Description"{
                throw ValidationError.descEmpty
            }
        } else {
            throw ValidationError.descEmpty
        }
    }
        
        // MARK: - Enums
        enum ValidationError: Error {
            case chooseImage
            case nameEmpty
            case descEmpty
            
            var localizedDescription: String {
                switch self {
                case .chooseImage:
                    return "Please choose crowd picture."
                case .nameEmpty:
                    return "Please enter crowd name"
                case .descEmpty:
                    return "Please enter description"
                }
            }
        }
    
   
    func checkAndCreateCrowd(){
        self.vc.showProgressHUD()
        if self.vc.isImageSelected{
            self.vc.showProgressHUD()
            if let image = vc.userImageView.image {
                let ref = FirebaseAPI.StorageRefenrenceType.crowdPicture
                CommonMethods.showLog(TAG, "REF : \(ref)")
                FirebaseAPI.default.upload(name :"\(self.vc.crowdNameText.text ?? "")_\(self.vc.userModel?.id ?? "").jpg" ,image: image, reference: ref) { (error, imageURLString) in
                    if let error = error {
                        CommonMethods.showLog(self.TAG, "Error : \(error)")
                        self.vc.hideProgressHUD()
                        self.vc.showDialog(title: Constants.APP_NAME,message: error.localizedDescription)
                    } else {
                        self.vc.userModel?.imageUrl = imageURLString
                        self.updateData(imageURLString ?? "")
                    }
                }
            }
        }
        else{
            self.vc.showDialog(title: Constants.APP_NAME,message: "Please choose crowd picture.")
        }
    }
    
    func updateData(_ imageUrl:String){
        CommonMethods.showLog(TAG, "Image : \(imageUrl)")
        let crowdModel = CrowdModel()
        crowdModel.imageUrl = imageUrl
        crowdModel.userId = self.vc.userModel?.id ?? ""
        crowdModel.name = self.vc.crowdNameText.text
        crowdModel.createdAt = Date()
        crowdModel.updatedAt = Date()
        crowdModel.description = self.vc.descriptionText.text
        FirebaseAPI.default.createNewCrowd(crowdModel: crowdModel){error,model in
            self.vc.hideProgressHUD()
            if error != nil{
                if let error = error{
                    self.vc.showDialog(title : Constants.APP_NAME, message: error.localizedDescription)
                }else{
                    self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                }
            }
            else{
                NotifyData.notifyCrowdVC(crowdModel: crowdModel)
                CommonMethods.dismiss(vc: self.vc,animated: true)
                Navigations.goToCrowdDetail(navigationController: self.vc.navigationController,crowdId  :crowdModel.id ?? "")
            }
            
        }
    }
    
    func checkAndUpdateCrowd(){
        self.vc.showProgressHUD()
        if self.vc.isImageSelected{
            self.vc.showProgressHUD()
            if let image = vc.userImageView.image {
                let ref = FirebaseAPI.StorageRefenrenceType.crowdPicture
                CommonMethods.showLog(TAG, "REF : \(ref)")
                FirebaseAPI.default.upload(name :"\(self.vc.crowdNameText.text ?? "")_\(self.vc.userModel?.id ?? "").jpg" ,image: image, reference: ref) { (error, imageURLString) in
                    if let error = error {
                        CommonMethods.showLog(self.TAG, "Error : \(error)")
                        self.vc.hideProgressHUD()
                        self.vc.showDialog(title: Constants.APP_NAME,message: error.localizedDescription)
                    } else {
                        self.vc.userModel?.imageUrl = imageURLString
                        self.editData(imageURLString ?? "")
                    }
                }
            }
        }
        else{
            self.vc.showDialog(title: Constants.APP_NAME,message: "Please choose crowd picture.")
        }
    }
    
    func editData(_ imageUrl:String){
        CommonMethods.showLog(TAG, "Image : \(imageUrl)")
        if let model = vc.model {
            model.imageUrl = imageUrl
            model.userId = self.vc.userModel?.id ?? ""
            model.name = self.vc.crowdNameText.text
            model.createdAt = Date()
            model.updatedAt = Date()
            model.description = self.vc.descriptionText.text
            FirebaseAPI.default.updateCrowd(crowdModel: model){error in
                self.vc.hideProgressHUD()
                if error != nil{
                    if let error = error{
                        self.vc.showDialog(title : Constants.APP_NAME, message: error)
                    }else{
                        self.vc.showDialog(title : Constants.APP_NAME, message: Constants.COMMON_ERROR_MESSAGE)
                    }
                }
                else{
                    NotifyData.notifyCrowdVC(crowdModel: model)
                    self.vc.delegate?.onCrowdUpdation()
                    CommonMethods.dismiss(vc: self.vc,animated: true)
                }
                
            }
        }
       
    }
}
